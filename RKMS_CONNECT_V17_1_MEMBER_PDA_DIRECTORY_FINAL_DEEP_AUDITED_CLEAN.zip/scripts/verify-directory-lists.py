from pathlib import Path
import re

app=Path('app.js').read_text(encoding='utf-8')

m=re.search(r'async function publicOfficers\(\)\{(.*?)\n\}', app, re.S)
assert m, 'publicOfficers missing'
body=m.group(1)
assert 'rkms_public_active_officers' in body, 'Safe public officer directory RPC missing'
assert 'rkms_get_active_officers' in body, 'Full management officer RPC missing'

m=re.search(r'async function loadDirectoryMembers\(filters=\{\}\)\{(.*?)\n\}', app, re.S)
assert m, 'loadDirectoryMembers missing'
assert 'rkms_directory_members' in m.group(1), 'Member directory RPC missing'

# PDA officer list is scoped by view authority; actions remain separately manage-authorized.
assert 'base.filter(x=>state.role===\'super_admin\'||rkmsIsHighestAuthority()||rkmsOfficerCanAccessTarget(x))' in app, 'Officer list geographic access filter missing'
assert 'rkmsOfficerCanAccessMember' in app, 'Member sensitive-access guard missing'

# Professional member filters.
for token in ['memMandal','memWing','memPhoto','data-mandal','data-wing','data-photo']:
    assert token in app, f'Member directory filter support missing: {token}'

# Professional officer geographic filters.
for token in ['dirMandal','dirTehsil','dirBlock','dirVillage','data-mandal','data-tehsil','data-block','data-village']:
    assert token in app, f'Officer directory filter support missing: {token}'

# Delete must be detail-only; no checkbox/bulk-delete UI in directory source.
member_fn=re.search(r'async function renderAdminMemberList\(\)\{(.*?)\n\}', app, re.S).group(1)
assert 'memberDetailDelete' not in member_fn, 'Delete button leaked into member list'
assert 'type="checkbox"' not in member_fn.lower(), 'Checkbox delete leaked into member list'
assert 'bulk' not in member_fn.lower(), 'Bulk delete leaked into member list'

# Guest/member officer contact buttons are not rendered from the public card/detail.
assert 'phone&&(isMgmt?canManage:false)' in app, 'Public officer call privacy guard missing'
assert 'phone&&isMgmt?' in app, 'Officer detail contact privacy guard missing'

print('DIRECTORY V17 VERIFICATION: PASS')
print('PASS: safe public officer RPC wired for Guest/member')
print('PASS: member directory professional filters wired')
print('PASS: officer geographic filters wired')
print('PASS: officer management list remains authorization-filtered')
print('PASS: member delete is detail-only')
print('PASS: public officer phone/call is hidden for Guest/member')
