# RKMS Connect Android

This project packages the supplied RKMS Connect web app as an Android WebView app.

## Included
- New `app-website.zip` web source bundled under `app/src/main/assets/www/`
- Supabase-backed login, member/officer screens and chat
- Android notification permission/channel
- Background WorkManager checks for unread chat and officer approval-count changes
- Fixed the supplied web source's chat bridge by exposing `window.rpc` and `window.supabase`

## Build
Use Java 17 and Gradle 8.13 or Android Studio. The GitHub Actions workflow can run `assembleDebug` from this project.

## Important notification note
The included notification system works by periodically checking the logged-in account. True instant push notifications when the app is fully closed require an FCM/FCM server setup tied to the Supabase backend; no Firebase project credentials were present in the supplied ZIP, so they are not embedded here.
