# Approval Date Only

Membership Certificate date is now strictly the PDA approval date (`approved_at`).
No joining date or created date fallback is used.
If approval date is unavailable, the certificate shows a blank date placeholder.
