# Chat Final Fix

Fixed:
- Member Chat participant source now includes approved Members + active PDA Officers.
- Member+Officer duplicate is de-duplicated, preferring the Officer role.
- Chat screen loads `rkms_chat_threads` and renders Recent Chats first.
- Recent chat row opens the existing thread directly; no need to select the person again.
- New chat row opens/creates the thread through `rkms_chat_open`.
- Added DB RPC migration for combined Member/Officer chat participants.
- Existing registration/password/certificate logic is preserved.
