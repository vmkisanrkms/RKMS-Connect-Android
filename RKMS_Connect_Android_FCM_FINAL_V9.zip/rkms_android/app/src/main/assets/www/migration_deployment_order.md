# RKMS CONNECT migration deployment order

For the current Singapore project, do NOT blindly rerun every historical migration. Verify which migrations are already applied.

## Final repair migration
Apply this migration as the self-contained final chat/password-reset schema+RPC repair:

`supabase/migrations/20260821_rkms_final_chat_password_reset.sql`

It now includes the required `member_recipient_id` chat schema repair and password-reset encrypted-payload columns before the dependent RPCs. The separate `2026_08_22_chat_member_member_repair.sql` is retained as a historical/idempotent safeguard but is not required when the final migration above is applied successfully.

## Edge Functions
Deploy:
- `supabase/functions/rkms-member-auth/index.ts`
- `supabase/functions/rkms-member-password/index.ts`

The member password-reset request stores only encrypted password material and MUST NOT update Supabase Auth until PDA/Super Admin approval.

## Production gate
After deployment, perform live tests for: request -> pending -> PDA/Super Admin approval -> Auth password update -> login; member-member chat; member-officer chat; and rejection.
