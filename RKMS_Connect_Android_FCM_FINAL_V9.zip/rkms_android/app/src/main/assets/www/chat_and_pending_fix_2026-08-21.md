# RKMS CONNECT — Chat + Pending Dashboard Fix

## Fixed
1. Temporary Member Login now survives page refresh in frontend identity restoration.
2. Member Chat uses the claimed temporary member session (`rkms_current_member_id`) instead of requiring `rkms_members.auth_user_id`.
3. Member Chat can therefore load approved Member participants and authorized active Officers after temporary Member login.
4. `rkms_chat_actor_member_id()` was updated in Supabase and deployed via migration.
5. PDA Officer Dashboard now shows **Pending सदस्य Approval** from the live `rkms_pending_member_count()` RPC.
6. Complaint pending count is shown separately as **Pending शिकायत**, so it is not confused with member approvals.
7. National President Dashboard uses the same corrected member approval count.

## Live verification
- `rkms_pending_member_count()` returns count = 2.
- `rkms_members` currently has 2 PENDING members.
- `rkms_chat_actor_member_id()` now resolves through `rkms_current_member_id()` and supports temporary member sessions.
- `app.js` passes `node --check`.
