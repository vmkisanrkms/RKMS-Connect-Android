# Chat Final V3 Verification
- Recent Chats uses existing `rkms_chat_threads(p_actor_type)` and reads its `data` array.
- Existing conversation opens with `rkms_chat_messages(p_conversation_id,p_actor_type)`.
- New chat uses existing `rkms_chat_open(p_other_type,p_other_id)`.
- Sending uses existing `rkms_chat_send_message(p_conversation_id,p_actor_type,p_body)`.
- Removed invalid migration that referenced nonexistent `rkms_chat_threads` table.
- Member/PDA participant migration retained.
- No changes to Member Save, Password Forgot, Certificate, Appointment Letter.
