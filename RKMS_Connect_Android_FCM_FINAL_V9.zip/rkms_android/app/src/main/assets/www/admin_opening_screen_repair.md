The previous Admin ZIP had a corrupted app.js and could stop rendering after the opening screen.
This build was reconstructed from a syntax-valid RKMS source, then the requested Admin dashboard changes were applied.

Requested changes:
- Total members card is clickable and opens Approved member list.
- Active PDA officers card is clickable and opens active officer list.
- Digital ID removed from the Super Admin management list.
- Appointment Letter removed from the Super Admin management list.
- Existing lower management options are retained.
- Member-to-member chat migration is included.

JavaScript syntax check: PASS.
