# Membership Certificate Format Update — 2026-08-21

Only the member certificate/letter presentation was changed.

- Approved ordinary members now see `सदस्यता प्रमाण-पत्र` in the member dashboard.
- Existing officer `नियुक्ति पत्र` flow remains unchanged.
- Existing logo at the top is retained.
- Member certificate uses a light-green background.
- A grayscale black/white RKMS logo is used as a subtle background watermark.
- Text follows the supplied membership certificate wording.
- Membership number uses the member's Member ID.
- Date uses approved_at/joining_date/created_at when available.
- Print/PDF button is included.
- No other member, officer, chat, login, or password-reset logic was intentionally changed.
