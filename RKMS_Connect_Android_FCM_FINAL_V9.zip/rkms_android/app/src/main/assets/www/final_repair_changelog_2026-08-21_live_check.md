# RKMS CONNECT — 21-08-2026 Live Check Repairs

- Confirmed Singapore Super Admin record is `Harmanjeet Singh` / role `SUPER_ADMIN` / ACTIVE / Auth UID `4aa3d6b6-0022-4fe0-8ba8-baa698245d6e`.
- Confirmed `harmanjatt50@gmail.com` belongs to Auth UID `88904b0b-d123-4772-99c5-bc09c6b75607`, which is the ACTIVE DISTRICT officer/member account, not the separate Super Admin Auth account.
- Improved Officer/Super Admin login error so an active officer account is explicitly identified instead of showing only a generic error.
- Fixed final chat/password-reset migration references from nonexistent `rkms_postings` to the live table `rkms_posts`.
- The migration must be applied to Singapore before the new chat/password-reset RPC definitions are considered live.
