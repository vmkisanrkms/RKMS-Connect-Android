CHAT LIVE ROOT CAUSE AND FIX — 22-08-2026

Root cause found from the live Supabase function:
rkms_chat_people(text,text,integer) returns an envelope:
{ success: true, data: [...] }

The frontend was treating the entire RPC result as an array:
Array.isArray(data) -> false
therefore it rendered "कोई approved member/PDA अधिकारी उपलब्ध नहीं है।"

Fix:
- Frontend now calls the actual 3-argument RPC contract.
- Frontend reads payload.data.
- Supabase rkms_chat_people was updated live to return the approved member/officer list.
- Ordinary members cannot see National President in the chat participant list.
- PDA officers can see approved members and active officers.
- Password Forgot was not changed.
