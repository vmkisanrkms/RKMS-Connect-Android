# Member → PDA Officer Certificate Switch

Final role behavior:
- Approved ordinary Member: `सदस्यता प्रमाण-पत्र` is shown.
- PDA Officer: membership certificate is hidden/rejected and `नियुक्ति पत्र` is shown.
- If a Member is promoted to PDA Officer, the next refreshed dashboard uses the officer state and shows the appointment letter instead of the membership certificate.
- Direct navigation to the membership-certificate route while officer status is active redirects to the appointment letter.
- Existing appointment-letter design/content remains unchanged.
