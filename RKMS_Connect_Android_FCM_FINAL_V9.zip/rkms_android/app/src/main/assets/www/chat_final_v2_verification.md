# Chat Final V2

Verified/changed:
- One coherent Recent Chats UI.
- Recent chat tap opens existing thread directly.
- New Chat supports approved Members and active PDA Officers.
- New Chat uses the existing `rkms_chat_open(p_other_type,p_other_id)` contract.
- Conversation renderer is present; no undefined `renderChatThread`.
- Message send uses `rkms_chat_send_message`.
- Back returns to Recent Chats.
- Added authorized thread-message RPC.
- Member Save, Password Forgot, Certificate/Appointment logic not intentionally changed.
