# RKMS CONNECT — Member Password Forgot Final Flow (21-08-2026)

## Final flow
1. Member Login → Forget Password.
2. Form: Mobile + DOB + Registered Email + New Password + Confirm Password.
3. Only one button is shown: `Password Reset Request Send`.
4. On send, a PENDING reset request is created and the requested Auth password is prepared immediately; the Member Login endpoint blocks login while the request is PENDING.
5. The button immediately changes to `Request Pending`.
6. Reopening Forgot Password while the request is PENDING shows `Request Already Pending` and does not create a duplicate request.
7. PDA officer approves the request.
8. After approval, the member can immediately log in with the new password. A successful login marks that approved reset request `USED`.
9. If the member forgets the approved-but-not-yet-used password before login, Forgot Password is allowed again. The old APPROVED reset is superseded and a new PENDING request is created.
10. No plaintext password is stored in the reset-request table.

## Chat final flow
- Member Chat lists all other approved members and all active PDA officers.
- If the same person is both an approved member and an active PDA officer, only one row is shown, preferring the officer row so the correct officer conversation opens.
- Officer Chat continues to list authorized approved members.
