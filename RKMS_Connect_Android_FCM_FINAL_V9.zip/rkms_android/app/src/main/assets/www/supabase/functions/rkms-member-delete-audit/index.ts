import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const url=Deno.env.get("SUPABASE_URL")!;
const service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const anon=Deno.env.get("SUPABASE_ANON_KEY")||service;
const admin=createClient(url,service);
const H={"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const out=(x:unknown,s=200)=>new Response(JSON.stringify(x),{status:s,headers:H});
const norm=(v:any)=>String(v??"").trim().toUpperCase();

Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:H});
 if(req.method!=="POST")return out({success:false,message:"POST required"},405);
 try{
  const auth=req.headers.get("authorization")||"";
  if(!auth.startsWith("Bearer "))return out({success:false,message:"Login जरूरी है।"},401);
  const jwt=auth.slice(7);
  const {data:u,error:ue}=await admin.auth.getUser(jwt);
  if(ue||!u?.user)return out({success:false,message:"Login session invalid है।"},401);
  const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});

  let superAdmin=false;try{superAdmin=!!(await userClient.rpc("rkms_is_super_admin")).data}catch{}
  let officer:any=null;
  if(!superAdmin){try{const r=await userClient.rpc("rkms_get_current_officer_profile");officer=r.data?.officer||r.data?.result?.officer||r.data||null}catch{}}
  const authority=superAdmin?"SUPER_ADMIN":norm(officer?.authority_level||officer?.level);
  if(!["SUPER_ADMIN","NATIONAL","STATE","MANDAL","DISTRICT"].includes(authority))
    return out({success:false,message:"Delete Audit देखने का अधिकार नहीं है।"},403);

  const limit=Math.min(Math.max(Number((await req.json().catch(()=>({})))?.limit||100),1),200);
  let q=admin.from("rkms_member_delete_audit").select("*").order("deleted_at",{ascending:false}).limit(limit);
  if(!superAdmin && authority!=="NATIONAL"){
    if(authority==="STATE" && officer?.state) q=q.eq("deleter_state",officer.state);
    if(authority==="MANDAL" && officer?.mandal) q=q.eq("deleter_mandal",officer.mandal);
    if(authority==="DISTRICT" && officer?.district) q=q.eq("deleter_district",officer.district);
  }
  const {data:rows,error}=await q;
  if(error)throw error;
  return out({success:true,rows:rows||[]});
 }catch(e){return out({success:false,message:e instanceof Error?e.message:"Audit server error"},500)}
});
