import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const url=Deno.env.get("SUPABASE_URL")!;
const key=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin=createClient(url,key);
const H={"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const out=(x:unknown,s=200)=>new Response(JSON.stringify(x),{status:s,headers:H});
const mobile=(v:string)=>String(v||"").replace(/\D/g,"").slice(-10);
const emailOk=(v:string)=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||""));
const synthetic=(id:string)=>`member-${id}@rkms.internal.invalid`;
const mimeAllowed=(v:string)=>["image/jpeg","image/png","image/webp"].includes(v);
async function enc(v:string){
 const d=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(key));
 const k=await crypto.subtle.importKey("raw",d,{name:"AES-GCM"},false,["encrypt"]);
 const iv=crypto.getRandomValues(new Uint8Array(12));
 const c=await crypto.subtle.encrypt({name:"AES-GCM",iv},k,new TextEncoder().encode(v));
 const b64=(x:Uint8Array)=>btoa(String.fromCharCode(...x));
 return {ciphertext:b64(new Uint8Array(c)),iv:b64(iv)};
}
function bytesFromBase64(v:string){
 const clean=String(v||"").replace(/^data:[^;]+;base64,/i,"");
 const bin=atob(clean);const out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out;
}
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:H});
 if(req.method!=="POST")return out({success:false,message:"POST required"},405);
 try{
  const b=await req.json(); const action=String(b.action||"").toLowerCase();
  if(action==="create_registration_password"){
   const mob=mobile(b.mobile),dob=String(b.dob||"").trim(),pass=String(b.password||"");
   if(mob.length!==10||!dob||pass.length<8)return out({success:false,message:"सही Mobile, DOB और कम से कम 8 अक्षर का Password जरूरी है।"},400);
   const {data:m,error}=await admin.from("rkms_members").select("id,member_id,mobile,email,status,auth_user_id,date_of_birth").eq("mobile",mob).eq("date_of_birth",dob).maybeSingle();
   if(error)throw error;if(!m)return out({success:false,message:"Mobile और DOB से सदस्य नहीं मिला।"},404);
   if(m.auth_user_id)return out({success:false,message:"इस सदस्य का Password पहले से बना हुआ है।"},409);
   const em=String(m.email||"").trim().toLowerCase(),loginEmail=em||synthetic(m.id);
   const {data:u,error:ce}=await admin.auth.admin.createUser({email:loginEmail,password:pass,email_confirm:true,user_metadata:{rkms_member_id:m.id,login_type:"member_mobile_or_email"}});
   if(ce)return out({success:false,message:ce.message},400);
   const {error:ue}=await admin.from("rkms_members").update({auth_user_id:u.user.id,email_verified:!!em,updated_at:new Date().toISOString()}).eq("id",m.id);
   if(ue){await admin.auth.admin.deleteUser(u.user.id);throw ue;}
   return out({success:true,message:"Password सफलतापूर्वक बन गया। Approval के बाद Login करें।"});
  }
  if(action==="login"){
   const ident=String(b.identifier||"").trim(),pass=String(b.password||"");if(!ident||!pass)return out({success:false,message:"Mobile/Email और Password दोनों भरें।"},400);
   let m:any=null;
   if(ident.includes("@")){const {data,error}=await admin.from("rkms_members").select("id,member_id,name,email,status,auth_user_id").ilike("email",ident.toLowerCase()).maybeSingle();if(error)throw error;m=data;}
   else{const mob=mobile(ident);const {data,error}=await admin.from("rkms_members").select("id,member_id,name,email,status,auth_user_id").eq("mobile",mob).maybeSingle();if(error)throw error;m=data;}
   if(!m)return out({success:false,message:"Mobile/Email मान्य नहीं है।"},401);
   if(String(m.status||"").toUpperCase()!=="APPROVED")return out({success:false,message:"आपका सदस्यता आवेदन अभी APPROVED नहीं हुआ है। Approval के बाद ही Login होगा।"},403);
   if(!m.auth_user_id)return out({success:false,message:"पहले Registration में Password बनाएं।"},400);
   const {data:pendingReset,error:pre}=await admin.from("rkms_member_password_reset_requests").select("id").eq("member_id",m.id).eq("status","PENDING").limit(1).maybeSingle();
   if(pre)throw pre;
   if(pendingReset?.id)return out({success:false,message:"Password Reset Request अभी PDA Approval में Pending है। Approval के बाद नए Password से Login करें।"},403);
   const {data:u,error:ue}=await admin.auth.admin.getUserById(m.auth_user_id);if(ue)throw ue;
   const e=u.user.email||m.email;if(!e)return out({success:false,message:"Login account की पहचान उपलब्ध नहीं है।"},400);
   const {data:s,error:se}=await admin.auth.signInWithPassword({email:e,password:pass});if(se)return out({success:false,message:"Mobile/Email या Password गलत है।"},401);
   await admin.from("rkms_member_password_reset_requests")
     .update({status:"USED",updated_at:new Date().toISOString()})
     .eq("member_id",m.id).eq("status","APPROVED");
   return out({success:true,session:s.session,member:{id:m.id,member_id:m.member_id,name:m.name,status:m.status}});
  }
  if(action==="password_reset_status"){
   const mob=mobile(b.mobile),dob=String(b.dob||"").trim(),email=String(b.email||"").trim().toLowerCase();
   if(mob.length!==10||!dob||!emailOk(email))return out({success:false,message:"Mobile, DOB और Registered Email सही भरें।"},400);
   const {data:m,error:me}=await admin.from("rkms_members").select("id,status").eq("mobile",mob).eq("date_of_birth",dob).ilike("email",email).maybeSingle();
   if(me)throw me;
   if(!m)return out({success:true,status:"NONE",message:"इस पहचान के लिए कोई Password Reset Request नहीं मिली।"});
   const {data:r,error:re}=await admin.from("rkms_member_password_reset_requests").select("id,status,created_at").eq("member_id",m.id).in("status",["PENDING","APPROVED"]).order("created_at",{ascending:false}).limit(1).maybeSingle();
   if(re)throw re;
   return out({success:true,status:String(r?.status||"NONE").toUpperCase(),request_id:r?.id||null,created_at:r?.created_at||null});
  }
  if(action==="request_password_reset"){
   const mob=mobile(b.mobile),dob=String(b.dob||"").trim(),email=String(b.email||"").trim().toLowerCase(),pass=String(b.password||"");
   if(mob.length!==10||!dob||!emailOk(email)||pass.length<8)return out({success:false,message:"Mobile, DOB, Registered Email और कम से कम 8 अक्षर का नया Password जरूरी है।"},400);
   const {data:m,error:me}=await admin.from("rkms_members").select("id,status,auth_user_id,email").eq("mobile",mob).eq("date_of_birth",dob).ilike("email",email).maybeSingle();
   if(me)throw me;
   if(!m)return out({success:false,message:"Mobile, DOB और Registered Email का Approved member record से मिलान नहीं हुआ।"},404);
   if(String(m.status||"").toUpperCase()!=="APPROVED")return out({success:false,message:"Member अभी APPROVED नहीं है। Approval के बाद ही Password Reset कर सकते हैं।"},403);
   if(!m.auth_user_id)return out({success:false,message:"Member का Login account उपलब्ध नहीं है। पहले Registration में Password बनाएं।"},400);
   const {data:pending,error:pe}=await admin.from("rkms_member_password_reset_requests").select("id").eq("member_id",m.id).eq("status","PENDING").order("created_at",{ascending:false}).limit(1).maybeSingle();
   if(pe)throw pe;
   if(pending?.id)return out({success:true,status:"PENDING",request_id:pending.id,message:"Password Reset Request पहले से Pending है। PDA Approval की प्रतीक्षा करें।"});
   // If an older approved reset was never used and the member forgot that password again,
   // invalidate that approval and start a fresh reset cycle.
   await admin.from("rkms_member_password_reset_requests")
     .update({status:"USED",updated_at:new Date().toISOString(),reason:"Superseded by a new password reset request"})
     .eq("member_id",m.id).eq("status","APPROVED");
   const crypt=await enc(pass);
   // Store only encrypted password material; Auth password is changed ONLY after PDA/Super Admin approval.
   const {data:req,error:re}=await admin.from("rkms_member_password_reset_requests").insert({
     member_id:m.id,mobile:mob,date_of_birth:dob,email,requested_by_auth_user_id:null,status:"PENDING",
     new_password_ciphertext:crypt.ciphertext,new_password_iv:crypt.iv
   }).select("id").single();
   if(re)throw re;
   return out({success:true,status:"PENDING",request_id:req.id,message:"Password Reset Request PDA अधिकारी के पास भेज दी गई है। Approval के बाद नए Password से Login करें।"});
  }
  // The old two-step complete_password_reset action was intentionally removed.
  // Password is prepared when the single reset request is sent; login remains
  // blocked until PDA approval.
  if(action==="upload_pending_member_photo"){
   const memberId=String(b.member_id||""),contentType=String(b.content_type||""),filename=String(b.filename||"photo");
   if(!memberId||!mimeAllowed(contentType))return out({success:false,message:"Photo type मान्य नहीं है।"},400);
   const bytes=bytesFromBase64(String(b.base64||""));if(!bytes.length||bytes.length>5*1024*1024)return out({success:false,message:"Photo 5 MB से छोटी होनी चाहिए।"},400);
   const {data:m,error:me}=await admin.from("rkms_members").select("id,status").eq("id",memberId).maybeSingle();if(me)throw me;if(!m)return out({success:false,message:"Member record नहीं मिला।"},404);
   const ext=contentType.split("/")[1]||"bin",safe=filename.replace(/[^a-zA-Z0-9_-]/g,"-").slice(0,60)||"photo";
   const path=`member-photos/${memberId}-${Date.now()}-${safe}.${ext}`;
   const {error:ue}=await admin.storage.from("rkms-media").upload(path,bytes,{contentType,upsert:false});if(ue)throw ue;
   const url=`${url}/storage/v1/object/public/rkms-media/${path}`;
   const {error:db}=await admin.from("rkms_members").update({photo_url:url,updated_at:new Date().toISOString()}).eq("id",memberId);if(db)throw db;
   return out({success:true,url});
  }
  return out({success:false,message:"Invalid action."},400);
 }catch(e){return out({success:false,message:e instanceof Error?e.message:"Server error"},500)}
});
