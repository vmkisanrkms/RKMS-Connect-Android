-- RKMS final backend changes
-- HISTORICAL migration retained for database history. Current RKMS CONNECT login no longer uses Aadhaar or OTP; current registration creates Password directly.
ALTER TABLE public.rkms_members
  ADD COLUMN IF NOT EXISTS aadhaar_last6_hash text;

ALTER TABLE public.rkms_member_applications
  ADD COLUMN IF NOT EXISTS aadhaar_last6_hash text;
