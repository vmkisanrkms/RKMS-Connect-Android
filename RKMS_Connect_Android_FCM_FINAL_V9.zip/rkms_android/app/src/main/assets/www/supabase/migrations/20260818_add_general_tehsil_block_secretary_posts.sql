-- RKMS Connect: restore general (non-wing) secretary posts.
INSERT INTO public.rkms_posts (post_name, description, level, is_it_cell)
VALUES
  ('तहसील सचिव', 'सामान्य तहसील स्तर का सचिव', 'TEHSIL', false),
  ('ब्लॉक सचिव', 'सामान्य ब्लॉक स्तर का सचिव', 'BLOCK', false)
ON CONFLICT (post_name) DO UPDATE
SET description = EXCLUDED.description,
    level = EXCLUDED.level,
    is_it_cell = EXCLUDED.is_it_cell;
