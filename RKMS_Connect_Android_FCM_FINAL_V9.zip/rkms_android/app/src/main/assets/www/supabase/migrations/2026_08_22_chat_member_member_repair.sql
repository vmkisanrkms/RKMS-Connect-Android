-- RKMS Chat repair: support member-to-member conversations and remove
-- the missing-column runtime error used by message authorization.
alter table public.rkms_chat_conversations
  add column if not exists member_recipient_id uuid references public.rkms_members(id) on delete cascade;
alter table public.rkms_chat_conversations alter column officer_id drop not null;
create unique index if not exists rkms_chat_conversations_member_pair_uq
  on public.rkms_chat_conversations (least(member_id, member_recipient_id), greatest(member_id, member_recipient_id))
  where member_recipient_id is not null;
create index if not exists rkms_chat_conversations_member_recipient_idx
  on public.rkms_chat_conversations(member_recipient_id)
  where member_recipient_id is not null;

-- The four chat RPCs are also replaced in the live Supabase migration by the
-- repair deployment so both participants can read/send member-to-member chats.
