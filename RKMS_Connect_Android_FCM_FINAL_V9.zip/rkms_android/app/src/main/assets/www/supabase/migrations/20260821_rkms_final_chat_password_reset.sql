-- RKMS CONNECT FINAL REPAIR 2026-08-21
-- Member password reset with PDA approval + chat attachments/participant fixes.

create table if not exists public.rkms_member_password_reset_requests (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.rkms_members(id) on delete cascade,
  mobile text not null,
  date_of_birth date not null,
  email text not null,
  status text not null default 'PENDING' check (status in ('PENDING','APPROVED','REJECTED','USED')),
  requested_by_auth_user_id uuid,
  reviewed_by_officer_id uuid,
  reviewed_at timestamptz,
  reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  new_password_ciphertext text,
  new_password_iv text
);
alter table public.rkms_member_password_reset_requests add column if not exists requested_by_auth_user_id uuid;
alter table public.rkms_member_password_reset_requests add column if not exists reviewed_by_officer_id uuid;
alter table public.rkms_member_password_reset_requests add column if not exists reason text;
alter table public.rkms_member_password_reset_requests add column if not exists created_at timestamptz;
alter table public.rkms_member_password_reset_requests add column if not exists updated_at timestamptz;
alter table public.rkms_member_password_reset_requests add column if not exists new_password_ciphertext text;
alter table public.rkms_member_password_reset_requests add column if not exists new_password_iv text;
update public.rkms_member_password_reset_requests set created_at=coalesce(created_at,requested_at,now()), updated_at=coalesce(updated_at,reviewed_at,requested_at,now()) where created_at is null or updated_at is null;
alter table public.rkms_member_password_reset_requests alter column created_at set default now();
alter table public.rkms_member_password_reset_requests alter column updated_at set default now();

create index if not exists rkms_member_password_reset_requests_status_idx
  on public.rkms_member_password_reset_requests(status,created_at desc);
create index if not exists rkms_member_password_reset_requests_member_idx
  on public.rkms_member_password_reset_requests(member_id,status,created_at desc);
alter table public.rkms_member_password_reset_requests enable row level security;

create or replace function public.rkms_request_member_password_reset(
  p_mobile text,p_date_of_birth date,p_email text
) returns jsonb language plpgsql security definer set search_path=public as $$
declare m public.rkms_members%rowtype; existing uuid;
begin
  select * into m from public.rkms_members
   where status='APPROVED'
     and mobile=regexp_replace(coalesce(p_mobile,''),'[^0-9]','','g')
     and date_of_birth=p_date_of_birth
     and lower(coalesce(email,''))=lower(trim(coalesce(p_email,'')))
   limit 1;
  if m.id is null then return jsonb_build_object('success',false,'message','Mobile, DOB और Registered Email का Approved member record से मिलान नहीं हुआ।'); end if;
  select id into existing from public.rkms_member_password_reset_requests
   where member_id=m.id and status='PENDING' order by created_at desc limit 1;
  if existing is not null then return jsonb_build_object('success',true,'request_id',existing,'message','Password Reset Request पहले से Pending है।'); end if;
  insert into public.rkms_member_password_reset_requests(member_id,mobile,date_of_birth,email,requested_by_auth_user_id)
  values(m.id,regexp_replace(p_mobile,'[^0-9]','','g'),p_date_of_birth,lower(trim(p_email)),auth.uid())
  returning id into existing;
  return jsonb_build_object('success',true,'request_id',existing,'message','Password Reset Request भेज दी गई है।');
end; $$;
grant execute on function public.rkms_request_member_password_reset(text,date,text) to anon,authenticated;
-- Legacy direct request RPC is no longer exposed; the Edge Function is the only password-reset entry point.
revoke execute on function public.rkms_request_member_password_reset(text,date,text) from anon,authenticated;

create or replace function public.rkms_list_member_password_reset_requests(
  p_status text default 'PENDING',p_limit int default 100
) returns jsonb language plpgsql security definer set search_path=public as $$
declare oid uuid; is_sa boolean:=false; v jsonb;
begin
  begin is_sa:=coalesce(public.rkms_is_super_admin(),false); exception when others then is_sa:=false; end;
  oid:=public.rkms_current_officer_id();
  if not is_sa and oid is null then return jsonb_build_object('success',false,'message','Authorized officer login जरूरी है।','data','[]'::jsonb); end if;
  select coalesce(jsonb_agg(to_jsonb(x) order by x.created_at desc),'[]'::jsonb) into v
  from (
    select r.id,r.status,r.mobile,r.date_of_birth,r.email,r.created_at,r.reviewed_at,r.reason,
           m.member_id,m.name member_name,m.state,m.mandal,m.district,m.tehsil,m.block,m.village,m.gram_panchayat
    from public.rkms_member_password_reset_requests r
    join public.rkms_members m on m.id=r.member_id
    where upper(r.status)=upper(coalesce(p_status,'PENDING'))
      and (is_sa or public.rkms_chat_officer_can_access_member(oid,m.id))
    order by r.created_at desc limit greatest(1,least(coalesce(p_limit,100),200))
  ) x;
  return jsonb_build_object('success',true,'data',v);
end; $$;
grant execute on function public.rkms_list_member_password_reset_requests(text,int) to authenticated;

create or replace function public.rkms_review_member_password_reset(
  p_request_id uuid,p_action text,p_reason text default ''
) returns jsonb language plpgsql security definer set search_path=public as $$
declare r public.rkms_member_password_reset_requests%rowtype; m public.rkms_members%rowtype; o public.rkms_officers%rowtype; oid uuid; sa boolean:=false; lvl text;
begin
  oid:=public.rkms_current_officer_id();
  begin sa:=coalesce(public.rkms_is_super_admin(),false); exception when others then sa:=false; end;
  if not sa and oid is null then return jsonb_build_object('success',false,'message','Authorized officer login जरूरी है।'); end if;
  select * into r from public.rkms_member_password_reset_requests where id=p_request_id for update;
  if r.id is null then return jsonb_build_object('success',false,'message','Reset request नहीं मिली।'); end if;
  if upper(r.status)<>'PENDING' then return jsonb_build_object('success',false,'message','यह request पहले ही process हो चुकी है।'); end if;
  select * into m from public.rkms_members where id=r.member_id;
  if m.id is null or upper(coalesce(m.status,''))<>'APPROVED' then return jsonb_build_object('success',false,'message','Member अब APPROVED नहीं है।'); end if;
  if not sa then
    select * into o from public.rkms_officers where id=oid and upper(coalesce(status,''))='ACTIVE';
    if o.id is null then return jsonb_build_object('success',false,'message','Active officer verification असफल है।'); end if;
    lvl:=upper(coalesce(o.authority_level,''));
    if lvl not in ('NATIONAL','STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then return jsonb_build_object('success',false,'message','इस पद को Password Reset approve करने का अधिकार नहीं है।'); end if;
    if lvl='STATE' and coalesce(o.state,'')<>coalesce(m.state,'') then return jsonb_build_object('success',false,'message','Member आपके State jurisdiction में नहीं है।'); end if;
    if lvl='MANDAL' and (coalesce(o.state,'')<>coalesce(m.state,'') or coalesce(o.mandal,'')<>coalesce(m.mandal,'')) then return jsonb_build_object('success',false,'message','Member आपके Mandal jurisdiction में नहीं है।'); end if;
    if lvl='DISTRICT' and (coalesce(o.state,'')<>coalesce(m.state,'') or coalesce(o.mandal,'')<>coalesce(m.mandal,'') or coalesce(o.district,'')<>coalesce(m.district,'')) then return jsonb_build_object('success',false,'message','Member आपके District jurisdiction में नहीं है।'); end if;
    if lvl='TEHSIL' and (coalesce(o.state,'')<>coalesce(m.state,'') or coalesce(o.mandal,'')<>coalesce(m.mandal,'') or coalesce(o.district,'')<>coalesce(m.district,'') or coalesce(o.tehsil,'')<>coalesce(m.tehsil,'')) then return jsonb_build_object('success',false,'message','Member आपके Tehsil jurisdiction में नहीं है।'); end if;
    if lvl='BLOCK' and (coalesce(o.state,'')<>coalesce(m.state,'') or coalesce(o.mandal,'')<>coalesce(m.mandal,'') or coalesce(o.district,'')<>coalesce(m.district,'') or coalesce(o.tehsil,'')<>coalesce(m.tehsil,'') or coalesce(o.block,'')<>coalesce(m.block,'')) then return jsonb_build_object('success',false,'message','Member आपके Block jurisdiction में नहीं है।'); end if;
    if lvl='VILLAGE' and (coalesce(o.state,'')<>coalesce(m.state,'') or coalesce(o.mandal,'')<>coalesce(m.mandal,'') or coalesce(o.district,'')<>coalesce(m.district,'') or coalesce(o.tehsil,'')<>coalesce(m.tehsil,'') or coalesce(o.block,'')<>coalesce(m.block,'') or coalesce(o.village,'')<>coalesce(m.village,'')) then return jsonb_build_object('success',false,'message','Member आपके Village jurisdiction में नहीं है।'); end if;
  end if;
  if upper(coalesce(p_action,''))='APPROVED' then
    update public.rkms_member_password_reset_requests set status='APPROVED',reviewed_by_officer_id=oid,reviewed_at=now(),reason=coalesce(p_reason,''),updated_at=now() where id=r.id;
    return jsonb_build_object('success',true,'status','APPROVED');
  elsif upper(coalesce(p_action,''))='REJECTED' then
    update public.rkms_member_password_reset_requests set status='REJECTED',reviewed_by_officer_id=oid,reviewed_at=now(),reason=coalesce(p_reason,'Rejected'),updated_at=now() where id=r.id;
    return jsonb_build_object('success',true,'status','REJECTED');
  end if;
  return jsonb_build_object('success',false,'message','Invalid action.');
end; $$;
grant execute on function public.rkms_review_member_password_reset(uuid,text,text) to authenticated;

-- Chat attachment columns. Keep the existing conversation/message model intact.
alter table public.rkms_chat_messages add column if not exists attachment_url text;
alter table public.rkms_chat_messages add column if not exists attachment_name text;
alter table public.rkms_chat_messages add column if not exists attachment_type text;

-- Replace participant discovery so members can see approved members + authorized active officers,
-- while officers can see all approved members allowed by their jurisdiction.
alter table public.rkms_chat_conversations add column if not exists member_recipient_id uuid references public.rkms_members(id) on delete cascade;
alter table public.rkms_chat_conversations alter column officer_id drop not null;
create index if not exists rkms_chat_conversations_member_recipient_idx on public.rkms_chat_conversations(member_recipient_id,updated_at desc);

create or replace function public.rkms_chat_people(p_actor_type text,p_search text default null,p_limit int default 100)
returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; q text:=nullif(trim(coalesce(p_search,'')),''), lim int:=greatest(1,least(coalesce(p_limit,100),100)); v jsonb;
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;

 if upper(p_actor_type)='MEMBER' then
   me_member:=public.rkms_chat_actor_member_id();
   if me_member is null then return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb); end if;

   -- Member Chat: every other approved member + every active PDA officer.
   -- If one person is both an approved member and an active officer, show one
   -- row only and keep the OFFICER row so the correct officer chat opens.
   select coalesce(jsonb_agg(x order by x.name),'[]'::jsonb) into v
   from (
     select * from (
       select distinct on (o.id)
         o.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,
         'OFFICER'::text chat_type,coalesce(p.post_name,'पदाधिकारी')::text post_name
       from public.rkms_officers o
       join public.rkms_members m on m.id=o.member_id
       left join public.rkms_posts p on p.officer_id=o.id and upper(coalesce(p.status,''))='ACTIVE'
       where upper(coalesce(o.status,''))='ACTIVE'
         and upper(coalesce(m.status,''))='APPROVED'
         and m.id<>me_member
         and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
       order by o.id, p.post_name nulls last
     ) officers

     union all

     select m.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,
            'MEMBER'::text chat_type,''::text post_name
     from public.rkms_members m
     where m.id<>me_member
       and upper(coalesce(m.status,''))='APPROVED'
       and not exists(
         select 1 from public.rkms_officers o
         where o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE'
       )
       and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
   ) x
   limit lim;

   return jsonb_build_object('success',true,'data',v);

 elsif upper(p_actor_type)='OFFICER' then
   me_officer:=public.rkms_chat_actor_officer_id();
   if me_officer is null then return jsonb_build_object('success',false,'message','Active PDA officer login जरूरी है।','data','[]'::jsonb); end if;
   select coalesce(jsonb_agg(x order by x.name),'[]'::jsonb) into v from (
     select m.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,'MEMBER'::text chat_type,''::text post_name
     from public.rkms_members m
     where upper(coalesce(m.status,''))='APPROVED'
       and public.rkms_chat_officer_can_access_member(me_officer,m.id)
       and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
   ) x limit lim;
   return jsonb_build_object('success',true,'data',v);
 end if;

 return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end; $$;
grant execute on function public.rkms_chat_people(text,text,int) to authenticated;

PPROVED'
       and public.rkms_chat_officer_can_access_member(me_officer,m.id)
       and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
   ) x limit lim;
   return jsonb_build_object('success',true,'data',v);
 end if;
 return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end; $$;
grant execute on function public.rkms_chat_people(text,text,int) to authenticated;

-- Attachment-aware send function. The old 3-argument version is removed from the public RPC surface.
drop function if exists public.rkms_chat_send_message(uuid,text,text);
create or replace function public.rkms_chat_send_message(
 p_conversation_id uuid,p_actor_type text,p_body text,
 p_attachment_url text default null,p_attachment_name text default null,p_attachment_type text default null
) returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; ok boolean:=false; clean text:=trim(coalesce(p_body,''));
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
 if length(clean)>4000 then return jsonb_build_object('success',false,'message','Message 4000 अक्षर से अधिक नहीं होना चाहिए।'); end if;
 if nullif(trim(coalesce(p_attachment_url,'')),'') is not null and length(coalesce(p_attachment_url,''))>1200 then return jsonb_build_object('success',false,'message','Attachment URL बहुत लंबा है।'); end if;
 if upper(p_actor_type)='MEMBER' then
   me_member:=public.rkms_chat_actor_member_id();
   ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
 elsif upper(p_actor_type)='OFFICER' then
   me_officer:=public.rkms_chat_actor_officer_id();
   ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer);
 end if;
 if not ok then return jsonb_build_object('success',false,'message','इस chat में message भेजने की अनुमति नहीं है।'); end if;
 if length(clean)<1 and nullif(trim(coalesce(p_attachment_url,'')),'') is null then return jsonb_build_object('success',false,'message','Message या attachment जरूरी है।'); end if;
 insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body,attachment_url,attachment_name,attachment_type)
 values(p_conversation_id,auth.uid(),upper(p_actor_type),clean,nullif(trim(p_attachment_url),''),nullif(trim(p_attachment_name),''),nullif(trim(p_attachment_type),''));
 update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
 return jsonb_build_object('success',true);
end; $$;
grant execute on function public.rkms_chat_send_message(uuid,text,text,text,text,text) to authenticated;

-- Return attachment fields in message history.
create or replace function public.rkms_chat_messages(p_conversation_id uuid,p_actor_type text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; ok boolean:=false; v jsonb;
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;
 if upper(p_actor_type)='MEMBER' then me_member:=public.rkms_chat_actor_member_id(); ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
 elsif upper(p_actor_type)='OFFICER' then me_officer:=public.rkms_chat_actor_officer_id(); ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer); end if;
 if not ok then return jsonb_build_object('success',false,'message','इस chat की अनुमति नहीं है।','data','[]'::jsonb); end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',m.id,'body',m.body,'sender_type',m.sender_type,'sender_auth_user_id',m.sender_auth_user_id,'sent_at',m.sent_at,'read_at',m.read_at,'attachment_url',m.attachment_url,'attachment_name',m.attachment_name,'attachment_type',m.attachment_type) order by m.sent_at),'[]'::jsonb') into v from public.rkms_chat_messages m where m.conversation_id=p_conversation_id;
 return jsonb_build_object('success',true,'data',v);
end; $$;
grant execute on function public.rkms_chat_messages(uuid,text) to authenticated;

create unique index if not exists rkms_member_password_reset_requests_pending_uq on public.rkms_member_password_reset_requests(member_id) where status='PENDING';
