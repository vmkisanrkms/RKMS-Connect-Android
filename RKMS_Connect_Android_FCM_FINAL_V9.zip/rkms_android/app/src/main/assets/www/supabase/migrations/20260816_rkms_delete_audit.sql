create table if not exists public.rkms_member_delete_audit (
 id uuid primary key default gen_random_uuid(),
 deleted_member_id text,
 deleted_member_name text,
 deleted_member_snapshot jsonb,
 deleter_user_id uuid,
 deleter_name text,
 deleter_authority_level text,
 deleter_state text,
 deleter_mandal text,
 deleter_district text,
 deleted_at timestamptz not null default now()
);
create index if not exists idx_rkms_member_delete_audit_deleted_at
  on public.rkms_member_delete_audit(deleted_at desc);
alter table public.rkms_member_delete_audit enable row level security;
revoke all on public.rkms_member_delete_audit from anon, authenticated;
