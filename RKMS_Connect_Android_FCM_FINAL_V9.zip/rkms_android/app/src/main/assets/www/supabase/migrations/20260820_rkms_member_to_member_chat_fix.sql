-- RKMS CONNECT: enable approved member <-> approved member chat.
-- Existing member <-> officer chat remains supported.

alter table public.rkms_chat_conversations
  add column if not exists member_recipient_id uuid references public.rkms_members(id) on delete cascade;

alter table public.rkms_chat_conversations
  alter column officer_id drop not null;

create index if not exists rkms_chat_conversations_member_recipient_idx
  on public.rkms_chat_conversations(member_recipient_id, updated_at desc);

create or replace function public.rkms_chat_open(p_other_type text,p_other_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  v_member uuid;
  v_officer uuid;
  v_recipient uuid;
  v_id uuid;
  typ text:=upper(coalesce(p_other_type,''));
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  me_member:=public.rkms_chat_actor_member_id();
  me_officer:=public.rkms_chat_actor_officer_id();

  if typ='MEMBER' then
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।');
    end if;

    select m.id into v_recipient
    from public.rkms_members m
    where m.id=p_other_id
      and upper(coalesce(m.status,''))='APPROVED'
    limit 1;

    if v_recipient is null then
      return jsonb_build_object('success',false,'message','Approved सदस्य उपलब्ध नहीं है।');
    end if;

    if v_recipient=me_member then
      return jsonb_build_object('success',false,'message','अपने ही account से Chat शुरू नहीं की जा सकती।');
    end if;

    -- Reuse an existing two-member conversation in either direction.
    select c.id into v_id
    from public.rkms_chat_conversations c
    where c.officer_id is null
      and ((c.member_id=me_member and c.member_recipient_id=v_recipient)
        or (c.member_id=v_recipient and c.member_recipient_id=me_member))
    order by c.updated_at desc
    limit 1;

    if v_id is null then
      insert into public.rkms_chat_conversations(member_id,member_recipient_id,officer_id)
      values(me_member,v_recipient,null)
      returning id into v_id;
    end if;

    return jsonb_build_object('success',true,'conversation_id',v_id);
  elsif typ='OFFICER' then
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।');
    end if;

    select o.id into v_officer
    from public.rkms_officers o
    where o.id=p_other_id
      and upper(coalesce(o.status,''))='ACTIVE'
    limit 1;

    if v_officer is null then
      return jsonb_build_object('success',false,'message','सक्रिय पदाधिकारी उपलब्ध नहीं है।');
    end if;

    if not public.rkms_chat_same_jurisdiction(me_member,v_officer) then
      return jsonb_build_object('success',false,'message','यह पदाधिकारी आपके अधिकार क्षेत्र में नहीं है।');
    end if;

    select c.id into v_id
    from public.rkms_chat_conversations c
    where c.member_id=me_member and c.officer_id=v_officer
    order by c.updated_at desc
    limit 1;

    if v_id is null then
      insert into public.rkms_chat_conversations(member_id,officer_id,member_recipient_id)
      values(me_member,v_officer,null)
      returning id into v_id;
    end if;

    return jsonb_build_object('success',true,'conversation_id',v_id);
  end if;

  return jsonb_build_object('success',false,'message','Invalid chat participant.');
end;
$$;

create or replace function public.rkms_chat_people(p_actor_type text,p_search text default null,p_limit int default 50)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  q text:=nullif(trim(coalesce(p_search,'')),'');
  lim int:=greatest(1,least(coalesce(p_limit,50),100));
  v jsonb;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb);
  end if;

  if upper(p_actor_type)='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb);
    end if;

    select coalesce(jsonb_agg(x order by x.name),'[]'::jsonb) into v
    from (
      select m.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,
             'MEMBER'::text as chat_type,
             ''::text as post_name
      from public.rkms_members m
      where m.id<>me_member
        and upper(coalesce(m.status,''))='APPROVED'
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
      limit lim
    ) x;

    return jsonb_build_object('success',true,'data',v);
  elsif upper(p_actor_type)='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    if me_officer is null then
      return jsonb_build_object('success',false,'message','ACTIVE पदाधिकारी login जरूरी है।','data','[]'::jsonb);
    end if;

    select coalesce(jsonb_agg(x order by x.name),'[]'::jsonb) into v
    from (
      select m.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,
             'MEMBER'::text as chat_type,
             ''::text as post_name
      from public.rkms_members m
      join public.rkms_officers o on o.member_id=m.id
      where upper(coalesce(m.status,''))='APPROVED'
        and upper(coalesce(o.status,''))='ACTIVE'
        and public.rkms_chat_officer_can_access_member(me_officer,m.id)
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
      limit lim
    ) x;

    return jsonb_build_object('success',true,'data',v);
  end if;

  return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end;
$$;

create or replace function public.rkms_chat_threads(p_actor_type text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  v jsonb;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb);
  end if;

  if upper(p_actor_type)='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb);
    end if;

    select coalesce(jsonb_agg(x order by x.last_message_at desc nulls last),'[]'::jsonb) into v
    from (
      select c.id conversation_id,c.last_message_at,
        coalesce((select cm.body from public.rkms_chat_messages cm where cm.conversation_id=c.id order by cm.sent_at desc limit 1),'') last_message,
        (select count(*) from public.rkms_chat_messages cm where cm.conversation_id=c.id and cm.read_at is null and cm.sender_auth_user_id<>auth.uid()) unread_count,
        case when c.officer_id is null then om2.name else coalesce(om.name,ofm.name) end other_name,
        case when c.officer_id is null then 'सदस्य' else coalesce(op.post_name,'पदाधिकारी') end other_role,
        case when c.officer_id is null then om2.photo_url else coalesce(om.photo_url,ofm.photo_url) end other_photo
      from public.rkms_chat_conversations c
      left join public.rkms_members om on om.id=c.member_id
      left join public.rkms_officers oo on oo.id=c.officer_id
      left join public.rkms_members ofm on ofm.id=oo.member_id
      left join public.rkms_posts op on op.officer_id=oo.id and upper(coalesce(op.status,''))='ACTIVE'
      left join public.rkms_members om2 on om2.id=c.member_recipient_id
      where c.member_id=me_member or c.member_recipient_id=me_member
    ) x;

    return jsonb_build_object('success',true,'data',v);
  elsif upper(p_actor_type)='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    if me_officer is null then
      return jsonb_build_object('success',false,'message','ACTIVE पदाधिकारी login जरूरी है।','data','[]'::jsonb);
    end if;

    select coalesce(jsonb_agg(x order by x.last_message_at desc nulls last),'[]'::jsonb) into v
    from (
      select c.id conversation_id,c.last_message_at,
        coalesce((select cm.body from public.rkms_chat_messages cm where cm.conversation_id=c.id order by cm.sent_at desc limit 1),'') last_message,
        (select count(*) from public.rkms_chat_messages cm where cm.conversation_id=c.id and cm.read_at is null and cm.sender_auth_user_id<>auth.uid()) unread_count,
        m.name other_name,'सदस्य' other_role,m.photo_url other_photo
      from public.rkms_chat_conversations c
      join public.rkms_members m on m.id=c.member_id
      where c.officer_id=me_officer
    ) x;

    return jsonb_build_object('success',true,'data',v);
  end if;

  return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end;
$$;

create or replace function public.rkms_chat_messages(p_conversation_id uuid,p_actor_type text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  ok boolean:=false;
  v jsonb;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;

  if upper(p_actor_type)='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
  elsif upper(p_actor_type)='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer);
  end if;

  if not ok then return jsonb_build_object('success',false,'message','इस chat की अनुमति नहीं है।','data','[]'::jsonb); end if;

  select coalesce(jsonb_agg(jsonb_build_object('id',m.id,'body',m.body,'sender_type',m.sender_type,'sender_auth_user_id',m.sender_auth_user_id,'sent_at',m.sent_at,'read_at',m.read_at) order by m.sent_at),'[]'::jsonb)
  into v from public.rkms_chat_messages m where m.conversation_id=p_conversation_id;

  return jsonb_build_object('success',true,'data',v);
end;
$$;

create or replace function public.rkms_chat_send_message(p_conversation_id uuid,p_actor_type text,p_body text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  ok boolean:=false;
  clean text:=trim(coalesce(p_body,''));
  v_id uuid;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
  if length(clean)<1 or length(clean)>4000 then return jsonb_build_object('success',false,'message','Message 1 से 4000 अक्षर तक रखें।'); end if;

  if upper(p_actor_type)='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
  elsif upper(p_actor_type)='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer);
  end if;

  if not ok then return jsonb_build_object('success',false,'message','इस chat में message भेजने की अनुमति नहीं है।'); end if;

  insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body)
  values(p_conversation_id,auth.uid(),upper(p_actor_type),clean)
  returning id into v_id;

  update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
  return jsonb_build_object('success',true,'message_id',v_id);
end;
$$;

create or replace function public.rkms_chat_mark_read(p_conversation_id uuid,p_actor_type text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  ok boolean:=false;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;

  if upper(p_actor_type)='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
  elsif upper(p_actor_type)='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer);
  end if;

  if not ok then return jsonb_build_object('success',false,'message','इस chat की अनुमति नहीं है।'); end if;

  update public.rkms_chat_messages
  set read_at=now()
  where conversation_id=p_conversation_id
    and sender_auth_user_id<>auth.uid()
    and read_at is null;

  return jsonb_build_object('success',true);
end;
$$;

grant execute on function public.rkms_chat_open(text,uuid) to authenticated;
grant execute on function public.rkms_chat_people(text,text,int) to authenticated;
grant execute on function public.rkms_chat_threads(text) to authenticated;
grant execute on function public.rkms_chat_messages(uuid,text) to authenticated;
grant execute on function public.rkms_chat_send_message(uuid,text,text) to authenticated;
grant execute on function public.rkms_chat_mark_read(uuid,text) to authenticated;
