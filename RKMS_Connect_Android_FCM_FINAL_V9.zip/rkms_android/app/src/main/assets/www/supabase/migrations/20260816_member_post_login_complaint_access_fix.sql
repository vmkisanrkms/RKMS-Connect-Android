-- Member post-login complaint access fix
CREATE OR REPLACE FUNCTION public.rkms_get_current_member_complaint_details(p_complaint_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE v_member_id uuid; v_data jsonb;
BEGIN
  IF p_complaint_id IS NULL THEN RETURN jsonb_build_object('success',false,'message','Complaint ID जरूरी है।'); END IF;
  v_member_id:=public.rkms_current_member_id();
  IF v_member_id IS NULL THEN RETURN jsonb_build_object('success',false,'message','Current authenticated member नहीं मिला।'); END IF;
  SELECT jsonb_build_object('id',c.id,'complaint_id',c.complaint_id,'member_id',c.member_id,'name',c.name,'mobile',c.mobile,'state',c.state,'mandal',c.mandal,'district',c.district,'tehsil',c.tehsil,'block',c.block,'village',c.village,'category',c.category,'subject',c.subject,'description',c.description,'photo_url',c.photo_url,'document_url',c.document_url,'status',c.status,'assigned_to',c.assigned_to,'action_taken',c.action_taken,'resolution',c.resolution,'created_at',c.created_at,'updated_at',c.updated_at) INTO v_data FROM public.rkms_complaints c WHERE c.id=p_complaint_id AND c.member_id=v_member_id;
  IF v_data IS NULL THEN RETURN jsonb_build_object('success',false,'message','यह complaint आपके member account से जुड़ी नहीं है या उपलब्ध नहीं है।'); END IF;
  RETURN jsonb_build_object('success',true,'data',v_data);
END;$function$;

CREATE OR REPLACE FUNCTION public.rkms_get_current_member_complaint_history(p_complaint_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE v_member_id uuid; v_ok boolean;
BEGIN
  IF p_complaint_id IS NULL THEN RETURN jsonb_build_object('success',false,'message','Complaint ID जरूरी है।'); END IF;
  v_member_id:=public.rkms_current_member_id();
  IF v_member_id IS NULL THEN RETURN jsonb_build_object('success',false,'message','Current authenticated member नहीं मिला।'); END IF;
  SELECT EXISTS(SELECT 1 FROM public.rkms_complaints c WHERE c.id=p_complaint_id AND c.member_id=v_member_id) INTO v_ok;
  IF NOT v_ok THEN RETURN jsonb_build_object('success',false,'message','इस complaint की history देखने की अनुमति नहीं है।'); END IF;
  RETURN jsonb_build_object('success',true,'data',COALESCE((SELECT jsonb_agg(jsonb_build_object('id',h.id,'complaint_id',h.complaint_id,'old_status',h.old_status,'new_status',h.new_status,'remarks',h.remarks,'changed_by',h.changed_by,'created_at',h.created_at) ORDER BY h.created_at ASC) FROM public.rkms_complaint_history h WHERE h.complaint_id=p_complaint_id),'[]'::jsonb));
END;$function$;

CREATE OR REPLACE FUNCTION public.rkms_get_current_member_complaints(p_search text DEFAULT NULL,p_status text DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE v_member_id uuid; v_data jsonb;
BEGIN
  v_member_id:=public.rkms_current_member_id();
  IF v_member_id IS NULL THEN RETURN jsonb_build_object('success',false,'message','Current authenticated member नहीं मिला।','data','[]'::jsonb); END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',c.id,'complaint_id',c.complaint_id,'member_id',c.member_id,'name',c.name,'mobile',c.mobile,'state',c.state,'mandal',c.mandal,'district',c.district,'tehsil',c.tehsil,'block',c.block,'village',c.village,'category',c.category,'subject',c.subject,'description',c.description,'photo_url',c.photo_url,'document_url',c.document_url,'status',c.status,'assigned_to',c.assigned_to,'action_taken',c.action_taken,'resolution',c.resolution,'created_at',c.created_at,'updated_at',c.updated_at) ORDER BY c.created_at DESC),'[]'::jsonb) INTO v_data
  FROM public.rkms_complaints c WHERE c.member_id=v_member_id
    AND (NULLIF(TRIM(COALESCE(p_search,'')),'') IS NULL OR c.complaint_id ILIKE '%'||TRIM(p_search)||'%' OR c.subject ILIKE '%'||TRIM(p_search)||'%' OR c.category ILIKE '%'||TRIM(p_search)||'%')
    AND (NULLIF(TRIM(COALESCE(p_status,'')),'') IS NULL OR UPPER(COALESCE(c.status,''))=UPPER(TRIM(p_status)));
  RETURN jsonb_build_object('success',true,'count',jsonb_array_length(v_data),'data',v_data);
END;$function$;
