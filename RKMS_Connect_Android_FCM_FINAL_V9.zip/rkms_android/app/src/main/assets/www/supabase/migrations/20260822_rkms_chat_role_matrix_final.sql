
-- RKMS CONNECT CHAT FINAL ROLE MATRIX
-- Password Forgot and all non-chat flows are intentionally untouched.
--
-- Member:
--   * all approved members except self
--   * all active PDA officers except National President
-- PDA Officer:
--   * all approved members
--   * all active PDA officers, including National President
-- National President:
--   * active PDA officers only
--
-- Conversation model:
--   MEMBER <-> MEMBER: member_id + member_recipient_id
--   MEMBER <-> OFFICER: member_id + officer_id
--   OFFICER <-> OFFICER: officer_id + officer_recipient_id
--
-- Existing member-officer conversations remain valid.

alter table public.rkms_chat_conversations
  alter column member_id drop not null;

create index if not exists rkms_chat_conv_officer_recipient_idx
  on public.rkms_chat_conversations(officer_recipient_id, updated_at desc);

create or replace function public.rkms_chat_is_national_president(p_officer_id uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1
    from public.rkms_officers o
    join public.rkms_posts p on p.id=o.post_id
    where o.id=p_officer_id
      and upper(coalesce(o.status,''))='ACTIVE'
      and upper(coalesce(p.level,''))='NATIONAL'
      and trim(coalesce(p.post_name,''))='राष्ट्रीय अध्यक्ष'
  );
$$;



create or replace function public.rkms_chat_people(
  p_actor_type text,
  p_search text default null,
  p_limit int default 100
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  actor_is_np boolean:=false;
  q text:=nullif(trim(coalesce(p_search,'')),'');
  lim int:=greatest(1,least(coalesce(p_limit,100),100));
  v jsonb;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb);
  end if;

  if upper(coalesce(p_actor_type,''))='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb);
    end if;

    with officer_people as (
      select distinct on (o.id)
        o.id,o.member_id,m.name,m.member_id as membership_no,m.photo_url,
        m.district,m.tehsil,m.block,m.village,
        'OFFICER'::text as chat_type,
        coalesce(p.post_name,'PDA अधिकारी')::text as post_name,
        coalesce(p.level,o.authority_level,'')::text as authority_level
      from public.rkms_officers o
      join public.rkms_members m on m.id=o.member_id
      left join public.rkms_posts p on p.id=o.post_id
      where upper(coalesce(o.status,''))='ACTIVE'
        and upper(coalesce(m.status,''))='APPROVED'
        and m.id<>me_member
        and not (
          upper(coalesce(p.level,''))='NATIONAL'
          and trim(coalesce(p.post_name,''))='राष्ट्रीय अध्यक्ष'
        )
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
      order by o.id,p.post_name nulls last
    ),
    ordinary_members as (
      select
        m.id,m.id as member_id,m.name,m.member_id as membership_no,m.photo_url,
        m.district,m.tehsil,m.block,m.village,
        'MEMBER'::text as chat_type,''::text as post_name,''::text as authority_level
      from public.rkms_members m
      where upper(coalesce(m.status,''))='APPROVED'
        and m.id<>me_member
        and not exists(
          select 1 from public.rkms_officers o
          where o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE'
        )
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
    )
    select coalesce(jsonb_agg(to_jsonb(x) order by lower(coalesce(x.name,'')),x.chat_type),'[]'::jsonb)
    into v
    from (
      select * from officer_people
      union all
      select * from ordinary_members
      order by lower(coalesce(name,'')),chat_type
      limit lim
    ) x;

    return jsonb_build_object('success',true,'data',v);

  elsif upper(coalesce(p_actor_type,''))='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    if me_officer is null then
      return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।','data','[]'::jsonb);
    end if;

    actor_is_np:=public.rkms_chat_is_national_president(me_officer);

    with officer_people as (
      select distinct on (o.id)
        o.id,o.member_id,m.name,m.member_id as membership_no,m.photo_url,
        m.district,m.tehsil,m.block,m.village,
        'OFFICER'::text as chat_type,
        coalesce(p.post_name,'PDA अधिकारी')::text as post_name,
        coalesce(p.level,o.authority_level,'')::text as authority_level
      from public.rkms_officers o
      join public.rkms_members m on m.id=o.member_id
      left join public.rkms_posts p on p.id=o.post_id
      where upper(coalesce(o.status,''))='ACTIVE'
        and upper(coalesce(m.status,''))='APPROVED'
        and o.id<>me_officer
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
      order by o.id,p.post_name nulls last
    ),
    ordinary_members as (
      select
        m.id,m.id as member_id,m.name,m.member_id as membership_no,m.photo_url,
        m.district,m.tehsil,m.block,m.village,
        'MEMBER'::text as chat_type,''::text as post_name,''::text as authority_level
      from public.rkms_members m
      where not actor_is_np
        and upper(coalesce(m.status,''))='APPROVED'
        and m.id<>coalesce((select member_id from public.rkms_officers where id=me_officer), '00000000-0000-0000-0000-000000000000'::uuid)
        and not exists(
          select 1 from public.rkms_officers o
          where o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE'
        )
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
    )
    select coalesce(jsonb_agg(to_jsonb(x) order by lower(coalesce(x.name,'')),x.chat_type),'[]'::jsonb)
    into v
    from (
      select * from officer_people
      union all
      select * from ordinary_members
      order by lower(coalesce(name,'')),chat_type
      limit lim
    ) x;

    return jsonb_build_object('success',true,'data',v);
  end if;

  return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end;
$$;

create or replace function public.rkms_chat_open(p_other_type text,p_other_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  target_member uuid;
  target_officer uuid;
  cid uuid;
  typ text:=upper(coalesce(p_other_type,''));
  actor_np boolean:=false;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  me_member:=public.rkms_chat_actor_member_id();
  me_officer:=public.rkms_chat_actor_officer_id();

  if typ='MEMBER' then
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।');
    end if;

    select m.id into target_member
    from public.rkms_members m
    where m.id=p_other_id and upper(coalesce(m.status,''))='APPROVED';

    if target_member is null or target_member=me_member then
      return jsonb_build_object('success',false,'message','Approved सदस्य उपलब्ध नहीं है।');
    end if;

    -- National President cannot be contacted by an ordinary member.
    if exists(
      select 1
      from public.rkms_officers o
      join public.rkms_posts p on p.id=o.post_id
      where o.member_id=target_member
        and upper(coalesce(o.status,''))='ACTIVE'
        and upper(coalesce(p.level,''))='NATIONAL'
        and trim(coalesce(p.post_name,''))='राष्ट्रीय अध्यक्ष'
    ) then
      return jsonb_build_object('success',false,'message','साधारण Member को राष्ट्रीय अध्यक्ष से Chat की अनुमति नहीं है।');
    end if;

    select c.id into cid
    from public.rkms_chat_conversations c
    where c.officer_id is null
      and c.officer_recipient_id is null
      and ((c.member_id=me_member and c.member_recipient_id=target_member)
        or (c.member_id=target_member and c.member_recipient_id=me_member))
    order by c.updated_at desc limit 1;

    if cid is null then
      insert into public.rkms_chat_conversations(member_id,member_recipient_id,officer_id,officer_recipient_id)
      values(me_member,target_member,null,null)
      returning id into cid;
    end if;

    return jsonb_build_object('success',true,'conversation_id',cid);

  elsif typ='OFFICER' then
    if me_officer is not null then
      actor_np:=public.rkms_chat_is_national_president(me_officer);

      select o.id into target_officer
      from public.rkms_officers o
      where o.id=p_other_id and upper(coalesce(o.status,''))='ACTIVE';

      if target_officer is not null then
        if actor_np=false then
          -- PDA officer -> all active officers.
          null;
        end if;

        if target_officer=me_officer then
          return jsonb_build_object('success',false,'message','अपने account से chat नहीं कर सकते।');
        end if;

        select c.id into cid
        from public.rkms_chat_conversations c
        where c.member_id is null
          and c.member_recipient_id is null
          and ((c.officer_id=me_officer and c.officer_recipient_id=target_officer)
            or (c.officer_id=target_officer and c.officer_recipient_id=me_officer))
        order by c.updated_at desc limit 1;

        if cid is null then
          insert into public.rkms_chat_conversations(member_id,member_recipient_id,officer_id,officer_recipient_id)
          values(null,null,me_officer,target_officer)
          returning id into cid;
        end if;

        return jsonb_build_object('success',true,'conversation_id',cid);
      end if;

      -- PDA officer can also start a member chat. National President cannot.
      if actor_np then
        return jsonb_build_object('success',false,'message','राष्ट्रीय अध्यक्ष केवल PDA अधिकारियों से Chat कर सकते हैं।');
      end if;

      select m.id into target_member
      from public.rkms_members m
      where m.id=p_other_id and upper(coalesce(m.status,''))='APPROVED';

      if target_member is null then
        return jsonb_build_object('success',false,'message','Approved सदस्य उपलब्ध नहीं है।');
      end if;

      select c.id into cid
      from public.rkms_chat_conversations c
      where c.member_id=target_member
        and c.member_recipient_id is null
        and c.officer_id=me_officer
        and c.officer_recipient_id is null
      order by c.updated_at desc limit 1;

      if cid is null then
        insert into public.rkms_chat_conversations(member_id,member_recipient_id,officer_id,officer_recipient_id)
        values(target_member,null,me_officer,null)
        returning id into cid;
      end if;

      return jsonb_build_object('success',true,'conversation_id',cid);
    end if;

    return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।');
  end if;

  return jsonb_build_object('success',false,'message','Invalid participant type.');
end;
$$;

create or replace function public.rkms_chat_threads(p_actor_type text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  actor_np boolean:=false;
  v jsonb;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb);
  end if;

  if upper(coalesce(p_actor_type,''))='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    if me_member is null then
      return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb);
    end if;

    select coalesce(jsonb_agg(to_jsonb(x) order by x.last_message_at desc nulls last),'[]'::jsonb)
    into v
    from (
      select c.id conversation_id,c.last_message_at,
        coalesce((select cm.body from public.rkms_chat_messages cm where cm.conversation_id=c.id order by cm.sent_at desc limit 1),'') last_message,
        (select count(*) from public.rkms_chat_messages cm where cm.conversation_id=c.id and cm.read_at is null and cm.sender_auth_user_id<>auth.uid()) unread_count,
        case
          when c.officer_id is null then om2.name
          else coalesce(ofm.name,'PDA अधिकारी')
        end other_name,
        case
          when c.officer_id is null then 'सदस्य'
          else coalesce(op.post_name,'PDA अधिकारी')
        end other_role,
        case
          when c.officer_id is null then om2.photo_url
          else ofm.photo_url
        end other_photo
      from public.rkms_chat_conversations c
      left join public.rkms_members om on om.id=c.member_id
      left join public.rkms_members om2 on om2.id=c.member_recipient_id
      left join public.rkms_officers oo on oo.id=c.officer_id
      left join public.rkms_members ofm on ofm.id=oo.member_id
      left join public.rkms_posts op on op.id=oo.post_id
      where (c.member_id=me_member or c.member_recipient_id=me_member)
    ) x;

    return jsonb_build_object('success',true,'data',v);

  elsif upper(coalesce(p_actor_type,''))='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    if me_officer is null then
      return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।','data','[]'::jsonb);
    end if;

    select public.rkms_chat_is_national_president(me_officer) into actor_np;

    select coalesce(jsonb_agg(to_jsonb(x) order by x.last_message_at desc nulls last),'[]'::jsonb)
    into v
    from (
      -- Officer -> Member
      select c.id conversation_id,c.last_message_at,
        coalesce((select cm.body from public.rkms_chat_messages cm where cm.conversation_id=c.id order by cm.sent_at desc limit 1),'') last_message,
        (select count(*) from public.rkms_chat_messages cm where cm.conversation_id=c.id and cm.read_at is null and cm.sender_auth_user_id<>auth.uid()) unread_count,
        m.name other_name,'सदस्य' other_role,m.photo_url other_photo
      from public.rkms_chat_conversations c
      join public.rkms_members m on m.id=c.member_id
      where not actor_np and c.officer_id=me_officer and c.officer_recipient_id is null

      union all

      -- Officer -> Officer
      select c.id conversation_id,c.last_message_at,
        coalesce((select cm.body from public.rkms_chat_messages cm where cm.conversation_id=c.id order by cm.sent_at desc limit 1),'') last_message,
        (select count(*) from public.rkms_chat_messages cm where cm.conversation_id=c.id and cm.read_at is null and cm.sender_auth_user_id<>auth.uid()) unread_count,
        m.name other_name,coalesce(p.post_name,'PDA अधिकारी') other_role,m.photo_url other_photo
      from public.rkms_chat_conversations c
      join public.rkms_officers oo on oo.id=case when c.officer_id=me_officer then c.officer_recipient_id else c.officer_id end
      join public.rkms_members m on m.id=oo.member_id
      left join public.rkms_posts p on p.id=oo.post_id
      where (c.officer_id=me_officer or c.officer_recipient_id=me_officer)
        and c.member_id is null
        and c.member_recipient_id is null
    ) x;

    return jsonb_build_object('success',true,'data',v);
  end if;

  return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end;
$$;

create or replace function public.rkms_chat_messages(p_conversation_id uuid,p_actor_type text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  ok boolean:=false;
  v jsonb;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb);
  end if;

  if upper(coalesce(p_actor_type,''))='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    ok:=exists(
      select 1 from public.rkms_chat_conversations c
      where c.id=p_conversation_id
        and (c.member_id=me_member or c.member_recipient_id=me_member)
    );
  elsif upper(coalesce(p_actor_type,''))='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    ok:=exists(
      select 1 from public.rkms_chat_conversations c
      where c.id=p_conversation_id
        and (c.officer_id=me_officer or c.officer_recipient_id=me_officer)
    );
  end if;

  if not ok then
    return jsonb_build_object('success',false,'message','इस chat की अनुमति नहीं है।','data','[]'::jsonb);
  end if;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id',m.id,'body',m.body,'sender_type',m.sender_type,
      'sender_auth_user_id',m.sender_auth_user_id,'sent_at',m.sent_at,
      'read_at',m.read_at,'attachment_url',m.attachment_url,
      'attachment_name',m.attachment_name,'attachment_type',m.attachment_type
    ) order by m.sent_at
  ),'[]'::jsonb)
  into v
  from public.rkms_chat_messages m
  where m.conversation_id=p_conversation_id;

  return jsonb_build_object('success',true,'data',v);
end;
$$;

create or replace function public.rkms_chat_send_message(
 p_conversation_id uuid,p_actor_type text,p_body text,
 p_attachment_url text default null,p_attachment_name text default null,p_attachment_type text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  me_member uuid;
  me_officer uuid;
  ok boolean:=false;
  clean text:=trim(coalesce(p_body,''));
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  if length(clean)>4000 then
    return jsonb_build_object('success',false,'message','Message 4000 अक्षर से अधिक नहीं होना चाहिए।');
  end if;

  if upper(coalesce(p_actor_type,''))='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id();
    ok:=exists(
      select 1 from public.rkms_chat_conversations c
      where c.id=p_conversation_id
        and (c.member_id=me_member or c.member_recipient_id=me_member)
    );
  elsif upper(coalesce(p_actor_type,''))='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id();
    ok:=exists(
      select 1 from public.rkms_chat_conversations c
      where c.id=p_conversation_id
        and (c.officer_id=me_officer or c.officer_recipient_id=me_officer)
    );
  end if;

  if not ok then
    return jsonb_build_object('success',false,'message','इस chat में message भेजने की अनुमति नहीं है।');
  end if;

  if length(clean)<1 and nullif(trim(coalesce(p_attachment_url,'')),'') is null then
    return jsonb_build_object('success',false,'message','Message या attachment जरूरी है।');
  end if;

  insert into public.rkms_chat_messages(
    conversation_id,sender_auth_user_id,sender_type,body,
    attachment_url,attachment_name,attachment_type
  )
  values(
    p_conversation_id,auth.uid(),upper(p_actor_type),clean,
    nullif(trim(p_attachment_url),''),
    nullif(trim(p_attachment_name),''),
    nullif(trim(p_attachment_type),'')
  );

  update public.rkms_chat_conversations
    set last_message_at=now(),updated_at=now()
    where id=p_conversation_id;

  return jsonb_build_object('success',true);
end;
$$;

grant execute on function public.rkms_chat_people(text,text,integer) to authenticated;
grant execute on function public.rkms_chat_open(text,uuid) to authenticated;
grant execute on function public.rkms_chat_threads(text) to authenticated;
grant execute on function public.rkms_chat_messages(uuid,text) to authenticated;
grant execute on function public.rkms_chat_send_message(uuid,text,text,text,text,text) to authenticated;
