-- RKMS CONNECT: secure officer-password protected member deletion.
create or replace function public.rkms_admin_member_delete_list(p_search text default null,p_limit int default 500)
returns jsonb
language plpgsql security definer set search_path=public
as $$
declare v jsonb;
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;
 if not exists(select 1 from public.rkms_admins a where a.auth_user_id=auth.uid() and upper(coalesce(a.status,''))='ACTIVE')
 then return jsonb_build_object('success',false,'message','अधिकृत अधिकारी नहीं है।','data','[]'::jsonb); end if;
 select coalesce(jsonb_agg(x),'[]'::jsonb) into v from (
   select m.id,m.name,m.member_id,m.mobile,m.status
   from public.rkms_members m
   where upper(coalesce(m.status,''))='APPROVED'
     and (nullif(trim(coalesce(p_search,'')),'') is null
          or m.name ilike '%'||trim(p_search)||'%'
          or m.member_id ilike '%'||trim(p_search)||'%'
          or m.mobile ilike '%'||trim(p_search)||'%')
   order by m.name
   limit greatest(1,least(coalesce(p_limit,500),1000))
 ) x;
 return jsonb_build_object('success',true,'data',v);
end; $$;

create or replace function public.rkms_admin_delete_members(p_member_ids uuid[],p_officer_password text)
returns jsonb
language plpgsql security definer set search_path=public
as $$
declare uid uuid:=auth.uid(); aid uuid; mid uuid; deleted int:=0;
begin
 if uid is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
 if coalesce(array_length(p_member_ids,1),0)=0 then return jsonb_build_object('success',false,'message','कोई सदस्य चुना नहीं गया।'); end if;
 if coalesce(length(trim(p_officer_password)),0)<1 then return jsonb_build_object('success',false,'message','अधिकारी का password जरूरी है।'); end if;

 select a.id into aid from public.rkms_admins a
 where a.auth_user_id=uid and upper(coalesce(a.status,''))='ACTIVE' limit 1;
 if aid is null then return jsonb_build_object('success',false,'message','अधिकृत अधिकारी नहीं है।'); end if;

 -- Verify the currently logged-in officer's Supabase Auth password.
 if not public.rkms_verify_current_auth_password(p_officer_password) then
   return jsonb_build_object('success',false,'message','अधिकारी का password गलत है।');
 end if;

 foreach mid in array p_member_ids loop
   if exists(select 1 from public.rkms_members m where m.id=mid and upper(coalesce(m.status,''))='APPROVED') then
     insert into public.rkms_member_delete_audit(member_id,deleted_by_auth_user_id,deleted_at,reason)
     values(mid,uid,now(),'Officer authorized member deletion');
     delete from public.rkms_members where id=mid;
     deleted:=deleted+1;
   end if;
 end loop;

 return jsonb_build_object('success',true,'deleted_count',deleted);
end; $$;

grant execute on function public.rkms_admin_member_delete_list(text,int) to authenticated;
grant execute on function public.rkms_admin_delete_members(uuid[],text) to authenticated;
