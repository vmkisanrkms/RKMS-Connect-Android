import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const url = Deno.env.get("SUPABASE_URL")!;
const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const anon = Deno.env.get("SUPABASE_ANON_KEY") || service;
const admin = createClient(url, service);
const H = {
  "Content-Type":"application/json",
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods":"POST, OPTIONS"
};
const out=(x:unknown,s=200)=>new Response(JSON.stringify(x),{status:s,headers:H});
const norm=(v:any)=>String(v??"").trim().toUpperCase();

Deno.serve(async(req)=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers:H});
  if(req.method!=="POST") return out({success:false,message:"POST required"},405);

  try{
    const auth=req.headers.get("authorization")||"";
    if(!auth.startsWith("Bearer ")) return out({success:false,message:"Login जरूरी है।"},401);
    const jwt=auth.slice(7);

    const {data:userData,error:userErr}=await admin.auth.getUser(jwt);
    if(userErr || !userData?.user) return out({success:false,message:"Login session invalid है।"},401);
    const uid=userData.user.id;

    const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});

    let isSuper=false;
    try { isSuper=!!(await userClient.rpc("rkms_is_super_admin")).data; } catch {}

    let officer:any=null;
    if(!isSuper){
      try{
        const r=await userClient.rpc("rkms_get_current_officer_profile");
        officer=r.data?.officer || r.data?.result?.officer || r.data || null;
      }catch{}
    }

    const authority=isSuper ? "SUPER_ADMIN" : norm(officer?.authority_level || officer?.level);
    const allowed=["SUPER_ADMIN","NATIONAL","STATE","MANDAL","DISTRICT"];
    if(!allowed.includes(authority))
      return out({success:false,message:"इस स्तर के अधिकारी को सदस्य Delete करने का अधिकार नहीं है।"},403);

    const body=await req.json();
    const memberId=String(body?.member_id||"").trim();
    if(!memberId) return out({success:false,message:"Member ID जरूरी है।"},400);

    const {data:member,error:memberErr}=await admin
      .from("rkms_members")
      .select("*")
      .or(`id.eq.${memberId},member_id.eq.${memberId}`)
      .maybeSingle();
    if(memberErr) throw memberErr;
    if(!member) return out({success:false,message:"सदस्य नहीं मिला।"},404);

    // Scope check: district and above may delete only within their authority area.
    if(!isSuper && authority!=="NATIONAL"){
      const targetState=norm(member.state), targetMandal=norm(member.mandal), targetDistrict=norm(member.district);
      const officerState=norm(officer?.state), officerMandal=norm(officer?.mandal), officerDistrict=norm(officer?.district);
      if(authority==="STATE" && officerState && targetState!==officerState)
        return out({success:false,message:"यह सदस्य आपके State क्षेत्र में नहीं है।"},403);
      if(authority==="MANDAL" && officerMandal && targetMandal!==officerMandal)
        return out({success:false,message:"यह सदस्य आपके Mandal क्षेत्र में नहीं है।"},403);
      if(authority==="DISTRICT" && officerDistrict && targetDistrict!==officerDistrict)
        return out({success:false,message:"यह सदस्य आपके District क्षेत्र में नहीं है।"},403);
    }

    // Keep a complete snapshot before deletion.
    const deleterName=String(officer?.name||userData.user.user_metadata?.name||userData.user.email||"").trim()||null;
    const snapshot={
      member,
      deleted_at:new Date().toISOString(),
      deleter_user_id:uid,
      deleter_name:deleterName,
      deleter_authority_level:authority,
      deleter_state:officer?.state||null,
      deleter_mandal:officer?.mandal||null,
      deleter_district:officer?.district||null
    };

    // Remove application/session/document/member records. FK rules handle
    // complaints/officer references safely; explicit deletes cover records
    // that are not guaranteed to cascade.
    await admin.from("rkms_member_documents").delete().eq("member_id",member.id);
    await admin.from("rkms_temp_member_sessions").delete().eq("member_id",member.id);
    await admin.from("rkms_member_applications").delete().eq("member_id",member.id);

    // Keep appointment history references valid; detach the member from officer records.
    await admin.from("rkms_officers").update({member_id:null}).eq("member_id",member.id);

    const {error:delErr}=await admin.from("rkms_members").delete().eq("id",member.id);
    if(delErr) throw delErr;

    // Audit is best-effort after the member has been removed. If the audit
    // insert fails, return the delete success rather than pretending deletion failed.
    const audit=await admin.from("rkms_member_delete_audit").insert({
      deleted_member_id:String(member.member_id||member.id),
      deleted_member_name:member.name||null,
      deleted_member_snapshot:snapshot,
      deleter_user_id:uid,
      deleter_name:deleterName,
      deleter_authority_level:authority,
      deleter_state:officer?.state||null,
      deleter_mandal:officer?.mandal||null,
      deleter_district:officer?.district||null
    });

    // Remove the Auth user after database deletion. If this fails, the
    // member record is already gone; report it for admin follow-up.
    let authWarning=null;
    if(member.auth_user_id){
      const {error:authErr}=await admin.auth.admin.deleteUser(member.auth_user_id);
      if(authErr) authWarning="Member database record deleted, but login account cleanup needs follow-up.";
    }

    return out({
      success:true,
      message:authWarning || "सदस्य सफलतापूर्वक Delete हो गया और Delete Audit सुरक्षित है।",
      audit_saved:!audit.error,
      auth_warning:authWarning
    });
  }catch(e){
    return out({success:false,message:e instanceof Error?e.message:"Delete server error"},500);
  }
});
