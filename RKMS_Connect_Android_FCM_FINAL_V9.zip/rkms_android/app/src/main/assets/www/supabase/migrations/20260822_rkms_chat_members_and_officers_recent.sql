
-- RKMS Chat final repair:
-- Members see approved members + active PDA officers.
-- Officers see approved members + active PDA officers.
-- A person with both roles is de-duplicated in the final result.
create or replace function public.rkms_chat_people(p_actor_type text default 'MEMBER')
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    return '[]'::jsonb;
  end if;

  return coalesce((
    with member_people as (
      select
        m.id,
        m.id as member_id,
        m.name,
        'MEMBER'::text as actor_type,
        'सदस्य'::text as role_label,
        m.photo_url
      from public.rkms_members m
      where upper(coalesce(m.status,''))='APPROVED'
        and m.auth_user_id is not null
        and m.auth_user_id <> uid
    ),
    officer_people as (
      select
        o.id,
        o.member_id,
        m.name,
        'OFFICER'::text as actor_type,
        'PDA अधिकारी'::text as role_label,
        m.photo_url
      from public.rkms_officers o
      join public.rkms_members m on m.id=o.member_id
      where upper(coalesce(o.status,''))='ACTIVE'
        and upper(coalesce(m.status,''))='APPROVED'
        and m.auth_user_id is not null
        and m.auth_user_id <> uid
    ),
    combined as (
      select * from officer_people
      union all
      select mp.* from member_people mp
      where not exists (
        select 1 from officer_people op where op.member_id=mp.member_id
      )
    )
    select jsonb_agg(to_jsonb(x) order by lower(coalesce(x.name,'')))
    from combined x
  ), '[]'::jsonb);
end;
$$;

grant execute on function public.rkms_chat_people(text) to authenticated;
