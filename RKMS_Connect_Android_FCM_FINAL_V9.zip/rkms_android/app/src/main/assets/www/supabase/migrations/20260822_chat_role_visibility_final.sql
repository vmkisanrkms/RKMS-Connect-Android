
-- RKMS CHAT ONLY: role visibility matrix
-- Password Forgot / member login / certificates / applications are untouched.
--
-- Rules:
-- 1) MEMBER:
--      may chat with all approved ordinary members and PDA officers from
--      Pradesh/state down to village/local level.
--      may NOT start a chat with National President or other top national
--      leadership accounts.
-- 2) PDA OFFICER:
--      may chat with everyone (approved members, all active officers,
--      national leadership).
-- 3) NATIONAL PRESIDENT:
--      may chat with all active PDA officers and approved members/officers.
-- 4) Existing officer/member duplicate is collapsed to one recipient.

create or replace function public.rkms_chat_people(p_actor_type text default 'MEMBER')
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  current_member_id uuid;
  current_officer_id uuid;
  actor_role text := upper(coalesce(p_actor_type,'MEMBER'));
begin
  begin
    current_member_id := public.rkms_current_member_id();
  exception when others then
    current_member_id := null;
  end;

  begin
    current_officer_id := public.rkms_current_officer_id();
  exception when others then
    current_officer_id := null;
  end;

  return coalesce((
    with base_members as (
      select
        m.id,
        m.id as member_id,
        m.name,
        'MEMBER'::text as actor_type,
        'सदस्य'::text as role_label,
        m.photo_url,
        upper(coalesce(m.role,'')) as member_role,
        upper(coalesce(m.designation,'')) as designation
      from public.rkms_members m
      where upper(coalesce(m.status,''))='APPROVED'
        and (current_member_id is null or m.id <> current_member_id)
    ),
    officers as (
      select
        o.id,
        o.member_id,
        m.name,
        'OFFICER'::text as actor_type,
        coalesce(nullif(o.designation,''),'PDA अधिकारी')::text as role_label,
        m.photo_url,
        upper(coalesce(o.role,'')) as officer_role,
        upper(coalesce(o.designation,'')) as designation
      from public.rkms_officers o
      join public.rkms_members m on m.id=o.member_id
      where upper(coalesce(o.status,''))='ACTIVE'
        and upper(coalesce(m.status,''))='APPROVED'
        and (current_officer_id is null or o.id <> current_officer_id)
        and (current_member_id is null or m.id <> current_member_id)
    ),
    visible_members as (
      select bm.*
      from base_members bm
      where
        -- National leadership is hidden from ordinary members.
        not (
          actor_role = 'MEMBER'
          and (
            bm.member_role in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH','RASHTRIYA_ADHYAKSH')
            or bm.designation in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH','RASHTRIYA ADHYAKSH','राष्ट्रीय अध्यक्ष')
          )
        )
    ),
    visible_officers as (
      select o.*
      from officers o
      where
        -- Members may contact officers at every non-national level.
        -- National-level officers remain restricted for ordinary members.
        not (
          actor_role = 'MEMBER'
          and (
            o.officer_role in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH')
            or o.designation in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH','RASHTRIYA ADHYAKSH','राष्ट्रीय अध्यक्ष')
          )
        )
    ),
    combined as (
      select
        id, member_id, name, actor_type, role_label, photo_url
      from visible_officers
      union all
      select
        id, member_id, name, actor_type, role_label, photo_url
      from visible_members vm
      where not exists (
        select 1 from visible_officers vo
        where vo.member_id=vm.member_id
      )
    )
    select jsonb_agg(to_jsonb(c) order by lower(coalesce(c.name,'')), c.actor_type)
    from combined c
  ), '[]'::jsonb);
end;
$$;

grant execute on function public.rkms_chat_people(text) to authenticated;

-- Enforce the same rule when opening a chat, so hiding a recipient in the UI
-- cannot be bypassed by calling the RPC directly.
create or replace function public.rkms_chat_open(
  p_other_type text,
  p_other_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  actor_role text := 'MEMBER';
  target_is_national boolean := false;
begin
  -- Determine current actor role without changing login/auth flow.
  begin
    if public.rkms_current_officer_id() is not null then
      actor_role := 'OFFICER';
    end if;
  exception when others then null;
  end;

  -- Treat explicit national-president designation as restricted target.
  if upper(coalesce(p_other_type,''))='OFFICER' then
    select exists(
      select 1
      from public.rkms_officers o
      join public.rkms_members m on m.id=o.member_id
      where o.id=p_other_id
        and (
          upper(coalesce(o.role,'')) in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH')
          or upper(coalesce(o.designation,'')) in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH','RASHTRIYA ADHYAKSH','राष्ट्रीय अध्यक्ष')
          or upper(coalesce(m.role,'')) in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH')
          or upper(coalesce(m.designation,'')) in ('NATIONAL_PRESIDENT','RASHTRIYA ADHYAKSH','राष्ट्रीय अध्यक्ष')
        )
    ) into target_is_national;
  else
    select exists(
      select 1
      from public.rkms_members m
      where m.id=p_other_id
        and (
          upper(coalesce(m.role,'')) in ('NATIONAL_PRESIDENT','RASHTRIYA_ADHYAKSH')
          or upper(coalesce(m.designation,'')) in ('NATIONAL_PRESIDENT','RASHTRIYA ADHYAKSH','राष्ट्रीय अध्यक्ष')
        )
    ) into target_is_national;
  end if;

  if actor_role='MEMBER' and target_is_national then
    raise exception 'इस सदस्य को राष्ट्रीय अध्यक्ष से Chat की अनुमति नहीं है।';
  end if;

  -- Delegate the actual conversation creation/reuse to the existing function
  -- under its original parameter contract.
  return public.rkms_chat_open_existing(p_other_type,p_other_id);
end;
$$;
