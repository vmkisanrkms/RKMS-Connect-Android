
-- CHAT ONLY FINAL FIX
-- Password Forgot / password-reset functions are intentionally untouched.
-- Participant discovery must not depend on members.auth_user_id being populated.

create or replace function public.rkms_chat_people(p_actor_type text default 'MEMBER')
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  current_member_id uuid;
  current_officer_id uuid;
begin
  begin
    current_member_id := public.rkms_current_member_id();
  exception when others then
    current_member_id := null;
  end;

  begin
    current_officer_id := public.rkms_current_officer_id();
  exception when others then
    current_officer_id := null;
  end;

  return coalesce((
    with members as (
      select
        m.id,
        m.id as member_id,
        m.name,
        'MEMBER'::text as actor_type,
        'सदस्य'::text as role_label,
        m.photo_url
      from public.rkms_members m
      where upper(coalesce(m.status,''))='APPROVED'
        and (current_member_id is null or m.id <> current_member_id)
    ),
    officers as (
      select
        o.id,
        o.member_id,
        m.name,
        'OFFICER'::text as actor_type,
        'PDA अधिकारी'::text as role_label,
        m.photo_url
      from public.rkms_officers o
      join public.rkms_members m on m.id=o.member_id
      where upper(coalesce(o.status,''))='ACTIVE'
        and upper(coalesce(m.status,''))='APPROVED'
        and (current_member_id is null or m.id <> current_member_id)
        and (current_officer_id is null or o.id <> current_officer_id)
    ),
    combined as (
      select * from officers
      union all
      select mm.*
      from members mm
      where not exists (
        select 1
        from officers oo
        where oo.member_id = mm.member_id
      )
    )
    select jsonb_agg(to_jsonb(c) order by lower(coalesce(c.name,'')), c.actor_type)
    from combined c
  ), '[]'::jsonb);
end;
$$;

grant execute on function public.rkms_chat_people(text) to authenticated;
