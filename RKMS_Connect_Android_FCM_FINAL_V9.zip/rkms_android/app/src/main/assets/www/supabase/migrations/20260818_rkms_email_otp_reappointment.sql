-- RKMS Email OTP + officer reappointment support
CREATE TABLE IF NOT EXISTS public.rkms_member_password_otps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid NOT NULL REFERENCES public.rkms_members(id) ON DELETE CASCADE,
  email text NOT NULL,
  purpose text NOT NULL CHECK (purpose IN ('FIRST_TIME','FORGOT')),
  code_hash text NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rkms_member_password_otps_email_idx
ON public.rkms_member_password_otps(email, purpose, created_at DESC);
ALTER TABLE public.rkms_member_password_otps ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.rkms_reappoint_officer(
 p_member_id uuid,p_old_officer_id uuid,p_post_id uuid,p_appointed_by_officer_id uuid,
 p_state text,p_mandal text DEFAULT NULL,p_district text DEFAULT NULL,p_tehsil text DEFAULT NULL,
 p_block text DEFAULT NULL,p_village text DEFAULT NULL,p_joining_date date DEFAULT CURRENT_DATE)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_actor uuid; v_old_member uuid; v_result jsonb;
BEGIN
 v_actor:=public.rkms_require_current_officer();
 IF v_actor IS NULL OR v_actor<>p_appointed_by_officer_id THEN
   RETURN jsonb_build_object('success',false,'message','Authenticated officer सत्यापित नहीं है।');
 END IF;
 SELECT member_id INTO v_old_member FROM public.rkms_officers
 WHERE id=p_old_officer_id AND status='ACTIVE' FOR UPDATE;
 IF v_old_member IS NULL OR v_old_member<>p_member_id THEN
   RETURN jsonb_build_object('success',false,'message','पुरानी active नियुक्ति नहीं मिली।');
 END IF;
 UPDATE public.rkms_officers SET status='INACTIVE',valid_to=COALESCE(p_joining_date,CURRENT_DATE),updated_at=now()
 WHERE id=p_old_officer_id;
 v_result:=public.rkms_appoint_officer_internal(p_member_id,p_post_id,v_actor,p_state,p_mandal,p_district,p_tehsil,p_block,p_village,p_joining_date);
 IF COALESCE((v_result->>'success')::boolean,false)=false THEN
   RAISE EXCEPTION '%',COALESCE(v_result->>'message','पद परिवर्तन असफल');
 END IF;
 RETURN v_result;
END; $$;

CREATE OR REPLACE FUNCTION public.rkms_super_admin_reappoint_officer(
 p_member_id uuid,p_old_officer_id uuid,p_post_name text,p_state text,
 p_mandal text DEFAULT NULL,p_district text DEFAULT NULL,p_tehsil text DEFAULT NULL,
 p_block text DEFAULT NULL,p_village text DEFAULT NULL,p_joining_date date DEFAULT CURRENT_DATE)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_old_member uuid; v_result jsonb;
BEGIN
 SELECT member_id INTO v_old_member FROM public.rkms_officers
 WHERE id=p_old_officer_id AND status='ACTIVE' FOR UPDATE;
 IF v_old_member IS NULL OR v_old_member<>p_member_id THEN
   RETURN jsonb_build_object('success',false,'message','पुरानी active नियुक्ति नहीं मिली.');
 END IF;
 UPDATE public.rkms_officers SET status='INACTIVE',valid_to=COALESCE(p_joining_date,CURRENT_DATE),updated_at=now()
 WHERE id=p_old_officer_id;
 v_result:=public.rkms_super_admin_appoint_officer(p_member_id,p_post_name,p_state,p_mandal,p_district,p_tehsil,p_block,p_village,p_joining_date);
 IF COALESCE((v_result->>'success')::boolean,false)=false THEN
   RAISE EXCEPTION '%',COALESCE(v_result->>'message','पद परिवर्तन असफल');
 END IF;
 RETURN v_result;
END; $$;
