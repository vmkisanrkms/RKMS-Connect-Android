import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json; charset=utf-8"};
const serviceClient=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
function normMobile(v:unknown){let d=String(v??"").replace(/\D/g,"");if(d.startsWith("91")&&d.length===12)d=d.slice(2);return d.slice(-10);}
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return new Response(JSON.stringify({success:false,message:"POST required"}),{status:405,headers:cors});
 try{
  const body=await req.json(),mobile=normMobile(body?.mobile);if(mobile.length!==10)throw new Error("सही 10 अंकों का मोबाइल नंबर दें।");
  const {data:members,error:memberError}=await serviceClient.from("rkms_members").select("id,member_id,name,father_name,mobile,whatsapp,email,photo_url,state,mandal,district,tehsil,block,village,gram_panchayat,address,membership_type,status").eq("status","APPROVED").eq("mobile",mobile).order("created_at",{ascending:false}).limit(1);
  if(memberError)throw memberError;const member=members?.[0];if(!member)throw new Error("इस मोबाइल नंबर से कोई APPROVED सदस्य नहीं मिला।");
  const authHeader=req.headers.get("Authorization")||"";if(!authHeader.toLowerCase().startsWith("bearer "))throw new Error("Temporary login session उपलब्ध नहीं है।");
  const sessionClient=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:authHeader}}});
  const {data:claimed,error:claimError}=await sessionClient.rpc("rkms_claim_temp_member_session",{p_mobile:mobile});if(claimError)throw claimError;if(!claimed?.success)throw new Error(claimed?.message||"Temporary Member login session नहीं बन सका।");
  const today=new Date().toISOString().slice(0,10);
  const {data:officers,error:officerError}=await serviceClient.from("rkms_officers").select("id,post_id,authority_level,state,mandal,district,tehsil,block,village,appointment_no,joining_date,valid_from,valid_to,status,created_at").eq("member_id",member.id).eq("status","ACTIVE").order("created_at",{ascending:false});
  if(officerError)throw officerError;const officer=(officers||[]).find((o:any)=>(!o.valid_from||o.valid_from<=today)&&(!o.valid_to||o.valid_to>=today))||null;
  let post=null;if(officer?.post_id){const {data:posts,error:postError}=await serviceClient.from("rkms_posts").select("id,post_name,level").eq("id",officer.post_id).limit(1);if(postError)throw postError;post=posts?.[0]||null;}
  return new Response(JSON.stringify({success:true,temporary_login:true,session_claimed:true,member,officer:officer?{...officer,post_name:post?.post_name||null,post_level:post?.level||null}:null}),{status:200,headers:cors});
 }catch(e){return new Response(JSON.stringify({success:false,message:e instanceof Error?e.message:"Member access failed"}),{status:500,headers:cors});}
});