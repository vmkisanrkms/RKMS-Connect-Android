-- RKMS CONNECT: chat for all approved members and active PDA officers.
alter table public.rkms_chat_conversations
  add column if not exists member_recipient_id uuid references public.rkms_members(id) on delete cascade;
alter table public.rkms_chat_conversations alter column officer_id drop not null;

create index if not exists rkms_chat_conv_member_recipient_idx
 on public.rkms_chat_conversations(member_recipient_id,updated_at desc);

create or replace function public.rkms_chat_open(p_other_type text,p_other_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; rid uuid; cid uuid; typ text:=upper(coalesce(p_other_type,''));
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
 me_member:=public.rkms_chat_actor_member_id();
 me_officer:=public.rkms_chat_actor_officer_id();

 if typ='MEMBER' then
   if me_member is null then return jsonb_build_object('success',false,'message','Approved member login जरूरी है।'); end if;
   select id into rid from public.rkms_members where id=p_other_id and upper(coalesce(status,''))='APPROVED';
   if rid is null then return jsonb_build_object('success',false,'message','Approved सदस्य उपलब्ध नहीं है।'); end if;
   if rid=me_member then return jsonb_build_object('success',false,'message','अपने account से chat नहीं कर सकते।'); end if;
   select id into cid from public.rkms_chat_conversations
    where officer_id is null and ((member_id=me_member and member_recipient_id=rid) or (member_id=rid and member_recipient_id=me_member))
    order by updated_at desc limit 1;
   if cid is null then
     insert into public.rkms_chat_conversations(member_id,member_recipient_id,officer_id)
     values(me_member,rid,null) returning id into cid;
   end if;
   return jsonb_build_object('success',true,'conversation_id',cid);
 elsif typ='OFFICER' then
   if me_member is null then return jsonb_build_object('success',false,'message','Member login जरूरी है।'); end if;
   select id into me_officer from public.rkms_officers where id=p_other_id and upper(coalesce(status,''))='ACTIVE';
   if me_officer is null then return jsonb_build_object('success',false,'message','सक्रिय PDA अधिकारी उपलब्ध नहीं है।'); end if;
   select id into cid from public.rkms_chat_conversations where member_id=me_member and officer_id=me_officer order by updated_at desc limit 1;
   if cid is null then
     insert into public.rkms_chat_conversations(member_id,officer_id,member_recipient_id)
     values(me_member,me_officer,null) returning id into cid;
   end if;
   return jsonb_build_object('success',true,'conversation_id',cid);
 end if;
 return jsonb_build_object('success',false,'message','Invalid participant type.');
end; $$;

create or replace function public.rkms_chat_people(p_actor_type text,p_search text default null,p_limit int default 100)
returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; q text:=nullif(trim(coalesce(p_search,'')),''); lim int:=greatest(1,least(coalesce(p_limit,100),100)); v jsonb;
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;
 if upper(p_actor_type)='MEMBER' then
   me_member:=public.rkms_chat_actor_member_id();
   if me_member is null then return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb); end if;
   select coalesce(jsonb_agg(x),'[]'::jsonb) into v from (
     select m.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,'MEMBER' chat_type,'' post_name
     from public.rkms_members m where m.id<>me_member and upper(coalesce(m.status,''))='APPROVED'
     and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
     limit lim) x;
   return jsonb_build_object('success',true,'data',v);
 elsif upper(p_actor_type)='OFFICER' then
   me_officer:=public.rkms_chat_actor_officer_id();
   if me_officer is null then return jsonb_build_object('success',false,'message','Active PDA officer login जरूरी है।','data','[]'::jsonb); end if;
   select coalesce(jsonb_agg(x),'[]'::jsonb) into v from (
     select m.id,m.name,m.member_id,m.photo_url,m.district,m.tehsil,m.block,m.village,'MEMBER' chat_type,'' post_name
     from public.rkms_members m join public.rkms_officers o on o.member_id=m.id
     where upper(coalesce(m.status,''))='APPROVED' and upper(coalesce(o.status,''))='ACTIVE'
     and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or m.district ilike '%'||q||'%')
     limit lim) x;
   return jsonb_build_object('success',true,'data',v);
 end if;
 return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end; $$;

create or replace function public.rkms_chat_messages(p_conversation_id uuid,p_actor_type text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; ok boolean:=false; v jsonb;
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;
 if upper(p_actor_type)='MEMBER' then
   me_member:=public.rkms_chat_actor_member_id();
   ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
 elsif upper(p_actor_type)='OFFICER' then
   me_officer:=public.rkms_chat_actor_officer_id();
   ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer);
 end if;
 if not ok then return jsonb_build_object('success',false,'message','इस chat की अनुमति नहीं है।','data','[]'::jsonb); end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',m.id,'body',m.body,'sender_type',m.sender_type,'sender_auth_user_id',m.sender_auth_user_id,'sent_at',m.sent_at,'read_at',m.read_at) order by m.sent_at),'[]'::jsonb') into v
 from public.rkms_chat_messages m where m.conversation_id=p_conversation_id;
 return jsonb_build_object('success',true,'data',v);
end; $$;

create or replace function public.rkms_chat_send_message(p_conversation_id uuid,p_actor_type text,p_body text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare me_member uuid; me_officer uuid; ok boolean:=false; clean text:=trim(coalesce(p_body,''));
begin
 if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
 if length(clean)<1 or length(clean)>4000 then return jsonb_build_object('success',false,'message','Message 1 से 4000 अक्षर तक रखें।'); end if;
 if upper(p_actor_type)='MEMBER' then
   me_member:=public.rkms_chat_actor_member_id();
   ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and (c.member_id=me_member or c.member_recipient_id=me_member));
 elsif upper(p_actor_type)='OFFICER' then
   me_officer:=public.rkms_chat_actor_officer_id();
   ok:=exists(select 1 from public.rkms_chat_conversations c where c.id=p_conversation_id and c.officer_id=me_officer);
 end if;
 if not ok then return jsonb_build_object('success',false,'message','इस chat में message भेजने की अनुमति नहीं है।'); end if;
 insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body) values(p_conversation_id,auth.uid(),upper(p_actor_type),clean);
 update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
 return jsonb_build_object('success',true);
end; $$;

grant execute on function public.rkms_chat_open(text,uuid) to authenticated;
grant execute on function public.rkms_chat_people(text,text,int) to authenticated;
grant execute on function public.rkms_chat_messages(uuid,text) to authenticated;
grant execute on function public.rkms_chat_send_message(uuid,text,text) to authenticated;
