# RKMS CONNECT — Final Repair Plan

## 1) Member Create Password
- Registration must contain Mobile, DOB, Registered Email, Password, Confirm Password.
- No OTP, no Aadhaar-last-6 password creation, no resend timer.
- Password must be created in Supabase Auth securely.
- Application remains subject to normal PDA approval.
- Only approved members can log in.

## 2) Forgot Password
- Require Mobile + DOB + Registered Email + New Password + Confirm Password.
- No OTP.
- Validate identity against the approved member record.
- Create a password-reset request with status PENDING.
- Do not change the Auth password while pending.
- Route approval only to an ACTIVE authorized PDA officer for the member's jurisdiction.
- APPROVE -> set the requested password in Supabase Auth and mark request APPROVED.
- REJECT -> do not change the Auth password and mark request REJECTED.
- Keep an audit trail.

## 3) Member Chat
- After successful Member login, show a real Chat option.
- Open the existing chat screen/route, not just a dummy button.
- Member can send/receive authorized messages.
- Attachment support must use the existing chat attachment/storage flow.
- Existing chat push functions remain.
- RLS must prevent unauthorized conversations.

## 4) Appointment Letter
- Organization logo top-left; organization name balanced on the opposite side.
- Full-width divider line.
- Centered "नियुक्ति पत्र".
- Square passport-size photo box.
- Full appointment details from member/officer records.
- Full-width divider line.
- National President Shri V.M. Singh on one side; appointing officer on the other.
- Signatures immediately above/touching the respective names.
- Print/PDF-ready.

## 5) Verification
- Do not claim a feature is final merely because a UI element exists.
- Test source references, handlers, routes, and backend actions.
- Do not delete existing working features while applying these changes.
