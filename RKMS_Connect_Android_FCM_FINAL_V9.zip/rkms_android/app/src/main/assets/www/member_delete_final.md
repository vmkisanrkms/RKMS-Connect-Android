Member Delete flow added:
1. Member name के आगे checkbox.
2. Delete Selected.
3. Officer password prompt.
4. Final confirmation.
5. Secure server-side authorization and delete audit.
6. Only APPROVED members are listed.

The server-side RPC fails closed if the project's current-auth password verifier is unavailable.
