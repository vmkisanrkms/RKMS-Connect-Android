RKMS CONNECT — CHAT ROLE MATRIX FINAL

Live Supabase migration successfully applied.

Rules:
1. Ordinary Member:
   - Approved Members: yes
   - Active PDA Officers from State/Pradesh through Mandal, District, Tehsil, Block and Village: yes
   - National President: no
2. PDA Officer:
   - All approved Members: yes
   - All active PDA Officers: yes
   - National President: yes
3. National President:
   - Active PDA Officers: yes
   - Member chat: no
4. Member+PDA duplicate:
   - One person is represented once; officer row is preferred.
5. Recent Chats:
   - Member/member, member/officer and officer/officer conversations are supported.
6. Conversation security:
   - Both sides of a conversation can read/send messages.
7. Password Forgot:
   - Not modified by this Chat repair.

The live migration was applied successfully to project kzczivaydandiqgnzfeg.
