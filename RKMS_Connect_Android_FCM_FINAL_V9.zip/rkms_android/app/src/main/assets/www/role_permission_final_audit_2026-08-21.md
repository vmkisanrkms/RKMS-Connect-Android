# RKMS CONNECT — Professional Final Repair Audit
Date: 21-08-2026

## Target
- Live Supabase: Singapore `kzczivaydandiqgnzfeg`
- Website source target: Singapore
- Shared login: Member Login separate; one Officer Login for Super Admin + ACTIVE officers

## Repairs in this package
1. Unified Officer Login role resolution uses live `rkms_get_login_identity`.
2. Super Admin routes to Super Admin dashboard.
3. ACTIVE officers route to Officer dashboard.
4. NATIONAL-level officer / National President uses a separate National President dashboard.
5. PDA dashboard options are scoped by `authority_level`.
6. Appointment Management is shown only when `rkms_get_my_appointment_permissions` grants access.
7. Member Delete is shown only to Super Admin and NATIONAL/STATE/MANDAL/DISTRICT officers.
8. Member Delete uses password re-verification, explicit confirmation, server-side jurisdiction checks and Delete Audit.
9. Member Delete frontend now calls the deployed `rkms-member-delete-secure` Edge Function, which also removes the member's Auth user when possible. This avoids leaving an orphaned login account.
10. Explicit login/re-auth now forces a fresh role resolution so a stale in-memory role cannot be reused.
11. Removed duplicate legacy login/delete/chat launcher blocks from the final `app.js` to avoid conflicting handlers and duplicate UI.
12. National President dashboard defaults to least privilege if permission data is unavailable.
13. Member registration/password, forgot-password PDA approval, chat, attachments, Digital ID, Appointment Letter, reports, content management, back handling and performance repairs remain included from the prior audited package.

## Live backend checked
- `rkms_get_login_identity` exists.
- `rkms_get_my_appointment_permissions` exists.
- `rkms_delete_member_secure(uuid)` exists.
- Required 21-08-2026 password-reset/chat migrations are present in the Singapore migration history.
- `rkms-member-auth` is ACTIVE version 24.
- `rkms-member-delete-secure` is ACTIVE version 1 with JWT verification enabled.
- Super Admin record: Harmanjeet Singh, `SUPER_ADMIN`, ACTIVE.
- `harmanjatt50@gmail.com` is a separate ACTIVE DISTRICT officer account.

## Source validation
- `node --check app.js`: PASS
- Config points to Singapore project.
- No service-role key is bundled in frontend config.

## Still required before calling production 100% verified
1. Live browser login test for Super Admin.
2. Live browser login test for each active PDA officer.
3. Live National President login test after the corresponding Auth account is linked.
4. Real member registration -> password -> PDA approval -> member login.
5. Real member photo upload.
6. Real forgot-password request -> jurisdiction approval -> password completion -> login.
7. Real chat and attachment upload/download.
8. Real Member Delete test using a disposable/test member, including Auth-user cleanup and audit.
9. Real appointment/reappointment/removal test.
10. Android Chrome Digital ID/Appointment Letter print/PDF one-page test.
11. Reports vs SQL count comparison.
12. Weak-network and rapid-tap regression.
13. Android/browser Back-button regression.
14. Full button-by-button live regression.

## Release rule
Do not call the site 100% production verified until the runtime tests above pass.
