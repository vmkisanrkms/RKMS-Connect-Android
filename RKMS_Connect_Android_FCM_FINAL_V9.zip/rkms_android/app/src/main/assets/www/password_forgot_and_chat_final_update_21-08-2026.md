# RKMS CONNECT — Focused Update: Password Forgot + Member Chat

Only the requested two areas were changed; this package also makes the password-reset approval path self-contained and deployment-safe.

## Password Forgot
- Removed the old two-button flow from the Member Forgot Password modal.
- One button only: `Password Reset Request Send`.
- New password + confirm password are required.
- Request becomes `PENDING` immediately and the button becomes `Request Pending`.
- Reopening the form while pending shows `Request Already Pending` and blocks duplicates.
- PDA/Super Admin approval is the ONLY step that applies the decrypted password to Supabase Auth.
- Successful login marks the approved reset request `USED`.
- If approval exists but the member forgot the password again before logging in, a new request can be created; the old approval is superseded.
- Login is blocked while a reset request is pending.
- Plaintext passwords are not stored in the reset-request table.

## Member Chat
- Member Chat now includes all other approved members plus all active PDA officers.
- If the same person is both an approved member and active PDA officer, only one list row is rendered, preferring the officer entry.
- This prevents duplicate rows for the same person while keeping the correct officer chat target.

## Files changed
- `app.js`
- `supabase/functions/rkms-member-auth/index.ts`
- `supabase/migrations/20260821_rkms_final_chat_password_reset.sql`
- `MEMBER_PASSWORD_FINAL_FIX.md`
- this changelog
