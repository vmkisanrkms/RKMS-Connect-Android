# Security Hardening Remaining — 21-08-2026

A live Supabase Security Advisor scan was performed against `kzczivaydandiqgnzfeg`.

Important: many SECURITY DEFINER warnings are not automatically vulnerabilities because the functions themselves perform role/jurisdiction checks, and some functions are intentionally public (for example public content/location lookups). They still need an explicit least-privilege review.

Items that remain for a professional production hardening pass:
- Several SECURITY DEFINER functions are executable by `anon` and/or `authenticated`; sensitive admin/officer functions should be restricted to the roles actually required.
- Several tables have RLS enabled with no policies. These need an intentional decision: add explicit policies or keep all access through controlled SECURITY DEFINER/RPC/Edge Function paths and document that design.
- Several functions have mutable `search_path`; set a fixed `search_path` on remaining functions.
- Some policies permit anonymous access to tables that contain administrative/audit/court/push/session data; review each policy and restrict to `authenticated` where public access is not intentional.
- Supabase Auth leaked-password protection is currently disabled and should be enabled before production.
- Performance advisor still reports duplicate indexes and some foreign-key/index/RLS optimization opportunities; review before high traffic.

Do not treat these warnings as proof that the application is broken. They are a hardening backlog that must be resolved/accepted deliberately before a security sign-off.
