# RKMS CONNECT — Final Source Audit & Repair Checklist
Date: 21-08-2026
Package base: RKMS_CONNECT_LAST_FINAL_ADMIN_LOGIN_FIXED_20-08-2026.zip
Current backend target: Singapore Supabase project `kzczivaydandiqgnzfeg`

## Source-level repairs completed in this package
- Officer/Super Admin password login handler restored and bound to the actual `#loginBtn`.
- Officer/Super Admin login now accepts Supabase email/password and routes by verified role.
- Officer recovery button now uses Supabase recovery email.
- Member registration keeps Mobile + DOB + optional Email + Password + Confirm Password; Aadhaar is not part of the registration UI.
- Member registration photo upload action was restored in `rkms-member-auth`.
- Member Forgot Password now uses Mobile + DOB + registered Email and creates a PDA approval request; no OTP is used.
- PDA/Super Admin password-reset request review UI and secure jurisdiction-aware review RPC were added.
- Password reset completion changes the Auth password only after the request is APPROVED.
- Member Chat is now a real route with participant search, conversation view, message sending and attachments.
- Chat attachment fields and attachment-aware RPC were added.
- Chat participant discovery was corrected so members can chat with approved members and authorized active officers; officers can chat with authorized approved members.
- Chat launcher now opens the real Chat screen instead of attempting to open an arbitrary first participant.
- Admin Content Management and Security/Audit dashboard links now point to real routes.
- Admin Logout is explicitly bound.
- Duplicate login Back-navigation condition was removed.
- Duplicate/invalid hashchange condition was removed.
- Opening Flash rotation no longer polls Supabase every 2 seconds; the already-loaded flash list rotates locally every 5 seconds.
- Approved-member list/report area loads use a 30-second in-memory cache to reduce repeated `rkms_search_members` calls.
- Legacy unused Email-OTP edge-function source was removed from this final source package so the website does not carry a contradictory OTP path.

## Requirements verified from source
- Address optional: PASS.
- Member photo optional: PASS.
- Password and Confirm Password on registration: PASS.
- Aadhaar registration fields removed: PASS.
- Member login by Mobile or Email + Password: PASS in source.
- Member login blocked until APPROVED: PASS in edge-function source.
- Member ID target format A12345: retained in package/backend migrations; live DB check required.
- State → Mandal → District → Tehsil → Block → Village cascading: retained.
- Digital ID only for APPROVED member: PASS in source.
- Digital ID shows Member ID and appointing-officer details/signature when returned: PASS in source.
- Appointment Letter shows Member ID, member photo, appointing officer/signature and required footer order: PASS in source.
- Officer appointment, post change/reappointment and removal: retained.
- Pending Approval: retained.
- Reports use live Supabase RPCs rather than hardcoded counts: PASS in source.
- Directory and call actions: retained.
- Member Delete confirmation/password guard/audit flow: retained.
- Android/SPA Back handling: repaired in source; physical-device regression still required.
- Async action double-tap locks: retained.
- Upload MIME/size validation: retained and chat attachment limits added.
- Regional notification priority/pinned preview: retained.
- Mobile content management: retained.

## Live verification still required before production release
These cannot honestly be marked 100% verified from a ZIP alone:
1. Deploy the current `rkms-member-auth` Edge Function to the Singapore project.
2. Apply the new migration `20260821_rkms_final_chat_password_reset.sql` to Singapore.
3. Verify the `rkms-media` storage bucket allows the intended authenticated uploads and does not allow unauthorized uploads.
4. Real Member registration → Password creation → PDA approval → Member login.
5. Real Member photo upload during registration.
6. Real Forgot Password request → correct jurisdiction PDA approval → password completion → login.
7. Real Officer/Super Admin login and recovery.
8. Real Member ↔ Member chat, Member ↔ Officer chat and Officer ↔ Member chat.
9. Real chat attachment upload/download.
10. Verify RLS and RPC authorization against a non-authorized member/officer account.
11. Test appointment/reappointment/removal with real records.
12. Test Digital ID and Appointment Letter print/PDF on Android Chrome; verify one-page output.
13. Compare Reports counts with SQL counts.
14. Test weak network and rapid Save/Approve/Reject/Appoint/Reappoint/Delete taps.
15. Test browser/Android Back from Login, Dashboard, Digital ID, Appointment Letter, Chat and Pending screens.
16. Full button-by-button regression on the live Singapore project.

## Production safety gate
- Do NOT delete/pause the Singapore project.
- Do NOT switch the live website to Mumbai until all live tests above pass.
- Mumbai migration remains a separate later step.
