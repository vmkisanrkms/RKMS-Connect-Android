package org.rkms.connect;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;

import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class FCMTokenRegistrar {
    private static final String SUPABASE_URL = "https://kzczivaydandiqgnzfeg.supabase.co";
    private static final String ANON_KEY = "sb_publishable_zPG4bJ8bpE8mokGVgEmNxg_eCDlju_9";
    private static final String FUNCTION = SUPABASE_URL + "/functions/v1/rkms-fcm-push";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    private FCMTokenRegistrar() {}

    public static void register(Context context, String accessToken) {
        if (accessToken == null || accessToken.trim().isEmpty()) return;
        final Context app = context.getApplicationContext();
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token -> {
                    if (token == null || token.trim().isEmpty()) return;
                    EXECUTOR.execute(() -> post(app, accessToken, "register_token", token));
                });
    }

    public static void unregister(Context context, String accessToken) {
        if (accessToken == null || accessToken.trim().isEmpty()) return;
        final Context app = context.getApplicationContext();
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token -> {
                    if (token == null || token.trim().isEmpty()) return;
                    EXECUTOR.execute(() -> post(app, accessToken, "unregister_token", token));
                });
    }

    public static void registerCurrentToken(Context context) {
        String access = SessionStore.access(context.getApplicationContext());
        if (!access.isEmpty()) register(context, access);
    }

    private static void post(Context context, String accessToken, String action, String token) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(FUNCTION);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setDoOutput(true);
            conn.setRequestProperty("apikey", ANON_KEY);
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Content-Type", "application/json");

            JSONObject body = new JSONObject();
            body.put("action", action);
            body.put("fcm_token", token);
            body.put("device_id", Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID));
            body.put("platform", "android");
            body.put("app_version", "1.0");

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                read(conn.getErrorStream());
            } else {
                read(conn.getInputStream());
            }
        } catch (Exception ignored) {
            // Notification registration must never crash or block the app.
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String read(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) out.append(line);
        }
        return out.toString();
    }
}
