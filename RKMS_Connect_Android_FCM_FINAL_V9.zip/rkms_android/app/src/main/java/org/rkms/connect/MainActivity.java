package org.rkms.connect;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION = 1001;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.addJavascriptInterface(new RKMSBridge(this), "RKMSNative");
        loadInitialRoute(getIntent());

        try { createNotificationChannel(); } catch (Throwable ignored) {}
        try { requestNotificationPermission(); } catch (Throwable ignored) {}
        try { FCMTokenRegistrar.registerCurrentToken(this); } catch (Throwable ignored) {}
    }

    private void loadInitialRoute(Intent intent) {
        String route = intent == null ? null : intent.getStringExtra("rkms_route");
        if (route == null || route.trim().isEmpty()) route = "";
        if (!route.startsWith("#")) route = "#" + route;
        webView.loadUrl("file:///android_asset/www/index.html" + route);
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebViewClient(new WebViewClient());
        view.setWebChromeClient(new WebChromeClient());
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    NotificationHelper.CHANNEL_ID,
                    "RKMS Connect Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Chat messages and RKMS alerts");
            channel.setShowBadge(true);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String route = intent == null ? null : intent.getStringExtra("rkms_route");
        if (route != null && !route.trim().isEmpty() && webView != null) {
            if (!route.startsWith("#")) route = "#" + route;
            webView.loadUrl("file:///android_asset/www/index.html" + route);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public static class RKMSBridge {
        private final Context context;
        RKMSBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void saveSession(String accessToken, String refreshToken, String role) {
            SessionStore.save(context, accessToken, refreshToken, role);
            try { FCMTokenRegistrar.register(context, accessToken); } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void clearSession() {
            String access = SessionStore.access(context);
            try { FCMTokenRegistrar.unregister(context, access); } catch (Throwable ignored) {}
            SessionStore.clear(context);
        }

        @JavascriptInterface
        public void showNotification(String title, String body) {
            NotificationHelper.show(context, title, body);
        }

        @JavascriptInterface
        public void toast(String message) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
    }
}
