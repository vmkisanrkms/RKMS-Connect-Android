package org.rkms.connect;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class NotificationCheckWorker extends Worker {
    private static final String SUPABASE_URL = "https://kzczivaydandiqgnzfeg.supabase.co";
    private static final String ANON_KEY = "sb_publishable_zPG4bJ8bpE8mokGVgEmNxg_eCDlju_9";

    public NotificationCheckWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        String access = SessionStore.access(c);
        String role = SessionStore.role(c);
        if (access.isEmpty() || role.isEmpty()) return Result.success();

        try {
            String actor = (role.equalsIgnoreCase("officer") || role.equalsIgnoreCase("super_admin")) ? "OFFICER" : "MEMBER";
            JSONObject threadsResp = rpc(c, access, "rkms_chat_threads", new JSONObject().put("p_actor_type", actor));
            if (threadsResp != null && threadsResp.optBoolean("ok", true)) {
                JSONArray rows = threadsResp.optJSONArray("data");
                if (rows != null) {
                    int unread = 0;
                    String name = "Chat";
                    String body = "नया Chat message आया है।";
                    for (int i = 0; i < rows.length(); i++) {
                        JSONObject x = rows.optJSONObject(i);
                        if (x == null) continue;
                        int u = x.optInt("unread_count", 0);
                        unread += u;
                        if (u > 0) {
                            name = x.optString("other_name", "Chat");
                            body = x.optString("last_message", "नया Chat message आया है।");
                        }
                    }
                    int previous = c.getSharedPreferences("rkms_native_notifications", Context.MODE_PRIVATE).getInt("unread", -1);
                    if (previous >= 0 && unread > previous) {
                        NotificationHelper.show(c, "RKMS Chat — " + name, body);
                    }
                    c.getSharedPreferences("rkms_native_notifications", Context.MODE_PRIVATE).edit().putInt("unread", unread).apply();
                }
            }

            if (role.equalsIgnoreCase("officer") || role.equalsIgnoreCase("super_admin")) {
                JSONObject pendingResp = rpc(c, access, "rkms_pending_member_count", new JSONObject());
                if (pendingResp != null && pendingResp.optBoolean("ok", true)) {
                    int count = pendingResp.optInt("count", pendingResp.optInt("data", 0));
                    int previous = c.getSharedPreferences("rkms_native_notifications", Context.MODE_PRIVATE).getInt("pending", -1);
                    if (previous >= 0 && count > previous) {
                        NotificationHelper.show(c, "RKMS Approval", "नया सदस्य Approval के लिए आया है।");
                    }
                    c.getSharedPreferences("rkms_native_notifications", Context.MODE_PRIVATE).edit().putInt("pending", count).apply();
                }
            }
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    private JSONObject rpc(Context c, String access, String function, JSONObject body) throws Exception {
        URL url = new URL(SUPABASE_URL + "/rest/v1/rpc/" + function);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setDoOutput(true);
        conn.setRequestProperty("apikey", ANON_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + access);
        conn.setRequestProperty("Content-Type", "application/json");
        byte[] out = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) { os.write(out); }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String text = read(is);
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + " " + text);
        JSONArray arr = null;
        JSONObject wrapper = new JSONObject();
        try {
            if (text.trim().startsWith("[")) arr = new JSONArray(text);
            else wrapper = new JSONObject(text);
        } catch (Exception ignored) {}
        JSONObject result = new JSONObject();
        result.put("ok", true);
        if (arr != null) result.put("data", arr);
        else {
            Object data = wrapper.opt("data");
            if (data != null) result.put("data", data);
            if (wrapper.has("count")) result.put("count", wrapper.optInt("count"));
        }
        return result;
    }

    private String read(InputStream is) throws Exception {
        if (is == null) return "";
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) b.append(line);
        }
        return b.toString();
    }
}
