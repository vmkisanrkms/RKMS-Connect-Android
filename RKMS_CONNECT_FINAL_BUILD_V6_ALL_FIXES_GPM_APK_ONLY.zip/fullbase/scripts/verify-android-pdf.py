from pathlib import Path

root = Path("android/app/src/main")
bridges = list(root.rglob("RKMSNativeBridge.java"))
activities = list(root.rglob("MainActivity.java"))

if not bridges:
    setup=Path('scripts/setup-android-native.sh').read_text(encoding='utf-8')
    required=['cat > "$APP_SRC/RKMSNativeBridge.java"','beginPdfSave','appendPdfChunk','finishPdfSave','android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI','RKMSNativeBridge(this, rkmsWebView)']
    missing=[x for x in required if x not in setup]
    if missing: raise SystemExit('ANDROID PDF BRIDGE: FAIL - missing from generated-source setup: '+', '.join(missing))
    print('ANDROID PDF BRIDGE: PASS (generated Android project not bundled; setup validated)')
    raise SystemExit(0)
if not activities:
    raise SystemExit("MainActivity.java not found")

bridge = bridges[0]
activity = activities[0]
bs = bridge.read_text(encoding="utf-8")
activity_source = activity.read_text(encoding="utf-8")

bridge_checks = [
    "beginPdfSave",
    "appendPdfChunk",
    "finishPdfSave",
    "cancelPdfSave",
    "android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI",
    "android.provider.MediaStore.Downloads.RELATIVE_PATH",
    "android.os.Environment.DIRECTORY_DOWNLOADS",
    '"application/pdf"',
    'RKMS CONNECT',
    "Base64.decode",
    "openOutputStream",
]
activity_checks = [
    "RKMSNativeBridge",
    "getBridge().getWebView()",
]

missing_bridge = [x for x in bridge_checks if x not in bs]
missing_activity = [x for x in activity_checks if x not in activity_source]

print("PDF bridge target:", bridge)
print("MainActivity target:", activity)

if missing_bridge or missing_activity:
    print("ANDROID PDF BRIDGE: FAIL")
    if missing_bridge:
        print("Missing from RKMSNativeBridge.java:")
        print("\n".join(missing_bridge))
    if missing_activity:
        print("Missing from MainActivity.java:")
        print("\n".join(missing_activity))
    raise SystemExit(1)

print("ANDROID PDF BRIDGE: PASS")
