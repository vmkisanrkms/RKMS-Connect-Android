# RKMS Connect V8 Navigation/Session Fix

This source is the clean V8 Android project with the notification navigation repair applied.

## Fixed
- Notification-opened routes now start at Home and then navigate through the SPA history.
- Back from notification-opened Chat returns to the Chat list/Home instead of exiting the app.
- Chat conversation view is treated as a child view of the Chat list for native Back.
- Notification taps reuse the existing MainActivity instead of creating a second app task.
- Pending notification routes are passed through the Android bridge after the website has booted.
- GitHub Actions detects an Android project at repository root OR inside `rkms_android`.
- No APK-only ZIP is accepted as an Android source project.

## Intentionally unchanged
- FCM notification delivery logic.
- Notification sound/vibration/channel configuration.
- FCM token registration.
- Supabase session refresh architecture.
- Bundled RKMS website and book assets.
