-- RKMS CONNECT final content-form reliability fix
-- 1) Optional content details stay optional.
-- 2) Flash keeps only its database-required title; body/date fields get safe defaults.
-- 3) Top authority can upload media for all top-authority-managed content types.

create or replace function public.rkms_can_manage_content(p_content_type text, p_action text default 'MANAGE')
returns boolean
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $$
declare
  v_officer uuid;
  v_type text := lower(trim(coalesce(p_content_type,'')));
  v_action text := upper(trim(coalesce(p_action,'MANAGE')));
  v_is_national_president boolean := false;
begin
  -- Super Admin and National President are top authorities for these content areas.
  if public.rkms_current_super_admin_id() is not null then
    return v_type in ('events','news','flash','gallery','documents','reports','campaigns','leadership','notifications');
  end if;

  if v_type not in ('events','news','flash','gallery','documents','reports','campaigns','leadership','notifications') then
    return false;
  end if;

  v_officer := public.rkms_current_officer_id();
  if v_officer is null then
    return false;
  end if;

  select exists(
    select 1
    from public.rkms_officers o
    left join public.rkms_posts p on p.id=o.post_id
    where o.id=v_officer
      and (
        upper(coalesce(o.authority_level,''))='NATIONAL'
        or lower(coalesce(p.post_name,'')) like '%राष्ट्रीय अध्यक्ष%'
      )
  ) into v_is_national_president;

  if v_is_national_president then
    return true;
  end if;

  return exists (
    select 1
    from public.rkms_content_permissions p
    where p.officer_id = v_officer
      and p.content_type = v_type
      and p.can_manage = true
  );
end;
$$;

create or replace function public.rkms_manage_flash(p_action text, p_id uuid default null, p_data jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $$
declare
  v_actor uuid;
  v_id uuid;
  s jsonb;
  v_level text;
  v_start timestamptz;
  v_end timestamptz;
begin
  if not public.rkms_content_scope_allowed('flash',p_action,p_id) then
    return jsonb_build_object('success',false,'message','इस Content पर आपके पद/क्षेत्र के अनुसार अधिकार नहीं है।');
  end if;

  v_actor:=coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id());
  s:=public.rkms_content_scope_json();
  v_level:=upper(coalesce(s->>'authority_level',''));

  if upper(p_action)='CREATE' then
    if nullif(trim(coalesce(p_data->>'title','')),'') is null then
      return jsonb_build_object('success',false,'message','Flash का Title जरूरी है। बाकी विवरण वैकल्पिक हैं।');
    end if;

    v_start:=coalesce(nullif(trim(p_data->>'start_at'),'')::timestamptz,now());
    v_end:=coalesce(nullif(trim(p_data->>'end_at'),'')::timestamptz,v_start + interval '7 days');
    if v_end<=v_start then
      return jsonb_build_object('success',false,'message','End Date/Time, Start Date/Time से आगे होना चाहिए।');
    end if;

    insert into public.rkms_flash_messages(
      title,body,image_url,start_at,end_at,published,created_by,
      scope_officer_id,scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village
    ) values(
      nullif(trim(p_data->>'title'),''),
      nullif(p_data->>'body',''),
      nullif(trim(p_data->>'image_url'),''),
      v_start,v_end,
      coalesce((p_data->>'published')::boolean,false),
      v_actor,(s->>'officer_id')::uuid,s->>'state',
      case when v_level in ('MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then s->>'mandal' end,
      case when v_level in ('DISTRICT','TEHSIL','BLOCK','VILLAGE') then s->>'district' end,
      case when v_level in ('TEHSIL','BLOCK','VILLAGE') then s->>'tehsil' end,
      case when v_level in ('BLOCK','VILLAGE') then s->>'block' end,
      case when v_level='VILLAGE' then s->>'village' end
    ) returning id into v_id;

  elsif upper(p_action)='UPDATE' then
    if nullif(trim(coalesce(p_data->>'title','')),'') is null then
      return jsonb_build_object('success',false,'message','Flash का Title जरूरी है। बाकी विवरण वैकल्पिक हैं।');
    end if;

    update public.rkms_flash_messages
    set title=trim(p_data->>'title'),
        body=case when p_data ? 'body' then nullif(p_data->>'body','') else body end,
        image_url=case when p_data ? 'image_url' then nullif(trim(p_data->>'image_url'),'') else image_url end,
        start_at=case when nullif(trim(p_data->>'start_at'),'') is not null then (p_data->>'start_at')::timestamptz else start_at end,
        end_at=case when nullif(trim(p_data->>'end_at'),'') is not null then (p_data->>'end_at')::timestamptz else end_at end,
        published=case when p_data ? 'published' then (p_data->>'published')::boolean else published end,
        updated_at=now()
    where id=p_id returning id into v_id;

  elsif upper(p_action)='DELETE' then
    delete from public.rkms_flash_messages where id=p_id returning id into v_id;
  else
    return jsonb_build_object('success',false,'message','Invalid action');
  end if;

  if v_id is null then
    return jsonb_build_object('success',false,'message','Flash record नहीं मिला या आपको अधिकार नहीं है।');
  end if;
  return jsonb_build_object('success',true,'id',v_id,'message','Flash सफलतापूर्वक save हो गया।');
exception when others then
  return jsonb_build_object('success',false,'message',sqlerrm);
end;
$$;
