# RKMS Connect — FCM Channel V3 Fix — 2026-09-24

## Why this change is required
Android notification channel sound/importance settings are persisted by the OS and an existing channel cannot reliably be changed by reinstalling application code. The previous RKMS channels used `rkms_notifications_v2` / `rkms_priority_v1`.

## Fix
Use fresh channel IDs:
- `rkms_notifications_v3`
- `rkms_priority_v2`

Both are HIGH importance, default notification sound and vibration.

The FCM HTTP v1 dispatch function must send the same channel IDs. The live `rkms-fcm-dispatch-v2` function was deployed with these channel IDs before this source package was finalized.

## Expected test
1. Install the new signed release APK.
2. Allow notifications.
3. Open RKMS once and log in so the FCM token is registered.
4. Clear Recent Apps.
5. Lock the phone.
6. Send a chat message from another account/device.
7. Android should show RKMS Connect notification with sound and vibration.
8. Tap it: the exact conversation should open.
