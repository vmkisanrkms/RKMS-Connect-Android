# RKMS Notification Direct Chat Fix — 2026-09-24

- Chat notification tap uses `conversation_id` as the authoritative target.
- Duplicate Android delivery (Capacitor action + native intent) is idempotent.
- If the exact chat is already open, no second render and no second history entry is created.
- `MainActivity.onResume()` no longer re-reads the persistent Activity Intent, preventing the same notification route from being reopened repeatedly.
- PDA/important popup remains suppressed while a chat notification route is pending.
- No Supabase/database schema or data changes are required for this fix.


## Back-stack duplicate delivery hardening — 2026-09-24

- Same notification route is now treated as idempotent even after the first render has completed.
- A recent duplicate `chat/<conversation_id>` delivery cannot create a second browser-history entry.
- This prevents Android Back from returning to the same notification-opened chat again.
- Normal Chat navigation is unchanged.

## 2026-09-24 Back-stack hardening after device video test
- Reproduced the reported behavior: notification opens the exact chat, but Android Back can return to the same chat again because duplicate notification/history entries may already exist in the WebView history.
- Notification-opened chats now remember the exact route visible before the notification.
- Android hardware Back and the chat header Back now use `history.replaceState()` to return directly to that saved route instead of popping browser history.
- This prevents the same notification chat from reopening 6-7 times even if duplicate notification callbacks/history entries exist.
- Normal non-notification chat Back behavior remains unchanged.
- `node --check rkms/app.js` passed.
