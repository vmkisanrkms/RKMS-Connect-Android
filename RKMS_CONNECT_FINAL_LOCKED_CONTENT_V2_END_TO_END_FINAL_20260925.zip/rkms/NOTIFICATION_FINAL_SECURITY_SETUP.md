# RKMS Notification Final Security Setup

## FCM dispatch secret

The notification SQL no longer stores the FCM dispatch authentication key in source/migrations. Runtime dispatch reads the Supabase Vault secret named `rkms_push_key`.

Before production push dispatch, create/update the Vault secret `rkms_push_key` with the value expected by the deployed `rkms-fcm-dispatch-v2` Edge Function. Keep the same secret value configured in the Edge Function environment. Do not commit the value to GitHub, ZIP files, SQL migrations, or frontend JavaScript.

## Navigation fix

A notification-opened chat is now a single normal browser history entry. Android Back and the Chat header Back both use the normal `history.back()` path. The notification callback never runs again as a result of Back, so the same chat cannot be reopened by the Back stack.
