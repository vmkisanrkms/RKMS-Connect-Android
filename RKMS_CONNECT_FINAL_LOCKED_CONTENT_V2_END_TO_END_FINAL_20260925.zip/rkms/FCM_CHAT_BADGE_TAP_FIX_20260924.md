# RKMS CONNECT — FCM Chat Badge + Tap Fix — 2026-09-24

## User-reported issues fixed
1. Multiple chat messages arrived but the bottom Chat tab did not show an unread count.
2. Tapping a system notification opened the RKMS home screen instead of the exact conversation.
3. Lock-screen notification vibration worked, but navigation data needed a stronger chat fallback.

## Frontend changes
- Added WhatsApp-style red unread badge to the bottom Chat tab.
- Badge counts unread messages (`sum(unread_count)`), not merely unread conversations.
- Refreshes after app boot, foreground notification receipt, app focus/visibility resume, and every 20 seconds while visible.
- `conversation_id` is treated as authoritative chat routing data even when an older/generic FCM `type` or route is present.

## Android changes
- Native notification intent extraction now routes to `chat/<conversation_id>` whenever `conversation_id` is present, regardless of legacy/generic notification type.
- Existing HIGH-importance FCM channels remain:
  - `rkms_notifications_v3`
  - `rkms_priority_v2`

## Backend
- Live Supabase `rkms-fcm-dispatch-v2` deployed as version 7.
- Chat FCM payload now sends `type: rkms_chat` and includes `conversation_id` and `route`.

## Verification
- `verify-fcm-pipeline.py`: PASS
- `verify-webview-notification-fix.py`: PASS
- `node --check app.js`: PASS
