# RKMS CONNECT v11 — 24-Hour / Closed-App Chat Notification Fix

## Final behavior
- New Chat messages generate a server-side push queue entry without requiring the receiver to have RKMS open.
- FCM delivery uses an Android `notification` payload plus HIGH priority and the RKMS notification channel, so Android can display the notification while the app is backgrounded or closed.
- Chat and normal RKMS notification queues use the same server dispatch path.
- Invalid/expired FCM registration tokens are removed from the server token table.
- When the app resumes, the current FCM token is re-registered so token rotation while the app was idle/closed is recovered.
- Existing Chat JWT resume refresh remains enabled separately; push delivery does not depend on the Chat screen being open.

## Backend deployment
The Supabase project now routes Chat and notification queue dispatch to `rkms-fcm-dispatch-v2`, which sends a visible Android notification payload and retains route/conversation data for notification taps.

## Limitation
No mobile push system can guarantee zero delay when the device is powered off, has no network, or the Android OS/OEM has imposed network/background restrictions. With the device powered on and connected, the design is intended to deliver regardless of whether the app was opened 5 hours, 12 hours, 24 hours, or longer.


## V14 audit hardening
- Android creates `rkms_notifications_v3` natively at app startup so the FCM channel exists even before the first foreground push.
- FCM token registration uses a persistent per-installation `device_id`, allowing multiple phones while preventing stale-token duplication on the same installation.
- Foreground notification listener, notification-tap routing, and Android resume token re-registration are enabled.
- Server dispatch uses HIGH-priority FCM HTTP v1 with the same notification channel and removes invalid registration tokens.
- Notification retry after a newly registered token is limited to recent undelivered queue items rather than replaying an unbounded historical backlog.
- Delivery logging is enabled in `rkms_fcm_delivery_log` for per-token success/failure diagnostics.
- Real-device 5h/12h/24h closed/background tests remain runtime tests and must be performed on a physical Android device; static/backend audit cannot truthfully mark elapsed-time tests as completed.
