# RKMS CONNECT Notification Final Hardening — 2026-09-25

## Fixed

1. Android native notification dispatch no longer waits on a JavaScript Promise through evaluateJavascript(). The previous Promise expression returned an unresolved/undefined value, causing native retry dispatch to continue after the notification had already opened Chat. After Back, those retries could reopen the same Chat.
2. Native notification dispatch now waits until the RKMS JS boot flag is ready, invokes the one-shot route handler, and immediately consumes the pending native route after acceptance.
3. Content notifications inherit geographic scope from News, Events, Flash, Gallery, Documents and Leadership instead of defaulting every content update to ALL.
4. Notification push targeting includes approved members plus active PDA officers at the target level and all subordinate levels within the same geographic hierarchy.
5. Membership approval notifications use the central notification queue and target officers in the applicant area.
6. PDA appointment creates a direct notification for the appointee and a separate area notification for members and subordinate PDA officers.
7. Notification push routes are deterministic: chat, pending approval, directory, news, events, flash, gallery, documents, reports, campaigns, leadership and app updates.
8. Chat notification routing remains conversation_id based.
9. Android output remains Release APK only; no Debug APK or AAB is requested.

## Critical navigation rule

Notification tap opens the exact destination once. The notification callback is not retained as a retry loop after acceptance. Back is owned by the normal SPA history and the notification-return marker is consumed before rendering the previous screen.
