from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
migs='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in sorted((root/'supabase/migrations').glob('20260926*.sql')))
checks=[]
def ok(name,cond):
    checks.append((name,cond)); print(('PASS: ' if cond else 'FAIL: ')+name)

ok('Only four V2 content types are enforced', all(x in migs for x in ["'COURT_ORDER'","'ORG_NOTICE'","'EVENT'","'FLASH'"]) and "'NEWS'" not in migs and "'GALLERY'" not in migs)
ok('Create is immediately live', 'rkms_manage_content_v2' in migs and 'insert into public.rkms_content_v2' in migs and 'perform public.rkms_v2_create_notifications' in migs)
ok('No V2 pending/approval/publish flow', not re.search(r'rkms_content_v2.*(pending|approval|publish)',migs,re.I))
ok('Multi-area target_areas supported', 'jsonb_array_elements(c.target_areas)' in migs)
ok('Audience OFFICERS/MEMBERS/ALL supported', all(x in migs for x in ["'OFFICERS'","'MEMBERS'","'ALL'"]))
ok('Court and Flash restricted to top authority', "ct in ('COURT_ORDER','FLASH') and not top_user" in migs)
ok('Home V2 reader exists', 'rkms_get_home_content_v2' in migs)
ok('Priority and normal Home logic exists', 'priority' in app and 'rkms_get_home_content_v2' in app)
ok('Flash expiry cleanup exists', 'rkms_v2_expire_flash' in migs and 'rkms_v2_delete_notifications' in migs)
ok('Edit notification resync exists', 'perform public.rkms_v2_delete_notifications(p_id)' in migs and 'perform public.rkms_v2_create_notifications(p_id)' in migs)
ok('Delete notification cleanup exists', "upper(p_action)='DELETE'" in migs and 'rkms_v2_delete_notifications(p_id)' in migs)
ok('DB hierarchy scope enforcement exists', 'rkms_v2_scope_allowed' in migs and 'not public.rkms_v2_scope_allowed' in migs)
ok('One V2 push per eligible user per content', 'rkms_v2_push_dedup' in migs and 'primary key (content_id, recipient_auth_user_id)' in migs)
ok('Create/Update/Delete history trigger exists', 'after insert or update or delete' in migs and "'CREATE'" in migs)
ok('Exact V2 notification route exists', "'content-v2/'||new.content_source_id::text" in migs and 'content-v2/' in app)
ok('Notification list deduplicates V2 content cards', 'const seenV2=new Set()' in app)
ok('Legacy News/Gallery Home buttons absent', 'data-route="news"' not in app and 'data-route="gallery"' not in app)
ok('Android release workflow is present', (root/'.github/workflows/rkms-android16-release-apk.yml').exists())

failed=[n for n,c in checks if not c]
print(f"\nCONTENT V2 FINAL STATIC AUDIT: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print('FAILED: '+', '.join(failed)); sys.exit(1)
