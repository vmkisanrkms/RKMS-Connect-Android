from pathlib import Path

p = Path("scripts/setup-android-native.sh")
s = p.read_text()
assert "rkmsWebView.setWebViewClient" not in s, "Capacitor WebViewClient must not be replaced"
assert "https://localhost/" in s, "localhost handling comment/check missing"
assert "rkmsDispatchNotificationRoute" in s, "native notification route dispatch missing"
assert '"CONTENT_FLASH".equalsIgnoreCase(type)' in s, "native CONTENT_FLASH route missing"
app = Path("app.js").read_text()
for route in ["content_news:'news'", "content_events:'events'", "content_flash:'flash'", "content_gallery:'gallery'", "content_documents:'documents'", "content_reports:'reports'", "content_campaigns:'campaigns'", "content_leadership:'leadership'", "app_update:'notifications'"]:
    assert route in app, f"Missing notification route mapping: {route}"
assert "chat/'+encodeURIComponent(cid)" in app, "chat notification route missing"
print("WebView + app-wide notification routing: PASS")
