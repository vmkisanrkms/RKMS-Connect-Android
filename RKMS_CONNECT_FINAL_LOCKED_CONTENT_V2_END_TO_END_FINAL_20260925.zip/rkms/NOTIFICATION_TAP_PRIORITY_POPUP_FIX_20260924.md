# RKMS Notification Tap -> Exact Chat / Priority Popup Fix — 2026-09-24

## Fix
A generic in-app important/PDA popup was being shown during app boot before a pending
notification-tap route was processed. This could make a Chat notification tap appear
to open the PDA appointment/position-change popup.

The boot order is now:

1. Detect pending notification route.
2. If present, open that exact route first.
3. Do not show the generic PDA/important popup in that case.
4. If there is no pending notification route, show the latest important popup normally.

The priority-popup loader also re-checks the pending route after its async database load,
preventing a race where a notification tap arrives while the popup list is loading.

For a Chat notification route, any currently visible priority popup is closed before
opening the Chat.

Chat routing remains authoritative by `conversation_id`, so:

Chat notification -> exact `chat/<conversation_id>` -> Chat

PDA/important notification -> PDA/important popup

## Validation
- `node --check app.js`: PASS
- `scripts/verify-fcm-pipeline.py`: PASS
- `scripts/verify-webview-notification-fix.py`: PASS
