# RKMS CONNECT — FINAL LOCKED CONTENT SPECIFICATION
Date: 25 September 2026

## Locked content types
1. ⚖️ Court Order / न्यायालय आदेश
2. 📢 संगठन सूचना
3. 📅 कार्यक्रम
4. 🚨 Flash

News and Photo/Media Gallery are removed from Home and from the Content Management component. Flash has no separate Home section.

## Home
Top dynamic block:
- All Flash (Normal + Priority)
- Priority संगठन सूचना
- Priority कार्यक्रम

Bottom dynamic block:
- All Flash (Normal + Priority)
- All संगठन सूचना
- All कार्यक्रम

Priority सूचना/कार्यक्रम remain in the bottom block as well.
Court Orders stay in their existing Court Order section and are not part of these two dynamic blocks.

## Targeting
All four content types use the same geographic targeting:
- पूरा संगठन
- प्रदेश
- मंडल
- जिला
- one or multiple selected areas
- Audience: अधिकारी / सदस्य / दोनों

Creator scope is enforced in the database/API, not only by UI.

## Permissions
- Super Admin and राष्ट्रीय अध्यक्ष: full management; can create Court Orders and Flash and manage anyone's content.
- Lower officers: create content only inside their own organizational scope.
- Creator can edit/delete their own content.
- No Pending, Approval, Reject, or Publish workflow.
- Create = immediately Live.

## Notification lock
POST VISIBILITY == NOTIFICATION TARGET.

A notification is generated for exactly the same geographic area(s) and audience(s) selected for the post. A user who cannot see the post must not receive its notification.

## Content fields
Court Order:
- Heading
- Short description
- PDF/photo attachment
- View / Download
- geographic + audience targeting
- no Normal/Priority

संगठन सूचना:
- Heading
- Description
- Attachment
- View / Download
- Normal/Priority
- geographic + audience targeting

कार्यक्रम:
- Name/Heading
- Date
- Time
- Location
- Description
- Attachments
- View / Download
- Normal/Priority
- geographic + audience targeting

Flash:
- Heading
- Description
- Attachment
- Start Date/Time
- End Date/Time
- Normal/Priority
- geographic + audience targeting
- Priority Flash appears for 3 seconds at app opening
- Flash expires/deletes after End Date/Time

## Audit
Content keeps:
- Created by / Created at
- Last updated by / Updated at
- update/delete history in a separate audit table
- Flash expiry cleanup also leaves audit history

## Transaction rule
A content item is considered Live only after its content record and notification records are successfully created. Attachment URLs are stored with the content item.
