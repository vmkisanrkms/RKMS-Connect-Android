# RKMS CONNECT — Exact Notification Target Final Fix — 2026-09-24

## Root cause found in source audit

The notification route correctly contained `chat/<conversation_id>`, but the render pipeline only rendered the Chat LIST.

`render()` calculated `pendingChatId = chatRouteConversationId()` but never used it. Therefore a notification could successfully navigate to `#chat/<conversation_id>` while the UI remained on the Chat list.

There was also a race in `rkmsOpenNotificationRoute()`: it called `go(exact)`, which starts `render()` without awaiting it, then separately attempted another render. A slow first render could finish later and overwrite the conversation screen.

## Final fix

1. `render()` now detects an exact `chat/<conversation_id>` route and immediately calls `openChatThread(pendingChatId)` after the route render.
2. Notification chat navigation no longer uses `go()` for the exact-chat path.
3. The exact `chat/<conversation_id>` history route is committed first and the complete render pipeline is awaited.
4. This prevents the Chat list from overwriting the requested conversation.
5. Existing PDA/priority-popup protection remains in place.
6. `conversation_id` remains authoritative over generic notification type/route.

## Required behavior

Chat notification tap:
FCM -> conversation_id -> Android intent -> exact `chat/<conversation_id>` -> exact conversation

No intermediate Chat list should remain as the final screen, and no PDA/priority popup should cover a chat notification.

## Verification performed on source

- `app.js` syntax structure preserved.
- `pendingChatId` is now actively consumed by `render()`.
- Exact-chat notification path no longer uses asynchronous `go()` race.
- Existing notification/PDA separation retained.
