# RKMS Connect — Final Notification System Fix — 2026-09-23

## App-side fixes
- Foreground FCM messages now create a real Android high-priority notification through the native bridge, not only a WebView toast.
- Foreground notification tap routing accepts `route`, `url`, `target_route`, `conversation_id` and equivalent payload keys.
- Pending notification routes survive app/WebView startup until the route is actually committed.
- Chat notification taps wait for the SPA to boot and then commit the exact `chat/<conversation_id>` hash.
- Android native notification channels use HIGH importance, default sound and vibration.

## Backend fixes
- Live Supabase project now creates push notifications when published/active content changes in News, Events, Flash, Gallery, Documents, Reports, Campaigns, Leadership and App Updates.
- The existing FCM queue/fan-out remains the delivery path, so the same notification system is used across the app.
- Live `rkms-fcm-dispatch-v2` was updated to honor the queue URL for non-chat notifications; chat messages still route directly by conversation.

## Verification
- `node --check app.js`: PASS
- `bash -n scripts/setup-android-native.sh`: PASS
- `scripts/verify-fcm-pipeline.py`: PASS
- Live notification content triggers: 9 installed and verified by database query.

## Build scope
Build only the signed Release APK from this source ZIP. No debug APK and no AAB are required.
