# RKMS Notification Tap → Direct Chat Fix — 2026-09-23

Fixed the notification tap path so a chat notification opens the matching conversation instead of stopping on Home.

Changes:
- JS push tap handler now accepts `route`, `conversation_id`, `conversationId`, and chat notification types.
- Android native notification intent extracts `route` and falls back to `chat/<conversation_id>`.
- Native dispatch now waits until the WebView JavaScript route handler exists and retries instead of clearing the pending route too early.
- WebView `onPageFinished` triggers a pending-route retry.
- Existing chat route `#chat/<conversation_id>` behavior is preserved.

Important: this ZIP is the corrected source/build package. A new signed release APK must be built from it for the fix to be present on the device.
