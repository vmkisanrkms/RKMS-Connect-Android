-- RKMS CONNECT FINAL LOCKED CONTENT V2
-- Replaces the old Home/news/gallery content model at the application layer.
-- Four content types only: COURT_ORDER, ORG_NOTICE, EVENT, FLASH.
-- Visibility and notification targeting use the same geographic/audience rules.

create table if not exists public.rkms_content_v2 (
  id uuid primary key default gen_random_uuid(),
  content_type text not null check (content_type in ('COURT_ORDER','ORG_NOTICE','EVENT','FLASH')),
  title text not null,
  description text,
  event_date date,
  event_time text,
  location text,
  attachments jsonb not null default '[]'::jsonb,
  target_type text not null check (target_type in ('ALL','STATE','MANDAL','DISTRICT')),
  target_areas jsonb not null default '[]'::jsonb,
  target_audience text not null default 'ALL' check (target_audience in ('OFFICERS','MEMBERS','ALL')),
  priority boolean not null default false,
  start_at timestamptz,
  end_at timestamptz,
  created_by uuid,
  updated_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  deleted_by uuid
);

create index if not exists idx_rkms_content_v2_live
  on public.rkms_content_v2(content_type, priority, created_at desc)
  where deleted_at is null;

create table if not exists public.rkms_content_v2_history (
  id bigint generated always as identity primary key,
  content_id uuid not null,
  action text not null,
  content_snapshot jsonb not null,
  actor_id uuid,
  created_at timestamptz not null default now()
);

alter table public.rkms_content_v2 enable row level security;
alter table public.rkms_content_v2_history enable row level security;

create or replace function public.rkms_v2_scope_allowed(
  p_target_type text,
  p_target_areas jsonb
) returns boolean
language plpgsql security definer set search_path=public,pg_catalog as $$
declare
  s jsonb := public.rkms_content_scope_json();
  lvl text := upper(coalesce(s->>'authority_level',''));
  st text := lower(coalesce(s->>'state',''));
  ma text := lower(coalesce(s->>'mandal',''));
  di text := lower(coalesce(s->>'district',''));
  a jsonb;
  at text;
begin
  if public.rkms_current_super_admin_id() is not null
     or public.rkms_is_national_president_current() then
    return true;
  end if;
  if upper(coalesce(p_target_type,''))='ALL' then return false; end if;

  if jsonb_typeof(p_target_areas) <> 'array' or jsonb_array_length(p_target_areas)=0 then
    return false;
  end if;

  for a in select value from jsonb_array_elements(p_target_areas)
  loop
    at:=upper(coalesce(a->>'type',p_target_type,''));
    if at='STATE' then
      if lvl not in ('STATE','MANDAL','DISTRICT') then return false; end if;
      if lower(coalesce(a->>'state',''))<>st then return false; end if;
    elsif at='MANDAL' then
      if lvl not in ('STATE','MANDAL','DISTRICT') then return false; end if;
      if lower(coalesce(a->>'state',''))<>st or (lvl<>'STATE' and lower(coalesce(a->>'mandal',''))<>ma) then return false; end if;
      if lvl='DISTRICT' and lower(coalesce(a->>'district',''))<>di then return false; end if;
    elsif at='DISTRICT' then
      if lvl not in ('STATE','MANDAL','DISTRICT') then return false; end if;
      if lower(coalesce(a->>'state',''))<>st or (lvl='MANDAL' and lower(coalesce(a->>'mandal',''))<>ma) then return false; end if;
      if lower(coalesce(a->>'district',''))<>di and lvl='DISTRICT' then return false; end if;
    else return false;
    end if;
  end loop;
  return true;
end $$;

create or replace function public.rkms_v2_can_manage(
  p_content_type text,
  p_action text,
  p_id uuid default null
) returns boolean
language plpgsql security definer set search_path=public,pg_catalog as $$
declare
  actor uuid := coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id());
  is_top boolean := public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current();
  creator uuid;
begin
  if actor is null then return false; end if;
  if is_top then return true; end if;

  if upper(coalesce(p_content_type,'')) in ('COURT_ORDER','FLASH') then
    return false;
  end if;

  if upper(coalesce(p_action,''))='CREATE' then return public.rkms_v2_scope_allowed('STATE','[{"type":"STATE","state":"__scope_check__"}]'::jsonb) is false;
  end if;

  select created_by into creator from public.rkms_content_v2
    where id=p_id and deleted_at is null;
  return creator=actor;
end $$;

create or replace function public.rkms_manage_content_v2(
  p_action text,
  p_id uuid default null,
  p_data jsonb default '{}'::jsonb
) returns jsonb
language plpgsql security definer set search_path=public,pg_catalog as $$
declare
  actor uuid := coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id());
  top_user boolean := public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current();
  ct text := upper(trim(coalesce(p_data->>'content_type','')));
  tt text := upper(trim(coalesce(p_data->>'target_type','')));
  areas jsonb := coalesce(p_data->'target_areas','[]'::jsonb);
  aud text := upper(trim(coalesce(p_data->>'target_audience','ALL')));
  pr boolean := coalesce((p_data->>'priority')::boolean,false);
  id2 uuid;
  a jsonb;
  ntype text;
  route text;
begin
  if actor is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;

  if upper(p_action)='CREATE' then
    if ct not in ('COURT_ORDER','ORG_NOTICE','EVENT','FLASH') then
      return jsonb_build_object('success',false,'message','अमान्य Content type।');
    end if;
    if ct in ('COURT_ORDER','FLASH') and not top_user then
      return jsonb_build_object('success',false,'message','यह Content केवल Super Admin या राष्ट्रीय अध्यक्ष जारी कर सकते हैं।');
    end if;
    if aud not in ('OFFICERS','MEMBERS','ALL') then aud:='ALL'; end if;
    if tt='ALL' then
      if not top_user then return jsonb_build_object('success',false,'message','पूरा संगठन target करने का अधिकार नहीं है।'); end if;
      areas:='[{"type":"ALL"}]'::jsonb;
    elsif not public.rkms_v2_scope_allowed(tt,areas) then
      return jsonb_build_object('success',false,'message','आप अपने अधिकार क्षेत्र के बाहर Content नहीं डाल सकते।');
    end if;

    insert into public.rkms_content_v2(
      content_type,title,description,event_date,event_time,location,attachments,
      target_type,target_areas,target_audience,priority,start_at,end_at,created_by,updated_by
    ) values (
      ct,
      nullif(trim(p_data->>'title'),''),
      p_data->>'description',
      nullif(p_data->>'event_date','')::date,
      p_data->>'event_time',
      p_data->>'location',
      areas,
      tt,areas,aud,case when ct='COURT_ORDER' then false else pr end,
      nullif(p_data->>'start_at','')::timestamptz,
      nullif(p_data->>'end_at','')::timestamptz,
      actor,actor
    ) returning id into id2;

    if ct='FLASH' and (p_data->>'end_at') is null then
      raise exception 'Flash का End Date/Time जरूरी है।';
    end if;

    ntype:=case ct when 'COURT_ORDER' then 'CONTENT_COURT_ORDER'
                    when 'ORG_NOTICE' then 'CONTENT_ORG_NOTICE'
                    when 'EVENT' then 'CONTENT_EVENTS'
                    else 'CONTENT_FLASH' end;
    route:='home';
    for a in select value from jsonb_array_elements(areas) loop
      insert into public.rkms_notifications(
        title,body,notification_type,target_type,target_value,target_audience,
        is_important,is_public,publisher_auth_user_id,content_source_id,
        content_source_type,target_state,target_mandal,target_district
      ) values (
        coalesce(p_data->>'title','RKMS सूचना'),
        coalesce(p_data->>'description','नई संगठन सामग्री उपलब्ध है।'),
        ntype,
        case when upper(a->>'type')='ALL' then 'ALL' else upper(a->>'type') end,
        case when upper(a->>'type')='ALL' then 'ALL'
             when upper(a->>'type')='STATE' then a->>'state'
             when upper(a->>'type')='MANDAL' then a->>'mandal'
             else a->>'district' end,
        aud,
        pr,true,auth.uid(),id2,'rkms_content_v2',
        a->>'state',a->>'mandal',a->>'district'
      );
    end loop;

    return jsonb_build_object('success',true,'id',id2,'action','CREATE');
  end if;

  if p_id is null then return jsonb_build_object('success',false,'message','Content ID जरूरी है।'); end if;

  if not public.rkms_v2_can_manage(
      (select content_type from public.rkms_content_v2 where id=p_id),
      p_action,p_id) then
    return jsonb_build_object('success',false,'message','इस Content पर अधिकार नहीं है।');
  end if;

  if upper(p_action)='UPDATE' then
    if tt='ALL' and not top_user then
      return jsonb_build_object('success',false,'message','पूरा संगठन target करने का अधिकार नहीं है।');
    end if;
    if tt<>'ALL' and not public.rkms_v2_scope_allowed(tt,areas) then
      return jsonb_build_object('success',false,'message','Targeting आपके अधिकार क्षेत्र से बाहर है।');
    end if;
    update public.rkms_content_v2 set
      title=coalesce(nullif(trim(p_data->>'title'),''),title),
      description=coalesce(p_data->>'description',description),
      event_date=case when p_data ? 'event_date' and nullif(p_data->>'event_date','') is not null then (p_data->>'event_date')::date else event_date end,
      event_time=coalesce(p_data->>'event_time',event_time),
      location=coalesce(p_data->>'location',location),
      attachments=case when p_data ? 'attachments' then p_data->'attachments' else attachments end,
      target_type=coalesce(nullif(tt,''),target_type),
      target_areas=case when jsonb_array_length(areas)>0 then areas else target_areas end,
      target_audience=coalesce(nullif(aud,''),target_audience),
      priority=case when content_type='COURT_ORDER' then false else coalesce((p_data->>'priority')::boolean,priority) end,
      start_at=case when p_data ? 'start_at' then nullif(p_data->>'start_at','')::timestamptz else start_at end,
      end_at=case when p_data ? 'end_at' then nullif(p_data->>'end_at','')::timestamptz else end_at end,
      updated_by=actor,updated_at=now()
    where id=p_id;
    return jsonb_build_object('success',true,'id',p_id,'action','UPDATE');
  elsif upper(p_action)='DELETE' then
    update public.rkms_content_v2 set deleted_at=now(),deleted_by=actor,updated_by=actor,updated_at=now() where id=p_id;
    return jsonb_build_object('success',true,'id',p_id,'action','DELETE');
  end if;
  return jsonb_build_object('success',false,'message','Invalid action.');
exception when others then
  return jsonb_build_object('success',false,'message',sqlerrm);
end $$;

create or replace function public.rkms_v2_user_scope()
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog as $$
declare
  o jsonb;
  m record;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then
    return '{"role":"TOP","audience":"ALL","target_type":"ALL","state":null,"mandal":null,"district":null}'::jsonb;
  end if;
  o:=public.rkms_content_scope_json();
  if o is not null and o->>'authority_level' is not null then
    return jsonb_build_object('role','OFFICER','audience','OFFICERS',
      'target_type',upper(coalesce(o->>'authority_level','DISTRICT')),
      'state',o->>'state','mandal',o->>'mandal','district',o->>'district');
  end if;
  select state,mandal,district into m from public.rkms_members where auth_user_id=auth.uid() limit 1;
  if found then
    return jsonb_build_object('role','MEMBER','audience','MEMBERS',
      'target_type','DISTRICT','state',m.state,'mandal',m.mandal,'district',m.district);
  end if;
  return '{"role":"NONE","audience":"MEMBERS","target_type":"NONE"}'::jsonb;
end $$;

create or replace function public.rkms_get_home_content_v2(p_limit int default 50)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog as $$
declare
  u jsonb:=public.rkms_v2_user_scope();
  r jsonb;
begin
  delete from public.rkms_content_v2 where content_type='FLASH' and end_at is not null and end_at<now();
  select coalesce(jsonb_agg(to_jsonb(x) order by x.priority desc,x.created_at desc),'[]'::jsonb)
    into r
  from (
    select c.*,
      case when c.content_type='EVENT' then 'कार्यक्रम'
           when c.content_type='ORG_NOTICE' then 'संगठन सूचना'
           when c.content_type='FLASH' then 'Flash'
           else 'न्यायालय आदेश' end as type_label
    from public.rkms_content_v2 c
    cross join lateral jsonb_array_elements(c.target_areas) a
    where c.deleted_at is null
      and (c.content_type<>'FLASH' or c.end_at is null or c.end_at>=now())
      and (
        upper(a->>'type')='ALL'
        or (upper(a->>'type')='STATE' and lower(a->>'state')=lower(coalesce(u->>'state','')))
        or (upper(a->>'type')='MANDAL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')))
        or (upper(a->>'type')='DISTRICT' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')))
      )
      and (c.target_audience='ALL' or c.target_audience=u->>'audience' or (u->>'role')='TOP')
  ) x limit greatest(1,least(p_limit,200));
  return r;
end $$;

create or replace function public.rkms_get_content_v2_manage(p_limit int default 100)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog as $$
begin
  if public.rkms_current_super_admin_id() is null and not public.rkms_is_national_president_current()
     and public.rkms_current_officer_id() is null then
    return '[]'::jsonb;
  end if;
  return coalesce((
    select jsonb_agg(to_jsonb(q) order by q.created_at desc)
    from (
      select c.*,coalesce(o.signature_name,m.name,case when c.created_by is null then 'Super Admin' else 'अधिकारी' end) created_by_name,
             coalesce(uo.signature_name,um.name,'—') updated_by_name
      from public.rkms_content_v2 c
      left join public.rkms_officers o on o.id=c.created_by
      left join public.rkms_members m on m.id=o.member_id
      left join public.rkms_officers uo on uo.id=c.updated_by
      left join public.rkms_members um on um.id=uo.member_id
      where c.deleted_at is null
        and (
          public.rkms_current_super_admin_id() is not null
          or public.rkms_is_national_president_current()
          or c.created_by=public.rkms_current_officer_id()
        )
      limit greatest(1,least(p_limit,300))
    ) q
  ),'[]'::jsonb);
end $$;

create or replace function public.rkms_v2_history_trg()
returns trigger language plpgsql security definer set search_path=public,pg_catalog as $$
begin
  if tg_op='DELETE' then
    insert into public.rkms_content_v2_history(content_id,action,content_snapshot,actor_id)
    values(old.id,'DELETE',to_jsonb(old),coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id()));
    return old;
  elsif tg_op='UPDATE' then
    insert into public.rkms_content_v2_history(content_id,action,content_snapshot,actor_id)
    values(new.id,'UPDATE',to_jsonb(new),coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id()));
    return new;
  end if;
  return new;
end $$;

drop trigger if exists trg_rkms_content_v2_history on public.rkms_content_v2;
create trigger trg_rkms_content_v2_history after update or delete on public.rkms_content_v2
for each row execute function public.rkms_v2_history_trg();

-- Best-effort scheduled cleanup for expired Flash. The Home RPC also cleans up,
-- so expiry remains enforced even if pg_cron is unavailable.
do $$
begin
  begin
    execute 'select cron.schedule(''rkms-v2-flash-expiry-cleanup'',''*/10 * * * *'',''delete from public.rkms_content_v2 where content_type = ''''FLASH'''' and end_at is not null and end_at < now()'')';
  exception when others then
    null;
  end;
end $$;
