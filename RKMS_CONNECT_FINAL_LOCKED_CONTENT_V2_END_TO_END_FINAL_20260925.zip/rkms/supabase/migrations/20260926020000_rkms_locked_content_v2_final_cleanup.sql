-- Final locked Content V2 cleanup/consistency migration.
-- Keeps the four locked content types authoritative and notification targeting
-- exactly aligned with visible content.

CREATE OR REPLACE FUNCTION public.rkms_v2_scope_allowed(
  p_target_type text,
  p_target_areas jsonb
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare
  s jsonb := public.rkms_content_scope_json();
  lvl text := upper(coalesce(s->>'authority_level',''));
  st text := lower(trim(coalesce(s->>'state','')));
  ma text := lower(trim(coalesce(s->>'mandal','')));
  di text := lower(trim(coalesce(s->>'district','')));
  a jsonb; at text;
begin
  if public.rkms_current_super_admin_id() is not null
     or public.rkms_is_national_president_current() then return true; end if;
  if upper(coalesce(p_target_type,''))='ALL' then return false; end if;
  if lvl not in ('STATE','MANDAL','DISTRICT') then return false; end if;
  if jsonb_typeof(p_target_areas) <> 'array' or jsonb_array_length(p_target_areas)=0 then return false; end if;
  for a in select value from jsonb_array_elements(p_target_areas) loop
    at:=upper(coalesce(a->>'type',p_target_type,''));
    if at='STATE' then
      if lvl<>'STATE' or lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
    elsif at='MANDAL' then
      if lvl not in ('STATE','MANDAL') then return false; end if;
      if lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
      if lvl='MANDAL' and lower(trim(coalesce(a->>'mandal','')))<>ma then return false; end if;
    elsif at='DISTRICT' then
      if lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
      if lvl='MANDAL' and lower(trim(coalesce(a->>'mandal','')))<>ma then return false; end if;
      if lvl='DISTRICT' and lower(trim(coalesce(a->>'district','')))<>di then return false; end if;
    else return false; end if;
  end loop;
  return true;
end $$;

-- Recreate notification cleanup so no stale queued push survives content changes.
CREATE OR REPLACE FUNCTION public.rkms_v2_delete_notifications(p_content_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
begin
  delete from public.rkms_push_queue q
   where q.notification_id in (
     select n.id from public.rkms_notifications n
      where n.content_source_id=p_content_id
        and lower(coalesce(n.content_source_type,''))='rkms_content_v2');
  delete from public.rkms_notifications n
   where n.content_source_id=p_content_id
     and lower(coalesce(n.content_source_type,''))='rkms_content_v2';
end $$;

-- Ensure expiry is notification-aware even when no Home request happens first.
CREATE OR REPLACE FUNCTION public.rkms_v2_expire_flash()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare r record;
begin
  for r in select id from public.rkms_content_v2
    where content_type='FLASH' and deleted_at is null and end_at is not null and end_at<now()
  loop
    perform public.rkms_v2_delete_notifications(r.id);
    update public.rkms_content_v2
       set deleted_at=now(), deleted_by=null, updated_at=now()
     where id=r.id and deleted_at is null;
  end loop;
end $$;

-- Final trigger route: V2 notifications always point to the exact content detail.
CREATE OR REPLACE FUNCTION public.rkms_enqueue_notification_push()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO public, extensions
AS $$
DECLARE qid uuid; r record; v_route text; v_target text; v_audience text;
BEGIN
  v_target:=upper(coalesce(new.target_type,'ALL')); v_audience:=upper(coalesce(new.target_audience,'ALL'));
  v_route:='notifications';
  IF new.content_source_id IS NOT NULL THEN
    v_route:=CASE lower(coalesce(new.content_source_type,''))
      WHEN 'rkms_content_v2' THEN 'content-v2/'||new.content_source_id::text
      WHEN 'rkms_news' THEN 'news/'||new.content_source_id::text
      WHEN 'rkms_events' THEN 'events/'||new.content_source_id::text
      WHEN 'rkms_flash_messages' THEN 'flash/'||new.content_source_id::text
      WHEN 'rkms_gallery' THEN 'gallery/'||new.content_source_id::text
      WHEN 'rkms_documents' THEN 'documents/'||new.content_source_id::text
      ELSE 'notifications' END;
  END IF;
  FOR r IN
    SELECT DISTINCT x.uid FROM (
      SELECT m.auth_user_id uid FROM public.rkms_members m
      WHERE m.auth_user_id IS NOT NULL AND v_audience IN ('ALL','MEMBERS','MEMBER') AND m.status='APPROVED'
        AND (v_target='ALL' OR (v_target='STATE' AND lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(m.state,'')))) OR (v_target='MANDAL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(m.mandal,'')))) OR (v_target='DISTRICT' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(m.district,'')))))
      UNION
      SELECT DISTINCT m.auth_user_id uid FROM public.rkms_members m JOIN public.rkms_officers o ON o.member_id=m.id AND upper(coalesce(o.status,''))='ACTIVE'
      WHERE m.auth_user_id IS NOT NULL AND v_audience IN ('ALL','OFFICERS')
        AND (v_target='ALL' OR (v_target='STATE' AND lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(o.state,'')))) OR (v_target='MANDAL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(o.state,''))) AND lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(o.mandal,'')))) OR (v_target='DISTRICT' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(o.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(o.mandal,''))) AND lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(o.district,'')))))
      UNION SELECT a.auth_user_id uid FROM public.rkms_admins a WHERE a.status='ACTIVE' AND upper(coalesce(a.role,''))='SUPER_ADMIN' AND a.auth_user_id IS NOT NULL AND v_audience='ALL'
      UNION SELECT DISTINCT m.auth_user_id uid FROM public.rkms_officers o JOIN public.rkms_posts p ON p.id=o.post_id JOIN public.rkms_members m ON m.id=o.member_id WHERE o.status='ACTIVE' AND lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष' AND m.status='APPROVED' AND m.auth_user_id IS NOT NULL AND v_audience='ALL'
    ) x WHERE x.uid IS NOT NULL
  LOOP
    INSERT INTO public.rkms_push_queue(recipient_auth_user_id,title,body,url,sender_auth_user_id,notification_id)
    VALUES(r.uid,new.title,coalesce(new.body,''),'#'||v_route,new.publisher_auth_user_id,new.id)
    RETURNING id INTO qid;
    BEGIN
      PERFORM net.http_post(url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',
        body:=jsonb_build_object('queue_id',qid),
        headers:=jsonb_build_object('Content-Type','application/json','x-rkms-push-key',coalesce((SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='rkms_push_key' LIMIT 1),'')));
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END LOOP;
  RETURN new;
END; $$;
