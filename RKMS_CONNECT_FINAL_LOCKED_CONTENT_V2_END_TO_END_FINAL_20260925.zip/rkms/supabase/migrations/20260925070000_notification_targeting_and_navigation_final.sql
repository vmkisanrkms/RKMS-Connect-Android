-- RKMS notification final hardening:
-- 1) content notifications inherit the publisher/content geographic scope;
-- 2) push delivery includes members plus subordinate PDA officers in that scope;
-- 3) membership approval requests target the relevant officers;
-- 4) PDA appointment announcements target members + subordinate officers;
-- 5) every push gets a deterministic in-app route.

CREATE OR REPLACE FUNCTION public.rkms_enqueue_content_update_notification()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
DECLARE
  v_title text; v_body text; v_type text; v_published boolean := true; v_status text;
  v_target text := 'ALL'; v_state text; v_mandal text; v_district text; v_tehsil text; v_block text; v_village text;
  v_scope_officer uuid; v_publisher uuid; v_source uuid;
BEGIN
  IF TG_OP='UPDATE' AND (to_jsonb(NEW) - ARRAY['updated_at','created_at']) = (to_jsonb(OLD) - ARRAY['updated_at','created_at']) THEN RETURN NEW; END IF;

  IF TG_TABLE_NAME='rkms_news' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false);
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नई समाचार सूचना');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'body'),''),'RKMS Connect में नया समाचार अपडेट हुआ है।');
    v_type:='CONTENT_NEWS'; v_publisher:=to_jsonb(NEW)->>'created_by'; v_source:=NEW.id;
    v_state:=nullif(trim(to_jsonb(NEW)->>'scope_state'),''); v_mandal:=nullif(trim(to_jsonb(NEW)->>'scope_mandal'),'');
    v_district:=nullif(trim(to_jsonb(NEW)->>'scope_district'),''); v_tehsil:=nullif(trim(to_jsonb(NEW)->>'scope_tehsil'),'');
    v_block:=nullif(trim(to_jsonb(NEW)->>'scope_block'),''); v_village:=nullif(trim(to_jsonb(NEW)->>'scope_village'),'');
    v_scope_officer:=nullif(to_jsonb(NEW)->>'scope_officer_id','')::uuid;
  ELSIF TG_TABLE_NAME='rkms_events' THEN
    v_status:=upper(coalesce(to_jsonb(NEW)->>'status','UPCOMING')); v_published:=v_status NOT IN ('CANCELLED','DELETED','INACTIVE');
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नया कार्यक्रम');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नया कार्यक्रम अपडेट हुआ है।');
    v_type:='CONTENT_EVENTS'; v_publisher:=to_jsonb(NEW)->>'created_by'; v_source:=NEW.id;
    v_state:=nullif(trim(to_jsonb(NEW)->>'state'),''); v_mandal:=nullif(trim(to_jsonb(NEW)->>'mandal'),'');
    v_district:=nullif(trim(to_jsonb(NEW)->>'district'),''); v_tehsil:=nullif(trim(to_jsonb(NEW)->>'tehsil'),'');
    v_block:=nullif(trim(to_jsonb(NEW)->>'block'),''); v_village:=nullif(trim(to_jsonb(NEW)->>'village'),'');
  ELSIF TG_TABLE_NAME='rkms_flash_messages' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false);
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'RKMS Flash सूचना');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'body'),''),'नई Flash सूचना उपलब्ध है।');
    v_type:='CONTENT_FLASH'; v_publisher:=to_jsonb(NEW)->>'created_by'; v_source:=NEW.id;
    v_state:=nullif(trim(to_jsonb(NEW)->>'scope_state'),''); v_mandal:=nullif(trim(to_jsonb(NEW)->>'scope_mandal'),'');
    v_district:=nullif(trim(to_jsonb(NEW)->>'scope_district'),''); v_tehsil:=nullif(trim(to_jsonb(NEW)->>'scope_tehsil'),'');
    v_block:=nullif(trim(to_jsonb(NEW)->>'scope_block'),''); v_village:=nullif(trim(to_jsonb(NEW)->>'scope_village'),'');
    v_scope_officer:=nullif(to_jsonb(NEW)->>'scope_officer_id','')::uuid;
  ELSIF TG_TABLE_NAME='rkms_gallery' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false);
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नई फोटो/मीडिया सूचना');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नई फोटो/मीडिया सामग्री उपलब्ध है।');
    v_type:='CONTENT_GALLERY'; v_source:=NEW.id;
    v_state:=nullif(trim(to_jsonb(NEW)->>'scope_state'),''); v_mandal:=nullif(trim(to_jsonb(NEW)->>'scope_mandal'),'');
    v_district:=nullif(trim(to_jsonb(NEW)->>'scope_district'),''); v_tehsil:=nullif(trim(to_jsonb(NEW)->>'scope_tehsil'),'');
    v_block:=nullif(trim(to_jsonb(NEW)->>'scope_block'),''); v_village:=nullif(trim(to_jsonb(NEW)->>'scope_village'),'');
    v_scope_officer:=nullif(to_jsonb(NEW)->>'scope_officer_id','')::uuid;
  ELSIF TG_TABLE_NAME='rkms_documents' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false);
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नया दस्तावेज');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नया दस्तावेज उपलब्ध है।');
    v_type:='CONTENT_DOCUMENTS'; v_publisher:=to_jsonb(NEW)->>'uploaded_by'; v_source:=NEW.id;
    v_state:=nullif(trim(to_jsonb(NEW)->>'scope_state'),''); v_mandal:=nullif(trim(to_jsonb(NEW)->>'scope_mandal'),'');
    v_district:=nullif(trim(to_jsonb(NEW)->>'scope_district'),''); v_tehsil:=nullif(trim(to_jsonb(NEW)->>'scope_tehsil'),'');
    v_block:=nullif(trim(to_jsonb(NEW)->>'scope_block'),''); v_village:=nullif(trim(to_jsonb(NEW)->>'scope_village'),'');
    v_scope_officer:=nullif(to_jsonb(NEW)->>'scope_officer_id','')::uuid;
  ELSIF TG_TABLE_NAME='rkms_reports' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false);
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नई रिपोर्ट');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नई रिपोर्ट उपलब्ध है।');
    v_type:='CONTENT_REPORTS'; v_source:=NEW.id;
  ELSIF TG_TABLE_NAME='rkms_campaigns' THEN
    v_status:=upper(coalesce(to_jsonb(NEW)->>'status','ACTIVE')); v_published:=v_status NOT IN ('CANCELLED','DELETED','INACTIVE','CLOSED');
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नया अभियान');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नया अभियान अपडेट हुआ है।');
    v_type:='CONTENT_CAMPAIGNS'; v_source:=NEW.id;
  ELSIF TG_TABLE_NAME='rkms_leadership' THEN
    v_status:=upper(coalesce(to_jsonb(NEW)->>'status','ACTIVE')); v_published:=v_status='ACTIVE';
    v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'name'),''),'नेतृत्व अपडेट');
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'post_name'),''),'RKMS Connect में नेतृत्व संबंधी नई जानकारी उपलब्ध है।');
    v_type:='CONTENT_LEADERSHIP'; v_source:=NEW.id;
    v_state:=nullif(trim(to_jsonb(NEW)->>'state'),''); v_mandal:=nullif(trim(to_jsonb(NEW)->>'mandal'),'');
    v_district:=nullif(trim(to_jsonb(NEW)->>'district'),''); v_tehsil:=nullif(trim(to_jsonb(NEW)->>'tehsil'),'');
    v_block:=nullif(trim(to_jsonb(NEW)->>'block'),''); v_village:=nullif(trim(to_jsonb(NEW)->>'village'),'');
  ELSIF TG_TABLE_NAME='rkms_app_updates' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'is_active')::boolean,true); v_title:='RKMS Connect नया अपडेट';
    v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'release_notes'),''),'RKMS Connect का नया app update उपलब्ध है।');
    v_type:='APP_UPDATE'; v_source:=NULL;
  ELSE RETURN NEW;
  END IF;

  IF NOT v_published THEN RETURN NEW; END IF;

  IF v_scope_officer IS NOT NULL AND (v_state IS NULL OR v_mandal IS NULL OR v_district IS NULL) THEN
    SELECT o.state,o.mandal,o.district,o.tehsil,o.block,o.village
      INTO v_state,v_mandal,v_district,v_tehsil,v_block,v_village
    FROM public.rkms_officers o WHERE o.id=v_scope_officer;
  END IF;

  IF v_state IS NOT NULL THEN
    IF v_village IS NOT NULL THEN v_target:='VILLAGE';
    ELSIF v_block IS NOT NULL THEN v_target:='BLOCK';
    ELSIF v_tehsil IS NOT NULL THEN v_target:='TEHSIL';
    ELSIF v_district IS NOT NULL THEN v_target:='DISTRICT';
    ELSIF v_mandal IS NOT NULL THEN v_target:='MANDAL';
    ELSE v_target:='STATE'; END IF;
  ELSE
    v_target:='ALL';
  END IF;

  INSERT INTO public.rkms_notifications(
    title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,
    publisher_auth_user_id,target_state,target_mandal,target_district,target_tehsil,target_block,target_village,
    content_source_id,content_source_type
  ) VALUES(
    v_title,v_body,v_type,v_target,
    CASE v_target WHEN 'STATE' THEN v_state WHEN 'MANDAL' THEN v_mandal WHEN 'DISTRICT' THEN v_district WHEN 'TEHSIL' THEN v_tehsil WHEN 'BLOCK' THEN v_block WHEN 'VILLAGE' THEN v_village ELSE 'ALL' END,
    'ALL',
    TG_TABLE_NAME IN ('rkms_flash_messages','rkms_app_updates'),
    true,
    CASE WHEN v_publisher IS NULL THEN NULL ELSE v_publisher::uuid END,
    v_state,v_mandal,v_district,v_tehsil,v_block,v_village,
    v_source,TG_TABLE_NAME
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.rkms_enqueue_notification_push()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, extensions
AS $$
DECLARE qid uuid; r record; v_route text; v_target text; v_rank integer;
BEGIN
  v_target:=upper(coalesce(new.target_type,'ALL'));
  v_rank:=public.rkms_level_rank(v_target);
  v_route:=CASE upper(coalesce(new.notification_type,''))
    WHEN 'CONTENT_NEWS' THEN 'news'
    WHEN 'CONTENT_EVENTS' THEN 'events'
    WHEN 'CONTENT_FLASH' THEN 'flash'
    WHEN 'CONTENT_GALLERY' THEN 'gallery'
    WHEN 'CONTENT_DOCUMENTS' THEN 'documents'
    WHEN 'CONTENT_REPORTS' THEN 'reports'
    WHEN 'CONTENT_CAMPAIGNS' THEN 'campaigns'
    WHEN 'CONTENT_LEADERSHIP' THEN 'leadership'
    WHEN 'APP_UPDATE' THEN 'notifications'
    WHEN 'MEMBERSHIP_APPROVAL' THEN 'pending'
    WHEN 'PDA_APPOINTMENT' THEN 'directory'
    ELSE 'notifications'
  END;

  IF upper(coalesce(new.target_type,''))='MEMBER' THEN
    v_route:=CASE upper(coalesce(new.notification_type,'')) WHEN 'MEMBERSHIP_APPROVED' THEN 'notifications' WHEN 'MEMBERSHIP_REJECTED' THEN 'notifications' WHEN 'PDA_REMOVED' THEN 'notifications' ELSE v_route END;
  END IF;

  FOR r IN
    SELECT DISTINCT x.uid FROM (
      SELECT m.auth_user_id uid
      FROM public.rkms_members m
      WHERE m.status='APPROVED' AND m.auth_user_id IS NOT NULL
        AND upper(coalesce(new.target_audience,'ALL')) IN ('ALL','MEMBERS','MEMBER')
        AND (
          v_target='ALL'
          OR (v_target='MEMBER' AND lower(coalesce(new.target_value,''))=lower(m.id::text))
          OR (v_target='STATE' AND lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(m.state,''))))
          OR (v_target='MANDAL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(m.mandal,''))))
          OR (v_target='DISTRICT' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(m.district,''))))
          OR (v_target='TEHSIL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,'')))=lower(trim(coalesce(m.district,''))) AND lower(trim(coalesce(new.target_tehsil,new.target_value,'')))=lower(trim(coalesce(m.tehsil,''))))
          OR (v_target='BLOCK' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,'')))=lower(trim(coalesce(m.district,''))) AND lower(trim(coalesce(new.target_tehsil,'')))=lower(trim(coalesce(m.tehsil,''))) AND lower(trim(coalesce(new.target_block,new.target_value,'')))=lower(trim(coalesce(m.block,''))))
          OR (v_target='VILLAGE' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,'')))=lower(trim(coalesce(m.district,''))) AND lower(trim(coalesce(new.target_tehsil,'')))=lower(trim(coalesce(m.tehsil,''))) AND lower(trim(coalesce(new.target_block,'')))=lower(trim(coalesce(m.block,''))) AND lower(trim(coalesce(new.target_village,new.target_value,'')))=lower(trim(coalesce(m.village,''))))
        )
        AND (new.target_post_id IS NULL OR EXISTS(SELECT 1 FROM public.rkms_officers o WHERE o.member_id=m.id AND o.status='ACTIVE' AND o.post_id=new.target_post_id))
      UNION
      SELECT DISTINCT m.auth_user_id uid
      FROM public.rkms_members m
      JOIN public.rkms_officers o ON o.member_id=m.id AND upper(coalesce(o.status,''))='ACTIVE'
      JOIN public.rkms_posts p ON p.id=o.post_id
      WHERE m.auth_user_id IS NOT NULL
        AND upper(coalesce(new.target_audience,'ALL')) IN ('ALL','OFFICERS')
        AND (
          v_target='ALL'
          OR (v_target='STATE' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) <= v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,new.target_value,''))))
          OR (v_target='MANDAL' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) <= v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,new.target_value,''))))
          OR (v_target='DISTRICT' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) <= v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,new.target_value,''))))
          OR (v_target='TEHSIL' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) <= v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,''))) AND lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(new.target_tehsil,new.target_value,''))))
          OR (v_target='BLOCK' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) <= v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,''))) AND lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(new.target_tehsil,''))) AND lower(trim(coalesce(o.block,'')))=lower(trim(coalesce(new.target_block,new.target_value,''))))
          OR (v_target='VILLAGE' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) <= v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,''))) AND lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(new.target_tehsil,''))) AND lower(trim(coalesce(o.block,'')))=lower(trim(coalesce(new.target_block,''))) AND lower(trim(coalesce(o.village,'')))=lower(trim(coalesce(new.target_village,new.target_value,''))))
        )
        AND (new.target_post_id IS NULL OR o.post_id=new.target_post_id)
      UNION
      SELECT a.auth_user_id uid FROM public.rkms_admins a
      WHERE a.status='ACTIVE' AND upper(coalesce(a.role,''))='SUPER_ADMIN' AND a.auth_user_id IS NOT NULL
        AND upper(coalesce(new.target_audience,'ALL'))='ALL'
      UNION
      SELECT DISTINCT m.auth_user_id uid
      FROM public.rkms_officers o JOIN public.rkms_posts p ON p.id=o.post_id JOIN public.rkms_members m ON m.id=o.member_id
      WHERE o.status='ACTIVE' AND lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष'
        AND m.status='APPROVED' AND m.auth_user_id IS NOT NULL
        AND upper(coalesce(new.target_audience,'ALL'))='ALL'
    ) x WHERE x.uid IS NOT NULL
  LOOP
    INSERT INTO public.rkms_push_queue(recipient_auth_user_id,title,body,url,sender_auth_user_id,notification_id)
    VALUES(r.uid,new.title,coalesce(new.body,''),'#'||v_route,new.publisher_auth_user_id,new.id)
    RETURNING id INTO qid;
    PERFORM net.http_post(
      url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',
      body:=jsonb_build_object('queue_id',qid),
      headers:=jsonb_build_object('Content-Type','application/json','x-rkms-push-key',coalesce((SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='rkms_push_key' LIMIT 1),''))
    );
  END LOOP;
  RETURN new;
END;
$$;

-- Pending membership applications: notify the officers responsible for the applicant's area.
CREATE OR REPLACE FUNCTION public.rkms_membership_application_notification()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
DECLARE v_target text; v_value text;
BEGIN
  IF upper(coalesce(NEW.status,'PENDING')) NOT IN ('PENDING','UNDER_REVIEW') THEN RETURN NEW; END IF;
  IF TG_OP='UPDATE' AND upper(coalesce(OLD.status,''))=upper(coalesce(NEW.status,'')) THEN RETURN NEW; END IF;
  IF NEW.district IS NOT NULL AND btrim(NEW.district)<>'' THEN v_target:='DISTRICT'; v_value:=NEW.district;
  ELSIF NEW.mandal IS NOT NULL AND btrim(NEW.mandal)<>'' THEN v_target:='MANDAL'; v_value:=NEW.mandal;
  ELSIF NEW.state IS NOT NULL AND btrim(NEW.state)<>'' THEN v_target:='STATE'; v_value:=NEW.state;
  ELSE v_target:='ALL'; v_value:='ALL'; END IF;
  INSERT INTO public.rkms_notifications(
    title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id,
    target_state,target_mandal,target_district,target_tehsil,target_block,target_village,content_source_id,content_source_type
  ) VALUES(
    coalesce(NEW.name,'सदस्य')||' की नई सदस्यता',
    'नई सदस्यता का आवेदन अनुमोदन के लिए लंबित है। सदस्य: '||coalesce(NEW.name,'सदस्य')||' | मोबाइल: '||coalesce(NEW.mobile,''),
    'MEMBERSHIP_APPROVAL',v_target,v_value,'OFFICERS',true,false,NULL,
    NEW.state,NEW.mandal,NEW.district,NEW.tehsil,NEW.block,NEW.village,NEW.id,'rkms_member_applications'
  );
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rkms_membership_application_notification ON public.rkms_member_applications;
CREATE TRIGGER trg_rkms_membership_application_notification
AFTER INSERT OR UPDATE OF status ON public.rkms_member_applications
FOR EACH ROW EXECUTE FUNCTION public.rkms_membership_application_notification();

-- Appointment announcement: notify the newly appointed person plus members and subordinate PDA officers in the appointed area.
CREATE OR REPLACE FUNCTION public.rkms_officer_appointment_notify()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
DECLARE m public.rkms_members%rowtype; p public.rkms_posts%rowtype; v_post text; v_authority text; v_target text;
BEGIN
  IF TG_OP <> 'INSERT' OR upper(coalesce(NEW.status,'')) <> 'ACTIVE' THEN RETURN NEW; END IF;
  SELECT * INTO m FROM public.rkms_members WHERE id=NEW.member_id;
  IF m.id IS NULL OR m.auth_user_id IS NULL THEN RETURN NEW; END IF;
  SELECT * INTO p FROM public.rkms_posts WHERE id=NEW.post_id;
  v_post:=coalesce(p.post_name,'PDA पद'); v_authority:=coalesce(nullif(trim(NEW.appointing_authority_name),''),'अधिकृत PDA अधिकारी');

  INSERT INTO public.rkms_notifications(title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id)
  VALUES('📜 PDA नियुक्ति / पद परिवर्तन','आपकी RKMS में '||v_post||' के पद पर नियुक्ति/पद परिवर्तन किया गया है। नियुक्ति प्राधिकारी: '||v_authority||'।','PDA_APPOINTMENT','MEMBER',m.id::text,'MEMBER',true,false,(SELECT mm.auth_user_id FROM public.rkms_members mm JOIN public.rkms_officers oo ON oo.member_id=mm.id WHERE oo.id=NEW.appointed_by_officer_id));

  IF upper(coalesce(NEW.authority_level,''))='VILLAGE' THEN v_target:='VILLAGE';
  ELSIF upper(coalesce(NEW.authority_level,''))='BLOCK' THEN v_target:='BLOCK';
  ELSIF upper(coalesce(NEW.authority_level,'')) IN ('TEHSIL','TAHSIL','SUBDISTRICT') THEN v_target:='TEHSIL';
  ELSIF upper(coalesce(NEW.authority_level,''))='DISTRICT' THEN v_target:='DISTRICT';
  ELSIF upper(coalesce(NEW.authority_level,''))='MANDAL' THEN v_target:='MANDAL';
  ELSIF upper(coalesce(NEW.authority_level,''))='STATE' THEN v_target:='STATE';
  ELSE v_target:='ALL'; END IF;

  INSERT INTO public.rkms_notifications(title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id,target_state,target_mandal,target_district,target_tehsil,target_block,target_village,content_source_id,content_source_type)
  VALUES('📢 PDA अधिकारी नियुक्ति','आपके क्षेत्र में '||v_post||' के पद पर नई नियुक्ति की गई है। नियुक्त अधिकारी: '||coalesce(m.name,'पदाधिकारी')||'।','PDA_APPOINTMENT',v_target,CASE v_target WHEN 'STATE' THEN NEW.state WHEN 'MANDAL' THEN NEW.mandal WHEN 'DISTRICT' THEN NEW.district WHEN 'TEHSIL' THEN NEW.tehsil WHEN 'BLOCK' THEN NEW.block WHEN 'VILLAGE' THEN NEW.village ELSE 'ALL' END,'ALL',true,true,NULL,NEW.state,NEW.mandal,NEW.district,NEW.tehsil,NEW.block,NEW.village,NEW.id,'rkms_officers');
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN RETURN NEW;
END;
$$;

-- Existing direct membership approval push function is retained for compatibility but is no longer triggered;
-- pending approval notifications use the central notification queue above.
DROP TRIGGER IF EXISTS trg_rkms_membership_approval_push ON public.rkms_member_applications;

-- Ensure current notification queue trigger remains attached exactly once.
DROP TRIGGER IF EXISTS rkms_notifications_enqueue_push ON public.rkms_notifications;
CREATE TRIGGER rkms_notifications_enqueue_push
AFTER INSERT ON public.rkms_notifications
FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_notification_push();
