-- FINAL LAST-GAP HARDENING
-- 1) Wire membership APPROVED/REJECTED notifications to the actual member status transition.
-- 2) Ensure only one such trigger exists.
-- 3) The notification dispatcher handles direct MEMBER delivery even when the member is not APPROVED yet.

DROP TRIGGER IF EXISTS trg_rkms_member_approval_notify ON public.rkms_members;
CREATE TRIGGER trg_rkms_member_approval_notify
AFTER UPDATE OF status ON public.rkms_members
FOR EACH ROW EXECUTE FUNCTION public.rkms_member_approval_notify();

-- Keep the application-level pending notification trigger authoritative for pending/under-review applications.
DROP TRIGGER IF EXISTS trg_rkms_membership_application_notification ON public.rkms_member_applications;
CREATE TRIGGER trg_rkms_membership_application_notification
AFTER INSERT OR UPDATE OF status ON public.rkms_member_applications
FOR EACH ROW EXECUTE FUNCTION public.rkms_membership_application_notification();

-- Ensure the single central notification -> push trigger is the only active enqueue path.
DROP TRIGGER IF EXISTS rkms_notifications_enqueue_push ON public.rkms_notifications;
CREATE TRIGGER rkms_notifications_enqueue_push
AFTER INSERT ON public.rkms_notifications
FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_notification_push();
