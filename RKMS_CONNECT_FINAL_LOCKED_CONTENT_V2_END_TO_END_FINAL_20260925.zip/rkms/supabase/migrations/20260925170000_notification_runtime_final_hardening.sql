-- Final runtime hardening: never store the internal FCM push key in SQL.
CREATE OR REPLACE FUNCTION public.rkms_dispatch_chat_fcm()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO public,extensions AS $$
BEGIN
  PERFORM net.http_post(
    url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',
    body:=jsonb_build_object('queue_id',q.id),
    headers:=jsonb_build_object('Content-Type','application/json','x-rkms-push-key',coalesce((SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='rkms_push_key' LIMIT 1),''))
  ) FROM public.rkms_push_queue q WHERE q.chat_message_id=NEW.id;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_rkms_flash_push_update ON public.rkms_flash_messages;
