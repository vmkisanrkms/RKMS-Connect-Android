-- RKMS Connect: app-wide push notifications for published content updates.
-- Chat continues to use the dedicated chat push queue.

CREATE OR REPLACE FUNCTION public.rkms_enqueue_content_update_notification()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
DECLARE v_title text; v_body text; v_type text; v_published boolean := true; v_status text;
BEGIN
  IF TG_OP='UPDATE' AND (to_jsonb(NEW) - ARRAY['updated_at','created_at']) = (to_jsonb(OLD) - ARRAY['updated_at','created_at']) THEN RETURN NEW; END IF;
  IF TG_TABLE_NAME='rkms_news' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नई समाचार सूचना'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'body'),''),'RKMS Connect में नया समाचार अपडेट हुआ है।'); v_type:='CONTENT_NEWS';
  ELSIF TG_TABLE_NAME='rkms_events' THEN
    v_status:=upper(coalesce(to_jsonb(NEW)->>'status','UPCOMING')); v_published:=v_status NOT IN ('CANCELLED','DELETED','INACTIVE'); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नया कार्यक्रम'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नया कार्यक्रम अपडेट हुआ है।'); v_type:='CONTENT_EVENTS';
  ELSIF TG_TABLE_NAME='rkms_flash_messages' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'RKMS Flash सूचना'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'body'),''),'नई Flash सूचना उपलब्ध है।'); v_type:='CONTENT_FLASH';
  ELSIF TG_TABLE_NAME='rkms_gallery' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नई फोटो/मीडिया सूचना'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नई फोटो/मीडिया सामग्री उपलब्ध है।'); v_type:='CONTENT_GALLERY';
  ELSIF TG_TABLE_NAME='rkms_documents' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नया दस्तावेज'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नया दस्तावेज उपलब्ध है।'); v_type:='CONTENT_DOCUMENTS';
  ELSIF TG_TABLE_NAME='rkms_reports' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'published')::boolean,false); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नई रिपोर्ट'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नई रिपोर्ट उपलब्ध है।'); v_type:='CONTENT_REPORTS';
  ELSIF TG_TABLE_NAME='rkms_campaigns' THEN
    v_status:=upper(coalesce(to_jsonb(NEW)->>'status','ACTIVE')); v_published:=v_status NOT IN ('CANCELLED','DELETED','INACTIVE','CLOSED'); v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'title'),''),'नया अभियान'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'description'),''),'RKMS Connect में नया अभियान अपडेट हुआ है।'); v_type:='CONTENT_CAMPAIGNS';
  ELSIF TG_TABLE_NAME='rkms_leadership' THEN
    v_status:=upper(coalesce(to_jsonb(NEW)->>'status','ACTIVE')); v_published:=v_status='ACTIVE'; v_title:=coalesce(nullif(trim(to_jsonb(NEW)->>'name'),''),'नेतृत्व अपडेट'); v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'post_name'),''),'RKMS Connect में नेतृत्व संबंधी नई जानकारी उपलब्ध है।'); v_type:='CONTENT_LEADERSHIP';
  ELSIF TG_TABLE_NAME='rkms_app_updates' THEN
    v_published:=coalesce((to_jsonb(NEW)->>'is_active')::boolean,true); v_title:='RKMS Connect नया अपडेट'; v_body:=coalesce(nullif(trim(to_jsonb(NEW)->>'release_notes'),''),'RKMS Connect का नया app update उपलब्ध है।'); v_type:='APP_UPDATE';
  ELSE RETURN NEW;
  END IF;
  IF NOT v_published THEN RETURN NEW; END IF;
  INSERT INTO public.rkms_notifications(title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id)
  VALUES(v_title,v_body,v_type,'ALL','ALL','ALL',TG_TABLE_NAME IN ('rkms_flash_messages','rkms_app_updates'),true,auth.uid());
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rkms_news_push_update ON public.rkms_news;
CREATE TRIGGER trg_rkms_news_push_update AFTER INSERT OR UPDATE ON public.rkms_news FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_events_push_update ON public.rkms_events;
CREATE TRIGGER trg_rkms_events_push_update AFTER INSERT OR UPDATE ON public.rkms_events FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_flash_push_update ON public.rkms_flash_messages;
CREATE TRIGGER trg_rkms_flash_push_update AFTER INSERT OR UPDATE ON public.rkms_flash_messages FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_gallery_push_update ON public.rkms_gallery;
CREATE TRIGGER trg_rkms_gallery_push_update AFTER INSERT OR UPDATE ON public.rkms_gallery FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_documents_push_update ON public.rkms_documents;
CREATE TRIGGER trg_rkms_documents_push_update AFTER INSERT OR UPDATE ON public.rkms_documents FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_reports_push_update ON public.rkms_reports;
CREATE TRIGGER trg_rkms_reports_push_update AFTER INSERT OR UPDATE ON public.rkms_reports FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_campaigns_push_update ON public.rkms_campaigns;
CREATE TRIGGER trg_rkms_campaigns_push_update AFTER INSERT OR UPDATE ON public.rkms_campaigns FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_leadership_push_update ON public.rkms_leadership;
CREATE TRIGGER trg_rkms_leadership_push_update AFTER INSERT OR UPDATE ON public.rkms_leadership FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
DROP TRIGGER IF EXISTS trg_rkms_app_updates_push_update ON public.rkms_app_updates;
CREATE TRIGGER trg_rkms_app_updates_push_update AFTER INSERT OR UPDATE ON public.rkms_app_updates FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_content_update_notification();
