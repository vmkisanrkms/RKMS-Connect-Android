-- RKMS CONNECT Content V2 - final end-to-end hardening
-- Enforces one push per eligible user per V2 Content, adds CREATE history,
-- keeps notification cleanup synchronized, and makes Flash expiry scheduling explicit.

create table if not exists public.rkms_v2_push_dedup (
  content_id uuid not null references public.rkms_content_v2(id) on delete cascade,
  recipient_auth_user_id uuid not null,
  created_at timestamptz not null default now(),
  primary key (content_id, recipient_auth_user_id)
);

alter table public.rkms_v2_push_dedup enable row level security;

create or replace function public.rkms_v2_delete_notifications(p_content_id uuid)
returns void language plpgsql security definer set search_path=public,pg_catalog as $$
begin
  delete from public.rkms_push_queue q
   where q.notification_id in (
     select n.id from public.rkms_notifications n
      where n.content_source_id=p_content_id
        and lower(coalesce(n.content_source_type,''))='rkms_content_v2');
  delete from public.rkms_v2_push_dedup where content_id=p_content_id;
  delete from public.rkms_notifications n
   where n.content_source_id=p_content_id
     and lower(coalesce(n.content_source_type,''))='rkms_content_v2';
end $$;

-- One notification row per target area is retained for correct visibility/listing,
-- but the push queue is deduplicated by (content,user), so overlapping areas can
-- never send the same V2 Content twice to the same user.
create or replace function public.rkms_enqueue_notification_push()
returns trigger language plpgsql security definer set search_path=public,pg_catalog as $$
declare
  qid uuid; r record; v_route text; v_target text; v_audience text;
begin
  v_target:=upper(coalesce(new.target_type,'ALL'));
  v_audience:=upper(coalesce(new.target_audience,'ALL'));
  v_route:='notifications';
  if new.content_source_id is not null then
    v_route:=case lower(coalesce(new.content_source_type,''))
      when 'rkms_content_v2' then 'content-v2/'||new.content_source_id::text
      when 'rkms_news' then 'news/'||new.content_source_id::text
      when 'rkms_events' then 'events/'||new.content_source_id::text
      when 'rkms_flash_messages' then 'flash/'||new.content_source_id::text
      when 'rkms_gallery' then 'gallery/'||new.content_source_id::text
      when 'rkms_documents' then 'documents/'||new.content_source_id::text
      else 'notifications' end;
  end if;

  for r in
    select distinct x.uid from (
      select m.auth_user_id uid
      from public.rkms_members m
      where m.auth_user_id is not null
        and v_audience in ('ALL','MEMBERS','MEMBER')
        and m.status='APPROVED'
        and (
          v_target='ALL'
          or (v_target='STATE' and lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(m.state,''))))
          or (v_target='MANDAL' and lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) and lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(m.mandal,''))))
          or (v_target='DISTRICT' and lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) and lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) and lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(m.district,''))))
        )
      union
      select distinct m.auth_user_id uid
      from public.rkms_members m
      join public.rkms_officers o on o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE'
      where m.auth_user_id is not null
        and v_audience in ('ALL','OFFICERS')
        and (
          v_target='ALL'
          or (v_target='STATE' and lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(o.state,''))))
          or (v_target='MANDAL' and lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(o.state,''))) and lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(o.mandal,''))))
          or (v_target='DISTRICT' and lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(o.state,''))) and lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(o.mandal,''))) and lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(o.district,''))))
        )
      union
      select a.auth_user_id uid
      from public.rkms_admins a
      where a.status='ACTIVE' and upper(coalesce(a.role,''))='SUPER_ADMIN'
        and a.auth_user_id is not null and v_audience='ALL'
      union
      select distinct m.auth_user_id uid
      from public.rkms_officers o
      join public.rkms_posts p on p.id=o.post_id
      join public.rkms_members m on m.id=o.member_id
      where o.status='ACTIVE'
        and lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष'
        and m.status='APPROVED' and m.auth_user_id is not null
        and v_audience='ALL'
    ) x where x.uid is not null
  loop
    -- For V2 Content, claim the recipient once for the entire Content before queueing.
    -- This remains effective even when one user matches multiple target-area rows.
    if lower(coalesce(new.content_source_type,''))='rkms_content_v2' and new.content_source_id is not null then
      insert into public.rkms_v2_push_dedup(content_id,recipient_auth_user_id)
      values(new.content_source_id,r.uid)
      on conflict (content_id,recipient_auth_user_id) do nothing;
      if not found then
        continue;
      end if;
    end if;

    insert into public.rkms_push_queue(recipient_auth_user_id,title,body,url,sender_auth_user_id,notification_id)
    values(r.uid,new.title,coalesce(new.body,''),'#'||v_route,new.publisher_auth_user_id,new.id)
    returning id into qid;

    begin
      perform net.http_post(
        url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',
        body:=jsonb_build_object('queue_id',qid),
        headers:=jsonb_build_object(
          'Content-Type','application/json',
          'x-rkms-push-key',coalesce((select decrypted_secret from vault.decrypted_secrets where name='rkms_push_key' limit 1),'')
        )
      );
    exception when others then
      null;
    end;
  end loop;
  return new;
end $$;

drop trigger if exists rkms_notifications_enqueue_push on public.rkms_notifications;
create trigger rkms_notifications_enqueue_push
after insert on public.rkms_notifications
for each row execute function public.rkms_enqueue_notification_push();

-- CREATE must also have an audit record; UPDATE/DELETE history remains unchanged.
create or replace function public.rkms_v2_history_trg()
returns trigger language plpgsql security definer set search_path=public,pg_catalog as $$
begin
  if tg_op='INSERT' then
    insert into public.rkms_content_v2_history(content_id,action,content_snapshot,actor_id)
    values(new.id,'CREATE',to_jsonb(new),coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id(),auth.uid()));
    return new;
  elsif tg_op='DELETE' then
    insert into public.rkms_content_v2_history(content_id,action,content_snapshot,actor_id)
    values(old.id,'DELETE',to_jsonb(old),coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id(),auth.uid()));
    return old;
  elsif tg_op='UPDATE' then
    insert into public.rkms_content_v2_history(content_id,action,content_snapshot,actor_id)
    values(new.id,'UPDATE',to_jsonb(new),coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id(),auth.uid()));
    return new;
  end if;
  return new;
end $$;

drop trigger if exists trg_rkms_content_v2_history on public.rkms_content_v2;
create trigger trg_rkms_content_v2_history
after insert or update or delete on public.rkms_content_v2
for each row execute function public.rkms_v2_history_trg();

create or replace function public.rkms_v2_expire_flash()
returns void language plpgsql security definer set search_path=public,pg_catalog as $$
declare r record;
begin
  for r in
    select id from public.rkms_content_v2
    where content_type='FLASH' and deleted_at is null and end_at is not null and end_at<now()
  loop
    perform public.rkms_v2_delete_notifications(r.id);
    update public.rkms_content_v2
       set deleted_at=now(), deleted_by=null, updated_at=now()
     where id=r.id and deleted_at is null;
  end loop;
end $$;

-- Make server-side expiry explicit on Supabase installations with pg_cron.
-- Home RPC expiry remains as a second safety net.
do $$
begin
  begin
    perform cron.unschedule('rkms-v2-flash-expiry-cleanup');
  exception when others then
    null;
  end;
  perform cron.schedule('rkms-v2-flash-expiry-cleanup','*/10 * * * *','select public.rkms_v2_expire_flash()');
exception when undefined_table or undefined_function then
  raise warning 'RKMS V2 Flash expiry cron could not be registered; enable pg_cron and rerun the final hardening migration.';
end $$;
