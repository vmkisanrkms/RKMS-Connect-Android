-- RKMS CONNECT V2 final hardening
-- Locks hierarchy scope, keeps notifications exactly aligned with content,
-- cleans notification/queue rows on edit/delete/Flash expiry, and provides
-- an exact notification route for V2 content.

CREATE OR REPLACE FUNCTION public.rkms_v2_scope_allowed(
  p_target_type text,
  p_target_areas jsonb
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare
  s jsonb := public.rkms_content_scope_json();
  lvl text := upper(coalesce(s->>'authority_level',''));
  st text := lower(trim(coalesce(s->>'state','')));
  ma text := lower(trim(coalesce(s->>'mandal','')));
  di text := lower(trim(coalesce(s->>'district','')));
  a jsonb; at text;
begin
  if public.rkms_current_super_admin_id() is not null
     or public.rkms_is_national_president_current() then return true; end if;
  if upper(coalesce(p_target_type,''))='ALL' then return false; end if;
  if lvl not in ('STATE','MANDAL','DISTRICT') then return false; end if;
  if jsonb_typeof(p_target_areas) <> 'array' or jsonb_array_length(p_target_areas)=0 then return false; end if;

  for a in select value from jsonb_array_elements(p_target_areas) loop
    at:=upper(coalesce(a->>'type',p_target_type,''));
    if at='STATE' then
      if lvl<>'STATE' then return false; end if;
      if lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
    elsif at='MANDAL' then
      if lvl not in ('STATE','MANDAL') then return false; end if;
      if lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
      if lvl='MANDAL' and lower(trim(coalesce(a->>'mandal','')))<>ma then return false; end if;
    elsif at='DISTRICT' then
      if lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
      if lvl='STATE' then null;
      elsif lvl='MANDAL' then
        if lower(trim(coalesce(a->>'mandal','')))<>ma then return false; end if;
      elsif lvl='DISTRICT' then
        if lower(trim(coalesce(a->>'district','')))<>di then return false; end if;
      end if;
    else return false;
    end if;
  end loop;
  return true;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_v2_delete_notifications(p_content_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
begin
  delete from public.rkms_push_queue
   where notification_id in (
     select id from public.rkms_notifications
      where content_source_id=p_content_id
        and lower(coalesce(content_source_type,''))='rkms_content_v2'
   );
  delete from public.rkms_notifications
   where content_source_id=p_content_id
     and lower(coalesce(content_source_type,''))='rkms_content_v2';
end $$;

CREATE OR REPLACE FUNCTION public.rkms_v2_create_notifications(p_content_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare c record; a jsonb; ntype text;
begin
  select * into c from public.rkms_content_v2 where id=p_content_id and deleted_at is null;
  if not found then return; end if;
  ntype:=case c.content_type when 'COURT_ORDER' then 'CONTENT_COURT_ORDER'
                              when 'ORG_NOTICE' then 'CONTENT_ORG_NOTICE'
                              when 'EVENT' then 'CONTENT_EVENTS'
                              else 'CONTENT_FLASH' end;
  for a in select value from jsonb_array_elements(c.target_areas) loop
    insert into public.rkms_notifications(
      title,body,notification_type,target_type,target_value,target_audience,
      is_important,is_public,publisher_auth_user_id,content_source_id,
      content_source_type,target_state,target_mandal,target_district
    ) values (
      coalesce(c.title,'RKMS सूचना'),coalesce(c.description,'नई संगठन सामग्री उपलब्ध है।'),ntype,
      case when upper(a->>'type')='ALL' then 'ALL' else upper(a->>'type') end,
      case when upper(a->>'type')='ALL' then 'ALL'
           when upper(a->>'type')='STATE' then a->>'state'
           when upper(a->>'type')='MANDAL' then a->>'mandal'
           else a->>'district' end,
      c.target_audience,c.priority,true,c.created_by,p_content_id,'rkms_content_v2',
      a->>'state',a->>'mandal',a->>'district'
    );
  end loop;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_manage_content_v2(
  p_action text, p_id uuid default null, p_data jsonb default '{}'::jsonb
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare
  actor uuid := coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id());
  top_user boolean := public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current();
  oldc public.rkms_content_v2%rowtype;
  ct text := upper(trim(coalesce(p_data->>'content_type','')));
  tt text := upper(trim(coalesce(p_data->>'target_type','')));
  areas jsonb := coalesce(p_data->'target_areas','[]'::jsonb);
  aud text := upper(trim(coalesce(p_data->>'target_audience','ALL')));
  pr boolean := coalesce((p_data->>'priority')::boolean,false);
  id2 uuid;
begin
  if actor is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;

  if upper(p_action)='CREATE' then
    if ct not in ('COURT_ORDER','ORG_NOTICE','EVENT','FLASH') then return jsonb_build_object('success',false,'message','अमान्य Content type।'); end if;
    if ct in ('COURT_ORDER','FLASH') and not top_user then return jsonb_build_object('success',false,'message','यह Content केवल Super Admin या राष्ट्रीय अध्यक्ष जारी कर सकते हैं।'); end if;
    if aud not in ('OFFICERS','MEMBERS','ALL') then return jsonb_build_object('success',false,'message','Audience अमान्य है।'); end if;
    if tt='ALL' then
      if not top_user then return jsonb_build_object('success',false,'message','पूरा संगठन target करने का अधिकार नहीं है।'); end if;
      areas:='[{"type":"ALL"}]'::jsonb;
    elsif not public.rkms_v2_scope_allowed(tt,areas) then
      return jsonb_build_object('success',false,'message','आप अपने अधिकार क्षेत्र के बाहर Content नहीं डाल सकते।');
    end if;
    if ct='FLASH' and nullif(p_data->>'end_at','') is null then return jsonb_build_object('success',false,'message','Flash का End Date/Time जरूरी है।'); end if;
    insert into public.rkms_content_v2(content_type,title,description,event_date,event_time,location,attachments,target_type,target_areas,target_audience,priority,start_at,end_at,created_by,updated_by)
    values(ct,nullif(trim(p_data->>'title'),''),p_data->>'description',nullif(p_data->>'event_date','')::date,p_data->>'event_time',p_data->>'location',areas,tt,areas,aud,case when ct='COURT_ORDER' then false else pr end,nullif(p_data->>'start_at','')::timestamptz,nullif(p_data->>'end_at','')::timestamptz,actor,actor)
    returning id into id2;
    perform public.rkms_v2_create_notifications(id2);
    return jsonb_build_object('success',true,'id',id2,'action','CREATE');
  end if;

  if p_id is null then return jsonb_build_object('success',false,'message','Content ID जरूरी है।'); end if;
  select * into oldc from public.rkms_content_v2 where id=p_id;
  if not found or oldc.deleted_at is not null then return jsonb_build_object('success',false,'message','Content उपलब्ध नहीं है।'); end if;
  if not public.rkms_v2_can_manage(oldc.content_type,p_action,p_id) then return jsonb_build_object('success',false,'message','इस Content पर अधिकार नहीं है।'); end if;

  if upper(p_action)='UPDATE' then
    if ct='' then ct:=oldc.content_type; end if;
    if tt='' then tt:=oldc.target_type; areas:=oldc.target_areas; else areas:=coalesce(p_data->'target_areas',oldc.target_areas); end if;
    if aud='' then aud:=oldc.target_audience; end if;
    if tt='ALL' and not top_user then return jsonb_build_object('success',false,'message','पूरा संगठन target करने का अधिकार नहीं है।'); end if;
    if tt<>'ALL' and not public.rkms_v2_scope_allowed(tt,areas) then return jsonb_build_object('success',false,'message','Targeting आपके अधिकार क्षेत्र से बाहर है।'); end if;
    if oldc.content_type='FLASH' and nullif(coalesce(p_data->>'end_at',oldc.end_at::text),'') is null then return jsonb_build_object('success',false,'message','Flash का End Date/Time जरूरी है।'); end if;
    update public.rkms_content_v2 set
      title=coalesce(nullif(trim(p_data->>'title'),''),title),description=coalesce(p_data->>'description',description),
      event_date=case when p_data ? 'event_date' and nullif(p_data->>'event_date','') is not null then (p_data->>'event_date')::date else event_date end,
      event_time=coalesce(p_data->>'event_time',event_time),location=coalesce(p_data->>'location',location),
      attachments=case when p_data ? 'attachments' then p_data->'attachments' else attachments end,
      target_type=tt,target_areas=areas,target_audience=aud,
      priority=case when content_type='COURT_ORDER' then false else coalesce((p_data->>'priority')::boolean,priority) end,
      start_at=case when p_data ? 'start_at' then nullif(p_data->>'start_at','')::timestamptz else start_at end,
      end_at=case when p_data ? 'end_at' then nullif(p_data->>'end_at','')::timestamptz else end_at end,
      updated_by=actor,updated_at=now()
    where id=p_id;
    perform public.rkms_v2_delete_notifications(p_id);
    perform public.rkms_v2_create_notifications(p_id);
    return jsonb_build_object('success',true,'id',p_id,'action','UPDATE');
  elsif upper(p_action)='DELETE' then
    perform public.rkms_v2_delete_notifications(p_id);
    update public.rkms_content_v2 set deleted_at=now(),deleted_by=actor,updated_by=actor,updated_at=now() where id=p_id;
    return jsonb_build_object('success',true,'id',p_id,'action','DELETE');
  end if;
  return jsonb_build_object('success',false,'message','Invalid action.');
exception when others then return jsonb_build_object('success',false,'message',sqlerrm);
end $$;

CREATE OR REPLACE FUNCTION public.rkms_v2_expire_flash()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare r record;
begin
  for r in select id from public.rkms_content_v2 where content_type='FLASH' and deleted_at is null and end_at is not null and end_at<now() loop
    perform public.rkms_v2_delete_notifications(r.id);
    update public.rkms_content_v2 set deleted_at=now(),deleted_by=null,updated_at=now() where id=r.id;
  end loop;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_get_home_content_v2(p_limit int default 50)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare u jsonb:=public.rkms_v2_user_scope(); r jsonb;
begin
  perform public.rkms_v2_expire_flash();
  select coalesce(jsonb_agg(to_jsonb(x) order by x.priority desc,x.created_at desc),'[]'::jsonb) into r
  from (
    select c.*,case when c.content_type='EVENT' then 'कार्यक्रम' when c.content_type='ORG_NOTICE' then 'संगठन सूचना' when c.content_type='FLASH' then 'Flash' else 'न्यायालय आदेश' end as type_label
    from public.rkms_content_v2 c cross join lateral jsonb_array_elements(c.target_areas) a
    where c.deleted_at is null and (c.content_type<>'FLASH' or c.end_at is null or c.end_at>=now())
      and (upper(a->>'type')='ALL' or (upper(a->>'type')='STATE' and lower(a->>'state')=lower(coalesce(u->>'state',''))) or (upper(a->>'type')='MANDAL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal',''))) or (upper(a->>'type')='DISTRICT' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district',''))))
      and (c.target_audience='ALL' or c.target_audience=u->>'audience' or (u->>'role')='TOP')
  ) x limit greatest(1,least(p_limit,200));
  return r;
end $$;

-- Replace the old best-effort cron with the notification-aware expiry routine.
do $$ begin
  begin perform cron.unschedule('rkms-v2-flash-expiry-cleanup'); exception when others then null; end;
  begin perform cron.schedule('rkms-v2-flash-expiry-cleanup','*/10 * * * *','select public.rkms_v2_expire_flash()'); exception when others then null; end;
end $$;

-- Make V2 notifications open the exact V2 content detail.
CREATE OR REPLACE FUNCTION public.rkms_enqueue_notification_push()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO public, extensions
AS $$
DECLARE qid uuid; r record; v_route text; v_target text; v_rank integer; v_audience text;
BEGIN
  v_target:=upper(coalesce(new.target_type,'ALL')); v_audience:=upper(coalesce(new.target_audience,'ALL')); v_rank:=public.rkms_level_rank(v_target);
  v_route:='notifications';
  IF new.content_source_id IS NOT NULL THEN
    v_route:=CASE lower(coalesce(new.content_source_type,''))
      WHEN 'rkms_content_v2' THEN 'content-v2/'||new.content_source_id::text
      WHEN 'rkms_news' THEN 'news/'||new.content_source_id::text
      WHEN 'rkms_events' THEN 'events/'||new.content_source_id::text
      WHEN 'rkms_flash_messages' THEN 'flash/'||new.content_source_id::text
      WHEN 'rkms_gallery' THEN 'gallery/'||new.content_source_id::text
      WHEN 'rkms_documents' THEN 'documents/'||new.content_source_id::text
      WHEN 'rkms_reports' THEN 'reports/'||new.content_source_id::text
      WHEN 'rkms_campaigns' THEN 'campaigns/'||new.content_source_id::text
      WHEN 'rkms_leadership' THEN 'leadership/'||new.content_source_id::text
      WHEN 'rkms_member_applications' THEN 'pending/'||new.content_source_id::text
      ELSE 'notifications' END;
  END IF;
  FOR r IN
    SELECT DISTINCT x.uid FROM (
      SELECT m.auth_user_id uid FROM public.rkms_members m
      WHERE m.auth_user_id IS NOT NULL AND v_audience IN ('ALL','MEMBERS','MEMBER') AND (m.status='APPROVED' OR (v_target='MEMBER' AND upper(coalesce(new.notification_type,'')) IN ('MEMBERSHIP_APPROVED','MEMBERSHIP_REJECTED','PDA_REMOVED')))
        AND (v_target='ALL' OR (v_target='STATE' AND lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(m.state,'')))) OR (v_target='MANDAL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(m.mandal,'')))) OR (v_target='DISTRICT' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(m.district,'')))))
      UNION
      SELECT DISTINCT m.auth_user_id uid FROM public.rkms_members m JOIN public.rkms_officers o ON o.member_id=m.id AND upper(coalesce(o.status,''))='ACTIVE'
      WHERE m.auth_user_id IS NOT NULL AND v_audience IN ('ALL','OFFICERS') AND (v_target='ALL' OR (v_target='STATE' AND lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(o.state,'')))) OR (v_target='MANDAL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(o.state,''))) AND lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(o.mandal,'')))) OR (v_target='DISTRICT' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(o.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(o.mandal,''))) AND lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(o.district,'')))))
      UNION SELECT a.auth_user_id uid FROM public.rkms_admins a WHERE a.status='ACTIVE' AND upper(coalesce(a.role,''))='SUPER_ADMIN' AND a.auth_user_id IS NOT NULL AND v_audience='ALL'
      UNION SELECT DISTINCT m.auth_user_id uid FROM public.rkms_officers o JOIN public.rkms_posts p ON p.id=o.post_id JOIN public.rkms_members m ON m.id=o.member_id WHERE o.status='ACTIVE' AND lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष' AND m.status='APPROVED' AND m.auth_user_id IS NOT NULL AND v_audience='ALL'
    ) x WHERE x.uid IS NOT NULL
  LOOP
    INSERT INTO public.rkms_push_queue(recipient_auth_user_id,title,body,url,sender_auth_user_id,notification_id)
    VALUES(r.uid,new.title,coalesce(new.body,''),'#'||v_route,new.publisher_auth_user_id,new.id) RETURNING id INTO qid;
    PERFORM net.http_post(url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',body:=jsonb_build_object('queue_id',qid),headers:=jsonb_build_object('Content-Type','application/json','x-rkms-push-key',coalesce((SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='rkms_push_key' LIMIT 1),'')));
  END LOOP;
  RETURN new;
END;
$$;
