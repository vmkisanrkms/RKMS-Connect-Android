-- RKMS FINAL MERGED NOTIFICATION HARDENING
-- This migration supersedes the earlier 20260925 notification routing fixes.
-- It deliberately keeps FCM authentication in Supabase Vault; no push secret is stored in source.

ALTER TABLE public.rkms_reports
  ADD COLUMN IF NOT EXISTS scope_officer_id uuid,
  ADD COLUMN IF NOT EXISTS scope_state text,
  ADD COLUMN IF NOT EXISTS scope_mandal text,
  ADD COLUMN IF NOT EXISTS scope_district text,
  ADD COLUMN IF NOT EXISTS scope_tehsil text,
  ADD COLUMN IF NOT EXISTS scope_block text,
  ADD COLUMN IF NOT EXISTS scope_village text;

ALTER TABLE public.rkms_campaigns
  ADD COLUMN IF NOT EXISTS scope_officer_id uuid,
  ADD COLUMN IF NOT EXISTS scope_state text,
  ADD COLUMN IF NOT EXISTS scope_mandal text,
  ADD COLUMN IF NOT EXISTS scope_district text,
  ADD COLUMN IF NOT EXISTS scope_tehsil text,
  ADD COLUMN IF NOT EXISTS scope_block text,
  ADD COLUMN IF NOT EXISTS scope_village text;

-- Single central content notification trigger. It creates one scoped notification per published record.
CREATE OR REPLACE FUNCTION public.rkms_notify_content_published()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
DECLARE
  j jsonb := to_jsonb(NEW);
  oldj jsonb := CASE WHEN TG_OP='UPDATE' THEN to_jsonb(OLD) ELSE '{}'::jsonb END;
  v_type text; v_title text; v_body text; v_state text; v_mandal text; v_district text;
  v_tehsil text; v_block text; v_village text; v_scope text; v_target_value text;
  v_officer uuid; v_publisher uuid; v_source uuid := NEW.id; v_url text; v_status text;
  v_pub boolean := true;
BEGIN
  IF TG_OP='DELETE' THEN RETURN OLD; END IF;

  CASE TG_TABLE_NAME
    WHEN 'rkms_news' THEN
      v_type:='CONTENT_NEWS'; v_pub:=coalesce((j->>'published')::boolean,false);
      v_title:=coalesce(nullif(trim(j->>'title'),''),'नई समाचार सूचना');
      v_body:=coalesce(nullif(trim(j->>'body'),''),'RKMS Connect में नया समाचार अपडेट हुआ है।');
    WHEN 'rkms_events' THEN
      v_type:='CONTENT_EVENTS'; v_status:=upper(coalesce(j->>'status','UPCOMING'));
      v_pub:=v_status NOT IN ('CANCELLED','DELETED','INACTIVE');
      v_title:=coalesce(nullif(trim(j->>'title'),''),'नया कार्यक्रम');
      v_body:=coalesce(nullif(trim(j->>'description'),''),'RKMS Connect में नया कार्यक्रम अपडेट हुआ है।');
    WHEN 'rkms_flash_messages' THEN
      v_type:='CONTENT_FLASH'; v_pub:=coalesce((j->>'published')::boolean,false);
      v_title:=coalesce(nullif(trim(j->>'title'),''),'RKMS Flash सूचना');
      v_body:=coalesce(nullif(trim(j->>'body'),''),'नई Flash सूचना उपलब्ध है।');
    WHEN 'rkms_gallery' THEN
      v_type:='CONTENT_GALLERY'; v_pub:=coalesce((j->>'published')::boolean,false);
      v_title:=coalesce(nullif(trim(j->>'title'),''),'नई फोटो/मीडिया सूचना');
      v_body:=coalesce(nullif(trim(j->>'description'),''),'RKMS Connect में नई फोटो/मीडिया सामग्री उपलब्ध है।');
    WHEN 'rkms_documents' THEN
      v_type:='CONTENT_DOCUMENTS'; v_pub:=coalesce((j->>'published')::boolean,false);
      v_title:=coalesce(nullif(trim(j->>'title'),''),'नया दस्तावेज');
      v_body:=coalesce(nullif(trim(j->>'description'),''),'RKMS Connect में नया दस्तावेज उपलब्ध है।');
    WHEN 'rkms_reports' THEN
      v_type:='CONTENT_REPORTS'; v_pub:=coalesce((j->>'published')::boolean,true);
      v_title:=coalesce(nullif(trim(j->>'title'),''),'नई रिपोर्ट');
      v_body:=coalesce(nullif(trim(j->>'description'),''),'RKMS Connect में नई रिपोर्ट उपलब्ध है।');
    WHEN 'rkms_campaigns' THEN
      v_type:='CONTENT_CAMPAIGNS'; v_status:=upper(coalesce(j->>'status','ACTIVE'));
      v_pub:=v_status NOT IN ('CANCELLED','DELETED','INACTIVE','CLOSED');
      v_title:=coalesce(nullif(trim(j->>'title'),''),'नया अभियान');
      v_body:=coalesce(nullif(trim(j->>'description'),''),'RKMS Connect में नया अभियान अपडेट हुआ है।');
    WHEN 'rkms_leadership' THEN
      v_type:='CONTENT_LEADERSHIP'; v_status:=upper(coalesce(j->>'status','ACTIVE')); v_pub:=v_status='ACTIVE';
      v_title:=coalesce(nullif(trim(j->>'name'),''),'नेतृत्व अपडेट');
      v_body:=coalesce(nullif(trim(j->>'post_name'),''),'RKMS Connect में नेतृत्व संबंधी नई जानकारी उपलब्ध है।');
    ELSE RETURN NEW;
  END CASE;

  IF NOT v_pub THEN RETURN NEW; END IF;
  -- Court Orders must never silently fall back to a global/ALL audience.
  -- They require at least one explicit geographic scope; the authority guard
  -- remains responsible for who may publish them.
  IF TG_TABLE_NAME='rkms_documents' AND upper(coalesce(j->>'category',''))='COURT_ORDER'
     AND nullif(trim(coalesce(j->>'scope_state',j->>'state',j->>'target_state','')),'') IS NULL
     AND nullif(trim(coalesce(j->>'scope_mandal',j->>'mandal',j->>'target_mandal','')),'') IS NULL
     AND nullif(trim(coalesce(j->>'scope_district',j->>'district',j->>'target_district','')),'') IS NULL
     AND nullif(trim(coalesce(j->>'scope_tehsil',j->>'tehsil',j->>'target_tehsil','')),'') IS NULL
     AND nullif(trim(coalesce(j->>'scope_block',j->>'block',j->>'target_block','')),'') IS NULL
     AND nullif(trim(coalesce(j->>'scope_village',j->>'village',j->>'target_village','')),'') IS NULL
     AND nullif(j->>'scope_officer_id','') IS NULL THEN
    RETURN NEW;
  END IF;
  -- Only fire when a record is newly published. Normal edits must not spam users.
  IF TG_OP='UPDATE' AND coalesce((oldj->>'published')::boolean,false) IS TRUE THEN RETURN NEW; END IF;

  IF EXISTS (
    SELECT 1 FROM public.rkms_notifications n
    WHERE n.content_source_id=v_source
      AND lower(coalesce(n.content_source_type,''))=lower(TG_TABLE_NAME)
      AND n.notification_type LIKE 'CONTENT_%'
  ) THEN RETURN NEW; END IF;

  v_state:=nullif(trim(coalesce(j->>'scope_state',j->>'state',j->>'target_state','')),'');
  v_mandal:=nullif(trim(coalesce(j->>'scope_mandal',j->>'mandal',j->>'target_mandal','')),'');
  v_district:=nullif(trim(coalesce(j->>'scope_district',j->>'district',j->>'target_district','')),'');
  v_tehsil:=nullif(trim(coalesce(j->>'scope_tehsil',j->>'tehsil',j->>'target_tehsil','')),'');
  v_block:=nullif(trim(coalesce(j->>'scope_block',j->>'block',j->>'target_block','')),'');
  v_village:=nullif(trim(coalesce(j->>'scope_village',j->>'village',j->>'target_village','')),'');

  IF nullif(j->>'scope_officer_id','') IS NOT NULL AND (v_state IS NULL OR v_mandal IS NULL OR v_district IS NULL) THEN
    SELECT o.state,o.mandal,o.district,o.tehsil,o.block,o.village
      INTO v_state,v_mandal,v_district,v_tehsil,v_block,v_village
    FROM public.rkms_officers o WHERE o.id=(j->>'scope_officer_id')::uuid;
  END IF;

  -- National publisher content is global. Otherwise the deepest supplied scope wins.
  IF nullif(j->>'scope_officer_id','') IS NOT NULL THEN
    SELECT o.authority_level INTO v_status FROM public.rkms_officers o WHERE o.id=(j->>'scope_officer_id')::uuid;
  END IF;
  IF upper(coalesce(v_status,''))='NATIONAL' THEN
    v_scope:='ALL';
  ELSIF v_village IS NOT NULL THEN v_scope:='VILLAGE';
  ELSIF v_block IS NOT NULL THEN v_scope:='BLOCK';
  ELSIF v_tehsil IS NOT NULL THEN v_scope:='TEHSIL';
  ELSIF v_district IS NOT NULL THEN v_scope:='DISTRICT';
  ELSIF v_mandal IS NOT NULL THEN v_scope:='MANDAL';
  ELSIF v_state IS NOT NULL THEN v_scope:='STATE';
  ELSE v_scope:='ALL'; END IF;

  v_target_value:=CASE v_scope
    WHEN 'STATE' THEN v_state WHEN 'MANDAL' THEN v_mandal WHEN 'DISTRICT' THEN v_district
    WHEN 'TEHSIL' THEN v_tehsil WHEN 'BLOCK' THEN v_block WHEN 'VILLAGE' THEN v_village ELSE 'ALL' END;
  v_url:=coalesce(j->>'file_url',j->>'media_url',j->>'image_url');

  IF nullif(coalesce(j->>'created_by',j->>'uploaded_by',j->>'publisher_id',j->>'updated_by'),'') IS NOT NULL THEN
    v_publisher:=(coalesce(j->>'created_by',j->>'uploaded_by',j->>'publisher_id',j->>'updated_by'))::uuid;
  END IF;

  INSERT INTO public.rkms_notifications(
    title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,
    publisher_auth_user_id,target_state,target_mandal,target_district,target_tehsil,target_block,target_village,
    attachment_url,attachment_name,content_source_id,content_source_type
  ) VALUES(
    v_title,v_body,v_type,v_scope,v_target_value,'ALL',v_type='CONTENT_FLASH',true,v_publisher,
    v_state,v_mandal,v_district,v_tehsil,v_block,v_village,v_url,coalesce(j->>'attachment_name',j->>'title'),v_source,TG_TABLE_NAME
  );
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Notification failure must never roll back the actual content publish.
  RETURN NEW;
END;
$$;

-- Remove all known legacy content push triggers, then install exactly one central trigger per content table.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['rkms_news','rkms_events','rkms_flash_messages','rkms_gallery','rkms_documents','rkms_reports','rkms_campaigns','rkms_leadership'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_rkms_%s_push_update ON public.%I',replace(t,'rkms_',''),t);
    EXECUTE format('DROP TRIGGER IF EXISTS trg_rkms_content_notification ON public.%I',t);
    EXECUTE format('CREATE TRIGGER trg_rkms_content_notification AFTER INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.rkms_notify_content_published()',t);
  END LOOP;
  DROP TRIGGER IF EXISTS rkms_news_content_notification ON public.rkms_news;
  DROP TRIGGER IF EXISTS rkms_documents_content_notification ON public.rkms_documents;
END $$;

-- Final push dispatcher. Exact content routes use LOWER() so stored table names such as
-- rkms_news/rkms_events always match. FCM authentication is read only from Vault.
CREATE OR REPLACE FUNCTION public.rkms_enqueue_notification_push()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO public, extensions
AS $$
DECLARE qid uuid; r record; v_route text; v_target text; v_rank integer; v_audience text;
BEGIN
  v_target:=upper(coalesce(new.target_type,'ALL'));
  v_audience:=upper(coalesce(new.target_audience,'ALL'));
  v_rank:=public.rkms_level_rank(v_target);
  v_route:=CASE upper(coalesce(new.notification_type,''))
    WHEN 'CONTENT_NEWS' THEN 'news' WHEN 'CONTENT_EVENTS' THEN 'events' WHEN 'CONTENT_FLASH' THEN 'flash'
    WHEN 'CONTENT_GALLERY' THEN 'gallery' WHEN 'CONTENT_DOCUMENTS' THEN 'documents' WHEN 'CONTENT_REPORTS' THEN 'reports'
    WHEN 'CONTENT_CAMPAIGNS' THEN 'campaigns' WHEN 'CONTENT_LEADERSHIP' THEN 'leadership' WHEN 'APP_UPDATE' THEN 'notifications'
    WHEN 'MEMBERSHIP_APPROVAL' THEN 'pending' WHEN 'PDA_APPOINTMENT' THEN 'directory' ELSE 'notifications' END;

  -- Exact content destination. LOWER() is intentional and fixes the earlier case mismatch.
  IF new.content_source_id IS NOT NULL THEN
    v_route:=CASE lower(coalesce(new.content_source_type,''))
      WHEN 'rkms_news' THEN 'news/'||new.content_source_id::text
      WHEN 'rkms_events' THEN 'events/'||new.content_source_id::text
      WHEN 'rkms_flash_messages' THEN 'flash/'||new.content_source_id::text
      WHEN 'rkms_gallery' THEN 'gallery/'||new.content_source_id::text
      WHEN 'rkms_documents' THEN 'documents/'||new.content_source_id::text
      WHEN 'rkms_reports' THEN 'reports/'||new.content_source_id::text
      WHEN 'rkms_campaigns' THEN 'campaigns/'||new.content_source_id::text
      WHEN 'rkms_leadership' THEN 'leadership/'||new.content_source_id::text
      WHEN 'rkms_member_applications' THEN 'pending/'||new.content_source_id::text
      ELSE v_route END;
  END IF;

  -- Only the direct appointed member gets the officer detail route.
  -- Area-wide PDA appointment notices deliberately carry no content_source_id and remain directory-scoped.
  IF upper(coalesce(new.notification_type,''))='PDA_APPOINTMENT'
     AND v_target='MEMBER' AND v_audience IN ('MEMBER','MEMBERS')
     AND lower(coalesce(new.content_source_type,''))='rkms_officers'
     AND new.content_source_id IS NOT NULL THEN
    v_route:='officer/'||new.content_source_id::text;
  END IF;

  IF v_target='MEMBER' AND upper(coalesce(new.notification_type,'')) IN ('MEMBERSHIP_APPROVED','MEMBERSHIP_REJECTED','PDA_REMOVED') THEN
    v_route:='notifications';
  END IF;

  FOR r IN
    SELECT DISTINCT x.uid FROM (
      SELECT m.auth_user_id uid
      FROM public.rkms_members m
      WHERE m.auth_user_id IS NOT NULL AND v_audience IN ('ALL','MEMBERS','MEMBER')
        AND (m.status='APPROVED' OR (v_target='MEMBER' AND upper(coalesce(new.notification_type,'')) IN ('MEMBERSHIP_APPROVED','MEMBERSHIP_REJECTED','PDA_REMOVED')))
        AND (
          v_target='ALL' OR (v_target='MEMBER' AND lower(coalesce(new.target_value,''))=lower(m.id::text))
          OR (v_target='STATE' AND lower(trim(coalesce(new.target_state,new.target_value,'')))=lower(trim(coalesce(m.state,''))))
          OR (v_target='MANDAL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,new.target_value,'')))=lower(trim(coalesce(m.mandal,''))))
          OR (v_target='DISTRICT' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,new.target_value,'')))=lower(trim(coalesce(m.district,''))))
          OR (v_target='TEHSIL' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,'')))=lower(trim(coalesce(m.district,''))) AND lower(trim(coalesce(new.target_tehsil,new.target_value,'')))=lower(trim(coalesce(m.tehsil,''))))
          OR (v_target='BLOCK' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,'')))=lower(trim(coalesce(m.district,''))) AND lower(trim(coalesce(new.target_tehsil,'')))=lower(trim(coalesce(m.tehsil,''))) AND lower(trim(coalesce(new.target_block,new.target_value,'')))=lower(trim(coalesce(m.block,''))))
          OR (v_target='VILLAGE' AND lower(trim(coalesce(new.target_state,'')))=lower(trim(coalesce(m.state,''))) AND lower(trim(coalesce(new.target_mandal,'')))=lower(trim(coalesce(m.mandal,''))) AND lower(trim(coalesce(new.target_district,'')))=lower(trim(coalesce(m.district,''))) AND lower(trim(coalesce(new.target_tehsil,'')))=lower(trim(coalesce(m.tehsil,''))) AND lower(trim(coalesce(new.target_block,'')))=lower(trim(coalesce(m.block,''))) AND lower(trim(coalesce(new.target_village,new.target_value,'')))=lower(trim(coalesce(m.village,''))))
        )
        AND (new.target_post_id IS NULL OR EXISTS(SELECT 1 FROM public.rkms_officers o WHERE o.member_id=m.id AND o.status='ACTIVE' AND o.post_id=new.target_post_id))
      UNION
      -- Direct officer notifications (e.g. membership approval authority).
      SELECT DISTINCT m.auth_user_id uid
      FROM public.rkms_members m
      JOIN public.rkms_officers o ON o.member_id=m.id AND upper(coalesce(o.status,''))='ACTIVE'
      WHERE m.auth_user_id IS NOT NULL AND v_target='OFFICER' AND v_audience IN ('ALL','OFFICERS')
        AND lower(coalesce(new.target_value,''))=lower(o.id::text)
        AND (new.target_post_id IS NULL OR o.post_id=new.target_post_id)
      UNION
      SELECT DISTINCT m.auth_user_id uid
      FROM public.rkms_members m JOIN public.rkms_officers o ON o.member_id=m.id AND upper(coalesce(o.status,''))='ACTIVE'
      WHERE m.auth_user_id IS NOT NULL AND v_audience IN ('ALL','OFFICERS')
        AND (
          v_target='ALL'
          OR (v_target='STATE' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) < v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,new.target_value,''))))
          OR (v_target='MANDAL' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) < v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,new.target_value,''))))
          OR (v_target='DISTRICT' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) < v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,new.target_value,''))))
          OR (v_target='TEHSIL' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) < v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,''))) AND lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(new.target_tehsil,new.target_value,''))))
          OR (v_target='BLOCK' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) < v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,''))) AND lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(new.target_tehsil,''))) AND lower(trim(coalesce(o.block,'')))=lower(trim(coalesce(new.target_block,new.target_value,''))))
          OR (v_target='VILLAGE' AND public.rkms_level_rank(upper(coalesce(o.authority_level,''))) < v_rank AND lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(new.target_state,''))) AND lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(new.target_mandal,''))) AND lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(new.target_district,''))) AND lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(new.target_tehsil,''))) AND lower(trim(coalesce(o.block,'')))=lower(trim(coalesce(new.target_block,''))) AND lower(trim(coalesce(o.village,'')))=lower(trim(coalesce(new.target_village,new.target_value,''))))
        )
        AND (new.target_post_id IS NULL OR o.post_id=new.target_post_id)
      UNION
      SELECT a.auth_user_id uid FROM public.rkms_admins a
      WHERE a.status='ACTIVE' AND upper(coalesce(a.role,''))='SUPER_ADMIN' AND a.auth_user_id IS NOT NULL AND v_audience='ALL'
      UNION
      SELECT DISTINCT m.auth_user_id uid FROM public.rkms_officers o JOIN public.rkms_posts p ON p.id=o.post_id JOIN public.rkms_members m ON m.id=o.member_id
      WHERE o.status='ACTIVE' AND lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष' AND m.status='APPROVED' AND m.auth_user_id IS NOT NULL AND v_audience='ALL'
    ) x WHERE x.uid IS NOT NULL
  LOOP
    INSERT INTO public.rkms_push_queue(recipient_auth_user_id,title,body,url,sender_auth_user_id,notification_id)
    VALUES(r.uid,new.title,coalesce(new.body,''),'#'||v_route,new.publisher_auth_user_id,new.id)
    RETURNING id INTO qid;
    PERFORM net.http_post(
      url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',
      body:=jsonb_build_object('queue_id',qid),
      headers:=jsonb_build_object('Content-Type','application/json','x-rkms-push-key',coalesce((SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='rkms_push_key' LIMIT 1),''))
    );
  END LOOP;
  RETURN new;
END;
$$;

-- Membership approval: choose the exact responsible authority first, then move upward one level at a time.
CREATE OR REPLACE FUNCTION public.rkms_membership_application_notification()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO public, pg_catalog
AS $$
DECLARE v_level text; v_officer uuid; v_post uuid; o public.rkms_officers%rowtype; levels text[];
BEGIN
  IF upper(coalesce(NEW.status,'PENDING')) NOT IN ('PENDING','UNDER_REVIEW') THEN RETURN NEW; END IF;
  IF TG_OP='UPDATE' AND upper(coalesce(OLD.status,''))=upper(coalesce(NEW.status,'')) THEN RETURN NEW; END IF;

  v_level:=CASE
    WHEN btrim(coalesce(NEW.village,''))<>'' THEN 'VILLAGE'
    WHEN btrim(coalesce(NEW.block,''))<>'' THEN 'BLOCK'
    WHEN btrim(coalesce(NEW.tehsil,''))<>'' THEN 'TEHSIL'
    WHEN btrim(coalesce(NEW.district,''))<>'' THEN 'DISTRICT'
    WHEN btrim(coalesce(NEW.mandal,''))<>'' THEN 'MANDAL'
    WHEN btrim(coalesce(NEW.state,''))<>'' THEN 'STATE'
    ELSE 'NATIONAL' END;

  levels:=CASE v_level
    WHEN 'VILLAGE' THEN ARRAY['VILLAGE','BLOCK','TEHSIL','DISTRICT','MANDAL','STATE','NATIONAL']
    WHEN 'BLOCK' THEN ARRAY['BLOCK','TEHSIL','DISTRICT','MANDAL','STATE','NATIONAL']
    WHEN 'TEHSIL' THEN ARRAY['TEHSIL','DISTRICT','MANDAL','STATE','NATIONAL']
    WHEN 'DISTRICT' THEN ARRAY['DISTRICT','MANDAL','STATE','NATIONAL']
    WHEN 'MANDAL' THEN ARRAY['MANDAL','STATE','NATIONAL']
    WHEN 'STATE' THEN ARRAY['STATE','NATIONAL']
    ELSE ARRAY['NATIONAL'] END;

  FOR v_level IN SELECT unnest(levels) LOOP
    o:=NULL;
    IF v_level='NATIONAL' THEN
      SELECT oo.* INTO o FROM public.rkms_officers oo JOIN public.rkms_posts pp ON pp.id=oo.post_id
      WHERE upper(coalesce(oo.status,''))='ACTIVE'
        AND (upper(coalesce(oo.authority_level,pp.level,''))='NATIONAL' OR lower(trim(coalesce(pp.post_name,''))) IN ('राष्ट्रीय अध्यक्ष','national president'))
      ORDER BY oo.created_at LIMIT 1;
    ELSE
      SELECT oo.* INTO o FROM public.rkms_officers oo JOIN public.rkms_posts pp ON pp.id=oo.post_id
      WHERE upper(coalesce(oo.status,''))='ACTIVE'
        AND upper(coalesce(oo.authority_level,pp.level,''))=v_level
        AND (v_level IN ('STATE','NATIONAL') OR lower(trim(coalesce(oo.state,'')))=lower(trim(coalesce(NEW.state,''))))
        AND (v_level IN ('STATE','MANDAL','NATIONAL') OR lower(trim(coalesce(oo.mandal,'')))=lower(trim(coalesce(NEW.mandal,''))))
        AND (v_level IN ('STATE','MANDAL','DISTRICT','NATIONAL') OR lower(trim(coalesce(oo.district,'')))=lower(trim(coalesce(NEW.district,''))))
        AND (v_level IN ('STATE','MANDAL','DISTRICT','TEHSIL','NATIONAL') OR lower(trim(coalesce(oo.tehsil,'')))=lower(trim(coalesce(NEW.tehsil,''))))
        AND (v_level IN ('STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','NATIONAL') OR lower(trim(coalesce(oo.block,'')))=lower(trim(coalesce(NEW.block,''))))
        AND (v_level<>'VILLAGE' OR lower(trim(coalesce(oo.village,'')))=lower(trim(coalesce(NEW.village,''))))
      ORDER BY oo.created_at LIMIT 1;
    END IF;
    IF o.id IS NOT NULL THEN v_officer:=o.id; v_post:=o.post_id; EXIT; END IF;
  END LOOP;

  IF v_officer IS NULL THEN RETURN NEW; END IF;
  INSERT INTO public.rkms_notifications(
    title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,target_post_id,
    target_state,target_mandal,target_district,target_tehsil,target_block,target_village,content_source_id,content_source_type
  ) VALUES(
    coalesce(NEW.name,'सदस्य')||' की नई सदस्यता',
    'नई सदस्यता का आवेदन अनुमोदन के लिए लंबित है। सदस्य: '||coalesce(NEW.name,'सदस्य')||' | मोबाइल: '||coalesce(NEW.mobile,''),
    'MEMBERSHIP_APPROVAL','OFFICER',v_officer::text,'OFFICERS',true,false,v_post,
    NEW.state,NEW.mandal,NEW.district,NEW.tehsil,NEW.block,NEW.village,NEW.id,'rkms_member_applications'
  );
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN RETURN NEW;
END;
$$;

-- PDA appointment: direct member notification contains the officer ID; area notice has no direct-record route.
CREATE OR REPLACE FUNCTION public.rkms_officer_appointment_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO public, pg_catalog
AS $$
DECLARE m public.rkms_members%rowtype; p public.rkms_posts%rowtype; v_post text; v_authority text; v_target text;
BEGIN
  IF TG_OP<>'INSERT' OR upper(coalesce(NEW.status,''))<>'ACTIVE' THEN RETURN NEW; END IF;
  SELECT * INTO m FROM public.rkms_members WHERE id=NEW.member_id;
  IF m.id IS NULL OR m.auth_user_id IS NULL THEN RETURN NEW; END IF;
  SELECT * INTO p FROM public.rkms_posts WHERE id=NEW.post_id;
  v_post:=coalesce(p.post_name,'PDA पद');
  v_authority:=coalesce(nullif(trim(NEW.appointing_authority_name),''),'अधिकृत PDA अधिकारी');

  INSERT INTO public.rkms_notifications(title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id,content_source_id,content_source_type)
  VALUES('📜 PDA नियुक्ति / पद परिवर्तन',
    'आपकी RKMS में '||v_post||' के पद पर नियुक्ति/पद परिवर्तन किया गया है। नियुक्ति प्राधिकारी: '||v_authority||'।',
    'PDA_APPOINTMENT','MEMBER',m.id::text,'MEMBER',true,false,
    (SELECT mm.auth_user_id FROM public.rkms_members mm JOIN public.rkms_officers oo ON oo.member_id=mm.id WHERE oo.id=NEW.appointed_by_officer_id),
    NEW.id,'rkms_officers');

  v_target:=CASE upper(coalesce(NEW.authority_level,''))
    WHEN 'VILLAGE' THEN 'VILLAGE' WHEN 'BLOCK' THEN 'BLOCK'
    WHEN 'TEHSIL' THEN 'TEHSIL' WHEN 'TAHSIL' THEN 'TEHSIL' WHEN 'SUBDISTRICT' THEN 'TEHSIL'
    WHEN 'DISTRICT' THEN 'DISTRICT' WHEN 'MANDAL' THEN 'MANDAL' WHEN 'STATE' THEN 'STATE' ELSE 'ALL' END;

  INSERT INTO public.rkms_notifications(title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id,target_state,target_mandal,target_district,target_tehsil,target_block,target_village)
  VALUES('📢 PDA अधिकारी नियुक्ति',
    'आपके क्षेत्र में '||v_post||' के पद पर नई नियुक्ति की गई है। नियुक्त अधिकारी: '||coalesce(m.name,'पदाधिकारी')||'।',
    'PDA_APPOINTMENT',v_target,
    CASE v_target WHEN 'STATE' THEN NEW.state WHEN 'MANDAL' THEN NEW.mandal WHEN 'DISTRICT' THEN NEW.district WHEN 'TEHSIL' THEN NEW.tehsil WHEN 'BLOCK' THEN NEW.block WHEN 'VILLAGE' THEN NEW.village ELSE 'ALL' END,
    'ALL',true,true,NULL,NEW.state,NEW.mandal,NEW.district,NEW.tehsil,NEW.block,NEW.village);
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rkms_officer_appointment_notify ON public.rkms_officers;
CREATE TRIGGER trg_rkms_officer_appointment_notify AFTER INSERT ON public.rkms_officers
FOR EACH ROW EXECUTE FUNCTION public.rkms_officer_appointment_notify();

DROP TRIGGER IF EXISTS trg_rkms_membership_application_notification ON public.rkms_member_applications;
CREATE TRIGGER trg_rkms_membership_application_notification AFTER INSERT OR UPDATE OF status ON public.rkms_member_applications
FOR EACH ROW EXECUTE FUNCTION public.rkms_membership_application_notification();

DROP TRIGGER IF EXISTS rkms_notifications_enqueue_push ON public.rkms_notifications;
CREATE TRIGGER rkms_notifications_enqueue_push AFTER INSERT ON public.rkms_notifications
FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_notification_push();
