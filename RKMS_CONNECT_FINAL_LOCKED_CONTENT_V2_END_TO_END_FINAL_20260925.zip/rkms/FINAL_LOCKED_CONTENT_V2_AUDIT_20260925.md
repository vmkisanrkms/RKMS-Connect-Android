# FINAL LOCKED CONTENT V2 — SOURCE AUDIT

Base: RKMS_CONNECT_NOTIFICATION_BACK_STEP_HISTORY_FIXED_V6_20260925-1.zip
Change date: 25 September 2026

Implemented in source:
- Removed old Home renderer and replaced it with the locked four-content Home model.
- Removed News and Photo/Media Gallery from Home quick actions.
- Removed the separate Home programme preview block.
- Added dynamic Home Top/Bottom rendering from `rkms_get_home_content_v2`.
- Added Court Order, संगठन सूचना, कार्यक्रम and Flash management tabs.
- Added geographic multi-area selection workflow (add multiple areas).
- Added Officer/Member/Both audience selection.
- Added Normal/Priority where required; Court Order is always non-priority.
- Added Create -> Live behavior; no content Publish/Approval UI.
- Added creator and top-authority management rules in the new SQL RPCs.
- Added unified content table and update/delete history.
- Added notification creation using the exact selected target type/area/audience.
- Added Flash expiry cleanup and 3-second Priority Flash opening overlay.
- Added content detail cards with created/updated attribution.
- Old News/Gallery routes no longer expose their old screens; they return to Home.
- Existing unrelated chat, membership, complaint, directory, appointment and login code was retained.

Database migration:
`supabase/migrations/20260926000000_rkms_locked_content_v2.sql`

Important deployment note:
The new source expects the new migration to be applied to the Supabase project before this Content V2 UI can operate. This ZIP is source/build-ready; an actual production Supabase execution and release APK build must still be performed in the target environment.
