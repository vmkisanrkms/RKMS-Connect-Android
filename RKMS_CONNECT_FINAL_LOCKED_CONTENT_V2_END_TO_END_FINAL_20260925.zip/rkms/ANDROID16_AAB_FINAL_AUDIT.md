# RKMS CONNECT — Android 16 / API 36 + AAB Final Audit

Date: 2026-09-14

## Final status

**SOURCE PACKAGE: READY for Android 16 (API 36) generation and AAB build.**

The package now prepares the generated Capacitor Android project with:

- compileSdkVersion 36
- targetSdkVersion 36
- Android Gradle Plugin 8.9.1
- Gradle 8.11.1
- JDK 17
- Android SDK Platform 36
- Build Tools 36.0.0
- package/application ID: `org.rkms.connect`

Android's current documentation identifies API 36 as Android 16 and lists AGP 8.9.1 as the minimum AGP for API 36. The selected Gradle version is compatible with AGP 8.9.x.

## Build outputs

GitHub Actions now builds all three artifacts:

1. Debug APK
2. Release APK
3. Release AAB

The AAB is produced at:

`android/app/build/outputs/bundle/release/app-release.aab`

The generated `android/` directory is intentionally not stored in the source ZIP. It is recreated by `npx cap add android`, then patched and verified on the GitHub runner so API 36 settings cannot silently be lost during regeneration.

## Signing

The workflow supports secure release signing through GitHub Actions secrets:

- `RKMS_KEYSTORE_BASE64`
- `RKMS_KEYSTORE_PASSWORD`
- `RKMS_KEY_ALIAS`
- `RKMS_KEY_PASSWORD`

When all four are present, the release AAB/APK are signed with the supplied keystore. When they are absent, the workflow still builds an unsigned release AAB/APK for build verification; an unsigned AAB is **not** directly uploadable to Google Play.

The keystore is never stored in the source ZIP.

## Android 16 compatibility hardening

- Edge-to-edge is treated as mandatory for targetSdk 36; no Android 16 opt-out is used.
- Existing web UI safe-area handling is retained for top/bottom system insets.
- Predictive back is explicitly enabled in the generated manifest patch.
- No legacy Android 16 edge-to-edge opt-out attribute is introduced.

A real Android 16 device test is still required after the AAB/APK is generated, especially for visual edge-to-edge behavior and back navigation.

## FCM / notifications

The Android build now explicitly processes the RKMS Firebase configuration:

- `google-services.json` is present and matches package `org.rkms.connect`.
- Google Services Gradle plugin 4.4.3 is added to the generated project.
- Capacitor Push Notifications remains installed.
- Default notification channel `rkms_notifications_v3` is created natively.
- The same channel is declared as the Firebase default background notification channel.
- Android 13+ notification permission flow is requested in the JS runtime.
- FCM token registration, foreground handling, tap navigation, and resume re-registration remain wired.

## Secure login / PDF / core flow

Static checks pass for:

- encrypted AndroidKeyStore saved credentials
- biometric/device-credential unlock
- native RKMS bridge
- PDF generation/download bridge
- FCM pipeline
- saved-login restore
- directory/contact authorization
- PDA authority hierarchy
- final RKMS runtime helper checks

## Complaint workflow

The complaint workflow remains wired end-to-end in the source package:

- private complaint evidence bucket
- 10 MB attachment limit
- JPG/PNG/WEBP/PDF validation
- accused-officer selection
- automatic jurisdiction routing
- category-aware routing
- officer transfer/forward
- priority
- SLA due date and breach processing
- member close/reopen
- complaint history
- next-authority guidance

A security audit found that the next-authority guidance RPC was authenticated but could expose guidance for an arbitrary complaint ID. This was fixed both in the live Supabase project and in the source migration `20260914191300_harden_complaint_next_authority_access.sql`. The RPC now requires the complaint member, an authorized handling/higher officer, or Super Admin.

## Verification limitation

The current analysis environment did not complete `npm install` within the available execution window, so a full native Gradle compilation was not performed here. The generated Android project is intentionally built on the GitHub runner by the included workflow. Therefore:

- static/source audit: PASS
- Android 16 configuration logic: PASS (mock-generated-project test)
- AAB workflow: configured
- actual runner Gradle/AAB compilation: **must be executed on GitHub Actions**
- real Android 16 device test: **must be executed after the APK/AAB is generated**

No source-level flow break was found in the audited complaint, FCM, saved-login, PDF, directory, authority, or navigation wiring.
