# RKMS CONNECT — Notification Chat Back One-Step Fix — 2026-09-24

## Problem
After tapping a chat notification, Chat opened correctly, but pressing the chat Back button could return to the same chat again because notification/Capacitor duplicate history entries remained in the WebView history.

## Fix
- Added one shared `rkmsReturnFromNotificationChat()` path.
- Both the chat header Back button and Android hardware Back use the same one-shot return logic.
- The notification chat history entry is replaced with the exact screen that was visible before the notification instead of calling `history.back()`.
- The notification-return marker is consumed before rendering, so repeated Back/callbacks cannot reopen the same chat.
- Normal non-notification chat Back behavior is unchanged.

## Expected flow
Notification tap → exact chat → Back → exact previous screen → Back → normal previous screen, one step at a time.

## Validation
- JavaScript syntax check passed.
