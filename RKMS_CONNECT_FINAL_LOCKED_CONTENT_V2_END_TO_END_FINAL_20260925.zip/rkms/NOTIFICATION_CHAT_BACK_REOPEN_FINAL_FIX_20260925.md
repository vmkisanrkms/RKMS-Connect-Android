# RKMS Connect — Notification Chat Back/Reopen Final Fix — 2026-09-25

## Problem reproduced from supplied video
Android notification -> exact chat -> Android Back -> chat list -> same chat reopened repeatedly.

## Fix
1. FCM queue_id/notification_id/message_id is carried as a unique notification event key.
2. Native MainActivity persists notification-event consumption in SharedPreferences for 120 seconds before asynchronous WebView dispatch.
3. The JS notification tap handler also persists the same event key in localStorage for 120 seconds.
4. Duplicate Capacitor/native deliveries of the same event become no-ops, even after Activity/WebView recreation.
5. The previous 5-second-only duplicate guard remains as an additional in-memory guard.
6. Back handling remains one normal SPA history step; the notification return marker is consumed before history.back().
7. A later intentional tap of an old notification is not permanently blocked; the durable duplicate-consumption window expires after 120 seconds.

## Static verification
- `node --check app.js`: PASS
- `bash -n scripts/setup-android-native.sh`: PASS
- Generated MainActivity test harness: PASS
- Notification event key + persistent consume helper present: PASS
- Two-argument native -> JS notification route dispatch present: PASS

## Device test status
This ZIP contains the code fix. A physical Motorola Edge 50 Pro test is still required to certify the exact runtime sequence on-device.
