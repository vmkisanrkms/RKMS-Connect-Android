# RKMS Connect — FCM Token Reconciliation Fix — 2026-09-24

## Root cause addressed
The live database showed that a recipient could reach zero active FCM tokens after an old token became NotRegistered. The existing JS relied primarily on Capacitor's registration callback; this fix additionally asks native FirebaseMessaging for the current token and sends it through the same authenticated `rkms-fcm-push` `register_token` endpoint.

## Changes
- Native `FirebaseMessaging.getInstance().getToken()` reconciliation added.
- Native token is returned to WebView through `RKMSNative.refreshFcmToken()`.
- JS registers the native token using the existing authenticated `register_token` flow.
- Registration remains idempotent and retains the existing retry/resume logic.
- No database schema change is required.

## Expected result
After login/app resume, the current Firebase token is re-registered even if the Capacitor registration event was missed or delayed. Once the token is present in `rkms_fcm_tokens`, the existing chat queue/FCM dispatcher can deliver queued pushes.

## Runtime test still required
Install the new release APK, login, confirm the recipient has an FCM token, then test with the app removed from Recent Apps and the phone locked.
