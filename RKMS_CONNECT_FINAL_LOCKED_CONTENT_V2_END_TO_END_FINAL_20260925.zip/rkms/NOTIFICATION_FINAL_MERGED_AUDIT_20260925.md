# RKMS CONNECT — FINAL MERGED NOTIFICATION AUDIT

This ZIP merges the strongest parts of the two supplied notification ZIPs and adds a final migration `20260925130000_notification_final_merged_hardening.sql`.

## Corrections made
- Kept the safer notification Back/navigation implementation from `FINAL_FIXED`, then added a one-shot `rkmsNotificationChat` history marker so Back uses the real previous history entry without creating a replacement route.
- Added exact content detail routes from `FINAL_ALL_POINTS_FIXED` for News, Events, Flash, Gallery, Documents, Reports, Campaigns and Leadership.
- Reports and Campaigns now carry state/mandal/district/tehsil/block/village scope from the officer context in the frontend.
- Exact content routing uses `lower(content_source_type)` so `rkms_news`, `rkms_events`, etc. match reliably.
- FCM dispatch authentication uses Supabase Vault `rkms_push_key`; no FCM secret is embedded in source.
- Membership approval targeting selects the most specific responsible authority and falls back upward in the correct hierarchy only when needed.
- Area content officer targeting is strictly subordinate (`rank < target rank`); equal/higher authorities are not included by the subordinate-officer branch.
- PDA direct appointment notification carries `content_source_id=officer.id` and opens `officer/<id>` only for the directly appointed member.
- PDA area-wide notification does not carry a direct officer content source, preventing all area recipients from being incorrectly routed to the officer detail screen.
- Central content trigger removes known legacy duplicate push triggers and deduplicates by content source.
- Central push trigger remains the single queue/FCM dispatch path.
- Android native `onResume()` does not re-read the same notification Intent; it only retries a pending dispatch, preventing repeated Chat reopening on Back/resume.

## Verification performed
- ZIP extraction succeeded.
- JavaScript syntax check (`node --check app.js`) passed.
- Hard-coded FCM push key scan performed; notification migrations reference Supabase Vault instead.
- Notification route case mismatch was removed in the final migration.
- Final ZIP still requires a real Supabase migration run and a release APK/device test before claiming runtime/device verification.
