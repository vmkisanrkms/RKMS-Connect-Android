# RKMS CONNECT — FCM Firebase Initialization Crash Fix — 2026-09-18

## Bug addressed
The supplied real-device bugreport showed a fatal crash in `org.rkms.connect`:
`IllegalStateException: Default FirebaseApp is not initialized in this process`
from `FirebaseMessaging.getInstance()` during Capacitor Push Notifications registration.

## Fix
- `MainActivity.onCreate()` explicitly initializes Firebase with `FirebaseApp.initializeApp(getApplicationContext())` before FCM registration can run.
- Initialization is guarded with `try/catch(Throwable)` so a Firebase initialization failure cannot terminate the app.
- `MainActivity.isRkmsFirebaseReady()` exposes readiness through `RKMSNativeBridge.isFirebaseReady()`.
- `app.js` checks Firebase readiness immediately before `Push.register()` and skips FCM registration if Firebase is unavailable.
- Existing notification channel, saved-login, and secure-session logic remains unchanged.
- The Android build workflow now verifies that the Firebase initialization and crash guard are injected into the generated project.

## Runtime verification required
Install the resulting signed Android 16 / API 36 APK on the Motorola Edge 50 Pro and verify launch, login, FCM registration, foreground notification, and background/closed notification.
