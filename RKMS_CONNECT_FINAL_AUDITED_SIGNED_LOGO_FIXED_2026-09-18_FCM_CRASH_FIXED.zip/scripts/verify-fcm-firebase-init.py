from pathlib import Path
import re
s=Path("scripts/setup-android-native.sh").read_text()
checks=[
    "FirebaseApp.initializeApp(getApplicationContext())",
    "rkmsFirebaseReady = (app != null)",
    "public static boolean isRkmsFirebaseReady()",
    "isFirebaseReady(){ return MainActivity.isRkmsFirebaseReady(); }",
]
for c in checks:
    assert c in s, f"missing: {c}"
app=Path("app.js").read_text()
assert "RKMS FCM disabled: Firebase initialization unavailable" in app
assert "await Push.register();" in app
print("FCM Firebase initialization/crash guard: PASS")
