# RKMS CONNECT — Content Creator Action UI Fix

Date: 2026-09-25

## Rule
- Super Admin and National President can manage all V2 content.
- A non-top officer can Edit/Delete only content created by that same officer.
- A non-top officer must not be offered Edit/Delete controls for another creator's content.
- Backend enforcement remains in `rkms_v2_can_manage()` / `rkms_manage_content_v2`; this patch adds matching UI enforcement.

## Source change
`app.js` adds `rkmsV2CanEditDeleteRow(row)` and applies it in `loadContentList()`.

## Verification
- `node --check app.js` PASS
- `npm run build` PASS
