from pathlib import Path

app=Path('app.js').read_text(encoding='utf-8')
html=Path('index.html').read_text(encoding='utf-8')
css=Path('styles.css').read_text(encoding='utf-8')

checks=[]
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('PASS: ' if ok else 'FAIL: ')+name)

# 1) Guest has no bottom navigation; authenticated navigation remains role-driven.
check('guest bottom navigation is hidden', 'footer.rkms-bottom-nav.guest-nav{display:none!important}' in css)
check('authenticated bottom navigation still exists', 'id="rkmsBottomNav"' in html and 'const loggedIn=!!token()' in app)
check('guest does not expose member-hub via bottom nav', 'guest-nav' in app and 'data-route="member-hub"' in html)

# 2/3) Home/nav labels: no separate member/officer login label.
check('Home login label is exactly Login', 'data-login-menu>Login' in app)
check('header Login label is exactly Login', '<button data-route="login">Login</button>' in html)
check('no home member/officer login label remains', 'सदस्य/पदाधिकारी लॉगिन' not in app and 'सदस्य/पदाधिकारी लॉगिन' not in html)

# 4) Locked Content V2 Home replaces the retired legacy events-preview block.
check('Home renders locked Content V2 top block', 'const top=rows.filter(x=>x.content_type==="FLASH" || (x.priority && ["ORG_NOTICE","EVENT"].includes(x.content_type)))' in app)
check('Home renders locked Content V2 bottom block', 'const bottom=rows.filter(x=>["FLASH","ORG_NOTICE","EVENT"].includes(x.content_type))' in app)
check('legacy separate events preview is not used', 'home-events-preview' not in app and 'rkms_get_events' not in app)

# 5) Digital ID uses approval/appointment signer metadata and signature.
check('Digital ID resolves approval signer metadata', 'getMembershipApprovalMeta(m)' in app)
check('Digital ID resolves appointing officer signature', 'meta.appointing_officer_signature_url' in app)
check('Digital ID renders appointing officer name/signature', 'appointedHtml' in app and 'authority-signature' in app)

# 6) One login entry; role is resolved after authentication.
check('single Login screen exists', 'सदस्य, PDA अधिकारी और Super Admin के लिए एक ही Login' in app)
check('single Login submit button exists', app.count('id="memberPasswordLoginBtn"')==1 and 'id="memberPasswordLoginBtn"' in app)
check('member login success re-resolves role', 'await refreshIdentity(true);' in app and 'state.role==="officer"' in app)
check('officer-login route cannot open a separate credential form', 'if(name==="officer-login")return loginScreen();' in app)
check('home Login opens unified login directly', 'data-login-menu' in app and 'onclick=()=>go("login")' in app)
check('officer dashboard is selected automatically for officer role', 'completeLogin(state.role==="officer"?"officer-dashboard"' in app)
check('member dashboard remains selected for member role', 'completeLogin(state.role==="officer"?"officer-dashboard":state.role==="super_admin"?"admin":"member-dashboard")' in app)

# 7) Login wording on public screen.
home=app[app.index('async function renderHome()'):app.index('async function renderOrganization()')]
check('public Home Login wording is not split by role', 'सदस्य/पदाधिकारी' not in home and 'सदस्य / PDA अधिकारी' not in home)

failed=[n for n,ok in checks if not ok]
print(f'\n{len(checks)-len(failed)}/{len(checks)} final login/navigation checks passed')
if failed:
    print('FAILED CHECKS:')
    for n in failed: print(' - '+n)
    raise SystemExit(1)
