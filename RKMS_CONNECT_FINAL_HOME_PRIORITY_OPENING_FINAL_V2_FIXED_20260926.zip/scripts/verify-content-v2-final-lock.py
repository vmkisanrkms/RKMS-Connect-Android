from pathlib import Path

root=Path('.')
app=(root/'app.js').read_text()
sql=(root/'supabase/migrations/20260926060000_rkms_content_v2_final_lock.sql').read_text()
workflow=(root/'.github/workflows/rkms-android16-release-apk.yml').read_text()

checks=[
('Only four V2 content types', all(x in app for x in ['COURT_ORDER','ORG_NOTICE','EVENT','FLASH'])),
('Old Flash opening RPC removed', 'rkms_get_active_flash' not in app and 'rkms_get_flash_messages' not in app),
('Old Flash rotator removed', 'loadActiveFlashes' not in app and 'homeFlashRotator' not in app),
('Final four-type management label', 'न्यायालय आदेश • संगठन सूचना • कार्यक्रम • Flash' in app),
('Priority content also remains in Home bottom', 'const bottom=rows.filter(x=>["FLASH","ORG_NOTICE","EVENT"].includes(x.content_type));' in app),
('Flash client start/end validation', 'Flash का Start Date/Time जरूरी है।' in app and 'Flash का End Date/Time जरूरी है।' in app),
('Flash DB start/end validation', 'start_ts := (p_data->>\'start_at\')::timestamptz' in sql and 'end_ts <= start_ts' in sql),
('Flash active window enforced', 'c.start_at is null or c.start_at<=now()' in sql and 'c.end_at is null or c.end_at>=now()' in sql),
('Home duplicate prevention', 'exists (\n        select 1 from jsonb_array_elements(c.target_areas)' in sql),
('Super Admin creator identity', 'rkms_admins sa' in sql and 'sa.name' in sql),
('Exact lower-officer target level', "upper(trim(coalesce(p_target_type,''))) <> lvl" in sql and 'jsonb_array_length(p_target_areas) <> 1' in sql),
('Content V2 Storage RLS', 'rkms v2 content media insert' in sql and 'content-v2/%' in sql),
('FCM token registration function packaged', (root/'supabase/functions/rkms-fcm-push/index.ts').exists()),
('Release APK workflow packaged', (root/'.github/workflows/rkms-android16-release-apk.yml').exists() and 'assembleRelease' in workflow and 'bundleRelease' not in workflow),
]
failed=[]
for name,ok in checks:
    print(('PASS: ' if ok else 'FAIL: ')+name)
    if not ok: failed.append(name)
print(f'FINAL CONTENT V2 LOCK AUDIT: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: raise SystemExit(1)
