from pathlib import Path

p = Path("scripts/setup-android-native.sh")
s = p.read_text()
assert "rkmsWebView.setWebViewClient" not in s, "Capacitor WebViewClient must not be replaced"
assert "https://localhost/" in s, "localhost handling comment/check missing"
assert "rkmsDispatchNotificationRoute" in s, "native notification route dispatch missing"
assert '"CONTENT_FLASH".equalsIgnoreCase(type)' in s, "native CONTENT_FLASH route missing"
app = Path("app.js").read_text()
# Final locked Content V2 uses one authoritative notification route.
# Legacy News/Gallery/old Flash routes are intentionally retired.
assert "content_v2:'content-v2/'" in app, "Missing Content V2 notification route mapping"
assert "app_update:'notifications'" in app, "Missing app update notification route mapping"
assert "chat/'+encodeURIComponent(cid)" in app, "chat notification route missing"
print("WebView + app-wide notification routing: PASS")
