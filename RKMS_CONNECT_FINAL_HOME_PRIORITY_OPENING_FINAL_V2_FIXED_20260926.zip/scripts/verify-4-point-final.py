from pathlib import Path
app=Path('app.js').read_text(encoding='utf-8')

def ok(label, cond):
    if not cond:
        raise SystemExit(f'FAIL: {label}')
    print(f'PASS: {label}')

# 1. Lower officers can target only their exact authority level; multi-area add is top-authority only.
ok('lower officer target list is exact-level only', '(rank[lvl] ? [lvl] : ["DISTRICT"])' in app)
ok('lower officer multi-area add button is hidden', 'id="v2_add_area" style="margin-top:8px" ${isTop?"":"hidden"}' in app)
ok('top authority retains full target options', 'lvl==="TOP"?["ALL","STATE","MANDAL","DISTRICT","TEHSIL","BLOCK","VILLAGE"]' in app)

# 2. Organization Information / Event audience is hard-locked to ALL in UI for every authority.
ok('general content audience is hidden ALL', 'isGeneral?`<input type="hidden" id="v2_audience" value="ALL">' in app)
ok('general content audience cannot expose officer/member selector', 'संगठन सूचना/कार्यक्रम के लिए Audience हमेशा ALL है' in app)

# 3/4. Current verification scripts contain the locked V2 checks.
home=Path('scripts/verify-home-content-final.py').read_text(encoding='utf-8')
nav=Path('scripts/verify-final-login-navigation.py').read_text(encoding='utf-8')
ok('Home verification checks locked V2 top', 'Priority content only in Home top block' in home and 'x.priority && ["ORG_NOTICE","EVENT"]' in home)
ok('Home verification checks locked V2 bottom', 'Home bottom block contains all Flash, notices and events' in home)
ok('Login/navigation verification checks V2 Home', 'Home renders locked Content V2 top block' in nav and 'Home renders locked Content V2 bottom block' in nav)
ok('Login/navigation verification rejects retired events preview', 'home-events-preview' in nav and 'rkms_get_events' in nav)
print('4/4 FINAL POINT GROUPS PASS')
