from pathlib import Path
s=Path('app.js').read_text(encoding='utf-8')
checks={
 'timestamp helper exists':'function rkmsV2AttributionHtml(x){' in s,
 'updated record shows only final change':'if(hasUpdate)' in s and 'अंतिम बदलाव:' in s and 'updatedAt.toLocaleString("hi-IN")' in s,
 'created record shows only created time':'return `<small class="note">डाली गई:' in s,
 'home card uses helper':'${rkmsV2AttributionHtml(x)}' in s,
 'detail modal uses helper':'<hr>${rkmsV2AttributionHtml(x)}' in s,
 'old dual timestamp block removed':'${x.updated_by_name?`<br>अंतिम बदलाव:' not in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
print(f"\nCONTENT TIMESTAMP DISPLAY VERIFICATION: {'PASS' if all(checks.values()) else 'FAIL'}")
raise SystemExit(0 if all(checks.values()) else 1)
