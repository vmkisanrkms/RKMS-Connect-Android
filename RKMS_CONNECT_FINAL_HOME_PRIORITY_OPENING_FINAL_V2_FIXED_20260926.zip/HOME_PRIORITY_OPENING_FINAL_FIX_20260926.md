# RKMS CONNECT — Home Priority / Opening Final Fix — 2026-09-26

## Final Home order
1. Priority content appears first, before the main RKMS hero/logo.
2. The opening Priority area accepts only content published by the National President or Super Admin.
3. Priority content is excluded from the lower "ताज़ा सूचना और कार्यक्रम" section.
4. Normal content appears only in the lower normal section.
5. Non-top-authority Content Management no longer exposes the Priority selector.
6. A database trigger rejects Priority content created/updated by any non-National-President/non-Super-Admin actor.

## Source checks
- `app.js`: `node --check` PASS
- Source base: `RKMS_CONNECT_FINAL_CONTENT_V2_4_POINT_100_PERCENT_FIXED_NO_DUPLICATES_20260926.zip`
