-- RKMS CONNECT FINAL HOME PRIORITY / OPENING AUTHORITY LOCK
-- Priority content shown in the Home opening area must be published by
-- the National President or Super Admin only.

CREATE OR REPLACE FUNCTION public.rkms_v2_priority_opening_authority_lock()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
BEGIN
  IF COALESCE(NEW.priority, false) THEN
    IF NOT (
      public.rkms_current_super_admin_id() IS NOT NULL
      OR public.rkms_is_national_president_current()
    ) THEN
      RAISE EXCEPTION 'Priority opening content केवल राष्ट्रीय अध्यक्ष या Super Admin जारी कर सकते हैं।';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rkms_v2_priority_opening_authority_lock
ON public.rkms_content_v2;

CREATE TRIGGER trg_rkms_v2_priority_opening_authority_lock
BEFORE INSERT OR UPDATE OF priority ON public.rkms_content_v2
FOR EACH ROW
EXECUTE FUNCTION public.rkms_v2_priority_opening_authority_lock();
