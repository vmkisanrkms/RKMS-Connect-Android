-- RKMS CONNECT Content V2: six-level geographic targeting
-- Final targeting hierarchy:
-- पूरा संगठन / प्रदेश / मंडल / जिला / तहसील / ब्लॉक / ग्राम
-- Authorization is enforced in PostgreSQL; UI is only a convenience layer.

DO $$
DECLARE c record;
BEGIN
  FOR c IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid='public.rkms_content_v2'::regclass
      AND contype='c'
      AND pg_get_constraintdef(oid) LIKE '%target_type%'
  LOOP
    EXECUTE format('ALTER TABLE public.rkms_content_v2 DROP CONSTRAINT %I', c.conname);
  END LOOP;
END $$;

ALTER TABLE public.rkms_content_v2
  ADD CONSTRAINT rkms_content_v2_target_type_check
  CHECK (target_type IN ('ALL','STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE'));

CREATE OR REPLACE FUNCTION public.rkms_v2_scope_allowed(
  p_target_type text, p_target_areas jsonb
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare
  s jsonb := public.rkms_content_scope_json();
  lvl text := upper(coalesce(s->>'authority_level',''));
  st text := lower(trim(coalesce(s->>'state','')));
  ma text := lower(trim(coalesce(s->>'mandal','')));
  di text := lower(trim(coalesce(s->>'district','')));
  te text := lower(trim(coalesce(s->>'tehsil','')));
  bl text := lower(trim(coalesce(s->>'block','')));
  vi text := lower(trim(coalesce(s->>'village','')));
  a jsonb; at text;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then return true; end if;
  if upper(coalesce(p_target_type,''))='ALL' then return false; end if;
  if lvl not in ('STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then return false; end if;
  if jsonb_typeof(p_target_areas) <> 'array' or jsonb_array_length(p_target_areas)=0 then return false; end if;

  for a in select value from jsonb_array_elements(p_target_areas) loop
    at:=upper(coalesce(a->>'type',p_target_type,''));
    if at not in ('STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then return false; end if;
    if (case at when 'STATE' then 1 when 'MANDAL' then 2 when 'DISTRICT' then 3 when 'TEHSIL' then 4 when 'BLOCK' then 5 when 'VILLAGE' then 6 else 99 end)
       < (case lvl when 'STATE' then 1 when 'MANDAL' then 2 when 'DISTRICT' then 3 when 'TEHSIL' then 4 when 'BLOCK' then 5 when 'VILLAGE' then 6 else 99 end) then return false; end if;

    if at in ('STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE')
       and lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
    if at in ('MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE')
       and lower(trim(coalesce(a->>'mandal','')))<>ma then return false; end if;
    if at in ('DISTRICT','TEHSIL','BLOCK','VILLAGE')
       and lower(trim(coalesce(a->>'district','')))<>di then return false; end if;
    if at in ('TEHSIL','BLOCK','VILLAGE')
       and lower(trim(coalesce(a->>'tehsil','')))<>te then return false; end if;
    if at in ('BLOCK','VILLAGE')
       and lower(trim(coalesce(a->>'block','')))<>bl then return false; end if;
    if at='VILLAGE' and lower(trim(coalesce(a->>'village','')))<>vi then return false; end if;
  end loop;
  return true;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_v2_create_notifications(p_content_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare c record; a jsonb; ntype text; at text;
begin
  select * into c from public.rkms_content_v2 where id=p_content_id and deleted_at is null;
  if not found then return; end if;
  ntype:=case c.content_type when 'COURT_ORDER' then 'CONTENT_COURT_ORDER' when 'ORG_NOTICE' then 'CONTENT_ORG_NOTICE' when 'EVENT' then 'CONTENT_EVENTS' else 'CONTENT_FLASH' end;
  for a in select value from jsonb_array_elements(c.target_areas) loop
    at:=upper(coalesce(a->>'type','ALL'));
    insert into public.rkms_notifications(
      title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,
      publisher_auth_user_id,content_source_id,content_source_type,
      target_state,target_mandal,target_district,target_tehsil,target_block,target_village
    ) values (
      coalesce(c.title,'RKMS सूचना'),coalesce(c.description,'नई संगठन सामग्री उपलब्ध है।'),ntype,
      at,
      case at when 'ALL' then 'ALL' when 'STATE' then a->>'state' when 'MANDAL' then a->>'mandal' when 'DISTRICT' then a->>'district' when 'TEHSIL' then a->>'tehsil' when 'BLOCK' then a->>'block' when 'VILLAGE' then a->>'village' else null end,
      c.target_audience,c.priority,true,c.created_by,p_content_id,'rkms_content_v2',
      a->>'state',a->>'mandal',a->>'district',a->>'tehsil',a->>'block',a->>'village'
    );
  end loop;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_v2_user_scope()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare o jsonb; m record;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then
    return '{"role":"TOP","audience":"ALL","target_type":"ALL","state":null,"mandal":null,"district":null,"tehsil":null,"block":null,"village":null}'::jsonb;
  end if;
  o:=public.rkms_content_scope_json();
  if o is not null and o->>'authority_level' is not null then
    return jsonb_build_object('role','OFFICER','audience','OFFICERS','target_type',upper(coalesce(o->>'authority_level','DISTRICT')),
      'state',o->>'state','mandal',o->>'mandal','district',o->>'district','tehsil',o->>'tehsil','block',o->>'block','village',o->>'village');
  end if;
  select state,mandal,district,tehsil,block,village into m from public.rkms_members where auth_user_id=auth.uid() limit 1;
  if found then
    return jsonb_build_object('role','MEMBER','audience','MEMBERS','target_type','VILLAGE',
      'state',m.state,'mandal',m.mandal,'district',m.district,'tehsil',m.tehsil,'block',m.block,'village',m.village);
  end if;
  return '{"role":"NONE","audience":"MEMBERS","target_type":"NONE"}'::jsonb;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_get_home_content_v2(p_limit int default 50)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare u jsonb:=public.rkms_v2_user_scope(); r jsonb;
begin
  perform public.rkms_v2_expire_flash();
  select coalesce(jsonb_agg(to_jsonb(x) order by x.priority desc,x.created_at desc),'[]'::jsonb) into r
  from (
    select c.*,case when c.content_type='EVENT' then 'कार्यक्रम' when c.content_type='ORG_NOTICE' then 'संगठन सूचना' when c.content_type='FLASH' then 'Flash' else 'न्यायालय आदेश' end as type_label
    from public.rkms_content_v2 c cross join lateral jsonb_array_elements(c.target_areas) a
    where c.deleted_at is null and (c.content_type<>'FLASH' or c.end_at is null or c.end_at>=now())
      and (
        upper(a->>'type')='ALL'
        or (upper(a->>'type')='STATE' and lower(a->>'state')=lower(coalesce(u->>'state','')))
        or (upper(a->>'type')='MANDAL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')))
        or (upper(a->>'type')='DISTRICT' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')))
        or (upper(a->>'type')='TEHSIL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')))
        or (upper(a->>'type')='BLOCK' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')) and lower(a->>'block')=lower(coalesce(u->>'block','')))
        or (upper(a->>'type')='VILLAGE' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')) and lower(a->>'block')=lower(coalesce(u->>'block','')) and lower(a->>'village')=lower(coalesce(u->>'village','')))
      )
      and (c.target_audience='ALL' or c.target_audience=u->>'audience' or (u->>'role')='TOP')
  ) x limit greatest(1,least(p_limit,200));
  return r;
end $$;

CREATE OR REPLACE FUNCTION public.rkms_enqueue_notification_push()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,extensions AS $$
declare qid uuid; r record; v_route text; v_target text; v_audience text;
begin
  v_target:=upper(coalesce(new.target_type,'ALL')); v_audience:=upper(coalesce(new.target_audience,'ALL')); v_route:='notifications';
  if new.content_source_id is not null then
    v_route:=case lower(coalesce(new.content_source_type,'')) when 'rkms_content_v2' then 'content-v2/'||new.content_source_id::text when 'rkms_news' then 'news/'||new.content_source_id::text when 'rkms_events' then 'events/'||new.content_source_id::text when 'rkms_flash_messages' then 'flash/'||new.content_source_id::text when 'rkms_gallery' then 'gallery/'||new.content_source_id::text when 'rkms_documents' then 'documents/'||new.content_source_id::text else 'notifications' end;
  end if;
  for r in
    select distinct x.uid from (
      select m.auth_user_id uid from public.rkms_members m where m.auth_user_id is not null and v_audience in ('ALL','MEMBERS','MEMBER') and m.status='APPROVED' and (
        v_target='ALL' or (v_target='STATE' and lower(coalesce(new.target_state,new.target_value,''))=lower(coalesce(m.state,''))) or
        (v_target='MANDAL' and lower(coalesce(new.target_state,''))=lower(coalesce(m.state,'')) and lower(coalesce(new.target_mandal,new.target_value,''))=lower(coalesce(m.mandal,''))) or
        (v_target='DISTRICT' and lower(coalesce(new.target_state,''))=lower(coalesce(m.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(m.mandal,'')) and lower(coalesce(new.target_district,new.target_value,''))=lower(coalesce(m.district,''))) or
        (v_target='TEHSIL' and lower(coalesce(new.target_state,''))=lower(coalesce(m.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(m.mandal,'')) and lower(coalesce(new.target_district,''))=lower(coalesce(m.district,'')) and lower(coalesce(new.target_tehsil,new.target_value,''))=lower(coalesce(m.tehsil,''))) or
        (v_target='BLOCK' and lower(coalesce(new.target_state,''))=lower(coalesce(m.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(m.mandal,'')) and lower(coalesce(new.target_district,''))=lower(coalesce(m.district,'')) and lower(coalesce(new.target_tehsil,''))=lower(coalesce(m.tehsil,'')) and lower(coalesce(new.target_block,new.target_value,''))=lower(coalesce(m.block,''))) or
        (v_target='VILLAGE' and lower(coalesce(new.target_state,''))=lower(coalesce(m.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(m.mandal,'')) and lower(coalesce(new.target_district,''))=lower(coalesce(m.district,'')) and lower(coalesce(new.target_tehsil,''))=lower(coalesce(m.tehsil,'')) and lower(coalesce(new.target_block,''))=lower(coalesce(m.block,'')) and lower(coalesce(new.target_village,new.target_value,''))=lower(coalesce(m.village,'')))
      )
      union
      select distinct m.auth_user_id uid from public.rkms_members m join public.rkms_officers o on o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE' where m.auth_user_id is not null and v_audience in ('ALL','OFFICERS') and (
        v_target='ALL' or (v_target='STATE' and lower(coalesce(new.target_state,new.target_value,''))=lower(coalesce(o.state,''))) or
        (v_target='MANDAL' and lower(coalesce(new.target_state,''))=lower(coalesce(o.state,'')) and lower(coalesce(new.target_mandal,new.target_value,''))=lower(coalesce(o.mandal,''))) or
        (v_target='DISTRICT' and lower(coalesce(new.target_state,''))=lower(coalesce(o.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(o.mandal,'')) and lower(coalesce(new.target_district,new.target_value,''))=lower(coalesce(o.district,''))) or
        (v_target='TEHSIL' and lower(coalesce(new.target_state,''))=lower(coalesce(o.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(o.mandal,'')) and lower(coalesce(new.target_district,''))=lower(coalesce(o.district,'')) and lower(coalesce(new.target_tehsil,new.target_value,''))=lower(coalesce(o.tehsil,''))) or
        (v_target='BLOCK' and lower(coalesce(new.target_state,''))=lower(coalesce(o.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(o.mandal,'')) and lower(coalesce(new.target_district,''))=lower(coalesce(o.district,'')) and lower(coalesce(new.target_tehsil,''))=lower(coalesce(o.tehsil,'')) and lower(coalesce(new.target_block,new.target_value,''))=lower(coalesce(o.block,''))) or
        (v_target='VILLAGE' and lower(coalesce(new.target_state,''))=lower(coalesce(o.state,'')) and lower(coalesce(new.target_mandal,''))=lower(coalesce(o.mandal,'')) and lower(coalesce(new.target_district,''))=lower(coalesce(o.district,'')) and lower(coalesce(new.target_tehsil,''))=lower(coalesce(o.tehsil,'')) and lower(coalesce(new.target_block,''))=lower(coalesce(o.block,'')) and lower(coalesce(new.target_village,new.target_value,''))=lower(coalesce(o.village,'')))
      )
      union select a.auth_user_id uid from public.rkms_admins a where a.status='ACTIVE' and upper(coalesce(a.role,''))='SUPER_ADMIN' and a.auth_user_id is not null and v_audience='ALL'
      union select distinct m.auth_user_id uid from public.rkms_officers o join public.rkms_posts p on p.id=o.post_id join public.rkms_members m on m.id=o.member_id where o.status='ACTIVE' and lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष' and m.status='APPROVED' and m.auth_user_id is not null and v_audience='ALL'
    ) x where x.uid is not null
  loop
    if lower(coalesce(new.content_source_type,''))='rkms_content_v2' and new.content_source_id is not null then
      insert into public.rkms_v2_push_dedup(content_id,recipient_auth_user_id) values(new.content_source_id,r.uid) on conflict (content_id,recipient_auth_user_id) do nothing;
      if not found then continue; end if;
    end if;
    insert into public.rkms_push_queue(recipient_auth_user_id,title,body,url,sender_auth_user_id,notification_id) values(r.uid,new.title,coalesce(new.body,''),'#'||v_route,new.publisher_auth_user_id,new.id) returning id into qid;
    begin perform net.http_post(url:='https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-dispatch-v2',body:=jsonb_build_object('queue_id',qid),headers:=jsonb_build_object('Content-Type','application/json','x-rkms-push-key',coalesce((select decrypted_secret from vault.decrypted_secrets where name='rkms_push_key' limit 1),''))); exception when others then null; end;
  end loop;
  return new;
end $$;

DROP TRIGGER IF EXISTS rkms_notifications_enqueue_push ON public.rkms_notifications;
CREATE TRIGGER rkms_notifications_enqueue_push AFTER INSERT ON public.rkms_notifications FOR EACH ROW EXECUTE FUNCTION public.rkms_enqueue_notification_push();
