-- Show the actual creator on public Home cards/details.
-- Keeps creator audit metadata server-side and resolves officer/member name safely.
CREATE OR REPLACE FUNCTION public.rkms_get_home_content_v2(p_limit integer DEFAULT 50)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
declare
  u jsonb:=public.rkms_v2_user_scope();
  r jsonb;
begin
  perform public.rkms_v2_expire_flash();

  select coalesce(jsonb_agg(to_jsonb(x) order by x.priority desc,x.created_at desc),'[]'::jsonb)
    into r
  from (
    select
      c.*,
      case when c.content_type='EVENT' then 'कार्यक्रम'
           when c.content_type='ORG_NOTICE' then 'संगठन सूचना'
           when c.content_type='FLASH' then 'Flash'
           else 'न्यायालय आदेश' end as type_label,
      case
        when sa.id is not null then coalesce(nullif(trim(sa.name),''),'Super Admin')
        else coalesce(nullif(trim(coalesce(o.signature_name,'')),''),nullif(trim(coalesce(m.name,'')),''),'अधिकारी')
      end as created_by_name,
      nullif(trim(coalesce(p.post_name,'')),'') as created_by_post,
      case
        when usa.id is not null then coalesce(nullif(trim(usa.name),''),'Super Admin')
        else coalesce(nullif(trim(coalesce(uo.signature_name,'')),''),nullif(trim(coalesce(um.name,'')),''),'अधिकारी')
      end as updated_by_name,
      nullif(trim(coalesce(up.post_name,'')),'') as updated_by_post
    from public.rkms_content_v2 c
    left join public.rkms_officers o on o.id=c.created_by
    left join public.rkms_members m on m.id=o.member_id
    left join public.rkms_posts p on p.id=o.post_id
    left join public.rkms_admins sa on sa.id=c.created_by and sa.role='SUPER_ADMIN' and sa.status='ACTIVE'
    left join public.rkms_officers uo on uo.id=c.updated_by
    left join public.rkms_members um on um.id=uo.member_id
    left join public.rkms_posts up on up.id=uo.post_id
    left join public.rkms_admins usa on usa.id=c.updated_by and usa.role='SUPER_ADMIN' and usa.status='ACTIVE' 
    cross join lateral jsonb_array_elements(c.target_areas) a
    where c.deleted_at is null
      and (c.content_type<>'FLASH' or c.end_at is null or c.end_at>=now())
      and (
        upper(a->>'type')='ALL'
        or (upper(a->>'type')='STATE' and lower(a->>'state')=lower(coalesce(u->>'state','')))
        or (upper(a->>'type')='MANDAL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')))
        or (upper(a->>'type')='DISTRICT' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')))
        or (upper(a->>'type')='TEHSIL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')))
        or (upper(a->>'type')='BLOCK' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')) and lower(a->>'block')=lower(coalesce(u->>'block','')))
        or (upper(a->>'type')='VILLAGE' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')) and lower(a->>'block')=lower(coalesce(u->>'block','')) and lower(a->>'village')=lower(coalesce(u->>'village','')))
      )
      and (c.target_audience='ALL' or c.target_audience=u->>'audience' or (u->>'role')='TOP')
  ) x
  limit greatest(1,least(p_limit,200));

  return r;
end $$;
