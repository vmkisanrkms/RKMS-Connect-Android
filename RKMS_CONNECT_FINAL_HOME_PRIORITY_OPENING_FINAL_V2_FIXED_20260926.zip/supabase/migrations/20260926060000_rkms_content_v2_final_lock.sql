-- RKMS CONNECT FINAL LOCK: Content V2 production hardening
-- 4 content types only, exact officer-level targeting, Flash start/end enforcement,
-- Home deduplication, Super Admin creator identity, and Content V2 media RLS.

-- ------------------------------------------------------------
-- 1) Exact authority-level targeting for lower officers.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rkms_v2_scope_allowed(
  p_target_type text,
  p_target_areas jsonb
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare
  s jsonb := public.rkms_content_scope_json();
  lvl text := upper(trim(coalesce(s->>'authority_level','')));
  st text := lower(trim(coalesce(s->>'state','')));
  ma text := lower(trim(coalesce(s->>'mandal','')));
  di text := lower(trim(coalesce(s->>'district','')));
  te text := lower(trim(coalesce(s->>'tehsil','')));
  bl text := lower(trim(coalesce(s->>'block','')));
  vi text := lower(trim(coalesce(s->>'village','')));
  a jsonb;
  at text;
begin
  if public.rkms_current_super_admin_id() is not null
     or public.rkms_is_national_president_current() then
    return true;
  end if;

  if lvl not in ('STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then
    return false;
  end if;
  if upper(trim(coalesce(p_target_type,''))) <> lvl then return false; end if;
  if jsonb_typeof(p_target_areas) <> 'array' or jsonb_array_length(p_target_areas) <> 1 then return false; end if;

  a := p_target_areas->0;
  at := upper(trim(coalesce(a->>'type','')));
  if at <> lvl then return false; end if;

  if st='' or lower(trim(coalesce(a->>'state','')))<>st then return false; end if;
  if lvl in ('MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE')
     and lower(trim(coalesce(a->>'mandal','')))<>ma then return false; end if;
  if lvl in ('DISTRICT','TEHSIL','BLOCK','VILLAGE')
     and lower(trim(coalesce(a->>'district','')))<>di then return false; end if;
  if lvl in ('TEHSIL','BLOCK','VILLAGE')
     and lower(trim(coalesce(a->>'tehsil','')))<>te then return false; end if;
  if lvl in ('BLOCK','VILLAGE')
     and lower(trim(coalesce(a->>'block','')))<>bl then return false; end if;
  if lvl='VILLAGE' and lower(trim(coalesce(a->>'village','')))<>vi then return false; end if;

  return true;
end $$;

-- ------------------------------------------------------------
-- 2) Content management: final permissions + Flash time validation.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rkms_manage_content_v2(
  p_action text,
  p_id uuid default null,
  p_data jsonb default '{}'::jsonb
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare
  action text := upper(trim(coalesce(p_action,'')));
  actor uuid := coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id());
  top_user boolean := public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current();
  oldc public.rkms_content_v2%rowtype;
  ct text := upper(trim(coalesce(p_data->>'content_type','')));
  tt text := upper(trim(coalesce(p_data->>'target_type','')));
  areas jsonb := coalesce(p_data->'target_areas','[]'::jsonb);
  aud text := upper(trim(coalesce(p_data->>'target_audience','ALL')));
  pr boolean := coalesce((p_data->>'priority')::boolean,false);
  start_ts timestamptz;
  end_ts timestamptz;
  id2 uuid;
begin
  if actor is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;

  if action='CREATE' then
    if ct not in ('COURT_ORDER','ORG_NOTICE','EVENT','FLASH') then
      return jsonb_build_object('success',false,'message','अमान्य Content type।');
    end if;
    if ct in ('COURT_ORDER','FLASH') and not top_user then
      return jsonb_build_object('success',false,'message','यह Content केवल Super Admin या राष्ट्रीय अध्यक्ष जारी कर सकते हैं।');
    end if;

    -- Organization Information and Program/Event are always visible to both
    -- officers and members in the matching geographic scope.
    if ct in ('ORG_NOTICE','EVENT') then aud := 'ALL';
    elsif aud not in ('OFFICERS','MEMBERS','ALL') then aud := 'ALL';
    end if;

    if tt='ALL' then
      if not top_user then return jsonb_build_object('success',false,'message','पूरा संगठन target करने का अधिकार नहीं है।'); end if;
      areas := '[{"type":"ALL"}]'::jsonb;
    elsif not public.rkms_v2_scope_allowed(tt,areas) then
      return jsonb_build_object('success',false,'message','Targeting आपके अधिकार क्षेत्र से बाहर है।');
    end if;

    if ct='FLASH' then
      if nullif(trim(p_data->>'start_at'),'') is null then
        return jsonb_build_object('success',false,'message','Flash का Start Date/Time जरूरी है।');
      end if;
      if nullif(trim(p_data->>'end_at'),'') is null then
        return jsonb_build_object('success',false,'message','Flash का End Date/Time जरूरी है।');
      end if;
      start_ts := (p_data->>'start_at')::timestamptz;
      end_ts := (p_data->>'end_at')::timestamptz;
      if end_ts <= start_ts then
        return jsonb_build_object('success',false,'message','Flash का End Date/Time Start Date/Time के बाद होना चाहिए।');
      end if;
    else
      start_ts := nullif(p_data->>'start_at','')::timestamptz;
      end_ts := nullif(p_data->>'end_at','')::timestamptz;
    end if;

    insert into public.rkms_content_v2(
      content_type,title,description,event_date,event_time,location,attachments,
      target_type,target_areas,target_audience,priority,start_at,end_at,created_by,updated_by
    ) values (
      ct,nullif(trim(p_data->>'title'),''),p_data->>'description',
      nullif(p_data->>'event_date','')::date,p_data->>'event_time',p_data->>'location',
      coalesce(p_data->'attachments','[]'::jsonb),tt,areas,aud,
      case when ct='COURT_ORDER' then false else pr end,
      start_ts,end_ts,actor,actor
    ) returning id into id2;

    perform public.rkms_v2_create_notifications(id2);
    return jsonb_build_object('success',true,'id',id2,'action','CREATE');
  end if;

  if p_id is null then return jsonb_build_object('success',false,'message','Content ID जरूरी है।'); end if;
  select * into oldc from public.rkms_content_v2 where id=p_id;
  if not found or oldc.deleted_at is not null then
    return jsonb_build_object('success',false,'message','Content उपलब्ध नहीं है।');
  end if;

  if not public.rkms_v2_can_manage(oldc.content_type,action,p_id) then
    return jsonb_build_object('success',false,'message','इस Content पर अधिकार नहीं है।');
  end if;

  if action='UPDATE' then
    -- Content type is immutable. A lower officer can only update their own
    -- ORG_NOTICE/EVENT; Top authority can update any of the four types.
    ct := oldc.content_type;
    if tt='' then tt := oldc.target_type; end if;
    if not (p_data ? 'target_areas') then areas := oldc.target_areas; end if;
    if not (p_data ? 'target_audience') then aud := oldc.target_audience; end if;
    if ct in ('ORG_NOTICE','EVENT') then aud := 'ALL'; end if;

    if tt='ALL' then
      if not top_user then return jsonb_build_object('success',false,'message','पूरा संगठन target करने का अधिकार नहीं है।'); end if;
      areas := '[{"type":"ALL"}]'::jsonb;
    elsif not public.rkms_v2_scope_allowed(tt,areas) and not top_user then
      return jsonb_build_object('success',false,'message','Targeting आपके अधिकार क्षेत्र से बाहर है।');
    end if;

    if ct='FLASH' then
      if p_data ? 'start_at' then start_ts := nullif(trim(p_data->>'start_at'),'')::timestamptz; else start_ts := oldc.start_at; end if;
      if p_data ? 'end_at' then end_ts := nullif(trim(p_data->>'end_at'),'')::timestamptz; else end_ts := oldc.end_at; end if;
      if start_ts is null or end_ts is null then return jsonb_build_object('success',false,'message','Flash का Start और End Date/Time दोनों जरूरी हैं।'); end if;
      if end_ts <= start_ts then return jsonb_build_object('success',false,'message','Flash का End Date/Time Start Date/Time के बाद होना चाहिए।'); end if;
    else
      start_ts := case when p_data ? 'start_at' then nullif(p_data->>'start_at','')::timestamptz else oldc.start_at end;
      end_ts := case when p_data ? 'end_at' then nullif(p_data->>'end_at','')::timestamptz else oldc.end_at end;
    end if;

    update public.rkms_content_v2 set
      title=coalesce(nullif(trim(p_data->>'title'),''),title),
      description=coalesce(p_data->>'description',description),
      event_date=case when p_data ? 'event_date' and nullif(p_data->>'event_date','') is not null then (p_data->>'event_date')::date else event_date end,
      event_time=coalesce(p_data->>'event_time',event_time),
      location=coalesce(p_data->>'location',location),
      attachments=case when p_data ? 'attachments' then coalesce(p_data->'attachments','[]'::jsonb) else attachments end,
      target_type=tt,target_areas=areas,target_audience=aud,
      priority=case when content_type='COURT_ORDER' then false else coalesce((p_data->>'priority')::boolean,priority) end,
      start_at=start_ts,end_at=end_ts,updated_by=actor,updated_at=now()
    where id=p_id;

    perform public.rkms_v2_delete_notifications(p_id);
    perform public.rkms_v2_create_notifications(p_id);
    return jsonb_build_object('success',true,'id',p_id,'action','UPDATE');
  elsif action='DELETE' then
    perform public.rkms_v2_delete_notifications(p_id);
    update public.rkms_content_v2 set deleted_at=now(),deleted_by=actor,updated_by=actor,updated_at=now() where id=p_id;
    return jsonb_build_object('success',true,'id',p_id,'action','DELETE');
  end if;

  return jsonb_build_object('success',false,'message','Invalid action.');
exception when others then
  return jsonb_build_object('success',false,'message',sqlerrm);
end $$;

-- ------------------------------------------------------------
-- 3) Home: active Flash window + one card per Content ID.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rkms_get_home_content_v2(p_limit integer DEFAULT 50)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare u jsonb:=public.rkms_v2_user_scope(); r jsonb;
begin
  perform public.rkms_v2_expire_flash();
  select coalesce(jsonb_agg(to_jsonb(x) order by x.priority desc,x.created_at desc),'[]'::jsonb) into r
  from (
    select c.*,
      case when c.content_type='EVENT' then 'कार्यक्रम'
           when c.content_type='ORG_NOTICE' then 'संगठन सूचना'
           when c.content_type='FLASH' then 'Flash'
           else 'न्यायालय आदेश' end as type_label,
      case when sa.id is not null then coalesce(nullif(trim(sa.name),''),'Super Admin')
           else coalesce(nullif(trim(coalesce(o.signature_name,'')),''),nullif(trim(coalesce(m.name,'')),''),'अधिकारी') end as created_by_name,
      nullif(trim(coalesce(p.post_name,'')),'') as created_by_post,
      case when usa.id is not null then coalesce(nullif(trim(usa.name),''),'Super Admin')
           else coalesce(nullif(trim(coalesce(uo.signature_name,'')),''),nullif(trim(coalesce(um.name,'')),''),'अधिकारी') end as updated_by_name,
      nullif(trim(coalesce(up.post_name,'')),'') as updated_by_post
    from public.rkms_content_v2 c
    left join public.rkms_officers o on o.id=c.created_by
    left join public.rkms_members m on m.id=o.member_id
    left join public.rkms_posts p on p.id=o.post_id
    left join public.rkms_admins sa on sa.id=c.created_by and sa.role='SUPER_ADMIN' and sa.status='ACTIVE'
    left join public.rkms_officers uo on uo.id=c.updated_by
    left join public.rkms_members um on um.id=uo.member_id
    left join public.rkms_posts up on up.id=uo.post_id
    left join public.rkms_admins usa on usa.id=c.updated_by and usa.role='SUPER_ADMIN' and usa.status='ACTIVE'
    where c.deleted_at is null
      and (c.content_type<>'FLASH' or ((c.start_at is null or c.start_at<=now()) and (c.end_at is null or c.end_at>=now())))
      and exists (
        select 1 from jsonb_array_elements(c.target_areas) a
        where upper(a->>'type')='ALL'
           or (upper(a->>'type')='STATE' and lower(a->>'state')=lower(coalesce(u->>'state','')))
           or (upper(a->>'type')='MANDAL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')))
           or (upper(a->>'type')='DISTRICT' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')))
           or (upper(a->>'type')='TEHSIL' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')))
           or (upper(a->>'type')='BLOCK' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')) and lower(a->>'block')=lower(coalesce(u->>'block','')))
           or (upper(a->>'type')='VILLAGE' and lower(a->>'state')=lower(coalesce(u->>'state','')) and lower(a->>'mandal')=lower(coalesce(u->>'mandal','')) and lower(a->>'district')=lower(coalesce(u->>'district','')) and lower(a->>'tehsil')=lower(coalesce(u->>'tehsil','')) and lower(a->>'block')=lower(coalesce(u->>'block','')) and lower(a->>'village')=lower(coalesce(u->>'village','')))
      )
      and (c.target_audience='ALL' or c.target_audience=u->>'audience' or u->>'role'='TOP')
    order by c.priority desc,c.created_at desc
    limit greatest(1,least(p_limit,200))
  ) x;
  return r;
end $$;

-- ------------------------------------------------------------
-- 4) Management list: correct Super Admin identity.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rkms_get_content_v2_manage(p_limit integer DEFAULT 100)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
begin
  if public.rkms_current_super_admin_id() is null and not public.rkms_is_national_president_current()
     and public.rkms_current_officer_id() is null then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(to_jsonb(q) order by q.created_at desc)
    from (
      select c.*,
        case when sa.id is not null then coalesce(nullif(trim(sa.name),''),'Super Admin')
             else coalesce(nullif(trim(coalesce(o.signature_name,'')),''),nullif(trim(coalesce(m.name,'')),''),'अधिकारी') end as created_by_name,
        nullif(trim(coalesce(p.post_name,'')),'') as created_by_post,
        case when usa.id is not null then coalesce(nullif(trim(usa.name),''),'Super Admin')
             else coalesce(nullif(trim(coalesce(uo.signature_name,'')),''),nullif(trim(coalesce(um.name,'')),'—'),'—') end as updated_by_name,
        nullif(trim(coalesce(up.post_name,'')),'') as updated_by_post
      from public.rkms_content_v2 c
      left join public.rkms_officers o on o.id=c.created_by
      left join public.rkms_members m on m.id=o.member_id
      left join public.rkms_posts p on p.id=o.post_id
      left join public.rkms_admins sa on sa.id=c.created_by and sa.role='SUPER_ADMIN' and sa.status='ACTIVE'
      left join public.rkms_officers uo on uo.id=c.updated_by
      left join public.rkms_members um on um.id=uo.member_id
      left join public.rkms_posts up on up.id=uo.post_id
      left join public.rkms_admins usa on usa.id=c.updated_by and usa.role='SUPER_ADMIN' and usa.status='ACTIVE'
      where c.deleted_at is null
        and (public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() or c.created_by=public.rkms_current_officer_id())
      limit greatest(1,least(p_limit,300))
    ) q
  ),'[]'::jsonb);
end $$;

-- ------------------------------------------------------------
-- 5) Content V2 attachment Storage RLS.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rkms_v2_can_upload_content_media()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public,pg_catalog AS $$
  select public.rkms_is_top_content_manager() or public.rkms_current_officer_id() is not null;
$$;

DROP POLICY IF EXISTS "rkms v2 content media insert" ON storage.objects;
CREATE POLICY "rkms v2 content media insert" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id='rkms-media' AND name LIKE 'content-v2/%' AND public.rkms_v2_can_upload_content_media()
);

DROP POLICY IF EXISTS "rkms v2 content media delete own" ON storage.objects;
CREATE POLICY "rkms v2 content media delete own" ON storage.objects
FOR DELETE TO authenticated
USING (
  bucket_id='rkms-media' AND name LIKE 'content-v2/%' AND public.rkms_v2_can_upload_content_media()
);

DROP POLICY IF EXISTS "rkms v2 content media update own" ON storage.objects;
CREATE POLICY "rkms v2 content media update own" ON storage.objects
FOR UPDATE TO authenticated
USING (
  bucket_id='rkms-media' AND name LIKE 'content-v2/%' AND public.rkms_v2_can_upload_content_media()
)
WITH CHECK (
  bucket_id='rkms-media' AND name LIKE 'content-v2/%' AND public.rkms_v2_can_upload_content_media()
);

-- Public read remains controlled by the existing bucket policy; this migration
-- does not open anonymous upload/update/delete access.

-- ------------------------------------------------------------
-- 6) Retire old application-level content notification triggers.
-- The old tables remain for historical compatibility, but they can no longer
-- create new News/Gallery/legacy Flash/Event notifications.
-- ------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_rkms_content_notification ON public.rkms_news;
DROP TRIGGER IF EXISTS trg_rkms_content_notification ON public.rkms_gallery;
DROP TRIGGER IF EXISTS trg_rkms_content_notification ON public.rkms_flash_messages;
DROP TRIGGER IF EXISTS trg_rkms_content_notification ON public.rkms_events;
DROP TRIGGER IF EXISTS trg_rkms_news_push_update ON public.rkms_news;
DROP TRIGGER IF EXISTS trg_rkms_gallery_push_update ON public.rkms_gallery;
DROP TRIGGER IF EXISTS trg_rkms_flash_push_update ON public.rkms_flash_messages;
DROP TRIGGER IF EXISTS trg_rkms_events_push_update ON public.rkms_events;
