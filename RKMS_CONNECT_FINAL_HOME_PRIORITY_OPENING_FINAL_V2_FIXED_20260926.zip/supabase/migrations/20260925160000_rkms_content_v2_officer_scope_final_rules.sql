-- RKMS CONNECT Content V2 final officer scope rules
-- ORG_NOTICE/EVENT: every active officer may create content for their own area.
-- Visibility is inherited by all descendants and both officers + members.
-- COURT_ORDER/FLASH remain top-authority only.

CREATE OR REPLACE FUNCTION public.rkms_v2_general_content_scope_allowed(p_target_type text,p_target_areas jsonb)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_catalog AS $$
declare s jsonb:=public.rkms_content_scope_json(); lvl text:=upper(coalesce(s->>'authority_level','')); a jsonb; at text;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then return true; end if;
  if lvl not in ('STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then return false; end if;
  if upper(coalesce(p_target_type,''))<>lvl or jsonb_typeof(p_target_areas)<>'array' or jsonb_array_length(p_target_areas)<>1 then return false; end if;
  a:=p_target_areas->0; at:=upper(coalesce(a->>'type',''));
  if at<>lvl then return false; end if;
  if lower(trim(coalesce(a->>'state','')))<>lower(trim(coalesce(s->>'state',''))) then return false; end if;
  if lvl in ('MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') and lower(trim(coalesce(a->>'mandal','')))<>lower(trim(coalesce(s->>'mandal',''))) then return false; end if;
  if lvl in ('DISTRICT','TEHSIL','BLOCK','VILLAGE') and lower(trim(coalesce(a->>'district','')))<>lower(trim(coalesce(s->>'district',''))) then return false; end if;
  if lvl in ('TEHSIL','BLOCK','VILLAGE') and lower(trim(coalesce(a->>'tehsil','')))<>lower(trim(coalesce(s->>'tehsil',''))) then return false; end if;
  if lvl in ('BLOCK','VILLAGE') and lower(trim(coalesce(a->>'block','')))<>lower(trim(coalesce(s->>'block',''))) then return false; end if;
  if lvl='VILLAGE' and lower(trim(coalesce(a->>'village','')))<>lower(trim(coalesce(s->>'village',''))) then return false; end if;
  return true;
end $$;

-- The application and existing V2 management RPC must be deployed together with this migration.
-- This guard function is called by rkms_manage_content_v2 for ORG_NOTICE and EVENT.
