import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL=Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin=createClient(SUPABASE_URL,SERVICE_ROLE);
const H={"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const out=(x:unknown,s=200)=>new Response(JSON.stringify(x),{status:s,headers:H});

async function dispatchQueue(queueId:string){
  const url=`${SUPABASE_URL}/functions/v1/rkms-fcm-dispatch-v2`;
  const key=Deno.env.get("RKMS_PUSH_KEY")||"";
  if(!key) throw new Error("RKMS_PUSH_KEY secret is missing.");
  return fetch(url,{method:"POST",headers:{"Content-Type":"application/json","x-rkms-push-key":key},body:JSON.stringify({queue_id:queueId})});
}

Deno.serve(async req=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers:H});
  try{
    if(req.method!=="POST") return out({success:false,message:"POST required"},405);
    const auth=req.headers.get("Authorization")||"";
    if(!auth.startsWith("Bearer ")) return out({success:false,message:"Login required"},401);
    const {data:{user},error:ue}=await admin.auth.getUser(auth.slice(7));
    if(ue||!user) return out({success:false,message:"Invalid login"},401);
    const b:any=await req.json().catch(()=>({}));
    const action=String(b.action||"").toLowerCase();

    if(action==="register_token"){
      const token=String(b.fcm_token||"").trim();
      if(!token) return out({success:false,message:"fcm_token required"},400);
      const device=String(b.device_id||"").trim()||null;
      const platform=String(b.platform||"android").trim().toLowerCase();
      const version=String(b.app_version||"").trim()||null;
      const {error:delErr}=await admin.from("rkms_fcm_tokens").delete().eq("fcm_token",token).neq("auth_user_id",user.id);
      if(delErr) throw delErr;
      const {data,error}=await admin.from("rkms_fcm_tokens").upsert(
        {auth_user_id:user.id,fcm_token:token,device_id:device,platform,app_version:version,updated_at:new Date().toISOString()},
        {onConflict:"fcm_token"}
      ).select("id").single();
      if(error) throw error;

      const cutoff=new Date(Date.now()-24*60*60*1000).toISOString();
      const {data:pending}=await admin.from("rkms_push_queue").select("id").eq("recipient_auth_user_id",user.id).is("delivered_at",null).gte("created_at",cutoff).order("created_at",{ascending:true}).limit(20);
      if(pending?.length){for(const q of pending){try{await dispatchQueue(q.id)}catch(_){}}}
      return out({success:true,registered:true,id:data.id,retried:pending?.length||0});
    }

    if(action==="unregister_token"){
      const token=String(b.fcm_token||"").trim();
      if(!token) return out({success:false,message:"fcm_token required"},400);
      const {error}=await admin.from("rkms_fcm_tokens").delete().eq("auth_user_id",user.id).eq("fcm_token",token);
      if(error) throw error;
      return out({success:true,unregistered:true});
    }

    if(action==="send_queue"){
      const queueId=String(b.queue_id||"").trim();
      if(!queueId) return out({success:false,message:"queue_id required"},400);
      const {data:q,error:qe}=await admin.from("rkms_push_queue").select("id,sender_auth_user_id,delivered_at").eq("id",queueId).maybeSingle();
      if(qe) throw qe;
      if(!q) return out({success:false,message:"Push queue item not found"},404);
      if(q.sender_auth_user_id!==user.id) return out({success:false,message:"Not allowed"},403);
      const r=await dispatchQueue(queueId);
      const j:any=await r.json().catch(()=>({}));
      return out(j,r.status);
    }

    if(action==="send") return out({success:false,message:"Direct token send is disabled; use the queue dispatcher."},403);
    return out({success:false,message:"Invalid action"},400);
  }catch(e){
    return out({success:false,message:e instanceof Error?e.message:"FCM server error"},500);
  }
});
