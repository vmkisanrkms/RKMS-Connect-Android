# RKMS CONNECT — FINAL CONTENT V2 LOCK AUDIT — 2026-09-26

Source: `RKMS_CONNECT_FINAL_CONTENT_RULES_CREATOR_ACTIONS_FIXED_KEYPAD_NO_DUPLICATES_FINAL_20260925.zip`

## Fixed in this build

1. Added self-contained Android 16 / API 36 Release APK workflow.
2. Added Content V2 Storage RLS migration for `content-v2/*` uploads/updates/deletes.
3. Added `rkms-fcm-push` Edge Function source to the ZIP. The internal dispatcher key is read from `RKMS_PUSH_KEY`; no secret is hard-coded in the new packaged function.
4. Flash now requires Start Date/Time and End Date/Time; End must be after Start.
5. Flash visibility is enforced server-side only while `start_at <= now() <= end_at`.
6. Removed the old app startup calls to `rkms_get_active_flash` and `rkms_get_flash_messages`.
7. Removed the old Home Flash rotator path.
8. Retired old News/Gallery notification route mappings from the app-level V2 notification router.
9. Corrected Content Management label to the four locked content types.
10. Priority Organization Information / Events remain in both Home top and Home bottom areas as required.
11. Home V2 now uses an `EXISTS` target-area check so one Content ID cannot become duplicate Home cards when multiple target areas match the same user.
12. Super Admin creator name/post resolution is now included in both Home and Content Management RPCs.
13. Lower-officer backend targeting is now exact: one target area and target type must equal the officer's authority level.
14. Organization Information and Event audience is forced to `ALL` server-side.
15. Upload cleanup scope is corrected so newly uploaded Content V2 files can be removed if the database save fails.
16. Added/updated static verification for the final locked structure.

## Verification

- `node --check app.js` — PASS
- `npm run build` — PASS
- `verify-rkms-final.py` — PASS
- `verify-content-management-final.py` — 18/18 PASS
- `verify-fcm-pipeline.py` — PASS
- `verify-webview-notification-fix.py` — PASS
- `verify-chat-mic-final.py` — PASS
- `verify-saved-login.py` — PASS
- `verify-final-three-point-fix.py` — 17/17 PASS
- `verify-content-v2-final-lock.py` — 14/14 PASS

## Important build note

The APK workflow intentionally builds **Release APK only** with `:app:assembleRelease`.
It does not build a debug APK or AAB.

The workflow requires these GitHub Actions secrets:

- `RKMS_KEYSTORE_BASE64`
- `RKMS_KEYSTORE_PASSWORD`
- `RKMS_KEY_ALIAS`
- `RKMS_KEY_PASSWORD`

The packaged `rkms-fcm-push` Edge Function requires the Supabase Edge Function secret `RKMS_PUSH_KEY` to match the internal key configured for `rkms-fcm-dispatch-v2`.
