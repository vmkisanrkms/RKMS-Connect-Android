#!/usr/bin/env bash
set -euo pipefail
APP_SRC="android/app/src/main/java/org/rkms/connect"
mkdir -p "$APP_SRC"
cat > "$APP_SRC/RKMSSecureCredentialsPlugin.java" <<'JAVA'
package org.rkms.connect;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name = "RKMSSecureCredentials")
public class RKMSSecureCredentialsPlugin extends Plugin {
    private static final String PREFS = "rkms_secure_credentials";
    private static final String KEY_ALIAS = "RKMS_CREDENTIALS_AES";
    private static final String ID_KEY = "identifier";
    private static final String CIPHER_KEY = "ciphertext";
    private static final String IV_KEY = "iv";

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        kg.init(new android.security.keystore.KeyGenParameterSpec.Builder(KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(false)
                .build());
        return kg.generateKey();
    }

    @PluginMethod
    public void save(PluginCall call) {
        String identifier = call.getString("identifier", "").trim();
        String password = call.getString("password", "");
        if (identifier.isEmpty() || password.isEmpty()) { call.reject("Missing credentials"); return; }
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] encrypted = c.doFinal(password.getBytes(StandardCharsets.UTF_8));
            prefs().edit().putString(ID_KEY, identifier)
                    .putString(CIPHER_KEY, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                    .putString(IV_KEY, Base64.encodeToString(c.getIV(), Base64.NO_WRAP)).apply();
            call.resolve();
        } catch (Exception e) { call.reject("Secure credential save failed"); }
    }

    @PluginMethod
    public void getSavedIdentifier(PluginCall call) {
        JSObject out = new JSObject();
        out.put("identifier", prefs().getString(ID_KEY, ""));
        call.resolve(out);
    }

    @PluginMethod
    public void authenticateAndGetCredentials(PluginCall call) {
        final String identifier = prefs().getString(ID_KEY, "");
        final String encoded = prefs().getString(CIPHER_KEY, "");
        final String encodedIv = prefs().getString(IV_KEY, "");
        if (identifier == null || identifier.isEmpty() || encoded == null || encoded.isEmpty() || encodedIv == null || encodedIv.isEmpty()) {
            call.reject("No saved credentials"); return;
        }
        BiometricManager bm = BiometricManager.from(getContext());
        int can = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        if (can != BiometricManager.BIOMETRIC_SUCCESS) { call.reject("Fingerprint / PIN / device screen lock is not available"); return; }
        try {
            FragmentActivity activity = (FragmentActivity) getActivity();
            Executor executor = Executors.newSingleThreadExecutor();
            BiometricPrompt prompt = new BiometricPrompt(activity, executor, new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(encodedIv, Base64.NO_WRAP)));
                        String password = new String(c.doFinal(Base64.decode(encoded, Base64.NO_WRAP)), StandardCharsets.UTF_8);
                        JSObject out = new JSObject(); out.put("identifier", identifier); out.put("password", password); call.resolve(out);
                    } catch (Exception e) { call.reject("Saved credentials could not be unlocked"); }
                }
                @Override public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) { call.reject("Authentication cancelled"); }
                @Override public void onAuthenticationFailed() { }
            });
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("RKMS Saved Login")
                    .setSubtitle("Fingerprint या phone PIN/password से Saved Login unlock करें")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    .build();
            activity.runOnUiThread(() -> prompt.authenticate(info));
        } catch (Exception e) { call.reject("Secure unlock unavailable"); }
    }

    @PluginMethod
    public void clear(PluginCall call) { prefs().edit().clear().apply(); call.resolve(); }
}
JAVA

MAIN="android/app/src/main/java/org/rkms/connect/MainActivity.java"
if [ -f "$MAIN" ]; then
  python3 - <<'PY'
from pathlib import Path
p=Path('android/app/src/main/java/org/rkms/connect/MainActivity.java')
s=p.read_text()
if 'RKMSSecureCredentialsPlugin' not in s:
    marker='public class MainActivity extends BridgeActivity {'
    replacement='public class MainActivity extends BridgeActivity {\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        super.onCreate(savedInstanceState);\n        registerPlugin(RKMSSecureCredentialsPlugin.class);\n        getBridge().getWebView().addJavascriptInterface(new RKMSNativeBridge(this), \"RKMSNative\");\n    }'
    if marker not in s:
        raise SystemExit('MainActivity class marker missing')
    s=s.replace(marker,replacement,1)
    p.write_text(s)
PY
else
  echo "ERROR: MainActivity.java not found" >&2
  find android/app/src/main -type f >&2
  exit 1
fi

cat > "$APP_SRC/RKMSNativeBridge.java" <<'JAVA'
package org.rkms.connect;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
public final class RKMSNativeBridge {
 private static final String PREFS="rkms_native_session", KEY_ALIAS="RKMS_NATIVE_SESSION_AES";
 private final SharedPreferences prefs;
 public RKMSNativeBridge(Context c){prefs=c.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
 private SecretKey key() throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(KEY_ALIAS))return((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore");kg.init(new android.security.keystore.KeyGenParameterSpec.Builder(KEY_ALIAS,android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).setUserAuthenticationRequired(false).build());return kg.generateKey();}
 private void put(String n,String v)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());prefs.edit().putString(n,Base64.encodeToString(c.doFinal(v.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP)).putString(n+"_iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).apply();}
 private String get(String n){try{String e=prefs.getString(n,"");String iv=prefs.getString(n+"_iv","");if(e.isEmpty()||iv.isEmpty())return"";Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(e,Base64.NO_WRAP)),StandardCharsets.UTF_8);}catch(Exception e){return"";}}
 @JavascriptInterface public void saveSession(String a,String r,String role){try{put("access",a==null?"":a);put("refresh",r==null?"":r);put("role",role==null?"":role);}catch(Exception ignored){}}
 @JavascriptInterface public void saveSessionNoPush(String a,String r,String role){saveSession(a,r,role);}
 @JavascriptInterface public String getAccessToken(){return get("access");}
 @JavascriptInterface public String getRefreshToken(){return get("refresh");}
 @JavascriptInterface public String getRole(){return get("role");}
 @JavascriptInterface public void clearSession(){prefs.edit().clear().apply();}
 @JavascriptInterface public void setBookZoomMode(boolean enabled){}
}
JAVA

python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
if 'androidx.biometric:biometric:' not in s:
    marker='dependencies {'
    if marker in s:
        s=s.replace(marker, marker+'\n    implementation "androidx.biometric:biometric:1.1.0"',1)
    else:
        s += '\n\ndependencies { implementation "androidx.biometric:biometric:1.1.0" }\n'
p.write_text(s)
PY
