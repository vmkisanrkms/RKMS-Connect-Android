# RKMS Book Reader – Video-style page curl fix

Changes in this build:
- Current page remains visible while the pulled flap peels away.
- Diagonal fold line creates a corner/edge peel rather than hiding the whole page.
- Pull progress follows the finger continuously.
- Releasing below the threshold reverses the peel; releasing beyond the threshold completes the turn.
- Corner position is preserved during the release animation.
- Previous and next turns are mirrored.
- Book pinch zoom is smooth and capped at 8x; two-finger pinch controls the amount continuously.
- At zoom > 1, one-finger drag pans the page and does not trigger page turning.
- Global RKMS WebView zoom is not disabled.
- Visible Book controls remain First, Back, Next, Last, Download only.
