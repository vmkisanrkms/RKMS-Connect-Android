RKMS FCM push function source.

This version sends HIGH-priority data-only FCM messages so the Android app's own notification service controls channel, sound, vibration and tap routing. Deploy this index.ts to the existing Supabase Edge Function rkms-fcm-push after verifying the project secrets remain configured.
