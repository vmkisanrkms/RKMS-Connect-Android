import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { importPKCS8, SignJWT } from "npm:jose@5.10.0";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

const H = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

const out = (x: unknown, s = 200) =>
  new Response(JSON.stringify(x), { status: s, headers: H });

type SA = {
  project_id: string;
  client_email: string;
  private_key: string;
  token_uri?: string;
};

let cached: { token: string; exp: number } | null = null;

function sa(): SA {
  const raw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT") || "";
  if (!raw) throw new Error("Firebase service account secret is missing.");

  let x: SA;
  try {
    x = JSON.parse(raw);
  } catch {
    throw new Error("Firebase service account secret is not valid JSON");
  }

  if (!x.project_id || !x.client_email || !x.private_key) {
    throw new Error("Firebase service account configuration is incomplete.");
  }

  return x;
}

async function accessToken(x: SA) {
  const now = Math.floor(Date.now() / 1000);

  if (cached && cached.exp > now + 60) return cached.token;

  const key = await importPKCS8(x.private_key, "RS256");

  const assertion = await new SignJWT({
    scope: "https://www.googleapis.com/auth/firebase.messaging"
  })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(x.client_email)
    .setSubject(x.client_email)
    .setAudience(
      x.token_uri || "https://oauth2.googleapis.com/token"
    )
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);

  const r = await fetch(
    x.token_uri || "https://oauth2.googleapis.com/token",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        grant_type:
          "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion
      })
    }
  );

  const j: any = await r.json().catch(() => ({}));

  if (!r.ok || !j.access_token) {
    throw new Error(
      `Firebase OAuth token failed (${r.status}).`
    );
  }

  cached = {
    token: j.access_token,
    exp: now + Number(j.expires_in || 3600)
  };

  return cached.token;
}

async function sendFCM(
  token: string,
  title: string,
  body: string,
  data: Record<string, string> = {}
) {
  const x = sa();
  const at = await accessToken(x);

  const cleanTitle =
    title || "RKMS Connect";

  const cleanBody =
    body || "नई RKMS सूचना";

  const cleanData: Record<string, string> = {
    title: cleanTitle,
    body: cleanBody,
    ...Object.fromEntries(
      Object.entries(data).map(([k, v]) => [
        String(k),
        String(v ?? "")
      ])
    )
  };

  /*
   * DATA-ONLY HIGH PRIORITY MESSAGE
   *
   * This intentionally does NOT include a top-level
   * notification payload. Android therefore delivers the
   * message to RKMSFirebaseMessagingService even when the
   * app is backgrounded/closed, allowing RKMS to create its
   * own notification channel, sound, vibration and tap route.
   */
  const payload = {
    message: {
      token,
      data: cleanData,
      android: {
        priority: "HIGH"
      }
    }
  };

  const r = await fetch(
    `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(
      x.project_id
    )}/messages:send`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${at}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    }
  );

  const j: any = await r.json().catch(() => ({}));

  if (!r.ok) {
    throw new Error(
      `FCM send failed (${r.status}): ${
        String(j?.error?.message || "unknown error")
      }`
    );
  }

  return j;
}

Deno.serve(async req => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: H });
  }

  try {
    if (req.method !== "POST") {
      return out(
        { success: false, message: "POST required" },
        405
      );
    }

    const auth =
      req.headers.get("Authorization") || "";

    if (!auth.startsWith("Bearer ")) {
      return out(
        { success: false, message: "Login required" },
        401
      );
    }

    const {
      data: { user },
      error: ue
    } = await admin.auth.getUser(auth.slice(7));

    if (ue || !user) {
      return out(
        { success: false, message: "Invalid login" },
        401
      );
    }

    const b: any =
      await req.json().catch(() => ({}));

    const action =
      String(b.action || "").toLowerCase();


    // =========================================================
    // REGISTER TOKEN
    // =========================================================

    if (action === "register_token") {
      const token =
        String(b.fcm_token || "").trim();

      if (!token) {
        return out(
          {
            success: false,
            message: "fcm_token required"
          },
          400
        );
      }

      const device =
        String(b.device_id || "").trim() || null;

      const platform =
        String(b.platform || "android")
          .trim()
          .toLowerCase();

      const version =
        String(b.app_version || "").trim() || null;

      const { error: delErr } =
        await admin
          .from("rkms_fcm_tokens")
          .delete()
          .eq("fcm_token", token)
          .neq("auth_user_id", user.id);

      if (delErr) throw delErr;

      const {
        data,
        error
      } = await admin
        .from("rkms_fcm_tokens")
        .upsert(
          {
            auth_user_id: user.id,
            fcm_token: token,
            device_id: device,
            platform,
            app_version: version,
            updated_at: new Date().toISOString()
          },
          { onConflict: "fcm_token" }
        )
        .select("id")
        .single();

      if (error) throw error;

      return out({
        success: true,
        registered: true,
        id: data.id
      });
    }


    // =========================================================
    // UNREGISTER TOKEN
    // =========================================================

    if (action === "unregister_token") {
      const token =
        String(b.fcm_token || "").trim();

      if (!token) {
        return out(
          {
            success: false,
            message: "fcm_token required"
          },
          400
        );
      }

      const { error } =
        await admin
          .from("rkms_fcm_tokens")
          .delete()
          .eq("auth_user_id", user.id)
          .eq("fcm_token", token);

      if (error) throw error;

      return out({
        success: true,
        unregistered: true
      });
    }


    // =========================================================
    // SEND QUEUED PUSH
    // =========================================================

    if (action === "send_queue") {
      const queueId =
        String(b.queue_id || "").trim();

      if (!queueId) {
        return out(
          {
            success: false,
            message: "queue_id required"
          },
          400
        );
      }

      const {
        data: q,
        error: qe
      } = await admin
        .from("rkms_push_queue")
        .select(
          "id,recipient_auth_user_id,sender_auth_user_id,title,body,url,chat_message_id,attempts,delivered_at"
        )
        .eq("id", queueId)
        .maybeSingle();

      if (qe) throw qe;

      if (!q) {
        return out(
          {
            success: false,
            message: "Push queue item not found"
          },
          404
        );
      }

      if (q.sender_auth_user_id !== user.id) {
        return out(
          {
            success: false,
            message: "Not allowed"
          },
          403
        );
      }

      if (q.delivered_at) {
        return out({
          success: true,
          sent: false,
          already_delivered: true
        });
      }

      const {
        data: tokens,
        error: te
      } = await admin
        .from("rkms_fcm_tokens")
        .select("id,fcm_token")
        .eq(
          "auth_user_id",
          q.recipient_auth_user_id
        );

      if (te) throw te;

      if (!tokens?.length) {
        await admin
          .from("rkms_push_queue")
          .update({
            attempts: (q.attempts || 0) + 1,
            last_error: "No active FCM token"
          })
          .eq("id", q.id);

        return out({
          success: true,
          sent: false,
          reason: "No active FCM token"
        });
      }

      let conversationId = "";
      let route = "home";

      if (q.chat_message_id) {
        const {
          data: m
        } = await admin
          .from("rkms_chat_messages")
          .select("conversation_id")
          .eq("id", q.chat_message_id)
          .maybeSingle();

        conversationId =
          String(m?.conversation_id || "");

        if (conversationId) {
          route =
            `chat/${conversationId}`;
        }
      }

      let sent = 0;
      let last = "";

      for (const t of tokens) {
        try {
          await sendFCM(
            t.fcm_token,
            q.title || "RKMS Connect",
            q.body ||
              "आपको नया Chat message मिला है।",
            {
              title:
                String(q.title || "RKMS Connect"),

              body:
                String(
                  q.body ||
                  "आपको नया Chat message मिला है।"
                ),

              route,

              conversation_id:
                conversationId,

              queue_id:
                String(q.id),

              type:
                q.chat_message_id
                  ? "rkms_chat"
                  : "rkms_notification"
            }
          );

          sent++;

        } catch (e) {
          last =
            e instanceof Error
              ? e.message
              : String(e);

          if (
            last.includes("NotRegistered") ||
            last.includes("UNREGISTERED") ||
            last.includes(
              "not a valid FCM registration token"
            )
          ) {
            await admin
              .from("rkms_fcm_tokens")
              .delete()
              .eq("id", t.id);
          }
        }
      }

      if (sent > 0) {
        await admin
          .from("rkms_push_queue")
          .update({
            delivered_at:
              new Date().toISOString(),

            attempts:
              (q.attempts || 0) + 1,

            last_error: null
          })
          .eq("id", q.id);

      } else {
        await admin
          .from("rkms_push_queue")
          .update({
            attempts:
              (q.attempts || 0) + 1,

            last_error:
              last || "FCM delivery failed"
          })
          .eq("id", q.id);
      }

      return out({
        success: true,
        sent: sent > 0,
        devices: sent,
        last_error:
          sent ? null : last
      });
    }


    // =========================================================
    // DIRECT SEND
    // =========================================================

    if (action === "send") {
      const token =
        String(b.fcm_token || "").trim();

      if (!token) {
        return out(
          {
            success: false,
            message: "fcm_token required"
          },
          400
        );
      }

      const data =
        b.data &&
        typeof b.data === "object"
          ? b.data
          : {};

      const r = await sendFCM(
        token,
        String(
          b.title || "RKMS Connect"
        ),
        String(
          b.body ||
          "आपको नया संदेश मिला है।"
        ),
        data
      );

      return out({
        success: true,
        sent: true,
        message_id:
          r?.name || null
      });
    }


    return out(
      {
        success: false,
        message: "Invalid action"
      },
      400
    );

  } catch (e) {
    return out(
      {
        success: false,
        message:
          e instanceof Error
            ? e.message
            : "FCM server error"
      },
      500
    );
  }
});
