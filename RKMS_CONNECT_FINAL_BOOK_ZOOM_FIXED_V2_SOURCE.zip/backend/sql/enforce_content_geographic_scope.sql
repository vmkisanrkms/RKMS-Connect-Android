-- RKMS Connect: authoritative geographic Content Management rules.
-- Applied to Supabase production as migration: enforce_content_geographic_scope
-- Super Admin and Rashtriya Adhyaksh remain unrestricted.
-- STATE/MANDAL/DISTRICT/TEHSIL/BLOCK/VILLAGE PDA content is stamped with
-- the officer's own assigned geographic scope and cannot be edited/deleted
-- outside that scope.

alter table public.rkms_flash_messages add column if not exists scope_officer_id uuid, add column if not exists scope_state text, add column if not exists scope_mandal text, add column if not exists scope_district text, add column if not exists scope_tehsil text, add column if not exists scope_block text, add column if not exists scope_village text;
alter table public.rkms_news add column if not exists scope_officer_id uuid, add column if not exists scope_state text, add column if not exists scope_mandal text, add column if not exists scope_district text, add column if not exists scope_tehsil text, add column if not exists scope_block text, add column if not exists scope_village text;
alter table public.rkms_gallery add column if not exists scope_officer_id uuid, add column if not exists scope_state text, add column if not exists scope_mandal text, add column if not exists scope_district text, add column if not exists scope_tehsil text, add column if not exists scope_block text, add column if not exists scope_village text;
alter table public.rkms_documents add column if not exists scope_officer_id uuid, add column if not exists scope_state text, add column if not exists scope_mandal text, add column if not exists scope_district text, add column if not exists scope_tehsil text, add column if not exists scope_block text, add column if not exists scope_village text;

create or replace function public.rkms_is_national_president_current()
returns boolean language sql stable security definer set search_path to public, pg_catalog as $$
  select exists(
    select 1 from public.rkms_officers o
    left join public.rkms_posts p on p.id=o.post_id
    where o.id=public.rkms_current_officer_id()
      and (upper(coalesce(o.authority_level,''))='NATIONAL' or lower(coalesce(p.post_name,'')) like '%राष्ट्रीय अध्यक्ष%')
  );
$$;

create or replace function public.rkms_content_scope_json()
returns jsonb language plpgsql stable security definer set search_path to public, pg_catalog as $$
declare v_officer uuid; v jsonb;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then
    return jsonb_build_object('is_top',true,'officer_id',null,'state',null,'mandal',null,'district',null,'tehsil',null,'block',null,'village',null);
  end if;
  v_officer:=public.rkms_current_officer_id();
  if v_officer is null then return jsonb_build_object('is_top',false); end if;
  select jsonb_build_object('is_top',false,'officer_id',o.id,'authority_level',upper(coalesce(o.authority_level,'')),'state',o.state,'mandal',o.mandal,'district',o.district,'tehsil',o.tehsil,'block',o.block,'village',o.village)
  into v from public.rkms_officers o where o.id=v_officer;
  return coalesce(v,jsonb_build_object('is_top',false));
end;
$$;

create or replace function public.rkms_content_scope_allowed(p_content_type text, p_action text, p_id uuid default null)
returns boolean language plpgsql stable security definer set search_path to public, pg_catalog as $$
declare v_type text:=lower(trim(coalesce(p_content_type,''))); v_action text:=upper(trim(coalesce(p_action,'MANAGE'))); s jsonb; v_level text; v_state text; v_mandal text; v_district text; v_tehsil text; v_block text; v_village text; r record;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then return true; end if;
  if not public.rkms_can_manage_content(v_type,v_action) then return false; end if;
  s:=public.rkms_content_scope_json();
  v_level:=upper(coalesce(s->>'authority_level',''));
  v_state:=s->>'state'; v_mandal:=s->>'mandal'; v_district:=s->>'district'; v_tehsil:=s->>'tehsil'; v_block:=s->>'block'; v_village:=s->>'village';
  if v_action='CREATE' then return true; end if;
  if p_id is null then return false; end if;
  if v_type='flash' then select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village into r from public.rkms_flash_messages where id=p_id;
  elsif v_type='news' then select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village into r from public.rkms_news where id=p_id;
  elsif v_type='gallery' then select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village into r from public.rkms_gallery where id=p_id;
  elsif v_type='documents' then select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village into r from public.rkms_documents where id=p_id;
  elsif v_type='events' then select state as scope_state,district as scope_district,tehsil as scope_tehsil,block as scope_block,village as scope_village,null::text as scope_mandal into r from public.rkms_events where id=p_id;
  else return false; end if;
  if not found then return false; end if;
  if v_state is null or lower(trim(coalesce(r.scope_state,'')))<>lower(trim(v_state)) then return false; end if;
  if v_level='STATE' then return true; end if;
  if v_mandal is not null and lower(trim(coalesce(r.scope_mandal,'')))<>lower(trim(v_mandal)) then return false; end if;
  if v_level='MANDAL' then return true; end if;
  if v_district is not null and lower(trim(coalesce(r.scope_district,'')))<>lower(trim(v_district)) then return false; end if;
  if v_level='DISTRICT' then return true; end if;
  if v_tehsil is not null and lower(trim(coalesce(r.scope_tehsil,'')))<>lower(trim(v_tehsil)) then return false; end if;
  if v_level='TEHSIL' then return true; end if;
  if v_block is not null and lower(trim(coalesce(r.scope_block,'')))<>lower(trim(v_block)) then return false; end if;
  if v_level='BLOCK' then return true; end if;
  if v_village is not null and lower(trim(coalesce(r.scope_village,'')))<>lower(trim(v_village)) then return false; end if;
  return v_level='VILLAGE';
end;
$$;

-- The five PDA-managed content RPCs were updated in production to call
-- rkms_content_scope_allowed() and automatically stamp the officer's scope:
-- rkms_manage_flash, rkms_manage_news, rkms_manage_gallery,
-- rkms_manage_documents, rkms_manage_events.
