# RKMS Book + Gurpartap Signature v2.7

Merged from the Book Reader v2.6 source with the authorized Gurpartap Singh IT Cell District Secretary signature fallback.

Book behavior is preserved from v2.6; the signature asset and signer resolution are added without using the generic external ACTION_VIEW download listener.
