# RKMS V9 final fixes

- Android display name is RKMS.
- Flash upload now uploads each selected photo first and refuses to save a Flash without a valid public URL.
- Notification audience UI explicitly labels ALL as all members + all PDA/officers + National President + Super Admin.
- Notification attachment upload remains supported for PDF/JPG/PNG/WEBP/DOC/DOCX.
- GitHub workflow extracts the single RKMS ZIP, verifies the Android project and app name, and builds the debug APK.

Important: the live Supabase database/FCM routing must remain configured so publishing an order/notice creates recipients for all intended accounts.
