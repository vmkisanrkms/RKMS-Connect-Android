RKMS Connect Book Reader — Video Match Final Update

Changes in this build:
- Visible reader controls remain only First/Fast, Back, Next, Last and Download.
- Removed instructional text from the reader UI.
- Normal RKMS WebView native zoom remains enabled outside the Book Reader.
- Book Reader disables native WebView zoom while open and uses its own two-finger pinch zoom.
- Zoomed pages can be panned with one finger.
- Page turning is edge/corner driven: light pull reveals a corner curl, continued drag increases the curl, release below threshold reverses, release past threshold completes the turn.
- Top and bottom corners are supported based on where the drag begins.
- Pointer capture is used so the page follows the finger even when the finger moves beyond the stage edge.
- Adjacent book pages are preloaded.
- 60 book pages are preserved.
- JavaScript syntax checked with node --check.

Important: final visual/gesture acceptance still requires a real Android phone test because WebView touch behavior must be confirmed on-device.
