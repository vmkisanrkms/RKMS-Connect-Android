package org.rkms.connect;

import android.content.Context;
import android.content.SharedPreferences;

public final class SessionStore {
    private static final String PREF = "rkms_native_session";
    private SessionStore() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static void save(Context c, String access, String refresh, String role) {
        SharedPreferences.Editor e = p(c).edit();
        if (access != null) e.putString("access", access);
        if (refresh != null && !refresh.isEmpty()) e.putString("refresh", refresh);
        if (role != null && !role.trim().isEmpty()) e.putString("role", role.trim());
        e.apply();
    }

    public static void clear(Context c) {
        p(c).edit().clear().apply();
    }

    public static String access(Context c) { return p(c).getString("access", ""); }
    public static String refresh(Context c) { return p(c).getString("refresh", ""); }
    public static String role(Context c) { return p(c).getString("role", ""); }
}
