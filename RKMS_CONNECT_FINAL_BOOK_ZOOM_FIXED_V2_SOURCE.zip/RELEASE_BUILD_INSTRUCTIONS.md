# RKMS Connect — Release Ready Source

This ZIP is intentionally structured so the Android Gradle project is at repository root.
Do not upload the outer folder itself into GitHub; upload its contents.

Expected repository root:

- `.github/workflows/build-apk.yml`
- `app/`
- `settings.gradle`
- `build.gradle`
- `gradle.properties`
- `backend/` (optional backend source)

The workflow uses Gradle 8.10.2 directly on the GitHub runner, so a local `gradlew` file is not required.

Navigation target:

Home → Chat List → Conversation → Back → Chat List → Back → Home → Back → Exit

Notification target:

Notification → Tap → Conversation → Back → Chat List → Back → Home

The existing FCM sound/vibration implementation is preserved.
