from pathlib import Path

app=Path('app.js').read_text()
css=Path('styles.css').read_text()

def ok(label, cond):
    if not cond:
        raise SystemExit(f'FAIL: {label}')
    print(f'PASS: {label}')

ok('Priority content only in Home top block', 'const top=rows.filter' in app and 'x.priority && ["ORG_NOTICE","EVENT"]' in app)
ok('Normal content only in Home bottom block', 'const bottom=rows.filter(x=>!x.priority' in app)
ok('Deleted V2 notifications hidden from notification center', 'activeV2Ids' in app and 'if(!activeV2Ids.has(cid)) return false' in app)
ok('Note boxes no longer force dashed bordered overlap layout', '.empty,.loading{border-radius' in css and '.note{display:block;color:var(--muted)' in css)
ok('V2 cards prevent content overflow', '.rkms-v2-card{min-width:0;overflow:hidden}' in css and 'overflow-wrap:anywhere' in css)
