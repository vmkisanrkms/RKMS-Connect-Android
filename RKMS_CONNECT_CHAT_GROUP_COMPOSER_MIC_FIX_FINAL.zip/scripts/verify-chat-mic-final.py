from pathlib import Path
app=Path('app.js').read_text(encoding='utf-8')
css=Path('styles.css').read_text(encoding='utf-8')
native=Path('scripts/setup-android-native.sh').read_text(encoding='utf-8')
checks=[
    ('--rkms-compose-runtime-h' in css,'composer runtime height'),
    ('scroll-padding-bottom' in css,'scroll padding'),
    ('position:relative !important' in css and '.wa-conversation-screen .wa-compose-wrap' in css,'composer in conversation flow'),
    ('isMicrophonePermissionGranted' in native,'native mic permission check'),
    ('requestMicrophonePermission' in native,'native mic permission request'),
    ('android.permission.RECORD_AUDIO' in native,'RECORD_AUDIO'),
    ('RESOURCE_AUDIO_CAPTURE' in native,'WebView audio permission'),
    ('MediaRecorder' in app,'MediaRecorder'),
    ('getUserMedia' in app,'getUserMedia')
]
for ok,name in checks:
    print(('PASS' if ok else 'FAIL')+': '+name)
    if not ok: raise SystemExit(1)
if 'padding-bottom:80px !important' in css: raise SystemExit('FAIL: old 80px padding remains')
if 'getUserMedia({audio:true});' not in app and 'getUserMedia({audio:true})' not in app: raise SystemExit('FAIL: fallback getUserMedia missing')
if 'Do not open/close a test stream' not in app: raise SystemExit('FAIL: microphone preflight still present')
print('Chat + microphone final source verification PASS.')
