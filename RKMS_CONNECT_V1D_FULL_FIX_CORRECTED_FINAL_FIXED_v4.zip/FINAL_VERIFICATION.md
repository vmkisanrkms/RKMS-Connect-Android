# RKMS CONNECT V1D Corrected Final Verification

## Source/static status
- app.js syntax: PASS
- PDF pipeline static verification: PASS
- Report download scope verification: PASS
- Native bridge static verification: PASS
- RKMS final verification: PASS
- GitHub workflow source selection: locked to `RKMS_CONNECT_V1D_FULL_FIX_CORRECTED_FINAL.zip`
- Android PDF bridge verification: runs after `npx cap add android` and native bridge setup in CI

## Functional release gates
The following require the generated APK on a real Android device before final PASS:
- Digital ID area rendering
- Digital ID direct PDF save to Downloads/RKMS CONNECT
- Digital ID Print
- Membership Certificate authority block
- Membership Certificate direct PDF save
- Launcher logo/circular mask
- Saved Login after logout/reopen
- PDA State dropdown and full cascading location flow


## V1D real-device retest fixes
1. Digital ID/Certificate PDF: remote Supabase images are fetched with CORS and converted to data URLs before canvas export, preventing the Android WebView `Tainted canvases may not be exported` error.
2. Saved Login: explicit Logout now returns to the Login screen, while secure saved credentials remain stored separately from the cleared session.
3. Digital ID approval signer: approval officer identity/post/signature are resolved with an officer/member fallback when legacy signer fields are empty.
4. PDA appointment: changing the post explicitly re-enables/loads the State selector whenever State scope is required.
5. Launcher logo: safe-area logo size increased moderately from the previous too-small V1D setting.
