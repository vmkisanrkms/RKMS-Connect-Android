from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
sql=(root/'supabase/migrations/20260907041549_report_download_scope_authorization_20260907.sql').read_text(encoding='utf-8')
checks={
 'member/no-download-ui': 'const canDownloadList=state.role==="officer"||state.role==="super_admin";' in app,
 'backend-scoped-rpc-called': 'rkms_get_report_download_data' in app,
 'download-handler-role-guard': 'state.role!=="officer"&&state.role!=="super_admin"' in app,
 'public-aggregate-not-used-for-officer-downloads': 'if(!canDownloadList){' in app and 'rkms_get_organization_report' in app,
 'rpc-is-security-definer': 'SECURITY DEFINER' in sql,
 'anon-execute-revoked': 'REVOKE ALL ON FUNCTION public.rkms_get_report_download_data() FROM anon;' in sql,
 'authenticated-execute-granted': 'GRANT EXECUTE ON FUNCTION public.rkms_get_report_download_data() TO authenticated;' in sql,
 'approved-member-scope': "upper(coalesce(m.status,''))='APPROVED'" in sql and "v_level='DISTRICT'" in sql,
 'active-officer-scope': "upper(coalesce(o.status,''))='ACTIVE'" in sql and "v_level='VILLAGE'" in sql,
 'scope-result-returned': "'scope', v_scope" in sql,
}
failed=[k for k,v in checks.items() if not v]
print('REPORT DOWNLOAD SCOPE VERIFICATION')
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if failed:
    print('FAILED:', ', '.join(failed)); sys.exit(1)
print('PASS: member has no list-download UI; PDA/Super Admin use backend-enforced scoped data.')
