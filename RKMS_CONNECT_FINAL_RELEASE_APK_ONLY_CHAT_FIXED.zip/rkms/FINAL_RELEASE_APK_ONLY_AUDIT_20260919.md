# RKMS CONNECT — Final Release APK Only Audit — 2026-09-19

## Scope
- Release APK only.
- No Debug APK build.
- No AAB build.
- Android API 36 / Android 16 target.
- Chat list and single-chat scroll/footer layout checked.

## Chat UI checks
- `.wa-chat-screen` and `.wa-conversation-screen` use a bounded mobile viewport.
- `.wa-chat-list` is the vertical scroll container.
- `.wa-messages` is the vertical scroll container for a single conversation.
- Global bottom navigation remains fixed and the chat viewport reserves its 62px footprint.
- Chat header/conversation header remains outside the scrolling message/list area.
- Bottom composer remains outside the message scroll area.
- Fixed a malformed mobile CSS declaration that previously joined `max-height` directly to `.wa-chat-list-head`.
- CSS parsed without syntax errors using `tinycss2`.

## Build workflow checks
- Workflow builds only `assembleRelease`.
- Workflow does not run `assembleDebug`.
- Workflow does not run `bundleRelease`.
- Workflow does not upload Debug APK or AAB.
- Release APK is signed and verified with `apksigner`.
- SHA-256 is generated for the final Release APK.
