from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
sql=(root/'supabase/migrations/20260914090000_harden_directory_lists_v17.sql').read_text(encoding='utf-8')

# Bottom member entry must land on the two-choice hub.
assert 'data-route="member-hub"' in (root/'index.html').read_text(encoding='utf-8')
assert 'if(name==="member-hub"){const html=await renderMemberOfficerChooser();setTimeout(loadChooserSlogans,0);return html;}' in app
assert 'data-route="member-list"' in app
assert 'data-route="directory"' in app

# The hub contains exactly the requested two directory choices.
chooser=re.search(r'async function renderMemberOfficerChooser\(\)\{(.*?)\n\}', app, re.S)
assert chooser, 'Member/PDA chooser missing'
body=chooser.group(1)
assert 'सदस्य देखें' in body and 'PDA अधिकारी देखें' in body
assert 'member-login-slogan chooser-slogan' in body
assert 'किसानों की आवाज़ बुलंद रहे' in body
assert 'केवल सदस्यों की सूची, विवरण, कॉल और संदेश।' not in body
assert 'केवल PDA/पदाधिकारियों की सूची, विवरण, कॉल और संदेश।' not in body
assert 'data-route="member-list"' in body and 'data-route="directory"' in body

# Member list and PDA list are separate renderers.
assert 'async function renderAdminMemberList()' in app
assert 'async function renderAdminActiveOfficers(){ return renderDirectory(); }' in app
assert 'rows.map(memberDirectoryCard)' in app
assert 'rows.map(officerCard)' in app

# Ordinary members must not be able to use the member directory RPC.
assert 'if not v_authenticated then' in sql
assert 'if not v_private then' in sql
assert "return jsonb_build_object('success',true,'count',0,'private_access',false,'data','[]'::jsonb);" in sql

# Geographic scope remains enforced for active officers.
for level in ['STATE','MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE']:
    assert f"v_level='{level}'" in sql
assert "v_level='NATIONAL'" in sql

# No cross-list renderer accidentally maps PDA rows into member cards or vice versa.
assert 'rows.map(memberDirectoryCard)' in app
assert 'rows.map(officerCard)' in app

print('MEMBER/PDA FINAL SCOPE AUDIT: PASS')
print('PASS: bottom सदस्य opens member-hub')
print('PASS: hub exposes exactly Member and PDA choices')
print('PASS: Member/PDA lists use separate renderers')
print('PASS: ordinary authenticated members are blocked from directory RPC')
print('PASS: active officer geographic scope remains backend enforced')
print('PASS: no cross-list renderer detected')
