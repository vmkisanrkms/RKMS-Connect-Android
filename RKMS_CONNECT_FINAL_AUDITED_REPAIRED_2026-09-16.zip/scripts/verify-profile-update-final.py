from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
migs='\n'.join(x.read_text(encoding='utf-8') for x in (root/'supabase/migrations').glob('*.sql'))
assert 'data-route="member-update"' in app
for item in ('mu_photo','mu_mobile','mu_signature','uploadMemberSignature','प्रोफ़ाइल अपडेट','मोबाइल नंबर अपडेट करें','हस्ताक्षर अपडेट करें'):
    assert item in app, item
assert 'rkms_update_member_self' in app
assert 'rkms_update_my_signature' in app
assert 'add column if not exists signature_url text' in migs
assert 'create or replace function public.rkms_update_member_self' in migs
assert "member-signatures/" in migs
assert "'signature_url',m.signature_url" in migs
start=app.index('async function renderMemberDashboard()')
end=app.index('async function uploadMemberPhoto',start)
block=app[start:end]
assert block.count('data-route="chat"')==1, 'Member dashboard must have exactly one Chat option'
off=app.index('async function officerDashboard()')
off_end=app.index('async function nationalPresidentDashboard',off)
off_block=app[off:off_end]
assert off_block.count('data-route="chat"')==1, 'Officer dashboard must have exactly one Chat option'
assert 'data-route="member-update"' in off_block, 'Officer dashboard must expose Profile Update'
print('Profile update + single Chat final audit: PASS')
