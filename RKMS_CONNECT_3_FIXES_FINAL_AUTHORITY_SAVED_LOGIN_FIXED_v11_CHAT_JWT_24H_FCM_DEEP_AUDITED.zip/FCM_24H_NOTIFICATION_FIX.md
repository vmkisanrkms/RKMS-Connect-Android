# RKMS CONNECT v11 — 24-Hour / Closed-App Chat Notification Fix

## Final behavior
- New Chat messages generate a server-side push queue entry without requiring the receiver to have RKMS open.
- FCM delivery uses an Android `notification` payload plus HIGH priority and the RKMS notification channel, so Android can display the notification while the app is backgrounded or closed.
- Chat and normal RKMS notification queues use the same server dispatch path.
- Invalid/expired FCM registration tokens are removed from the server token table.
- When the app resumes, the current FCM token is re-registered so token rotation while the app was idle/closed is recovered.
- Existing Chat JWT resume refresh remains enabled separately; push delivery does not depend on the Chat screen being open.

## Backend deployment
The Supabase project now routes Chat and notification queue dispatch to `rkms-fcm-dispatch-v2`, which sends a visible Android notification payload and retains route/conversation data for notification taps.

## Limitation
No mobile push system can guarantee zero delay when the device is powered off, has no network, or the Android OS/OEM has imposed network/background restrictions. With the device powered on and connected, the design is intended to deliver regardless of whether the app was opened 5 hours, 12 hours, 24 hours, or longer.
