# RKMS Button + Gallery Fix — 2026-09-25

Applied to `app.js`:

1. Captured `e.currentTarget` before async `await` for the audited async button handlers.
2. Replaced post-await `unlockButton(e.currentTarget)` with `unlockButton(button)`.
3. Captured Member Update action before the async call.
4. Changed Gallery `media_type` from unsupported `IMAGE` to database-supported `PHOTO` for photos; videos remain `VIDEO`.
5. Verified with `node --check app.js`.

Database verification:
- `rkms_gallery_media_type_check` currently allows `PHOTO` and `VIDEO`.

The source ZIP is intended for the existing GitHub release workflow. It is not a newly signed APK; rebuilding with the project's release keystore is required for an installable release APK.
