from pathlib import Path
import re, sys

errors=[]
css=Path("styles.css").read_text()
setup=Path("scripts/setup-android-native.sh").read_text()
configure=Path("scripts/configure-android-16.sh").read_text()
vars_path=Path("android/variables.gradle")

# This verifier runs before the CI workflow creates the Android project.
# Therefore android/ and .github/workflows/ may legitimately not exist yet.
# Validate the checked-in Android 16 configuration script instead of trying
# to open a literal wildcard workflow path.
if not vars_path.exists():
    if "compileSdkVersion" not in configure or "targetSdkVersion" not in configure:
        errors.append("Android 16 configuration script does not set compile/target SDK")
    if "36" not in configure:
        errors.append("Android 16 configuration script does not target API 36")
    if "8.9.1" not in configure:
        errors.append("Android 16 configuration script does not configure AGP 8.9.1")
    if "gradle-8.11.1-bin.zip" not in configure:
        errors.append("Android 16 configuration script does not configure Gradle 8.11.1")
else:
    vars=vars_path.read_text()
    root=Path("android/build.gradle").read_text()
    wrap=Path("android/gradle/wrapper/gradle-wrapper.properties").read_text()
    if not re.search(r"compileSdkVersion\s*=\s*36", vars): errors.append("compileSdkVersion is not 36")
    if not re.search(r"targetSdkVersion\s*=\s*36", vars): errors.append("targetSdkVersion is not 36")
    if "com.android.tools.build:gradle:8.9.1" not in root: errors.append("AGP 8.9.1 not configured")
    if "gradle-8.11.1-bin.zip" not in wrap: errors.append("Gradle 8.11.1 not configured")

if "safe-area-inset-top" not in css or "safe-area-inset-bottom" not in css:
    errors.append("edge-to-edge safe-area insets are not present in web UI")
if "windowOptOutEdgeToEdgeEnforcement" in setup:
    errors.append("Android 16 edge-to-edge opt-out must not be used")
if 'enableOnBackInvokedCallback="true"' not in setup:
    errors.append("predictive back is not explicitly enabled in generated manifest patch")

if errors:
    print("ANDROID 16 API 36 VERIFY: FAIL")
    for e in errors: print(" -", e)
    sys.exit(1)

print("ANDROID 16 API 36 VERIFY: PASS")
if vars_path.exists():
    print(" - generated Android project already present and validated")
else:
    print(" - pre-generation CI check validated configure-android-16.sh")
print(" - compileSdkVersion=36")
print(" - targetSdkVersion=36")
print(" - AGP=8.9.1")
print(" - Gradle=8.11.1")
print(" - edge-to-edge safe-area handling present")
print(" - predictive back enabled")
