from pathlib import Path

app = Path("app.js").read_text(encoding="utf-8")
setup = Path("scripts/setup-android-native.sh").read_text(encoding="utf-8")
workflow = Path(".github/workflows/android-apk.yml").read_text(encoding="utf-8")

checks = [
    "function rkmsSaveLoginCredentials(identifier,password)",
    "await p.save({identifier:String(identifier).trim(),password:String(password)})",
    "const check=await p.getSavedIdentifier()",
    "function rkmsRestoreLoginCredentials(inputId,passwordId)",
    "p.authenticateAndGetCredentials()",
    "rkmsRestoreLoginCredentials(\"loginEmail\",\"loginPassword\")",
    "rkmsRestoreLoginCredentials(\"memberIdentifier\",\"memberPasswordLogin\")",
    "RKMSSecureCredentialsPlugin",
    "registerPlugin(RKMSSecureCredentialsPlugin.class);",
    "super.onCreate(savedInstanceState);",
    "AES/GCM/NoPadding",
    "AndroidKeyStore",
    "BiometricPrompt",
    "androidx.biometric:biometric:1.1.0",
]
text = app + "\n" + setup + "\n" + workflow
missing = [x for x in checks if x not in text]
if missing:
    raise SystemExit("SAVED LOGIN VERIFICATION FAILED: " + ", ".join(missing))

# The same DOM slot is intentionally reused because only one login screen is rendered at a time.
if app.count('id="rkmsSavedCredentialSlot"') < 2:
    raise SystemExit("SAVED LOGIN VERIFICATION FAILED: login credential slot missing")

print("SAVED LOGIN VERIFICATION: PASS")
print("- encrypted AndroidKeyStore credential storage")
print("- save confirmation by read-back")
print("- biometric/device-credential unlock")
print("- ID prefix suggestion and password auto-fill")
print("- member + officer login restore hooks")
print("- Android biometric dependency included")

needle = 'registerPlugin(RKMSSecureCredentialsPlugin.class);\\n        super.onCreate(savedInstanceState);'
if needle not in setup:
    raise SystemExit("SAVED LOGIN VERIFICATION FAILED: native plugin must be registered before BridgeActivity.onCreate")
print("- native Capacitor plugin registration order verified")
