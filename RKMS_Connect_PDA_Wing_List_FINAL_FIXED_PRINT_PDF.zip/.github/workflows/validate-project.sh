#!/usr/bin/env bash
set -euo pipefail

fail(){ echo "VALIDATION ERROR: $*" >&2; exit 1; }

[[ -f settings.gradle || -f settings.gradle.kts ]] || fail "settings.gradle missing"
[[ -f build.gradle || -f build.gradle.kts ]] || fail "root build.gradle missing"
[[ -f gradle.properties ]] || fail "gradle.properties missing"
[[ -d app ]] || fail "app module missing"
[[ -f app/build.gradle || -f app/build.gradle.kts ]] || fail "app build file missing"
[[ -f app/src/main/AndroidManifest.xml ]] || fail "AndroidManifest.xml missing"
[[ -f app/src/main/assets/www/index.html ]] || fail "web index missing"
[[ -f app/src/main/assets/www/app.js ]] || fail "web app.js missing"
[[ -f app/src/main/assets/www/config.js ]] || fail "web config missing"

BOOK_DIR="app/src/main/assets/www/assets/book"
[[ -f "$BOOK_DIR/cover.jpg" ]] || fail "book cover missing"
count=$(find "$BOOK_DIR" -maxdepth 1 -type f -name 'page-[0-9][0-9].jpg' | wc -l | tr -d ' ')
[[ "$count" == "60" ]] || fail "expected 60 numbered book pages, found $count"

if command -v node >/dev/null 2>&1; then
  node --check app/src/main/assets/www/app.js
fi

if grep -RInE 'SUPABASE_SERVICE_ROLE_KEY|service_role|BEGIN (RSA|OPENSSH|EC|DSA) PRIVATE KEY' app/src/main/assets app/src/main/java app/src/main/res 2>/dev/null; then
  fail "possible server credential/private key found in client sources"
fi

echo "RKMS source validation: PASS"
