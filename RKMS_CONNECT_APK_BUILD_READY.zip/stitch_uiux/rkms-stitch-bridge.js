/* RKMS CONNECT — Stitch runtime bridge
 * Uses the same existing Supabase project/config as the host app.
 * No OTP. No service/secret key. No duplicate data store.
 */
(function(w){'use strict';
  w.RKMS_STITCH_BRIDGE = {
    SUPABASE_URL: 'https://kzczivaydandiqgnzfeg.supabase.co',
    SUPABASE_ANON_KEY: 'sb_publishable_zPG4bJ8bpE8mokGVgEmNxg_eCDlju_9'
  };
  w.RKMS_ENV = Object.assign({}, w.RKMS_ENV||{}, w.RKMS_STITCH_BRIDGE);
  w.RKMS_CONFIG = Object.assign({}, w.RKMS_CONFIG||{}, w.RKMS_STITCH_BRIDGE);
  w.RKMS_PARENT_APP = window.parent !== window ? window.parent : null;
})(window);
