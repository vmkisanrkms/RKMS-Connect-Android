---
name: Sovereign Civic
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#44474f'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#747780'
  outline-variant: '#c4c6d0'
  surface-tint: '#465e8e'
  primary: '#00173b'
  on-primary: '#ffffff'
  primary-container: '#0f2c59'
  on-primary-container: '#7c94c8'
  inverse-primary: '#aec7fd'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#0d182a'
  on-tertiary: '#ffffff'
  tertiary-container: '#222d3f'
  on-tertiary-container: '#8994ab'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#aec7fd'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#2d4674'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#d8e3fb'
  tertiary-fixed-dim: '#bcc7de'
  on-tertiary-fixed: '#111c2d'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Noto Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Noto Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Noto Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-lg:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  title-md:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Noto Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Noto Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Noto Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  spacing-xxs: 0.125rem
  spacing-xs: 0.25rem
  spacing-sm: 0.5rem
  spacing-md: 0.75rem
  spacing-base: 1rem
  spacing-lg: 1.25rem
  spacing-xl: 1.5rem
  spacing-2xl: 2rem
  spacing-3xl: 2.5rem
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 2rem
---

## Brand & Style

This design system establishes a high-trust, authoritative, and dignified digital identity for a national union and grassroots organizational management application. The brand persona is disciplined, institutional, protective, and empowering—bridging the dignity of formal administrative governance with ground-level accessibility for agricultural and labor leaders across India.

The aesthetic philosophy draws from **Modern Corporate / Institutional Precision** filtered through an Indian sovereign civic lens:
- **Visual Weight & Groundedness:** Heavy structural anchors, refined deep navy framing, and purposeful architectural division replace frivolous decoration.
- **Auspicious Authority:** Saffron-marigold and aged brass accents evoke collective resilience, heritage, and administrative merit without lapsing into festival kitsch or decorative excess.
- **Bilingual Equivalence:** Absolute parity in readability between Devanagari and Latin scripts, maintaining vertical optical balance across varying glyph heights and complex conjuncts.
- **Dignified Restraint:** Restrained micro-interactions and crisp 1px hairpins communicate military-grade record-keeping, verified identity, and official accountability.

## Colors

The palette establishes an immediate standard of constitutional trust, legibility under direct sunlight, and distinct departmental visual hierarchy.

### Palette Architecture
- **Primary (`#0F2C59` - Deep Imperial Navy):** The structural core. Represents institutional permanence, constitutional order, and sovereign clarity. Applied to primary app bars, high-emphasis action triggers, authoritative badges, and active navigation items.
- **Secondary (`#D97706` - Auspicious Saffron/Amber):** The energetic civic catalyst. Represents agricultural vitality, resolve, and urgent official attention. Applied strictly to key confirmation points, active indicators, verified ribbons, and high-priority action alerts.
- **Tertiary (`#1E293B` - Deep Slate Charcoal):** High-contrast contrast anchor. Utilized for deep structural borders, dense data tables, typography, and inactive dark states.
- **Neutral (`#F8FAFC` - Off-White Slate Base):** Reduces optical glare in high-luminosity outdoor conditions compared to pure `#FFFFFF`.
- **Surface Elevation Containers:**
  - `surface-canvas`: `#F8FAFC`
  - `surface-card`: `#FFFFFF`
  - `surface-tinted`: `#F1F5F9`
  - `surface-accent-muted`: `#FEF3C7` (Saffron Subdued Container)
- **Status & Administrative Badging:**
  - `status-verified`: `#047857` (Emerald Reserve)
  - `status-pending`: `#B45309` (Burnished Ochre)
  - `status-critical`: `#B91C1C` (Crimson Alert)
  - `status-official-gold`: `#92400E` over `#FEF3C7` (Seal of Authority)

## Typography

Typography in this design system must support complete linguistic equity between Hindi (Devanagari) and English (Latin). **Noto Sans** (with full Noto Sans Devanagari weight pairing) serves as the unified typographical system.

### Principles
- **Matra Headroom & Vertical Alignment:** Hindi matras (upper diacritics like *ekara* and lower conjuncts like *ukaar*) require a minimum of 1.35x to 1.45x line-height multiplier compared to pure Latin text to avoid optical truncation.
- **Weight Calibration:** Light weights (<400) are forbidden in all body text and UI controls to prevent stroke disappearance on low-density IPS displays under bright field environments.
- **Uppercase Discipline:** All-caps styling is restricted strictly to micro-labels, member ID prefixes, and official clearance codes in Latin script. Hindi text must never receive synthetic letter spacing alterations that break the *Shirorekha* (top continuous line).

## Layout & Spacing

The layout is engineered around an 8-point spatial cadence tailored for handheld, one-handed field operation on Android devices.

### Mobile Grid (Handheld Primary: 360dp - 440dp)
- **Columns:** 4-column fluid layout.
- **Side Margins:** 16dp (`margin-mobile`).
- **Gutter:** 16dp (`gutter-mobile`).
- **Touch Target Floor:** All active tap zones strictly measure $\ge 48\text{dp} \times 48\text{dp}$.
- **Thumb Zone Compliance:** Primary interactive modules, critical submission floating triggers, and verification actions reside in the bottom 60% of viewport elevation.

### Tablet Grid (Field Administrative Terminals: 600dp - 840dp)
- **Columns:** 8-column layout.
- **Side Margins:** 32dp (`margin-tablet`).
- **Gutter:** 24dp (`gutter-tablet`).
- **Panel Reflow:** Master-detail split screens: Navigation/Record lists consume 3 columns, detailed profile/action sheets consume 5 columns.

## Elevation & Depth

This design system rejects theatrical, diffuse "floating" UI physics in favor of **Tonal Architectonic Layering** paired with calibrated, directional administrative shadows. The visual perception of depth directly corresponds to data permanence and authority level.

### Layer Hierarchy
1. **Base Slate (0dp - Canvas):** `#F8FAFC`. Background bedrock.
2. **Sheet / Card Tier (1dp - 2dp):** `#FFFFFF` surfaces structured with a crisp, low-contrast bounding perimeter (`1px solid #E2E8F0`).
   - *Shadow:* `0px 1px 3px 0px rgba(15, 44, 89, 0.06), 0px 1px 2px -1px rgba(15, 44, 89, 0.04)`.
3. **Elevated Functional Panels (3dp - 4dp):** Interactive lists, active dropdown trays, filter chips.
   - *Shadow:* `0px 4px 6px -1px rgba(15, 44, 89, 0.08), 0px 2px 4px -2px rgba(15, 44, 89, 0.04)`.
   - *Border:* `1px solid #CBD5E1`.
4. **Authoritative Overlays & Drawers (8dp - 16dp):** Action sheets, member identification cards, bottom verification modals.
   - *Shadow:* `0px 12px 24px -4px rgba(15, 44, 89, 0.14), 0px 4px 8px -2px rgba(15, 44, 89, 0.06)`.
   - *Border Top:* `1px solid #E2E8F0`.
5. **Tinted Navy Accents:** Deep navy surfaces utilize an interior inset rim highlight (`inset 0 1px 0 0 rgba(255, 255, 255, 0.12)`) to give buttons and headers a sculpted, high-security passport-like feel.

## Shapes

The shape geometry utilizes a **Soft Structural (0.25rem - 0.5rem base)** design standard. High-radii "bubble" curves are eliminated to preserve the look and feel of an official ledger, organizational charter, and government-grade identification tool.

### Geometry Specifications
- **Micro Tokens (Chips, Badges, Checkboxes):** `4px` (`rounded-xs` / `rounded-sm`).
- **Standard Controls (Inputs, Primary Buttons, Alerts):** `8px` (`rounded-md` / `rounded-lg`).
- **Card Containers & Modules:** `8px` to `12px` maximum.
- **Top Sheets & Modals:** `16px` on top-left and top-right radii only; bottom corners square (`0px`).
- **Strict Prohibition:** Full-pill (`9999px`) styling is prohibited on critical action buttons; pills are reserved only for dynamic numeric status counters and live connection badges.

## Components

### Buttons
- **Primary Institutional Button:** Filled in `#0F2C59`, text in `#FFFFFF` (Noto Sans Medium/SemiBold), `8px` corner radius, `48px` minimum height. Surface includes a subtle top inset border (`inset 0 1px 0 rgba(255,255,255,0.15)`). Focused state introduces a `2px` offset ring in `#D97706`.
- **Secondary Action Button (Civic Alert):** Filled in `#D97706`, text in `#FFFFFF`. Applied for immediate field broadcasts, urgent registry updates, or formal authorization tasks.
- **Outlined / Administrative Button:** Pure `#FFFFFF` surface with `1.5px solid #0F2C59`, text in `#0F2C59`.
- **Disabled State:** Surface `#E2E8F0`, text `#94A3B8`, `0px` shadow elevation.

### Badges & Official Seals
- **Verified Leader Badge:** Gold/Bronze-washed background (`#FEF3C7`), `1px solid #F59E0B`, text `#92400E`, leading checkmark/emblem icon scaled to 14dp.
- **Unit / Cadre Designation Chip:** Deep navy tone (`#0F2C59`), text `#FFFFFF`, corner radius `4px`, padding `2px 8px`, typography `label-sm`.

### Input Fields
- **Container Architecture:** Boxed field, `52px` height, background `#FFFFFF`, boundary `1px solid #CBD5E1`, corner radius `6px`.
- **Labeling Paradigm:** Floating bilingual label in `#475569`. Active focus transitions boundary to `2px solid #0F2C59` and shifts label to `#0F2C59`.
- **Error State:** Border shifts to `1.5px solid #B91C1C` with trailing warning indicator; assistive feedback rendered below in `#B91C1C` (12px).

### Lists & Record Rows
- **Official Ledger Item:** Background `#FFFFFF`, padding `16px`, separated by hairline divider (`1px solid #F1F5F9`).
- **Visual Structure:** Left-anchored circular or squared-soft official avatar/index mark (40dp); center dual-line content (Title: `title-md` in `#1E293B`, Subtitle: `body-sm` in `#64748B`); right-anchored timestamp, role badge, and chevron arrow.

### Checkboxes & Radio Controls
- **Checkboxes:** `20dp x 20dp`, corner radius `3px`. Unselected: `1.5px solid #64748B` border with `#FFFFFF` fill. Selected: `#0F2C59` fill with crisp white check glyph.
- **Radio Buttons:** `20dp x 20dp` concentric double-ring. Outer rim `#0F2C59` with centered 8dp solid navy dot when active.

### Cards & Official Registers
- **Dossier / ID Card Format:** Background `#FFFFFF`, radius `8px`, border `1px solid #E2E8F0`, elevation tier 1. Top edge accentuated with an official 3px continuous brand line (`#0F2C59` with `#D97706` quadrant split). Interior includes watermark organizational seal rendered at 4% opacity behind key details.

### Additional Specialized Components
- **Bilingual Language Toggle:** Fixed top-right utility element. Segmented capsule (`#F1F5F9`), selected segment filled with `#0F2C59` and text `#FFFFFF` (`अ / A`), unselected `#475569`.
- **Network / Offline Continuity Bar:** Fixed sub-header status strip. Background `#FEF3C7`, border bottom `1px solid #FDE68A`, text `#92400E` ("Offline Mode: Data will sync to Central Registry when network restores").