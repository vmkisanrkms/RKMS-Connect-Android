-- RKMS CONNECT: atomic appointment order-number generation
-- Safe/idempotent: no DROP/TRUNCATE/reset and preserves existing records.
CREATE OR REPLACE FUNCTION public.rkms_generate_appointment_order_no()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public, pg_catalog
AS $$
BEGIN
  IF NEW.order_no IS NULL OR btrim(NEW.order_no) = '' THEN
    NEW.order_no := 'RKMS/ORD/' || to_char(CURRENT_DATE, 'YYYY') || '/' || replace(substr(gen_random_uuid()::text, 1, 8), '-', '');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rkms_appointments_order_no ON public.rkms_appointments;
CREATE TRIGGER trg_rkms_appointments_order_no
BEFORE INSERT ON public.rkms_appointments
FOR EACH ROW EXECUTE FUNCTION public.rkms_generate_appointment_order_no();

COMMENT ON FUNCTION public.rkms_generate_appointment_order_no() IS
'Generates a database-side collision-resistant appointment order number when the client does not supply one.';
