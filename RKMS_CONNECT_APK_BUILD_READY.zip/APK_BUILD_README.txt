RKMS CONNECT — APK BUILD ZIP

1. Upload the contents of this ZIP to a GitHub repository.
2. Open GitHub Actions.
3. Select "RKMS CONNECT Android APK".
4. Click "Run workflow".
5. When the build completes, download the artifact:
   RKMS-CONNECT-debug-apk

The workflow creates the Capacitor Android project in GitHub Actions,
builds the debug APK with Gradle, and uploads the APK as an artifact.
