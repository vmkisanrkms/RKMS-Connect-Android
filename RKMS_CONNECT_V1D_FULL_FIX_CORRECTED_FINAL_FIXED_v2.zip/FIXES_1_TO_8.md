# RKMS CONNECT — Issues 1 to 8 Final Repair

1. **Digital ID क्षेत्र** — normal members now show their member location in `क्षेत्र` instead of `—`.
2. **Digital ID PDF** — missing `downloadPdf()` repaired; Android generates the PDF and saves it directly to Downloads/RKMS CONNECT; web downloads the PDF normally.
3. **Digital ID Print** — Android native `PrintManager` bridge added as `RKMSNative.printPage()`.
4. **Member Profile** — bottom Profile button now opens a real `मेरी प्रोफ़ाइल` screen instead of reopening Member Dashboard.
5. **Membership Certificate authority** — National President name/post/signature block is now included, with the membership approval officer block retained when available.
6. **Membership Certificate PDF** — dedicated PDF button added and routed through the direct PDF generation/save bridge; Print remains a separate native print action.
7. **Android launcher logo** — launcher logo safe-area scale reduced further so the circular Android mask does not cut the RKMS emblem.
8. **Saved Login** — secure saved credentials remain after Logout; the saved-login option is now visible immediately on the login screen, and credentials are stored in Android Keystore-backed encrypted storage.

### Additional repair included
- PDA appointment State dropdown filtering now normalizes Hindi/English state names, so `पंजाब` and `Punjab` are treated as the same state.

### Deep-audit verification status

| Issue | Source verification | Release status |
|---|---|---|
| 1. Digital ID क्षेत्र | `officerAreaLabel()` / `memberAreaLabel()` present | 🟡 Device verification required |
| 2. Digital ID PDF | `downloadPdf()` defined and bound to PDF buttons | 🟡 Device verification required |
| 3. Digital ID Print | Native `PrintManager` bridge uses injected Activity/WebView; compile-risk fixed | 🟡 Device verification required |
| 4. Member Profile | `member-profile` route and `renderMemberProfile()` wired | 🟢 Source fixed |
| 5. Membership Certificate authority | National President block rendered in certificate | 🟢 Source fixed |
| 6. Membership Certificate PDF | PDF button wired to common PDF/print bridge | 🟡 Device verification required |
| 7. Android launcher logo | Workflow applies reduced safe-area logo after Capacitor sync | 🟡 Device verification required |
| 8. Saved Login | Android Keystore credential plugin registered; logout clears session only, not saved credentials | 🟡 Device verification required |

### Native bridge repair
The previous native bridge incorrectly called `getActivity()` and `getBridge()` from a plain Java bridge class. The bridge now receives the Activity and WebView from `MainActivity` and uses those stored references for Android printing.


- `node --check app.js` — PASS
- Native bridge source checked: no invalid `getActivity()` / `getBridge()` calls remain inside `RKMSNativeBridge`; Activity/WebView are injected from `MainActivity`.
- `तहसील कोषाध्यक्ष` is an intended live database post and must NOT be removed.
- Android APK must be rebuilt and installed for real-device verification of #2, #3, #7 and #8.
