package org.rkms.connect;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.content.ContentValues;
import android.provider.MediaStore;
import java.io.InputStream;
import java.io.OutputStream;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION = 1001;
    private static final int FILE_CHOOSER = 1002;
    private static final int MICROPHONE_PERMISSION = 1003;
    private static final String ASSET_HOME = "file:///android_asset/www/index.html";
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPermissionRequest;
    private String pendingNotificationRoute = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.addJavascriptInterface(new RKMSBridge(this), "RKMSNative");
        createNotificationChannel();
        requestNotificationPermission();
        Intent launchIntent = getIntent();
        loadInitialRoute(launchIntent);
        // Consume notification extras so an Activity recreation/relaunch cannot
        // replay the same Chat route unexpectedly.
        if (routeFromIntent(launchIntent) != null && !routeFromIntent(launchIntent).isEmpty()) {
            setIntent(new Intent(this, MainActivity.class));
        }
    }

    private void loadInitialRoute(Intent intent) {
        // Always establish Home as the first WebView entry. A notification route
        // is then pushed into the same single-page history after the website boots.
        // This guarantees Android Back from Chat returns to Home instead of exiting.
        pendingNotificationRoute = routeFromIntent(intent);
        webView.loadUrl(ASSET_HOME);
    }

    private void openPendingNotificationRoute() {
        if (pendingNotificationRoute == null || pendingNotificationRoute.isEmpty() || webView == null) return;
        final String route = pendingNotificationRoute;
        pendingNotificationRoute = "";
        String js = "(function(r){try{" +
                "window.__RKMS_PENDING_NOTIFICATION_ROUTE=r;" +
                "if(window.rkmsOpenNotificationRoute)window.rkmsOpenNotificationRoute(r);" +
                "}catch(e){console.warn('RKMS notification route failed',e)}})(" +
                org.json.JSONObject.quote(route) + ");";
        webView.evaluateJavascript(js, null);
    }

    private String routeFromIntent(Intent intent) {
        if (intent == null) return "";

        String route = intent.getStringExtra("rkms_route");
        if (route == null || route.trim().isEmpty()) {
            route = intent.getStringExtra("route");
        }

        if (route == null || route.trim().isEmpty()) {
            String conversationId = intent.getStringExtra("conversation_id");
            if (conversationId != null && !conversationId.trim().isEmpty()) {
                route = "chat/" + conversationId.trim();
            }
        }

        return sanitizeRoute(route);
    }

    private String sanitizeRoute(String route) {
        if (route == null || route.trim().isEmpty()) return "";
        String r = route.trim();
        while (r.startsWith("#")) r = r.substring(1);
        r = r.replace('\\', '/');
        if (r.contains("..") || r.startsWith("http:") || r.startsWith("https:") || r.startsWith("file:")) return "home";
        String base = r.contains("/") ? r.substring(0, r.indexOf('/')) : r;
        if (!NotificationRoutePolicy.isAllowedBase(base)) return "home";
        if (r.matches("chat/[A-Za-z0-9_-]+") || r.matches("district/[A-Za-z0-9_.:-]+") ||
                r.matches("officer/[A-Za-z0-9_.:-]+") || r.matches("my-complaint/[A-Za-z0-9_.:-]+") ||
                r.matches("complaint-detail/[A-Za-z0-9_.:-]+") || r.equals(base)) return r;
        return "home";
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true);

        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return handleExternalUrl(request == null ? null : request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleExternalUrl(url == null ? null : Uri.parse(url));
            }

            private boolean handleExternalUrl(Uri uri) {
                if (uri == null) return true;
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("file".equals(scheme)) return false;
                if ("http".equals(scheme) || "https".equals(scheme) || "tel".equals(scheme) || "mailto".equals(scheme) || "geo".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                String nativeAccess = SessionStore.access(getApplicationContext());
                String nativeRefresh = SessionStore.refresh(getApplicationContext());
                if (nativeAccess != null && !nativeAccess.isEmpty()) {
                    String jsAccess = org.json.JSONObject.quote(nativeAccess);
                    String jsRefresh = org.json.JSONObject.quote(nativeRefresh == null ? "" : nativeRefresh);
                    v.evaluateJavascript(
                        "(function(a,r){try{" +
                        "var oldA=localStorage.getItem('rkms_access_token')||'';" +
                        "var oldR=localStorage.getItem('rkms_refresh_token')||'';" +
                        "localStorage.setItem('rkms_access_token',a);" +
                        "if(r)localStorage.setItem('rkms_refresh_token',r);" +
                        "try{var p=JSON.parse(atob(a.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));if(p.exp)localStorage.setItem('rkms_access_expires_at',String(Number(p.exp)*1000));}catch(e){}" +
                        "if(window.RKMSNative)window.RKMSNative.saveSession(a,r,'');" +
                        "if(oldA!==a||oldR!==r){try{window.dispatchEvent(new CustomEvent('rkms:native-session-restored'));}catch(e){}}" +
                        "}catch(e){console.warn('RKMS session restore failed',e)}})(" +
                        jsAccess + "," + jsRefresh + ");", null);
                } else {
                    v.evaluateJavascript(
                        "(function(){try{var a=localStorage.getItem('rkms_access_token')||'';var r=localStorage.getItem('rkms_refresh_token')||'';" +
                        "if(a&&window.RKMSNative)window.RKMSNative.saveSession(a,r,'');}catch(e){}})();", null);
                }
                if (pendingNotificationRoute != null && !pendingNotificationRoute.isEmpty()) {
                    v.postDelayed(() -> openPendingNotificationRoute(), 700);
                }
            }
        });

        view.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || url.trim().isEmpty()) return;
            try {
                Intent downloadIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(downloadIntent);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "इस फ़ाइल को खोलने के लिए कोई app उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show();
            }
        });

        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(intent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (request == null) return;
                    boolean audioRequested = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) { audioRequested = true; break; }
                    }
                    if (!audioRequested) { request.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingPermissionRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECORD_AUDIO}, MICROPHONE_PERMISSION);
                    }
                });
            }
        });
    }

    @JavascriptInterface
    public void downloadBookPage(String page, String filename) {
        try {
            int p = Integer.parseInt(page);
            if (p < 1 || p > 60) throw new IllegalArgumentException();
            String safe = (filename == null || filename.trim().isEmpty()) ?
                    String.format("RKMS_Book_Page_%02d.jpg", p) : filename.replaceAll("[^A-Za-z0-9._-]", "_");
            String asset = p == 1 ? "www/assets/book/cover.jpg" :
                    String.format("www/assets/book/page-%02d.jpg", p);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/RKMS");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException();
                try (InputStream in = getAssets().open(asset); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException();
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                runOnUiThread(() -> Toast.makeText(this, "पृष्ठ Downloads/RKMS में save हो गया।", Toast.LENGTH_SHORT).show());
            } else {
                throw new UnsupportedOperationException();
            }
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "पृष्ठ download नहीं हो पाया।", Toast.LENGTH_SHORT).show());
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            Uri sound = android.media.RingtoneManager.getDefaultUri(
                    android.media.RingtoneManager.TYPE_NOTIFICATION
            );
            android.media.AudioAttributes audioAttributes =
                    new android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build();

            NotificationChannel channel = new NotificationChannel(
                    NotificationHelper.CHANNEL_ID,
                    "RKMS Connect Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("RKMS Connect messages and alerts");
            channel.setShowBadge(true);
            channel.setLockscreenVisibility(
                    android.app.Notification.VISIBILITY_PUBLIC
            );
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 300, 150, 300});
            channel.setSound(sound, audioAttributes);

            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Consume notification intent without retaining its route as the launcher intent.
        // Retaining it could reopen the same Chat after the Activity is recreated.
        String route = routeFromIntent(intent);
        if (route.isEmpty()) return;
        pendingNotificationRoute = route;
        if (webView != null) {
            webView.postDelayed(() -> openPendingNotificationRoute(), 150);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MICROPHONE_PERMISSION && pendingPermissionRequest != null) {
            PermissionRequest request = pendingPermissionRequest;
            pendingPermissionRequest = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                request.deny();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                android.content.ClipData clipData = data.getClipData();
                if (clipData != null && clipData.getItemCount() > 0) {
                    results = new Uri[clipData.getItemCount()];
                    for (int i = 0; i < clipData.getItemCount(); i++) {
                        results[i] = clipData.getItemAt(i).getUri();
                    }
                } else {
                    Uri uri = data.getData();
                    if (uri != null) results = new Uri[]{uri};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{" +
                "if(window.rkmsAndroidBack)return window.rkmsAndroidBack();" +
                "var r=(location.hash||'#home').replace(/^#/, '');" +
                "if(r!=='home'){location.hash='#home';return 'handled';}" +
                "return 'exit';" +
                "}catch(e){console.error('RKMS Android Back',e);return 'exit';}})();",
                value -> {
                    if (value != null && value.contains("exit")) {
                        runOnUiThread(this::finish);
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            String access = SessionStore.access(getApplicationContext());
            if (access != null && !access.isEmpty()) FCMTokenRegistrar.register(getApplicationContext(), access);
        } catch (Throwable e) {
            android.util.Log.w("RKMS_FCM", "onResume registration failed", e);
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingPermissionRequest != null) { try { pendingPermissionRequest.deny(); } catch (Throwable ignored) {} pendingPermissionRequest = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    static final class NotificationRoutePolicy {
        private static final java.util.Set<String> ALLOWED = new java.util.HashSet<>(java.util.Arrays.asList(
                "home", "member-list", "active-officers", "organization", "leadership", "vmsingh",
                "directory", "district", "officer", "membership", "login", "login-slogans",
                "content-management", "officer-login", "chat", "password-reset-requests",
                "member-dashboard", "member-update", "digital-id", "appointment-letter",
                "membership-certificate", "complaint", "my-complaints", "my-complaint", "book",
                "news", "events", "gallery", "documents", "reports", "campaigns",
                "notifications", "admin", "content", "security-audit", "officer-dashboard",
                "officer-complaints", "complaint-detail", "pending", "appointment"
        ));
        static boolean isAllowedBase(String route) { return ALLOWED.contains(route); }
    }

    public static class RKMSBridge {
        private final Context context;
        RKMSBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void saveSession(String accessToken, String refreshToken, String role) {
            // Never erase a previously stored role just because the WebView
            // is restoring tokens and does not know the role yet.
            String keepRole = (role == null || role.trim().isEmpty()) ? SessionStore.role(context) : role;
            SessionStore.save(context, accessToken, refreshToken, keepRole);
            try { if (accessToken != null && !accessToken.isEmpty()) FCMTokenRegistrar.register(context, accessToken); } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void saveSessionNoPush(String accessToken, String refreshToken, String role) {
            String keepRole = (role == null || role.trim().isEmpty()) ? SessionStore.role(context) : role;
            SessionStore.save(context, accessToken, refreshToken, keepRole);
        }

        @JavascriptInterface
        public String getAccessToken() {
            return SessionStore.access(context);
        }

        @JavascriptInterface
        public String getRefreshToken() {
            return SessionStore.refresh(context);
        }

        @JavascriptInterface
        public String getRole() {
            return SessionStore.role(context);
        }

        @JavascriptInterface
        public void clearSession() {
            String access = SessionStore.access(context);
            try { FCMTokenRegistrar.unregister(context, access); } catch (Throwable ignored) {}
            SessionStore.clear(context);
        }

        @JavascriptInterface
        public void showNotification(String title, String body) { NotificationHelper.show(context, title, body, "home", null); }

        @JavascriptInterface
        public void toast(String message) { Toast.makeText(context, message, Toast.LENGTH_SHORT).show(); }
    }
}
