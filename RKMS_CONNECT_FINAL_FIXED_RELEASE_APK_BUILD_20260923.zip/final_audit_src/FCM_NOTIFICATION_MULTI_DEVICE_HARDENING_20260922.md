# RKMS Connect — Multi-Device FCM Notification Hardening — 2026-09-22

## Changes
- Explicit Android 13+ POST_NOTIFICATIONS permission declaration.
- Stable default FCM notification channel and high importance native channel.
- Stable white notification icon for Android system-rendered background notifications.
- FCM token registration now retries up to three times immediately and schedules exponential retry on failure.
- Latest FCM token is persisted locally and re-registered after resume/network recovery.
- Token registration is tied to a stable per-installation device ID.
- Existing foreground/tap notification listeners and server endpoint are retained.

## Runtime limitation
Android OEM battery/background restrictions can still delay push delivery. The app cannot guarantee delivery when the device has no network, is powered off, or the OS has restricted background activity.
