# RKMS Chat Composer Position Fix — 2026-09-20

## Required order
Messages → Chat Composer → RKMS App Bottom Navigation → Android System Navigation Area

## Fix
- Chat composer is fixed to the top edge of the RKMS app bottom navigation.
- App bottom navigation remains above the Android system navigation/safe-area.
- When keyboard opens, RKMS bottom navigation hides and composer moves to the visual viewport bottom.
- Removed the runtime `padding-bottom` that was incorrectly adding the footer height inside the conversation screen.
- Message list reserves the actual composer height so messages are not hidden behind the composer.

## Static verification
- `node --check app.js`: PASS
- Composer CSS final override present: PASS
- Keyboard-open composer override present: PASS
- Bottom navigation safe-area rule preserved: PASS
