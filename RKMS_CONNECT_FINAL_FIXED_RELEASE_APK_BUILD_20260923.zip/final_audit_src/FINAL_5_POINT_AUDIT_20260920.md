# RKMS CONNECT — Corrected Final Group/5-Point Source Audit — 20 Sep 2026

## Scope

This is the corrected audit after device screenshots showed that the earlier Point 5 audit was incomplete. Point 5 is now treated as a WhatsApp-style Group Management requirement: Group photo + name + description + members/admin management.

## Requested fixes

1. Android system navigation and RKMS app footer must occupy separate areas; chat composer must sit directly above the RKMS footer without an unnecessary gap.
2. Digital ID must show appointing-authority name/post/signature, including National President appointments.
3. Digital ID / appointment letter PDF must use the live WebView-rendered document so the phone view and PDF layout match.
4. Android voice recording must start reliably with microphone/WebView permission handling and clean recorder lifecycle.
5. Group management must be professional/WhatsApp-style: Group photo change, Group name change, Group description, Add Member, Admin management, Group Info/Settings, and Leave Group.

## Implemented

### 1. Footer / Android navigation
- Footer height now includes `env(safe-area-inset-bottom)`.
- The RKMS footer content remains above the Android system navigation/gesture area.
- Runtime footer height is measured by ResizeObserver/MutationObserver and exposed through `--rkms-bottom-nav-h`.
- Conversation height subtracts the measured full footer height.
- Composer remains in the conversation flow immediately above the RKMS footer.
- The previous duplicate/incorrect safe-area padding approach was replaced by a single system-navigation reservation.

### 2. Digital ID
- `rkms_get_digital_id_meta` returns appointing officer name/post/signature for National President appointments as well as officer-appointed cases.
- Existing signer-resolution UI remains intact.

### 3. Exact-render PDF
- Android uses the native `captureCurrentDocumentAsPdf()` path for the live WebView document.
- Web fallback rendering remains available.

### 4. Voice recording
- `getUserMedia`/MediaRecorder flow is present with Android microphone permission request, WebView audio permission, safe fallback constraints, and track cleanup.

### 5. Professional Group Management
- Group header shows the real Group photo when `rkms_chat_groups.photo_url` is present.
- Group Info is opened by tapping the Group header.
- Authorized Admin/Super Admin can:
  - change Group photo (JPG/PNG, max 5 MB)
  - change Group name (1–80 characters)
  - edit Group description (max 500 characters)
  - add members through search/select flow
  - make/remove Admin
  - remove members
  - leave the Group
- New Group creation now also supports optional photo and description.
- Group list/header refreshes from `rkms_chat_threads` after Group updates.
- Backend `rkms_chat_group_manage` has server-side authorization for `RENAME`, `UPDATE_PHOTO`, and `UPDATE_DESCRIPTION`.
- Backend `rkms_chat_group_info` returns Group name, photo URL, description, member list, and `can_manage`.

## Verification

All repository `scripts/verify-*.py` checks pass after the changes.

Additional checks passed:
- `node --check app.js`
- all `scripts/*.sh` pass `bash -n`
- Chat + microphone + Group + Digital ID + PDF source verification
- Android safe-area footer separation
- Group photo UI
- Group rename UI
- Professional Add Member flow
- Group description flow

## Supabase

The production Supabase project has the updated Group Management RPC with `RENAME`, `UPDATE_PHOTO`, and `UPDATE_DESCRIPTION`, plus the updated Group Info RPC returning photo/name/description. The database table already contains `rkms_chat_groups.photo_url`.

## Runtime limitation

Static/source audit is PASS. A Release APK installed on the Motorola Edge 50 Pro is still required for final device-runtime confirmation of the exact footer/system-navigation pixels, microphone hardware capture, PDF visual equality, and the Group Photo picker/upload on that device.
