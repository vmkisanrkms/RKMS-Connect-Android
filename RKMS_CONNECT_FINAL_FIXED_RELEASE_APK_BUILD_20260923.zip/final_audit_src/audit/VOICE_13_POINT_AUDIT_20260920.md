# RKMS Voice Recording — 13 Point Source Audit

Source audited: RKMS Connect final group-management source ZIP, 20 Sep 2026.

1. Mic button starts recording: PASS — `getUserMedia()` + `MediaRecorder`.
2. Android microphone permission: PASS — `RECORD_AUDIO` + WebView `RESOURCE_AUDIO_CAPTURE` bridge.
3. First-tap permission flow: FIXED — JS no longer blocks after triggering a native permission request; WebView permission flow handles the runtime request.
4. Recording indicator/timer: PASS — recording timer and stop state are shown on the mic button.
5. Stop recording: PASS — `MediaRecorder.stop()` finalizes the stream and stops tracks.
6. Audio data/File: PASS — `Blob` is converted to a `File` with an audio MIME type.
7. Upload: PASS — voice file is routed through `uploadChatFile()` and the existing `rkms-media` storage path.
8. Send: PASS — `sendChatMessage()` now explicitly uses the pending voice file, so it does not depend only on `input.files` assignment.
9. Playback: PASS — local preview uses `<audio controls>` and sent audio uses the existing audio renderer.
10. Cancel: PASS — remove-attachment clears the pending voice file and file input.
11. Keyboard coexistence: PASS — composer remains the existing chat composer; no voice-specific fixed-position overlay was introduced.
12. Native bridge: PASS — `RECORD_AUDIO`, `RESOURCE_AUDIO_CAPTURE`, and runtime permission callback are retained.
13. File picker regression protection: PASS — `onShowFileChooser` remains in the same WebChromeClient and voice state is isolated from normal file selection.

Additional fixes in this source package:
- Removed literal `\\n` Java source corruption from the Credential Manager callback template.
- Removed the legacy 6-argument `rkms_chat_group_manage` overload via migration; only the final 8-argument signature remains.
- Digital ID appointment signer metadata now accepts appointment authority only from a real `rkms_officers` appointment row; membership approval data cannot create an appointing-authority signature block.

Static syntax checks performed:
- `node --check app.js`: PASS
- `bash -n scripts/setup-android-native.sh`: PASS

Runtime note: the 13 source/runtime-contract checks are fixed, but final Motorola Edge 50 Pro recording success still requires installing the rebuilt APK and pressing the microphone button on-device.
