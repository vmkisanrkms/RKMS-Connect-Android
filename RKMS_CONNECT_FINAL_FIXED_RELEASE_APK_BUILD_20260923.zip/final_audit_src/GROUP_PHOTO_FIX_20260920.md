# RKMS Group Photo Fix — 20 Sep 2026

The group-photo update no longer depends on the overloaded/large `rkms_chat_group_manage` RPC.
The app uses `rkms_chat_set_group_photo(uuid,text)` after the group conversation is created and after the photo is uploaded to `chat-groups/{conversation_id}/...`.

Apply the included migration before deploying/rebuilding the app.
