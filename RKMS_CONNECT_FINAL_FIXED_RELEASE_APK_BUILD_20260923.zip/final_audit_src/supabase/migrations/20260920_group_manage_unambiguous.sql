-- RKMS Connect: remove the legacy 6-argument overload.
-- PostgREST cannot reliably choose between the old wrapper and the final
-- 8-argument function when nullable arguments are used. The app now uses
-- the final 8-argument signature for every group management action.
DROP FUNCTION IF EXISTS public.rkms_chat_group_manage(uuid,text,text,text,uuid,text);

NOTIFY pgrst, 'reload schema';
