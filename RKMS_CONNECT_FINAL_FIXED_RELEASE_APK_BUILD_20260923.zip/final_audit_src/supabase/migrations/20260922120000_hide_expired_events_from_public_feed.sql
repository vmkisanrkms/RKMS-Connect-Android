CREATE OR REPLACE FUNCTION public.rkms_get_events(p_limit integer DEFAULT 50)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_catalog'
AS $function$
    SELECT jsonb_build_object(
        'success', true,
        'data',
        COALESCE(
            (
                SELECT jsonb_agg(
                    jsonb_build_object(
                        'id', e.id,
                        'title', e.title,
                        'description', e.description,
                        'event_date', e.event_date,
                        'event_time', e.event_time,
                        'location', e.location,
                        'state', e.state,
                        'district', e.district,
                        'tehsil', e.tehsil,
                        'block', e.block,
                        'village', e.village,
                        'image_url', e.image_url,
                        'status', e.status,
                        'created_at', e.created_at
                    )
                    ORDER BY e.event_date ASC NULLS LAST, e.created_at DESC
                )
                FROM (
                    SELECT *
                    FROM public.rkms_events
                    WHERE status <> 'CANCELLED'
                      AND (
                        event_date > (now() AT TIME ZONE 'Asia/Kolkata')::date
                        OR (
                          event_date = (now() AT TIME ZONE 'Asia/Kolkata')::date
                          AND NULLIF(btrim(event_time),'') IS NOT NULL
                          AND btrim(event_time) ~ '^[0-2][0-9]:[0-5][0-9]$'
                          AND (event_date + btrim(event_time)::time) > (now() AT TIME ZONE 'Asia/Kolkata')
                        )
                      )
                    ORDER BY event_date ASC NULLS LAST, created_at DESC
                    LIMIT GREATEST(1, LEAST(COALESCE(p_limit,50),200))
                ) e
            ),
            '[]'::jsonb
        )
    );
$function$;
