-- RKMS notification hardening
-- Important ALL-organization broadcasts may only be created/updated by
-- Super Admin or the active National President.

CREATE OR REPLACE FUNCTION public.rkms_guard_priority_broadcast()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $$
DECLARE
  v_admin uuid;
  v_np boolean := false;
BEGIN
  IF coalesce(NEW.is_important,false)
     AND upper(coalesce(NEW.target_type,'ALL'))='ALL' THEN
    v_admin := public.rkms_current_super_admin_id();
    IF v_admin IS NULL THEN
      SELECT EXISTS(
        SELECT 1
        FROM public.rkms_officers o
        JOIN public.rkms_posts p ON p.id=o.post_id
        WHERE o.id=public.rkms_current_officer_id()
          AND o.status='ACTIVE'
          AND lower(trim(coalesce(p.post_name,'')))='राष्ट्रीय अध्यक्ष'
      ) INTO v_np;
      IF NOT v_np THEN
        RAISE EXCEPTION 'महत्वपूर्ण सभी-संगठन सूचना केवल राष्ट्रीय अध्यक्ष या Super Admin जारी कर सकते हैं।';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rkms_guard_priority_broadcast
  ON public.rkms_notifications;

CREATE TRIGGER trg_rkms_guard_priority_broadcast
BEFORE INSERT OR UPDATE ON public.rkms_notifications
FOR EACH ROW
EXECUTE FUNCTION public.rkms_guard_priority_broadcast();

ALTER TABLE public.rkms_push_queue
  ADD COLUMN IF NOT EXISTS notification_id uuid;

CREATE INDEX IF NOT EXISTS idx_rkms_push_queue_notification_id
  ON public.rkms_push_queue(notification_id);
