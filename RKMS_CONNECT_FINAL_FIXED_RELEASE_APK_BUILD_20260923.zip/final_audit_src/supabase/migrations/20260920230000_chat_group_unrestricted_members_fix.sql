-- RKMS Chat: Group Admin may add/remove any person visible in Chat people.
-- A chat person does not need a login account to be a group member.
-- auth_user_id remains nullable for such members; they cannot receive/login until
-- an auth account exists, but their group membership itself must not fail.

alter table public.rkms_chat_group_members
  alter column auth_user_id drop not null;

-- Return all approved members and active officers to the Chat people picker.
-- Jurisdiction is deliberately NOT used for group membership selection.
create or replace function public.rkms_chat_people(p_actor_type text, p_search text default null, p_limit integer default 100)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $function$
declare
  me_member uuid; me_officer uuid; actor text:=upper(coalesce(p_actor_type,''));
  actor_is_super_admin boolean:=false;
  q text:=nullif(trim(coalesce(p_search,'')),'');
  lim int:=greatest(1,least(coalesce(p_limit,100),100)); v jsonb;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;
  if actor='SUPER_ADMIN' then
    if not public.rkms_is_super_admin() then return jsonb_build_object('success',false,'message','Super Admin authorization required.','data','[]'::jsonb); end if;
    actor:='MEMBER';
  end if;
  me_member:=public.rkms_chat_actor_member_id();
  me_officer:=public.rkms_chat_actor_officer_id();
  actor_is_super_admin:=public.rkms_is_super_admin();

  if actor not in ('MEMBER','OFFICER') then
    return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
  end if;

  with officer_people as (
    select distinct on (o.id) o.id,o.member_id,m.name,m.member_id membership_no,m.auth_user_id,m.photo_url,
      coalesce(o.state,m.state) state,coalesce(o.mandal,m.mandal) mandal,coalesce(o.district,m.district) district,
      coalesce(o.tehsil,m.tehsil) tehsil,coalesce(o.block,m.block) block,coalesce(o.village,m.village) village,
      'OFFICER'::text chat_type,coalesce(p.post_name,'PDA अधिकारी') post_name,coalesce(p.level,o.authority_level,'') authority_level
    from public.rkms_officers o
    join public.rkms_members m on m.id=o.member_id
    left join public.rkms_posts p on p.id=o.post_id
    where upper(coalesce(o.status,''))='ACTIVE'
      and upper(coalesce(m.status,''))='APPROVED'
      and o.id<>coalesce(me_officer,'00000000-0000-0000-0000-000000000000'::uuid)
      and m.id<>coalesce(me_member,'00000000-0000-0000-0000-000000000000'::uuid)
      and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or coalesce(o.state,m.state) ilike '%'||q||'%' or coalesce(o.mandal,m.mandal) ilike '%'||q||'%' or coalesce(o.district,m.district) ilike '%'||q||'%')
    order by o.id,p.post_name nulls last
  ), ordinary_members as (
    select m.id,m.id member_id,m.name,m.member_id membership_no,m.auth_user_id,m.photo_url,m.state,m.mandal,m.district,m.tehsil,m.block,m.village,
      'MEMBER'::text chat_type,''::text post_name,''::text authority_level
    from public.rkms_members m
    where upper(coalesce(m.status,''))='APPROVED'
      and m.id<>coalesce(me_member,'00000000-0000-0000-0000-000000000000'::uuid)
      and not exists(select 1 from public.rkms_officers o where o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE')
      and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%')
  ), combined as (select * from officer_people union all select * from ordinary_members)
  select coalesce(jsonb_agg(to_jsonb(x) order by lower(coalesce(x.name,'')),x.chat_type),'[]'::jsonb)
    into v from (select * from combined limit lim) x;
  return jsonb_build_object('success',true,'data',v);
end;
$function$;

-- Group creation: no login or jurisdiction requirement for selected participants.
create or replace function public.rkms_chat_create_group(p_actor_type text,p_name text,p_description text default null,p_participants jsonb default '[]'::jsonb,p_photo_url text default null)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $function$
declare
  t text:=upper(coalesce(p_actor_type,'')); me_member uuid; me_officer uuid; gid uuid; cid uuid; x jsonb; pt text; pid uuid;
  target_member uuid; target_auth uuid;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
  if length(trim(coalesce(p_name,'')))<2 then return jsonb_build_object('success',false,'message','Group का नाम जरूरी है।'); end if;
  if jsonb_array_length(coalesce(p_participants,'[]'::jsonb))<1 then return jsonb_build_object('success',false,'message','कम से कम एक सदस्य चुनें।'); end if;

  if t='MEMBER' then
    me_member:=public.rkms_chat_actor_member_id(); if me_member is null then return jsonb_build_object('success',false,'message','Approved member login जरूरी है।'); end if;
  elsif t='OFFICER' then
    me_officer:=public.rkms_chat_actor_officer_id(); if me_officer is null then return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।'); end if;
  else return jsonb_build_object('success',false,'message','Invalid actor type.'); end if;

  insert into public.rkms_chat_groups(name,description,photo_url,created_by_auth_user_id,created_by_actor_type)
  values(trim(p_name),nullif(trim(p_description),''),nullif(trim(p_photo_url),''),auth.uid(),t) returning id into gid;

  if t='MEMBER' then
    insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'MEMBER',me_member,auth.uid(),'ADMIN');
  else
    insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'OFFICER',me_officer,auth.uid(),'ADMIN');
  end if;

  for x in select * from jsonb_array_elements(coalesce(p_participants,'[]'::jsonb)) loop
    pt:=upper(coalesce(x->>'type','')); pid:=(x->>'id')::uuid;
    if pt='MEMBER' then
      select m.id,m.auth_user_id into target_member,target_auth from public.rkms_members m where m.id=pid and upper(coalesce(m.status,''))='APPROVED';
      if target_member is null then raise exception 'चयनित Member उपलब्ध नहीं है।'; end if;
      if t='MEMBER' and pid=public.rkms_chat_actor_member_id() then continue; end if;
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      values(gid,'MEMBER',pid,target_auth,'MEMBER') on conflict(group_id,actor_type,actor_id) do nothing;
    elsif pt='OFFICER' then
      select o.member_id,m.auth_user_id into target_member,target_auth
      from public.rkms_officers o join public.rkms_members m on m.id=o.member_id
      where o.id=pid and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED';
      if target_member is null then raise exception 'चयनित PDA अधिकारी उपलब्ध नहीं है।'; end if;
      if t='OFFICER' and pid=me_officer then continue; end if;
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      values(gid,'OFFICER',pid,target_auth,'MEMBER') on conflict(group_id,actor_type,actor_id) do nothing;
    else
      raise exception 'Invalid group participant.';
    end if;
  end loop;

  if (select count(*) from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null)<2 then
    delete from public.rkms_chat_groups where id=gid;
    return jsonb_build_object('success',false,'message','Group में कम से कम 2 सदस्य होने चाहिए।');
  end if;
  insert into public.rkms_chat_conversations(group_id,member_id,member_recipient_id,officer_id,officer_recipient_id)
    values(gid,null,null,null,null) returning id into cid;
  return jsonb_build_object('success',true,'group_id',gid,'conversation_id',cid);
exception when others then
  begin delete from public.rkms_chat_groups where id=gid; exception when others then null; end;
  return jsonb_build_object('success',false,'message',sqlerrm);
end;
$function$;

-- Group Admin ADD/REMOVE: no jurisdiction or target-login restriction.
create or replace function public.rkms_chat_group_manage(
  p_conversation_id uuid,p_actor_type text,p_action text,p_target_type text default null,p_target_id uuid default null,p_group_name text default null
)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare
  action text:=upper(coalesce(p_action,'')); target_type text:=upper(coalesce(p_target_type,'')); gid uuid;
  is_admin boolean:=false; is_super boolean:=false; target_role text; target_exists boolean:=false; admin_count integer;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
  select c.group_id into gid from public.rkms_chat_conversations c where c.id=p_conversation_id and c.group_id is not null;
  if gid is null then return jsonb_build_object('success',false,'message','यह Group chat नहीं है।'); end if;
  is_super:=public.rkms_is_super_admin();
  is_admin:=is_super or exists(select 1 from public.rkms_chat_group_members gm where gm.group_id=gid and gm.auth_user_id=auth.uid() and gm.left_at is null and upper(gm.role)='ADMIN');

  if action='RENAME' then
    if not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin Group का नाम बदल सकता है।'); end if;
    if length(trim(coalesce(p_group_name,'')))<1 or length(trim(p_group_name))>80 then return jsonb_build_object('success',false,'message','Group का नाम 1 से 80 अक्षरों के बीच रखें।'); end if;
    update public.rkms_chat_groups set name=trim(p_group_name),updated_at=now() where id=gid;
    return jsonb_build_object('success',true,'action','RENAME','group_id',gid,'name',trim(p_group_name));
  end if;
  if action='LIST' then return public.rkms_chat_group_info(p_conversation_id,p_actor_type); end if;
  if action in ('ADD','REMOVE','MAKE_ADMIN','REMOVE_ADMIN') and not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin यह बदलाव कर सकता है।'); end if;
  if action='LEAVE' then
    update public.rkms_chat_group_members set left_at=now() where group_id=gid and auth_user_id=auth.uid() and left_at is null;
    if not found then return jsonb_build_object('success',false,'message','आप इस Group के active member नहीं हैं।'); end if;
    return jsonb_build_object('success',true,'action','LEAVE');
  end if;
  if target_type not in ('MEMBER','OFFICER') or p_target_id is null then return jsonb_build_object('success',false,'message','Target member उपलब्ध नहीं है।'); end if;

  select upper(gm.role) into target_role from public.rkms_chat_group_members gm
    where gm.group_id=gid and gm.actor_type=target_type and gm.actor_id=p_target_id and gm.left_at is null;
  target_exists:=found;

  if action='ADD' then
    if target_exists then return jsonb_build_object('success',false,'message','यह सदस्य पहले से Group में है।'); end if;
    if target_type='MEMBER' then
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      select gid,'MEMBER',m.id,m.auth_user_id,'MEMBER' from public.rkms_members m
      where m.id=p_target_id and upper(coalesce(m.status,''))='APPROVED';
    else
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      select gid,'OFFICER',o.id,m.auth_user_id,'MEMBER' from public.rkms_officers o join public.rkms_members m on m.id=o.member_id
      where o.id=p_target_id and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED';
    end if;
    if not found then return jsonb_build_object('success',false,'message','चयनित सदस्य उपलब्ध नहीं है।'); end if;
    return jsonb_build_object('success',true,'action','ADD');
  end if;

  if action in ('REMOVE','MAKE_ADMIN','REMOVE_ADMIN') then
    if not target_exists then return jsonb_build_object('success',false,'message','यह member Group में नहीं है।'); end if;
  end if;
  if action='REMOVE' then
    if exists(select 1 from public.rkms_chat_group_members gm where gm.group_id=gid and gm.actor_type=target_type and gm.actor_id=p_target_id and gm.auth_user_id=auth.uid() and gm.left_at is null) then
      return jsonb_build_object('success',false,'message','अपने लिए Group छोड़ें option का उपयोग करें।');
    end if;
    if target_role='ADMIN' then
      select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
      if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    end if;
    update public.rkms_chat_group_members set left_at=now() where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','REMOVE');
  end if;
  if action='MAKE_ADMIN' then
    update public.rkms_chat_group_members set role='ADMIN' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','MAKE_ADMIN');
  end if;
  if action='REMOVE_ADMIN' then
    select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
    if target_role<>'ADMIN' then return jsonb_build_object('success',false,'message','यह member Admin नहीं है।'); end if;
    if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    update public.rkms_chat_group_members set role='MEMBER' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','REMOVE_ADMIN');
  end if;
  return jsonb_build_object('success',false,'message','Invalid group action.');
exception when others then return jsonb_build_object('success',false,'message',sqlerrm);
end;
$function$;
