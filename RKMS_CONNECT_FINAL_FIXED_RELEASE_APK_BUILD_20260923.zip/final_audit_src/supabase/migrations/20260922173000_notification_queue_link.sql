-- Keep each notification push queue row linked to its source notification.
-- The live function writes notification_id during fan-out; the dispatcher uses it
-- to select the correct Android notification channel.
ALTER TABLE public.rkms_push_queue
  ADD COLUMN IF NOT EXISTS notification_id uuid;
CREATE INDEX IF NOT EXISTS idx_rkms_push_queue_notification_id
  ON public.rkms_push_queue(notification_id);
