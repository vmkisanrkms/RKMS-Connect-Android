create or replace function public.rkms_chat_create_group_v2(
  p_actor_type text,
  p_name text,
  p_description text default null,
  p_participants jsonb default '[]'::jsonb,
  p_photo_url text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_catalog
as $$
begin
  return public.rkms_chat_create_group(p_actor_type,p_name,p_description,p_participants,p_photo_url);
exception when others then
  return jsonb_build_object('success',false,'message',sqlerrm);
end;
$$;

revoke all on function public.rkms_chat_create_group_v2(text,text,text,jsonb,text) from public;
grant execute on function public.rkms_chat_create_group_v2(text,text,text,jsonb,text) to authenticated;
notify pgrst, 'reload schema';
