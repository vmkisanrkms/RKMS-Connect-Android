create or replace function public.rkms_chat_set_group_photo(
  p_conversation_id uuid,
  p_photo_url text
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  gid uuid;
  is_admin boolean:=false;
  photo text:=nullif(trim(coalesce(p_photo_url,'')),'');
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;
  select c.group_id into gid from public.rkms_chat_conversations c where c.id=p_conversation_id and c.group_id is not null;
  if gid is null then return jsonb_build_object('success',false,'message','यह Group chat नहीं है।'); end if;
  is_admin := public.rkms_is_super_admin() or exists(
    select 1 from public.rkms_chat_group_members gm
    where gm.group_id=gid and gm.auth_user_id=auth.uid() and gm.left_at is null and upper(coalesce(gm.role,''))='ADMIN'
  );
  if not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin Photo बदल सकता है।'); end if;
  if photo is null then return jsonb_build_object('success',false,'message','Group photo उपलब्ध नहीं है।'); end if;
  update public.rkms_chat_groups set photo_url=photo,updated_at=now() where id=gid;
  return jsonb_build_object('success',true,'action','UPDATE_PHOTO','group_id',gid,'photo_url',photo);
exception when others then return jsonb_build_object('success',false,'message',sqlerrm);
end;
$$;
revoke all on function public.rkms_chat_set_group_photo(uuid,text) from public;
grant execute on function public.rkms_chat_set_group_photo(uuid,text) to authenticated;
notify pgrst, 'reload schema';
