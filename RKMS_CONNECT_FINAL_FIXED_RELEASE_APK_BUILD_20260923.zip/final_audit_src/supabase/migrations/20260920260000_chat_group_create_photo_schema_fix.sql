-- RKMS CONNECT: remove ambiguous 4-argument group-create overload.
-- Keep the 5-argument function with p_photo_url so PostgREST has one RPC signature.
drop function if exists public.rkms_chat_create_group(text,text,text,jsonb);
notify pgrst, 'reload schema';
