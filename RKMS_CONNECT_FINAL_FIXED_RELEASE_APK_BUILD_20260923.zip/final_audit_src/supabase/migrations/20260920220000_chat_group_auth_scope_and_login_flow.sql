-- RKMS final Chat Group creation hardening — 2026-09-20
-- 1) Never expose selectable people without an auth account.
-- 2) Officer group lists are limited to the officer's actual jurisdiction.
-- 3) Group creation resolves auth_user_id server-side and rejects missing accounts.
-- 4) Officer-to-officer additions use the same jurisdiction check.
-- The migration is idempotent and matches the live RPC deployed for this fix.


create or replace function public.rkms_chat_people(p_actor_type text, p_search text default null, p_limit integer default 100)
returns jsonb language plpgsql security definer set search_path to 'public','pg_catalog' as $function$
declare
  me_member uuid; me_officer uuid; actor text:=upper(coalesce(p_actor_type,''));
  actor_is_np boolean:=false; actor_is_super_admin boolean:=false; actor_level text;
  q text:=nullif(trim(coalesce(p_search,'')),''); lim int:=greatest(1,least(coalesce(p_limit,100),100)); v jsonb;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।','data','[]'::jsonb); end if;
  if actor='SUPER_ADMIN' then
    if not public.rkms_is_super_admin() then return jsonb_build_object('success',false,'message','Super Admin authorization required.','data','[]'::jsonb); end if;
    actor:='MEMBER';
  end if;
  me_member:=public.rkms_chat_actor_member_id(); me_officer:=public.rkms_chat_actor_officer_id(); actor_is_super_admin:=public.rkms_is_super_admin();
  if actor='MEMBER' then
    if me_member is null then return jsonb_build_object('success',false,'message','Approved member login जरूरी है।','data','[]'::jsonb); end if;
    with officer_people as (
      select distinct on (o.id) o.id,o.member_id,m.name,m.member_id membership_no,m.auth_user_id,m.photo_url,
      coalesce(o.state,m.state) state,coalesce(o.mandal,m.mandal) mandal,coalesce(o.district,m.district) district,coalesce(o.tehsil,m.tehsil) tehsil,coalesce(o.block,m.block) block,coalesce(o.village,m.village) village,
      'OFFICER'::text chat_type,coalesce(p.post_name,'PDA अधिकारी') post_name,coalesce(p.level,o.authority_level,'') authority_level
      from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
      where upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED' and m.auth_user_id is not null and m.id<>me_member
        and not exists(select 1 from public.rkms_admins a where a.auth_user_id=m.auth_user_id and upper(coalesce(a.role,''))='SUPER_ADMIN' and upper(coalesce(a.status,''))='ACTIVE')
        and (actor_is_super_admin or not (upper(coalesce(p.level,''))='NATIONAL' and trim(coalesce(p.post_name,''))='राष्ट्रीय अध्यक्ष'))
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%')
    ), ordinary_members as (
      select m.id,m.id member_id,m.name,m.member_id membership_no,m.auth_user_id,m.photo_url,m.state,m.mandal,m.district,m.tehsil,m.block,m.village,'MEMBER'::text chat_type,''::text post_name,''::text authority_level
      from public.rkms_members m
      where upper(coalesce(m.status,''))='APPROVED' and m.auth_user_id is not null and m.id<>me_member
        and not exists(select 1 from public.rkms_admins a where a.auth_user_id=m.auth_user_id and upper(coalesce(a.role,''))='SUPER_ADMIN' and upper(coalesce(a.status,''))='ACTIVE')
        and not exists(select 1 from public.rkms_officers o where o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE')
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%')
    ), combined as (select * from officer_people union all select * from ordinary_members)
    select coalesce(jsonb_agg(to_jsonb(x) order by lower(coalesce(x.name,'')),x.chat_type),'[]'::jsonb) into v from (select * from combined limit lim) x;
    return jsonb_build_object('success',true,'data',v);
  end if;
  if actor='OFFICER' then
    if me_officer is null then return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।','data','[]'::jsonb); end if;
    actor_is_np:=public.rkms_chat_is_national_president(me_officer);
    select upper(trim(o.authority_level)) into actor_level from public.rkms_officers o where o.id=me_officer;
    with officer_people as (
      select distinct on (o.id) o.id,o.member_id,m.name,m.member_id membership_no,m.auth_user_id,m.photo_url,
      coalesce(o.state,m.state) state,coalesce(o.mandal,m.mandal) mandal,coalesce(o.district,m.district) district,coalesce(o.tehsil,m.tehsil) tehsil,coalesce(o.block,m.block) block,coalesce(o.village,m.village) village,
      'OFFICER'::text chat_type,coalesce(p.post_name,'PDA अधिकारी') post_name,coalesce(p.level,o.authority_level,'') authority_level
      from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
      where upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED' and m.auth_user_id is not null and o.id<>me_officer
        and not exists(select 1 from public.rkms_admins a where a.auth_user_id=m.auth_user_id and upper(coalesce(a.role,''))='SUPER_ADMIN' and upper(coalesce(a.status,''))='ACTIVE')
        and (actor_is_np or public.rkms_chat_officer_can_access_member(me_officer,o.member_id))
        and (not (upper(coalesce(p.level,''))='NATIONAL' and trim(coalesce(p.post_name,''))='राष्ट्रीय अध्यक्ष') or actor_level in ('NATIONAL','STATE','MANDAL'))
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%' or coalesce(o.state,m.state) ilike '%'||q||'%' or coalesce(o.mandal,m.mandal) ilike '%'||q||'%' or coalesce(o.district,m.district) ilike '%'||q||'%')
      order by o.id,p.post_name nulls last
    ), ordinary_members as (
      select m.id,m.id member_id,m.name,m.member_id membership_no,m.auth_user_id,m.photo_url,m.state,m.mandal,m.district,m.tehsil,m.block,m.village,'MEMBER'::text chat_type,''::text post_name,''::text authority_level
      from public.rkms_members m
      where not actor_is_np and upper(coalesce(m.status,''))='APPROVED' and m.auth_user_id is not null
        and m.id<>coalesce((select member_id from public.rkms_officers where id=me_officer),'00000000-0000-0000-0000-000000000000'::uuid)
        and public.rkms_chat_officer_can_access_member(me_officer,m.id)
        and not exists(select 1 from public.rkms_admins a where a.auth_user_id=m.auth_user_id and upper(coalesce(a.role,''))='SUPER_ADMIN' and upper(coalesce(a.status,''))='ACTIVE')
        and not exists(select 1 from public.rkms_officers o where o.member_id=m.id and upper(coalesce(o.status,''))='ACTIVE')
        and (q is null or m.name ilike '%'||q||'%' or m.member_id ilike '%'||q||'%')
    ), combined as (select * from officer_people union all select * from ordinary_members)
    select coalesce(jsonb_agg(to_jsonb(x) order by lower(coalesce(x.name,'')),x.chat_type),'[]'::jsonb) into v from (select * from combined limit lim) x;
    return jsonb_build_object('success',true,'data',v);
  end if;
  return jsonb_build_object('success',false,'message','Invalid actor type.','data','[]'::jsonb);
end;$function$;

create or replace function public.rkms_chat_create_group(p_actor_type text,p_name text,p_description text default null,p_participants jsonb default '[]'::jsonb,p_photo_url text default null)
returns jsonb language plpgsql security definer set search_path to 'public','pg_catalog' as $function$
declare t text:=upper(coalesce(p_actor_type,'')); me_member uuid; me_officer uuid; gid uuid; cid uuid; x jsonb; pt text; pid uuid; target_member uuid; target_auth uuid;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
  if length(trim(coalesce(p_name,'')))<2 then return jsonb_build_object('success',false,'message','Group का नाम जरूरी है।'); end if;
  if jsonb_array_length(coalesce(p_participants,'[]'::jsonb))<1 then return jsonb_build_object('success',false,'message','कम से कम एक सदस्य चुनें।'); end if;
  if t='MEMBER' then me_member:=public.rkms_chat_actor_member_id(); if me_member is null then return jsonb_build_object('success',false,'message','Approved member login जरूरी है।'); end if;
  elsif t='OFFICER' then me_officer:=public.rkms_chat_actor_officer_id(); if me_officer is null then return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।'); end if;
  else return jsonb_build_object('success',false,'message','Invalid actor type.'); end if;
  insert into public.rkms_chat_groups(name,description,photo_url,created_by_auth_user_id,created_by_actor_type) values(trim(p_name),nullif(trim(p_description),''),nullif(trim(p_photo_url),''),auth.uid(),t) returning id into gid;
  if t='MEMBER' then insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'MEMBER',me_member,auth.uid(),'ADMIN'); else insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'OFFICER',me_officer,auth.uid(),'ADMIN'); end if;
  for x in select * from jsonb_array_elements(coalesce(p_participants,'[]'::jsonb)) loop
    pt:=upper(coalesce(x->>'type','')); pid:=(x->>'id')::uuid;
    if pt='MEMBER' then
      select m.id,m.auth_user_id into target_member,target_auth from public.rkms_members m where m.id=pid and upper(coalesce(m.status,''))='APPROVED';
      if target_member is null then raise exception 'चयनित Member उपलब्ध नहीं है।'; end if;
      if target_auth is null then raise exception 'चयनित सदस्य का Login account उपलब्ध नहीं है। पहले उस सदस्य का Login account बनना जरूरी है।'; end if;
      if t='MEMBER' and pid=me_member then continue; end if;
      if t='OFFICER' and public.rkms_chat_is_national_president(me_officer) then raise exception 'राष्ट्रीय अध्यक्ष इस Group में सदस्य नहीं जोड़ सकते।'; end if;
      if t='OFFICER' and not public.rkms_chat_officer_can_access_member(me_officer,pid) then raise exception 'यह सदस्य आपके अधिकार क्षेत्र में उपलब्ध नहीं है।'; end if;
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'MEMBER',pid,target_auth,'MEMBER') on conflict(group_id,actor_type,actor_id) do nothing;
    elsif pt='OFFICER' then
      select o.member_id,m.auth_user_id into target_member,target_auth from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=pid and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED';
      if target_member is null then raise exception 'चयनित PDA अधिकारी उपलब्ध नहीं है।'; end if;
      if target_auth is null then raise exception 'चयनित PDA अधिकारी का Login account उपलब्ध नहीं है।'; end if;
      if t='MEMBER' and public.rkms_chat_is_national_president(pid) then raise exception 'राष्ट्रीय अध्यक्ष को Member Group में जोड़ने की अनुमति नहीं है।'; end if;
      if t='OFFICER' and pid=me_officer then continue; end if;
      if t='OFFICER' and not public.rkms_chat_is_national_president(me_officer) and not public.rkms_chat_officer_can_access_member(me_officer,target_member) then raise exception 'यह पदाधिकारी आपके अधिकार क्षेत्र में उपलब्ध नहीं है।'; end if;
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'OFFICER',pid,target_auth,'MEMBER') on conflict(group_id,actor_type,actor_id) do nothing;
    else raise exception 'Invalid group participant.'; end if;
  end loop;
  if (select count(*) from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null)<2 then delete from public.rkms_chat_groups where id=gid; return jsonb_build_object('success',false,'message','Group में कम से कम 2 सदस्य होने चाहिए।'); end if;
  insert into public.rkms_chat_conversations(group_id,member_id,member_recipient_id,officer_id,officer_recipient_id) values(gid,null,null,null,null) returning id into cid;
  return jsonb_build_object('success',true,'group_id',gid,'conversation_id',cid);
exception when others then begin delete from public.rkms_chat_groups where id=gid; exception when others then null; end; return jsonb_build_object('success',false,'message',sqlerrm); end;$function$;

create or replace function public.rkms_chat_create_group(p_actor_type text,p_name text,p_description text default null,p_participants jsonb default '[]'::jsonb)
returns jsonb language sql security definer set search_path to 'public','pg_catalog' as $function$
 select public.rkms_chat_create_group(p_actor_type,p_name,p_description,p_participants,NULL::text);$function$;
