-- RKMS CONNECT — Group activity messages
-- Persists visible system-style events in the same group conversation so every
-- active member sees who added/removed/left/changed admin status.

create or replace function public.rkms_chat_group_manage(
  p_conversation_id uuid,
  p_actor_type text,
  p_action text,
  p_target_type text default null,
  p_target_id uuid default null,
  p_group_name text default null,
  p_group_description text default null,
  p_group_photo_url text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_catalog
as $function$
declare
  action text:=upper(coalesce(p_action,''));
  target_type text:=upper(coalesce(p_target_type,''));
  gid uuid;
  is_admin boolean:=false;
  is_super boolean:=false;
  target_role text;
  target_exists boolean:=false;
  admin_count integer;
  actor_name text;
  target_name text;
  actor_sender_type text;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;

  select c.group_id into gid from public.rkms_chat_conversations c
  where c.id=p_conversation_id and c.group_id is not null;
  if gid is null then return jsonb_build_object('success',false,'message','यह Group chat नहीं है।'); end if;

  is_super:=public.rkms_is_super_admin();
  is_admin:=is_super or exists(
    select 1 from public.rkms_chat_group_members gm
    where gm.group_id=gid and gm.auth_user_id=auth.uid()
      and gm.left_at is null and upper(gm.role)='ADMIN'
  );

  if action='LIST' then return public.rkms_chat_group_info(p_conversation_id,p_actor_type); end if;

  if action='RENAME' then
    if not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin Group का नाम बदल सकता है।'); end if;
    if length(trim(coalesce(p_group_name,'')))<1 or length(trim(p_group_name))>80 then
      return jsonb_build_object('success',false,'message','Group का नाम 1 से 80 अक्षरों के बीच रखें।');
    end if;
    update public.rkms_chat_groups set name=trim(p_group_name),updated_at=now() where id=gid;
    return jsonb_build_object('success',true,'action','RENAME','group_id',gid,'name',trim(p_group_name));
  end if;

  if action='UPDATE_DESCRIPTION' then
    if not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin Description बदल सकता है।'); end if;
    if length(coalesce(p_group_description,''))>500 then return jsonb_build_object('success',false,'message','Description अधिकतम 500 अक्षरों की हो सकती है।'); end if;
    update public.rkms_chat_groups set description=nullif(trim(coalesce(p_group_description,'')),''),updated_at=now() where id=gid;
    return jsonb_build_object('success',true,'action','UPDATE_DESCRIPTION','group_id',gid);
  end if;

  if action='UPDATE_PHOTO' then
    if not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin Photo बदल सकता है।'); end if;
    if nullif(trim(coalesce(p_group_photo_url,'')),'') is null then return jsonb_build_object('success',false,'message','Group photo उपलब्ध नहीं है।'); end if;
    update public.rkms_chat_groups set photo_url=trim(p_group_photo_url),updated_at=now() where id=gid;
    return jsonb_build_object('success',true,'action','UPDATE_PHOTO','group_id',gid,'photo_url',trim(p_group_photo_url));
  end if;

  if action in ('ADD','REMOVE','MAKE_ADMIN','REMOVE_ADMIN') and not is_admin then
    return jsonb_build_object('success',false,'message','केवल Group Admin यह बदलाव कर सकता है।');
  end if;

  -- Resolve the actor display name once. Group events are stored as ordinary
  -- chat rows using the actor's auth identity, then rendered as system events.
  select coalesce(m.name,om.name,'Group Admin') into actor_name
  from public.rkms_members m
  left join public.rkms_officers oo on oo.member_id=m.id and upper(coalesce(oo.status,''))='ACTIVE'
  left join public.rkms_members om on om.id=oo.member_id
  where m.auth_user_id=auth.uid()
  limit 1;
  actor_name:=coalesce(actor_name,'Group Admin');
  select case when exists(select 1 from public.rkms_officers oo join public.rkms_members mm on mm.id=oo.member_id where mm.auth_user_id=auth.uid() and upper(coalesce(oo.status,''))='ACTIVE') then 'OFFICER' else 'MEMBER' end into actor_sender_type;

  if action='LEAVE' then
    update public.rkms_chat_group_members set left_at=now()
    where group_id=gid and auth_user_id=auth.uid() and left_at is null;
    if not found then return jsonb_build_object('success',false,'message','आप इस Group के active member नहीं हैं।'); end if;
    insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body)
    values(p_conversation_id,auth.uid(),coalesce(actor_sender_type,'MEMBER'),'[[RKMS_GROUP_EVENT]] '||actor_name||' ने group छोड़ दिया');
    update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
    return jsonb_build_object('success',true,'action','LEAVE');
  end if;

  if target_type not in ('MEMBER','OFFICER') or p_target_id is null then
    return jsonb_build_object('success',false,'message','Target member उपलब्ध नहीं है।');
  end if;

  select upper(gm.role) into target_role
  from public.rkms_chat_group_members gm
  where gm.group_id=gid and gm.actor_type=target_type and gm.actor_id=p_target_id and gm.left_at is null;
  target_exists:=found;

  if target_type='MEMBER' then
    select name into target_name from public.rkms_members where id=p_target_id;
  else
    select m.name into target_name from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=p_target_id;
  end if;
  target_name:=coalesce(target_name,'सदस्य');

  if action='ADD' then
    if target_exists then return jsonb_build_object('success',false,'message','यह सदस्य पहले से Group में है।'); end if;
    if target_type='MEMBER' then
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      select gid,'MEMBER',m.id,m.auth_user_id,'MEMBER' from public.rkms_members m
      where m.id=p_target_id and upper(coalesce(m.status,''))='APPROVED';
    else
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      select gid,'OFFICER',o.id,m.auth_user_id,'MEMBER' from public.rkms_officers o join public.rkms_members m on m.id=o.member_id
      where o.id=p_target_id and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED';
    end if;
    if not found then return jsonb_build_object('success',false,'message','चयनित सदस्य उपलब्ध नहीं है।'); end if;
    insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body)
    values(p_conversation_id,auth.uid(),coalesce(actor_sender_type,'MEMBER'),'[[RKMS_GROUP_EVENT]] '||actor_name||' ने '||target_name||' को group में जोड़ा');
    update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
    return jsonb_build_object('success',true,'action','ADD');
  end if;

  if action in ('REMOVE','MAKE_ADMIN','REMOVE_ADMIN') and not target_exists then
    return jsonb_build_object('success',false,'message','यह member Group में नहीं है।');
  end if;

  if action='REMOVE' then
    if exists(select 1 from public.rkms_chat_group_members gm where gm.group_id=gid and gm.actor_type=target_type and gm.actor_id=p_target_id and gm.auth_user_id=auth.uid() and gm.left_at is null) then
      return jsonb_build_object('success',false,'message','अपने लिए Group छोड़ें option का उपयोग करें।');
    end if;
    if target_role='ADMIN' then
      select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
      if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    end if;
    update public.rkms_chat_group_members set left_at=now() where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body)
    values(p_conversation_id,auth.uid(),coalesce(actor_sender_type,'MEMBER'),'[[RKMS_GROUP_EVENT]] '||actor_name||' ने '||target_name||' को group से हटा दिया');
    update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
    return jsonb_build_object('success',true,'action','REMOVE');
  end if;

  if action='MAKE_ADMIN' then
    update public.rkms_chat_group_members set role='ADMIN' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body)
    values(p_conversation_id,auth.uid(),coalesce(actor_sender_type,'MEMBER'),'[[RKMS_GROUP_EVENT]] '||actor_name||' ने '||target_name||' को Admin बनाया');
    update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
    return jsonb_build_object('success',true,'action','MAKE_ADMIN');
  end if;

  if action='REMOVE_ADMIN' then
    select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
    if target_role<>'ADMIN' then return jsonb_build_object('success',false,'message','यह member Admin नहीं है।'); end if;
    if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    update public.rkms_chat_group_members set role='MEMBER' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    insert into public.rkms_chat_messages(conversation_id,sender_auth_user_id,sender_type,body)
    values(p_conversation_id,auth.uid(),coalesce(actor_sender_type,'MEMBER'),'[[RKMS_GROUP_EVENT]] '||actor_name||' ने '||target_name||' को Admin पद से हटा दिया');
    update public.rkms_chat_conversations set last_message_at=now(),updated_at=now() where id=p_conversation_id;
    return jsonb_build_object('success',true,'action','REMOVE_ADMIN');
  end if;

  return jsonb_build_object('success',false,'message','Invalid group action.');
exception when others then return jsonb_build_object('success',false,'message',sqlerrm);
end;
$function$;

revoke execute on function public.rkms_chat_group_manage(uuid,text,text,text,uuid,text,text,text) from anon;
grant execute on function public.rkms_chat_group_manage(uuid,text,text,text,uuid,text,text,text) to authenticated;
