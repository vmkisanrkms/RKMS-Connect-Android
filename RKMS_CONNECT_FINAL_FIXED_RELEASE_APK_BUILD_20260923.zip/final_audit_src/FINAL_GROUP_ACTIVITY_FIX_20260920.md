# RKMS CONNECT — Group Activity Messages Fix

Fixed five requested group activity behaviors:
1. Admin remove event is persisted in group chat with actor and target names.
2. Self-leave event is persisted in group chat.
3. Make Admin event is persisted; member role remains ADMIN in group info/list.
4. Remove Admin event is persisted; member remains in group as MEMBER.
5. Events are stored in `rkms_chat_messages`, so Realtime/history/notifications use the same chat pipeline.

The UI renders `[[RKMS_GROUP_EVENT]]` rows as centered system-style activity messages.
