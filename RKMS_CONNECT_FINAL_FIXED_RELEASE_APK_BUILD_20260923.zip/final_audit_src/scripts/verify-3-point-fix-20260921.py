from pathlib import Path
s=Path('app.js').read_text()
checks={
 'Digital ID copies approval authority type':'if(data.approver_authority_type)out.approver_authority_type=String(data.approver_authority_type).trim().toUpperCase();' in s,
 'Digital ID loads membership approval meta':'async function renderDigitalId(){' in s and 'const approval=await getMembershipApprovalMeta(m);' in s,
 'Digital ID does not use appointment signer variable flow':'const hasAppointment=' not in s[s.index('async function renderDigitalId(){'):s.index('async function renderMembershipCertificate(){')],
 'Digital ID renders approving officer block':'सदस्यता अनुमोदक अधिकारी' in s[s.index('async function renderDigitalId(){'):s.index('async function renderMembershipCertificate(){')],
 'Android Back closes group settings modal':'#chat-group-manage-modal' in s and 'overlaySelectors=' in s,
 'Remove refreshes chat threads':'await loadChatThreads();await openChatThread(conversationId);await openChatGroupManagement(conversationId);' in s,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
print(f'\n{len(checks)-len(failed)}/{len(checks)} requested-fix checks passed')
raise SystemExit(1 if failed else 0)
