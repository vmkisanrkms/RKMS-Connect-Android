from pathlib import Path
import re
app=Path('app.js').read_text(encoding='utf-8')
setup=Path('scripts/setup-android-native.sh').read_text(encoding='utf-8')
config=Path('capacitor.config.json').read_text(encoding='utf-8')
package=Path('package.json').read_text(encoding='utf-8')
google=Path('google-services.json')
checks={
 'Firebase Android config present': google.exists(),
 'Google Services Gradle plugin configured': 'com.google.gms:google-services:4.4.3' in setup and 'com.google.gms.google-services' in setup,
 'Capacitor push plugin dependency': '@capacitor/push-notifications' in package,
 'FCM registration function': 'async function rkmsRegisterFcmPush' in app,
 'stable device id': 'function rkmsDeviceId' in app and 'device_id:rkmsDeviceId()' in app,
 'registration listener': "addListener('registration'" in app,
 'foreground listener': "addListener('pushNotificationReceived'" in app,
 'tap listener': "addListener('pushNotificationActionPerformed'" in app,
 'notification channels': all(x in app and x in setup for x in ('rkms_notifications_v2','rkms_priority_v1')) and 'createRkmsNotificationChannel' in setup,
 'background default notification channel': 'default_notification_channel_id' in setup and 'rkms_default_notification_channel_id' in setup,
 'resume token re-registration': 'visibilitychange' in app and 'rkmsRegisterFcmPush()' in app,
 'server endpoint': 'rkms-fcm-push' in app,
 'no client chat push duplicate fallback': 'rkms-fcm-dispatch' not in app[app.find('async function sendChatMessage'):app.find('function showChatActionSheet')],
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if not all(checks.values()): raise SystemExit('FCM pipeline verification failed')
print('FCM PIPELINE STATIC VERIFICATION: PASS')
