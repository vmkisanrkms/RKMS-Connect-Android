from pathlib import Path
import re

setup=Path("scripts/setup-android-native.sh").read_text(encoding="utf-8")
checks={
    "native bridge receives Activity": "RKMSNativeBridge(this, rkmsWebView)" in setup,
    "native bridge stores Activity": "private final android.app.Activity activity;" in setup,
    "native bridge stores WebView": "private final android.webkit.WebView webView;" in setup,
    "print uses stored Activity": "activity.runOnUiThread" in setup,
    "print uses stored WebView": "webView.createPrintDocumentAdapter" in setup,
    "no invalid bridge getActivity call": "getActivity()" not in setup.split('cat > "$APP_SRC/RKMSNativeBridge.java"',1)[-1],
    "no invalid bridge getBridge call": "getBridge()" not in setup.split('cat > "$APP_SRC/RKMSNativeBridge.java"',1)[-1],
    "custom password vault removed": "RKMSSecureCredentialsPlugin" not in setup,
    "native notification channels created": "createRkmsNotificationChannel" in setup and "rkms_notifications_v2" in setup and "rkms_priority_v1" in setup,
    "no hard-coded MainActivity source path": "Path('android/app/src/main/java/org/rkms/connect/MainActivity.java')" not in setup,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(("PASS: " if v else "FAIL: ")+k)
if failed: raise SystemExit("Native bridge verification failed: "+", ".join(failed))
