# RKMS FINAL 4-POINT FIX AUDIT — 2026-09-20

- Login: visible Autofill button; username/current-password autocomplete retained; Android WebView autofill importance enabled; password-save prompt is marked only after Credential Manager reports success.
- Chat composer: normal flex-flow composer is explicitly kept above the fixed RKMS bottom navigation; keyboard-open state removes footer reservation while the app footer is hidden.
- New Group: Team RKMS is excluded from group participants; missing-auth participants are excluded; stale/unauthorized selections are blocked before RPC; backend still resolves auth_user_id and rejects NULL.
- Authority scope: group participants are taken from the server-scoped chat people list and a client-side stale-selection guard is added; backend remains authoritative.
