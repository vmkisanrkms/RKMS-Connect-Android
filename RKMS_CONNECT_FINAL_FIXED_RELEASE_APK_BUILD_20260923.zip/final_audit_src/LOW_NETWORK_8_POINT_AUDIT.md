# LOW NETWORK CHAT — 8 POINT IMPLEMENTATION
Implemented in app.js:
1. IndexedDB offline chat cache and cache-first conversation rendering.
2. Persistent outgoing text/message queue with client_message_id.
3. 12s request timeout via AbortController + bounded retries.
4. Automatic outbox sync and refresh after network recovery.
5. Existing Realtime + polling fallback retained; reconnect triggered on network recovery.
6. Lazy image decode and video preload=none to reduce data usage.
7. online/offline listeners and Realtime restart on recovery.
8. Cache-first startup/open-chat path; network failure no longer blocks cached conversation rendering.

Note: APK compilation/signing still requires running the Android release workflow.
