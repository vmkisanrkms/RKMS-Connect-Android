# RKMS Group Chat Professional Final — 20 Sep 2026

This build includes the corrected WhatsApp-style Group structure requested by the user.

- Group photo: view/change for authorized Admin/Super Admin
- Group name: rename dialog, 1–80 characters
- Group description: edit, max 500 characters
- Add Member: search/select professional member list
- Member roles: Admin/Member management
- Group Info: photo, name, description, member count
- Group Settings: authorized management actions
- Leave Group
- New Group creation: optional photo + description
- Android system navigation and RKMS app footer separated using the actual bottom safe-area inset
- Chat composer remains directly above the RKMS app footer

The backend authorization is server-side in Supabase. The app does not trust a client-only admin flag for rename/photo/description updates.
