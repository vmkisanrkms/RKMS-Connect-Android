# RKMS CONNECT — Final 3-Point Fix Audit — 2026-09-20

## Scope
Source audited and fixed for the three reported runtime areas:
1. Chat composer/footer positioning.
2. New Group creation: `auth_user_id` and authority-scope failures.
3. Unified Login: one-time password-save prompt and saved ID/password retrieval.

## Fixes applied

### 1. Chat composer
- Closed keyboard viewport is calculated as viewport minus RKMS site header minus bottom navigation.
- Keyboard-open mode uses visual viewport and hides RKMS bottom navigation.
- Composer remains normal flex-flow content inside the conversation viewport.
- Conflicting later `position: fixed` composer override was removed.
- Messages remain the scrollable area.

### 2. New Group
- `rkms_chat_people` now excludes approved users whose `auth_user_id` is NULL.
- Officer member lists are filtered by `rkms_chat_officer_can_access_member`.
- Officer-to-officer group additions are also authority-scoped.
- Group creation resolves the selected member/officer's `auth_user_id` server-side.
- NULL `auth_user_id` is rejected with a clear account-required message instead of a PostgreSQL NOT NULL error.
- Live Supabase RPCs were updated and the same migration was added to the source ZIP.

### 3. Login / saved credentials
- Username/password fields use explicit username/current-password autocomplete metadata.
- Android Credential Manager retrieval bridge was added.
- Saved Login action can request the saved credential and fill both fields.
- Password-save request is limited to once per account on the device, preventing a prompt on every Logout/Login cycle.
- Existing encrypted session persistence was not removed.
- No custom password vault was added.

## Verification
- RKMS final static verification: PASS
- Final fixes verification: PASS
- Saved-login verification: PASS
- Login/navigation verification: 19/19 PASS
- Native bridge verification: PASS
- Android 16/API 36 source verification: PASS
- Three-point verification: 18/18 PASS
- Live Supabase authority checks: PASS for tested members:
  - Harsahib A52938: accessible to Harmanjeet Singh's district authority.
  - Kamaljeet Singh A00005: same jurisdiction, but currently has NULL `auth_user_id`; the new group picker/backend now blocks this account until a login account exists.
  - Joginder Singh A53789: outside that district authority and therefore blocked.
  - Jasveer Singh A81287: outside that district authority and therefore blocked.

## Important runtime boundary
The source and live database logic have been statically audited and the live RPC changes applied successfully. A physical Motorola Edge 50 Pro runtime test was not executed in this environment, so Android keyboard/autofill UI behavior still needs the final APK installed on the device for end-to-end confirmation.
