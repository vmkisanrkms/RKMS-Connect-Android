# RKMS CONNECT — Final Group Management Audit — 20 Sep 2026

- Group creation accepts visible Chat members even when `auth_user_id` is NULL.
- `rkms_chat_group_members.auth_user_id` is nullable for group membership.
- Group member selection is not restricted by officer jurisdiction.
- Group Admin can ADD/REMOVE visible Member/PDA participants.
- Group Admin can MAKE_ADMIN / REMOVE_ADMIN.
- Group Admin can RENAME Group.
- Group Admin can UPDATE_DESCRIPTION (max 500 chars).
- Group Admin can UPDATE_PHOTO; app enforces JPG/PNG and 5 MB before upload.
- Group Info returns Group name, description, photo URL, members and `can_manage`.
- Leave Group remains available.
- Super Admin retains management access.
- The final management RPC preserves the unrestricted participant rule while restoring photo/description actions that were lost in the previous unrestricted migration.
