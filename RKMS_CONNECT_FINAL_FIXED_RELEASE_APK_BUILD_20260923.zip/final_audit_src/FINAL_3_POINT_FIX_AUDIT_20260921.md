# RKMS Connect — 3 Point Source Fix Audit — 2026-09-21

Source base: RKMS_CONNECT_GROUP_PHOTO_SCHEMA_FIXED_FINAL_20260921_FIXED.zip

## Fixed

1. **Member Digital ID — membership approval authority**
   - Digital ID now uses `rkms_get_membership_approval_signer` / `approved_by` approval data.
   - When membership was approved by an officer, Digital ID shows National President + the actual approving officer.
   - The approving officer's signature is shown when available.
   - Appointment authority is no longer used as the member Digital ID approval signer.
   - National President/Super Admin approval remains a single National President authority block.

2. **Android hardware Back in Group Info / Group Settings**
   - Hardware Back now closes the topmost Group Info/Settings modal first.
   - Nested group overlays (member action sheet, add-member modal, text editor) are also closed before SPA history is changed.
   - Home still exits the Android app as before.

3. **Group Settings member removal immediate refresh**
   - After REMOVE / MAKE_ADMIN / REMOVE_ADMIN, chat threads are refreshed, the conversation is refreshed, and Group Info is reopened from fresh group data.
   - Removed members therefore disappear immediately without requiring Back + reopen.

## Validation

- `node --check app.js`: PASS
- `scripts/verify-final-three-point-fix.py`: 17/18 existing checks pass; its single failure is an older unrelated composer-rule check already present in the base source.
- The three requested fixes were additionally verified by direct source inspection.

No live database change is included in this ZIP.
