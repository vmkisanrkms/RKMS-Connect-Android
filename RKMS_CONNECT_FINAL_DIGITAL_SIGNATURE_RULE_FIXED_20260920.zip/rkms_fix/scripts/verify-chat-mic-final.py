from pathlib import Path
app=Path('app.js').read_text(encoding='utf-8')
css=Path('styles.css').read_text(encoding='utf-8')
native=Path('scripts/setup-android-native.sh').read_text(encoding='utf-8')
checks=[
    ('--rkms-compose-runtime-h' in css,'composer runtime height'),
    ('scroll-padding-bottom' in css,'scroll padding'),
    ('position:relative !important' in css and '.wa-conversation-screen .wa-compose-wrap' in css,'composer in conversation flow'),
    ('isMicrophonePermissionGranted' in native,'native mic permission check'),
    ('requestMicrophonePermission' in native,'native mic permission request'),
    ('android.permission.RECORD_AUDIO' in native,'RECORD_AUDIO'),
    ('RESOURCE_AUDIO_CAPTURE' in native,'WebView audio permission'),
    ('MediaRecorder' in app,'MediaRecorder'),
    ('getUserMedia' in app,'getUserMedia')
]
for ok,name in checks:
    print(('PASS' if ok else 'FAIL')+': '+name)
    if not ok: raise SystemExit(1)
if 'padding-bottom:80px !important' in css: raise SystemExit('FAIL: old 80px padding remains')
if '{audio:true}' not in app: raise SystemExit('FAIL: fallback getUserMedia missing')
if 'Do not open/close a test stream' not in app: raise SystemExit('FAIL: microphone preflight still present')

extra=[
 ('chat-group-rename' in app and 'RENAME' in app,'Group rename UI'),
 ('chat-group-photo-btn' in app and 'UPDATE_PHOTO' in app,'Group photo change UI'),
 ('chat-group-add-member' in app and 'openChatGroupAddMember' in app,'Professional add member flow'),
 ('chat-group-description' in app and 'UPDATE_DESCRIPTION' in app,'Group description flow'),
 (Path('supabase/migrations/20260920123000_rkms_group_whatsapp_professional_final.sql').exists(),'Group professional migration documentation'),
 ('appointing_officer_name' in app and 'appointing_authority_name' in app,'Digital ID appointing authority'),
 ('captureCurrentDocumentAsPdf' in app and 'captureCurrentDocumentAsPdf' in native,'Native exact-render PDF bridge'),
 ('height:calc(62px + env(safe-area-inset-bottom)) !important' in css and 'padding-bottom:env(safe-area-inset-bottom) !important' in css,'Footer Android safe-area separation'),
 ('padding:4px max(8px,3vw) 4px !important' in css,'Composer compact padding'),
]
for ok,name in extra:
    print(('PASS' if ok else 'FAIL')+': '+name)
    if not ok: raise SystemExit(1)
print('Chat + microphone + group + Digital ID + PDF source verification PASS.')
