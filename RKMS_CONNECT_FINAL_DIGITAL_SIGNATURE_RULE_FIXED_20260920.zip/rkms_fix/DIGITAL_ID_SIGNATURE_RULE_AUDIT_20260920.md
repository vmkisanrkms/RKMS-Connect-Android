# Digital ID Signature Rule Audit — 2026-09-20

## Required rules
1. If the appointing officer has a signature URL, that signature is rendered above the appointing officer's name.
2. If the National President has a signature URL, it is rendered above the National President's name.
3. If the National President has no signature URL, no blank signature line is rendered; only National President name/post/details remain.
4. If another appointing officer has no signature URL, no blank signature line is rendered; the officer's name/post remain.
5. A member/current officer signature is never used as an appointing-authority fallback.
6. National President/Super Admin appointment renders only the National President block; no duplicate appointing-authority block.
7. Appointment Letter follows the same signature-line behavior.

## Verification
- `node --check app.js`: PASS
- `verify-rkms-final.py`: PASS
- `verify-rkms-final-fixes.py`: PASS
- `verify-chat-mic-final.py`: PASS
- `verify-android-16.py`: PASS
- `verify-native-bridge.py`: PASS
- `verify-saved-login.py`: PASS
- `verify-android-pdf.py`: PASS
- `verify-pdf-pipeline.py`: PASS
