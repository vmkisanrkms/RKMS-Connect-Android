# Digital ID Authority Rule Fix — 2026-09-20

## Required behavior
- If appointment is made by Rashtriya Adhyaksh / National President or Super Admin: show ONLY one authority block for Rashtriya Adhyaksh.
- If appointment is made by another officer: show TWO blocks — Rashtriya Adhyaksh on one side and the separate Niyuktikarta on the other.
- Never duplicate National President as the Niyuktikarta.
- Never use the member's own signature as appointing-authority signature.

## Source fix
`app.js` `renderDigitalId()` now computes `nationalOnlyAppointment` and suppresses the appointing-authority block for National President/Super Admin appointments.

## Verification
- node --check app.js: PASS
- Existing RKMS final verification: PASS
- Final fixes verification: PASS
- Chat/microphone/group/Digital ID/PDF verification: PASS
- Android 16/API 36 verification: PASS
- Native bridge verification: PASS
- Saved login verification: PASS
- Android PDF verification: PASS
- PDF pipeline verification: PASS
