# RKMS CONNECT — Final Source Fix Audit — 2026-09-20

## Fixed in this package
1. Chat keyboard geometry: removed the duplicated site-header subtraction that caused excess blank space above the Android keyboard.
2. Closed-keyboard layout: Messages → Composer → RKMS footer → Android system navigation safe area.
3. Open-keyboard layout: Messages → Composer → Android keyboard; RKMS footer is hidden and no footer/header height is reserved a second time.
4. Bottom navigation now reserves the real Android safe-area inset instead of collapsing it into the 62px content height.
5. Digital ID signer resolution remains authoritative: no member-signature fallback is used for National President/appointing-authority blocks.
6. Group management retains professional WhatsApp-style photo/name/description/add-member/admin/member-management flows.
7. Existing PDF/native bridge, microphone, FCM, saved-login, and Android API 36 source paths were preserved.

## Verification performed
- `node --check app.js`
- `scripts/verify-rkms-final-fixes.py` — PASS
- `scripts/verify-chat-mic-final.py` — PASS
- `scripts/verify-android-pdf.py` — PASS

## Important
This is a source ZIP. Static/source verification passed. A physical Motorola Edge 50 Pro runtime test was not performed in this environment, so device-level behavior is not represented as a completed runtime test.
