# RKMS CONNECT — FINAL DEEP AUDIT / FIX UPDATE — 2026-09-20

## Fixes applied after deep source-contract audit

1. **Group RPC contract fixed**
   - Removed conflicting 5-argument and 6-argument `rkms_chat_group_manage` overloads in a new final migration.
   - Added one final compatible RPC contract with optional group name, description and photo URL parameters.
   - `RENAME`, `UPDATE_DESCRIPTION`, `UPDATE_PHOTO`, `ADD`, `REMOVE`, `MAKE_ADMIN`, `REMOVE_ADMIN`, `LEAVE`, and `LIST` are supported.
   - Server-side admin authorization is preserved.

2. **Group photo update fixed**
   - Existing Group Info photo change now uses `uploadGroupPhoto(file, conversationId)`.
   - Photo path is `chat-groups/<conversation_id>/...`.
   - The uploaded URL is passed to the final `UPDATE_PHOTO` RPC contract.

3. **Group Info fixed**
   - `rkms_chat_group_info` now returns top-level `name`, `description`, and `photo_url` in addition to member data and `can_manage`.
   - Frontend already consumes these fields.

4. **Keyboard CSS conflict fixed**
   - The later runtime-injected keyboard CSS no longer subtracts the site header a second time.
   - Keyboard-open and closed conversation height now use `--rkms-chat-available-h` consistently.
   - This removes the previously identified conflicting runtime rule that could recreate the blank gap.

## Verification

Existing verification scripts all PASS:
- RKMS final static verification
- Final fixes verification
- Chat + microphone + group + Digital ID + PDF
- Android 16/API 36
- Native bridge
- Saved login
- Android PDF
- PDF pipeline

Additional deep contract audit PASS:
- Group RPC overload removal and final signature
- Group photo/description DB update contract
- Group Info metadata return contract
- Group photo uploader path
- Keyboard runtime CSS conflict removal

## Important

This ZIP contains the corrected source and migration. It does **not** by itself prove live Supabase migration execution or real-device runtime success. Before Release APK distribution, apply/run the new migration through the project's Supabase migration pipeline and perform the actual device test for Group Photo, Group Info, keyboard/composer, microphone, Digital ID, PDF Download/Print, saved login and FCM.
