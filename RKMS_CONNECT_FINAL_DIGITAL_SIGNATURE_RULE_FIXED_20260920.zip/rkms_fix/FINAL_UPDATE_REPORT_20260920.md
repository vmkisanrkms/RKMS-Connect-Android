# RKMS CONNECT FINAL SOURCE UPDATE — 2026-09-20

## Updated in source ZIP
- Digital ID authority rendering now always keeps the existing National President block and a separate Appointing Authority block.
- Appointing Authority signature is resolved only from the actual appointing officer, or the National President when the appointment authority is explicitly National President.
- The appointed member's own `signature_url` is never reused as the appointing authority signature.
- Digital ID shows signature above appointing authority name/post.
- Group creation is backward-compatible with both 5-argument and legacy 4-argument `rkms_chat_create_group` RPC signatures.
- Group photo is uploaded only after a conversation/group ID exists, using `chat-groups/<conversation_id>/...`, so Storage RLS can authorize the upload.
- Group photo upload failure no longer destroys an otherwise successful Group creation; the user receives the exact upload error and remains in the new Group.
- Existing group name, description, add/remove member, admin, leave, chat, microphone, FCM, saved-login, PDF and Android 16/API 36 source paths are preserved.

## Verification
- node --check app.js: PASS
- RKMS final static verification: PASS
- final fixes verification: PASS
- chat/microphone/group/Digital ID verification: PASS
- Android 16/API 36 verification: PASS
- native bridge verification: PASS
- saved login verification: PASS
- Android PDF verification: PASS
- PDF pipeline verification: PASS

## Database
No database migration or live database modification is included in this ZIP update.
