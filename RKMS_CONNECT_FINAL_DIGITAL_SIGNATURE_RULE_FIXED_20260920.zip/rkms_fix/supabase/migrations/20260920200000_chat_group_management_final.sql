-- RKMS Chat Group Management — member/admin controls + secure group info
-- Adds server-side authorization for Group Admin, add/remove members and admin roles.

create or replace function public.rkms_chat_group_info(p_conversation_id uuid, p_actor_type text)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_catalog
as $function$
declare
  t text := upper(coalesce(p_actor_type,''));
  g uuid;
  can_manage boolean := false;
  v jsonb;
  group_name text;
  group_description text;
  group_photo_url text;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  select c.group_id into g
  from public.rkms_chat_conversations c
  where c.id=p_conversation_id and c.group_id is not null;

  if g is null then
    return jsonb_build_object('success',false,'message','यह Group chat नहीं है।');
  end if;

  if not exists(
    select 1 from public.rkms_chat_group_members gm
    where gm.group_id=g and gm.auth_user_id=auth.uid() and gm.left_at is null
  ) and not public.rkms_is_super_admin() then
    return jsonb_build_object('success',false,'message','इस Group की अनुमति नहीं है।');
  end if;

  select name,description,photo_url into group_name,group_description,group_photo_url
  from public.rkms_chat_groups where id=g;

  can_manage := public.rkms_is_super_admin()
    or exists(
      select 1 from public.rkms_chat_group_members gm
      where gm.group_id=g and gm.auth_user_id=auth.uid() and gm.left_at is null and upper(gm.role)='ADMIN'
    );

  select coalesce(jsonb_agg(to_jsonb(x) order by x.role_order, lower(coalesce(x.name,''))),'[]'::jsonb)
    into v
  from (
    select gm.actor_type,gm.actor_id,gm.auth_user_id,upper(gm.role) role,gm.joined_at,
           case when gm.actor_type='MEMBER' then m.name else om.name end name,
           case when gm.actor_type='MEMBER' then m.photo_url else om.photo_url end photo_url,
           case when gm.actor_type='MEMBER' then 'सदस्य' else coalesce(op.post_name,'पदाधिकारी') end post_name,
           case when gm.actor_type='MEMBER' then m.member_id else om.member_id end member_id,
           case when gm.actor_type='MEMBER' then m.district else oo.district end district,
           case when upper(gm.role)='ADMIN' then 0 else 1 end role_order
    from public.rkms_chat_group_members gm
    left join public.rkms_members m on gm.actor_type='MEMBER' and m.id=gm.actor_id
    left join public.rkms_officers oo on gm.actor_type='OFFICER' and oo.id=gm.actor_id
    left join public.rkms_members om on gm.actor_type='OFFICER' and om.id=oo.member_id
    left join public.rkms_posts op on op.id=oo.post_id
    where gm.group_id=g and gm.left_at is null
  ) x;

  return jsonb_build_object('success',true,'group_id',g,'name',group_name,'description',group_description,'photo_url',group_photo_url,'can_manage',can_manage,'data',v);
end;
$function$;

revoke execute on function public.rkms_chat_group_info(uuid,text) from anon;
grant execute on function public.rkms_chat_group_info(uuid,text) to authenticated;

create or replace function public.rkms_chat_group_manage(
  p_conversation_id uuid,
  p_actor_type text,
  p_action text,
  p_target_type text default null,
  p_target_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_catalog
as $function$
declare
  action text := upper(coalesce(p_action,''));
  actor text := upper(coalesce(p_actor_type,''));
  target_type text := upper(coalesce(p_target_type,''));
  gid uuid;
  is_admin boolean := false;
  is_super boolean := false;
  target_auth uuid;
  target_name text;
  target_role text;
  admin_count integer;
  actor_member uuid;
  actor_officer uuid;
  ok boolean := false;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  select c.group_id into gid
  from public.rkms_chat_conversations c
  where c.id=p_conversation_id and c.group_id is not null;
  if gid is null then
    return jsonb_build_object('success',false,'message','यह Group chat नहीं है।');
  end if;

  is_super := public.rkms_is_super_admin();
  is_admin := is_super or exists(
    select 1 from public.rkms_chat_group_members gm
    where gm.group_id=gid and gm.auth_user_id=auth.uid() and gm.left_at is null and upper(gm.role)='ADMIN'
  );

  if action='LIST' then
    return public.rkms_chat_group_info(p_conversation_id,p_actor_type);
  end if;

  if action in ('ADD','REMOVE','MAKE_ADMIN','REMOVE_ADMIN') and not is_admin then
    return jsonb_build_object('success',false,'message','केवल Group Admin यह बदलाव कर सकता है।');
  end if;

  if action='LEAVE' then
    update public.rkms_chat_group_members
       set left_at=now()
     where group_id=gid and auth_user_id=auth.uid() and left_at is null;
    if not found then
      return jsonb_build_object('success',false,'message','आप इस Group के active member नहीं हैं।');
    end if;
    return jsonb_build_object('success',true,'action','LEAVE');
  end if;

  if target_type not in ('MEMBER','OFFICER') or p_target_id is null then
    return jsonb_build_object('success',false,'message','Target member उपलब्ध नहीं है।');
  end if;

  select gm.auth_user_id,upper(gm.role) into target_auth,target_role
  from public.rkms_chat_group_members gm
  where gm.group_id=gid and gm.actor_type=target_type and gm.actor_id=p_target_id and gm.left_at is null;

  if action='ADD' then
    if target_auth is not null then
      return jsonb_build_object('success',false,'message','यह सदस्य पहले से Group में है।');
    end if;

    if target_type='MEMBER' then
      select m.auth_user_id,m.name into target_auth,target_name
      from public.rkms_members m
      where m.id=p_target_id and upper(coalesce(m.status,''))='APPROVED';
      if target_auth is null then return jsonb_build_object('success',false,'message','Approved member उपलब्ध नहीं है।'); end if;

      if not is_super and actor='OFFICER' then
        actor_officer := public.rkms_chat_actor_officer_id();
        if actor_officer is null or not public.rkms_chat_officer_can_access_member(actor_officer,p_target_id) then
          return jsonb_build_object('success',false,'message','इस सदस्य को Group में जोड़ने का अधिकार आपके क्षेत्र में नहीं है।');
        end if;
      end if;

      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      values(gid,'MEMBER',p_target_id,target_auth,'MEMBER');
    else
      select m.auth_user_id,m.name into target_auth,target_name
      from public.rkms_officers o join public.rkms_members m on m.id=o.member_id
      where o.id=p_target_id and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED';
      if target_auth is null then return jsonb_build_object('success',false,'message','Active PDA अधिकारी उपलब्ध नहीं है।'); end if;

      if not is_super and actor='OFFICER' then
        actor_officer := public.rkms_chat_actor_officer_id();
        if actor_officer is null or not public.rkms_can_manage_officer(actor_officer,p_target_id) then
          return jsonb_build_object('success',false,'message','इस पदाधिकारी को Group में जोड़ने का अधिकार नहीं है।');
        end if;
      end if;

      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role)
      values(gid,'OFFICER',p_target_id,target_auth,'MEMBER');
    end if;
    return jsonb_build_object('success',true,'action','ADD');
  end if;

  if target_auth is null then
    return jsonb_build_object('success',false,'message','यह member Group में नहीं है।');
  end if;

  if action='REMOVE' then
    if target_auth=auth.uid() then
      return jsonb_build_object('success',false,'message','अपने लिए Group छोड़ें option का उपयोग करें।');
    end if;
    if target_role='ADMIN' then
      select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
      if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    end if;
    update public.rkms_chat_group_members set left_at=now() where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','REMOVE');
  end if;

  if action='MAKE_ADMIN' then
    update public.rkms_chat_group_members set role='ADMIN' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','MAKE_ADMIN');
  end if;

  if action='REMOVE_ADMIN' then
    select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
    if target_role<>'ADMIN' then return jsonb_build_object('success',false,'message','यह member Admin नहीं है।'); end if;
    if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    update public.rkms_chat_group_members set role='MEMBER' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','REMOVE_ADMIN');
  end if;

  return jsonb_build_object('success',false,'message','Invalid group action.');
exception when others then
  return jsonb_build_object('success',false,'message',sqlerrm);
end;
$function$;

revoke execute on function public.rkms_chat_group_manage(uuid,text,text,text,uuid) from anon;
grant execute on function public.rkms_chat_group_manage(uuid,text,text,text,uuid) to authenticated;
