-- RKMS FINAL GROUP RPC CONTRACT FIX — 2026-09-20
-- Replaces conflicting 5/6-argument overloads with one compatible function.
-- Supports existing ADD/REMOVE/ADMIN/LEAVE/RENAME plus photo and description updates.

drop function if exists public.rkms_chat_group_manage(uuid,text,text,text,uuid);
drop function if exists public.rkms_chat_group_manage(uuid,text,text,text,uuid,text);

create or replace function public.rkms_chat_group_manage(
  p_conversation_id uuid,
  p_actor_type text,
  p_action text,
  p_target_type text default null,
  p_target_id uuid default null,
  p_group_name text default null,
  p_group_description text default null,
  p_group_photo_url text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_catalog
as $function$
declare
  action text := upper(coalesce(p_action,''));
  actor text := upper(coalesce(p_actor_type,''));
  target_type text := upper(coalesce(p_target_type,''));
  gid uuid;
  is_admin boolean := false;
  is_super boolean := false;
  target_auth uuid;
  target_role text;
  admin_count integer;
  actor_officer uuid;
begin
  if auth.uid() is null then return jsonb_build_object('success',false,'message','Login जरूरी है।'); end if;
  select c.group_id into gid from public.rkms_chat_conversations c where c.id=p_conversation_id and c.group_id is not null;
  if gid is null then return jsonb_build_object('success',false,'message','यह Group chat नहीं है।'); end if;
  is_super:=public.rkms_is_super_admin();
  is_admin:=is_super or exists(select 1 from public.rkms_chat_group_members gm where gm.group_id=gid and gm.auth_user_id=auth.uid() and gm.left_at is null and upper(gm.role)='ADMIN');
  if action in ('RENAME','UPDATE_DESCRIPTION','UPDATE_PHOTO') and not is_admin then
    return jsonb_build_object('success',false,'message','केवल Group Admin यह बदलाव कर सकता है।');
  end if;
  if action='UPDATE_PHOTO' then
    if length(trim(coalesce(p_group_photo_url,'')))<1 then return jsonb_build_object('success',false,'message','Group photo URL उपलब्ध नहीं है।'); end if;
    update public.rkms_chat_groups set photo_url=trim(p_group_photo_url),updated_at=now() where id=gid;
    if not found then return jsonb_build_object('success',false,'message','Group नहीं मिला।'); end if;
    return jsonb_build_object('success',true,'action','UPDATE_PHOTO','group_id',gid,'photo_url',trim(p_group_photo_url));
  end if;
  if action='UPDATE_DESCRIPTION' then
    if length(coalesce(p_group_description,''))>500 then return jsonb_build_object('success',false,'message','Description 500 अक्षरों से अधिक नहीं हो सकती।'); end if;
    update public.rkms_chat_groups set description=nullif(trim(coalesce(p_group_description,'')),''),updated_at=now() where id=gid;
    if not found then return jsonb_build_object('success',false,'message','Group नहीं मिला।'); end if;
    return jsonb_build_object('success',true,'action','UPDATE_DESCRIPTION','group_id',gid,'description',nullif(trim(coalesce(p_group_description,'')),''));
  end if;
  if action='RENAME' then
    if not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin Group का नाम बदल सकता है।'); end if;
    if length(trim(coalesce(p_group_name,'')))<1 or length(trim(p_group_name))>80 then return jsonb_build_object('success',false,'message','Group का नाम 1 से 80 अक्षरों के बीच रखें।'); end if;
    update public.rkms_chat_groups set name=trim(p_group_name),updated_at=now() where id=gid;
    if not found then return jsonb_build_object('success',false,'message','Group नहीं मिला।'); end if;
    return jsonb_build_object('success',true,'action','RENAME','group_id',gid,'name',trim(p_group_name));
  end if;
  if action='LIST' then return public.rkms_chat_group_info(p_conversation_id,p_actor_type); end if;
  if action in ('ADD','REMOVE','MAKE_ADMIN','REMOVE_ADMIN') and not is_admin then return jsonb_build_object('success',false,'message','केवल Group Admin यह बदलाव कर सकता है।'); end if;
  if action='LEAVE' then
    update public.rkms_chat_group_members set left_at=now() where group_id=gid and auth_user_id=auth.uid() and left_at is null;
    if not found then return jsonb_build_object('success',false,'message','आप इस Group के active member नहीं हैं।'); end if;
    return jsonb_build_object('success',true,'action','LEAVE');
  end if;
  if target_type not in ('MEMBER','OFFICER') or p_target_id is null then return jsonb_build_object('success',false,'message','Target member उपलब्ध नहीं है।'); end if;
  select gm.auth_user_id,upper(gm.role) into target_auth,target_role from public.rkms_chat_group_members gm where gm.group_id=gid and gm.actor_type=target_type and gm.actor_id=p_target_id and gm.left_at is null;
  if action='ADD' then
    if target_auth is not null then return jsonb_build_object('success',false,'message','यह सदस्य पहले से Group में है।'); end if;
    if target_type='MEMBER' then
      select m.auth_user_id into target_auth from public.rkms_members m where m.id=p_target_id and upper(coalesce(m.status,''))='APPROVED';
      if target_auth is null then return jsonb_build_object('success',false,'message','Approved member उपलब्ध नहीं है।'); end if;
      if not is_super and actor='OFFICER' then actor_officer:=public.rkms_chat_actor_officer_id(); if actor_officer is null or not public.rkms_chat_officer_can_access_member(actor_officer,p_target_id) then return jsonb_build_object('success',false,'message','इस सदस्य को Group में जोड़ने का अधिकार आपके क्षेत्र में नहीं है।'); end if; end if;
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'MEMBER',p_target_id,target_auth,'MEMBER');
    else
      select m.auth_user_id into target_auth from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=p_target_id and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(m.status,''))='APPROVED';
      if target_auth is null then return jsonb_build_object('success',false,'message','Active PDA अधिकारी उपलब्ध नहीं है।'); end if;
      if not is_super and actor='OFFICER' then actor_officer:=public.rkms_chat_actor_officer_id(); if actor_officer is null or not public.rkms_can_manage_officer(actor_officer,p_target_id) then return jsonb_build_object('success',false,'message','इस पदाधिकारी को Group में जोड़ने का अधिकार आपके क्षेत्र में नहीं है।'); end if; end if;
      insert into public.rkms_chat_group_members(group_id,actor_type,actor_id,auth_user_id,role) values(gid,'OFFICER',p_target_id,target_auth,'MEMBER');
    end if;
    return jsonb_build_object('success',true,'action','ADD');
  end if;
  if target_auth is null then return jsonb_build_object('success',false,'message','यह member Group में नहीं है।'); end if;
  if action='REMOVE' then
    if target_auth=auth.uid() then return jsonb_build_object('success',false,'message','अपने लिए Group छोड़ें option का उपयोग करें।'); end if;
    if target_role='ADMIN' then select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN'; if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if; end if;
    update public.rkms_chat_group_members set left_at=now() where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','REMOVE');
  end if;
  if action='MAKE_ADMIN' then update public.rkms_chat_group_members set role='ADMIN' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null; return jsonb_build_object('success',true,'action','MAKE_ADMIN'); end if;
  if action='REMOVE_ADMIN' then
    select count(*) into admin_count from public.rkms_chat_group_members gm where gm.group_id=gid and gm.left_at is null and upper(gm.role)='ADMIN';
    if target_role<>'ADMIN' then return jsonb_build_object('success',false,'message','यह member Admin नहीं है।'); end if;
    if admin_count<=1 then return jsonb_build_object('success',false,'message','आखिरी Group Admin को हटाया नहीं जा सकता।'); end if;
    update public.rkms_chat_group_members set role='MEMBER' where group_id=gid and actor_type=target_type and actor_id=p_target_id and left_at is null;
    return jsonb_build_object('success',true,'action','REMOVE_ADMIN');
  end if;
  return jsonb_build_object('success',false,'message','Invalid group action.');
exception when others then return jsonb_build_object('success',false,'message',sqlerrm);
end;
$function$;

revoke execute on function public.rkms_chat_group_manage(uuid,text,text,text,uuid,text,text,text) from anon;
grant execute on function public.rkms_chat_group_manage(uuid,text,text,text,uuid,text,text,text) to authenticated;
