from pathlib import Path
import re

setup=Path("scripts/setup-android-native.sh").read_text(encoding="utf-8")
checks={
    "native bridge receives Activity": "RKMSNativeBridge(this, getBridge().getWebView())" in setup,
    "native bridge stores Activity": "private final android.app.Activity activity;" in setup,
    "native bridge stores WebView": "private final android.webkit.WebView webView;" in setup,
    "print uses stored Activity": "activity.runOnUiThread" in setup,
    "print uses stored WebView": "webView.createPrintDocumentAdapter" in setup,
    "no invalid bridge getActivity call": "getActivity()" not in setup.split('cat > "$APP_SRC/RKMSNativeBridge.java"',1)[-1],
    "no invalid bridge getBridge call": "getBridge()" not in setup.split('cat > "$APP_SRC/RKMSNativeBridge.java"',1)[-1],
    "secure plugin registered": "registerPlugin(RKMSSecureCredentialsPlugin.class)" in setup,
    "no hard-coded MainActivity source path": "Path('android/app/src/main/java/org/rkms/connect/MainActivity.java')" not in setup,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(("PASS: " if v else "FAIL: ")+k)
if failed: raise SystemExit("Native bridge verification failed: "+", ".join(failed))
