from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
# Every named function call must have a declaration when it is part of the known critical signer API.
refs=len(re.findall(r'\bresolveOfficerSignature\s*\(',app))
defs=len(re.findall(r'\bfunction\s+resolveOfficerSignature\s*\(',app))
assert defs==1 and refs>=1, f'resolveOfficerSignature refs={refs} defs={defs}'
assert 'RKMSSecureCredentialsPlugin' in (root/'scripts/setup-android-native.sh').read_text()
assert 'RKMSNativeBridge' in (root/'scripts/setup-android-native.sh').read_text()
assert 'async function rkmsRegisterFcmPush' in app
assert "action:'register_token'" in app
assert 'async function rkmsUnregisterFcmPush' in app
assert 'history.replaceState({rkmsRoute:"home"' in app
assert 'rkmsSaveLoginCredentials' in app
assert 'if(oid && (!out.approver_name||!out.approver_post||!out.approver_signature_url))await fillFromOfficer(oid);' in app
assert 'officerAreaLabel(officer,m)||memberAreaLabel(m)' in app
assert (root/'assets/rkms-logo-transparent.png').exists()
print('RKMS final static verification: PASS')
print(f'resolveOfficerSignature: {refs} call/definition references, {defs} definition')
