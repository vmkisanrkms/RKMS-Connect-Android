# RKMS Connect — Website WebView Build

This Android build intentionally loads the same live RKMS website used in the browser:

https://cucurucho-dd9a67.netlify.app/

The APK does **not** use `file:///android_asset/www/index.html` as its main screen. This prevents the APK from running an older bundled copy of the website while the browser runs the current website.

The native bridge and Firebase/notification code are retained. A WebView file chooser is also enabled so website forms that use attachments can work inside the APK.

Build with Android Studio using Java 17 / Gradle 8.13, or use the included GitHub Actions workflow:
`.github/workflows/build-apk.yml`

The workflow produces an installable debug APK artifact.

## Final cleanup
- APK opens the live Netlify website directly.
- Removed bundled www frontend to prevent stale website copies from being mistaken for the runtime frontend.
- The browser website remains the single frontend source of truth.
