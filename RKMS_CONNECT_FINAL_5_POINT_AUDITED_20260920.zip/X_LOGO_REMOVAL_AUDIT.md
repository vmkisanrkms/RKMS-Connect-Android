# RKMS CONNECT — Logo Audit

## PASS

1. The dedicated Android launcher source is `assets/rkms-launcher-original-transparent.png`.
2. Its SHA-256 exactly matches the supplied transparent RKMS logo.
3. Android launcher PNGs are derived from that RKMS artwork only.
4. No CONNECT text has been added inside the launcher artwork.
5. The app launcher uses the original RKMS logo only; no X/Twitter logo is used as the launcher icon.
6. The old extra Android AAB workflow has been removed from this APK-first package; only the APK-only workflow is included.
7. Normal `×` close controls in dialogs are UI controls, not an X/Twitter logo.

## Complaint

- Member gets clear Close/Reopen actions at the appropriate states.
- Authorized PDA officer gets a clear Close Complaint action after resolution.
- Backend officer-close RPC is used; UI visibility alone is not the security boundary.

## Build order

APK first → install and test on the phone → only after APK PASS, create the AAB.
