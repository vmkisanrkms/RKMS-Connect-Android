# RKMS CONNECT — Android 16 / API 36 Build Target

This package is configured for Android 16 (API level 36).

- compileSdkVersion: 36
- targetSdkVersion: 36
- Android Gradle Plugin: 8.9.1
- Gradle: 8.11.1
- JDK: 17
- Android SDK Platform: android-36
- Build Tools: 36.0.0

The GitHub Actions workflow installs API 36, configures the generated Capacitor Android project, verifies the configuration, and builds the debug APK.


## APK / Play Release

The Android workflow now generates debug APK, release APK, and release APK. If the GitHub repository contains the four signing secrets `RKMS_KEYSTORE_BASE64`, `RKMS_KEYSTORE_PASSWORD`, `RKMS_KEY_ALIAS`, and `RKMS_KEY_PASSWORD`, the release artifacts are signed with the supplied upload/release keystore. If those secrets are absent, an unsigned release APK/APK is still produced for verification; it is not directly uploadable to Google Play until signed.
