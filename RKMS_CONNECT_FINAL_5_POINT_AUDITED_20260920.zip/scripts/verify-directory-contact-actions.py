#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/"app.js").read_text(encoding="utf-8")
MIGDIR=ROOT/"supabase/migrations"
MIGS="\n".join(p.read_text(encoding="utf-8") for p in MIGDIR.glob("*.sql"))

checks=[]
def chk(name, ok):
    checks.append((name, bool(ok)))

chk("Officer cards pair Message with Call under the same phone/management gate",
     'phone&&canContact' in APP and
     'data-directory-chat="${esc(x.officer_id)}"' in APP and
     'data-directory-chat-type="OFFICER"' in APP)

chk("Member directory cards pair Message with Call under rkmsCanCallDirectoryMember",
     'rkmsCanCallDirectoryMember(m)?`<a' in APP and
     'data-directory-chat-type="MEMBER"' in APP)

chk("Area member cards pair Message with Call under canCall",
     '${canCall?`<a' in APP and
     'data-directory-chat-type="MEMBER"' in APP)

chk("Directory Message opens existing RKMS Chat flow",
     'await openNewChat(' in APP and
     'rpc("rkms_chat_open"' in APP)

chk("No WhatsApp contact action was introduced",
     not re.search(r'wa\.me|api\.whatsapp|whatsapp\.com/send', APP, re.I))

chk("Guest/public officer directory uses safe public RPC",
     'rkms_public_active_officers' in APP and
     'const management=state.role===\'super_admin\'||state.role===\'officer\'' in APP)

chk("Officer detail uses defined management flag",
     'const management=state.role===\'super_admin\'||canManage;' in APP and
     'phone&&management?' in APP and
     'phone&&isMgmt?' not in APP[APP.find("async function renderOfficer"):APP.find("function rkmsLocationAllowed")] and 'phone&&management?' in APP)

chk("Server-side chat authority migration is present",
     '20260914110000_directory_contact_chat_authority_v18.sql' in [p.name for p in MIGDIR.iterdir()])

chk("Server-side chat authority protects officer targets",
     'rkms_can_manage_officer(actor_officer,target_officer)' in MIGS)

chk("Server-side chat authority protects member targets",
     'rkms_chat_officer_can_access_member(actor_officer,target)' in MIGS)

chk("Anonymous chat-open execution is revoked",
     'revoke execute on function public.rkms_chat_open(text,text,uuid) from anon' in MIGS.lower())

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(("PASS" if ok else "FAIL")+": "+n)
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print("\nFailed:")
    for n in failed: print("-",n)
    sys.exit(1)
