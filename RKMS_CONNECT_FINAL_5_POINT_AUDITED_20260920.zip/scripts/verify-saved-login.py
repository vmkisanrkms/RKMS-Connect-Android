from pathlib import Path
root=Path(".")
app=(root/"app.js").read_text(encoding="utf-8")
setup=(root/"scripts/setup-android-native.sh").read_text(encoding="utf-8")
assert "RKMSSecureCredentials" not in app
assert "RKMSSecureCredentials" not in setup
assert "androidx.credentials:credentials:1.5.0" in setup
assert "androidx.credentials:credentials-play-services-auth:1.5.0" in setup
assert "savePassword" in setup
assert 'autocomplete="current-password"' in app
print("GOOGLE PASSWORD MANAGER / CREDENTIAL MANAGER VERIFY: PASS")
