from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
# Every named function call must have a declaration when it is part of the known critical signer API.
refs=len(re.findall(r'\bresolveOfficerSignature\s*\(',app))
defs=len(re.findall(r'\bfunction\s+resolveOfficerSignature\s*\(',app))
assert defs==1 and refs>=1, f'resolveOfficerSignature refs={refs} defs={defs}'
setup=(root/'scripts/setup-android-native.sh').read_text(); assert 'RKMSSecureCredentialsPlugin' not in setup; assert 'androidx.credentials:credentials:1.5.0' in setup
assert 'RKMSNativeBridge' in (root/'scripts/setup-android-native.sh').read_text()
assert 'async function rkmsRegisterFcmPush' in app
assert "action:'register_token'" in app
assert 'async function rkmsUnregisterFcmPush' in app
assert 'rkms-fcm-dispatch' not in app[app.find('async function sendChatMessage'):app.find('function showChatActionSheet')]
assert 'push_queue_ids' not in app[app.find('async function sendChatMessage'):app.find('function showChatActionSheet')]
assert 'visibilitychange' in app and 'rkmsRegisterFcmPush' in app
assert 'rkms_notifications_v2' in app
assert 'history.replaceState({rkmsRoute:"home"' in app
assert 'savePassword' in setup and 'CredentialManager' in setup
assert 'RKMSSecureCredentials' not in app and 'RKMSSecureCredentials' not in setup
assert 'if(oid && (!out.approver_name||!out.approver_post||!out.approver_signature_url))await fillFromOfficer(oid);' in app
assert 'officerAreaLabel(officer,m)||memberAreaLabel(m)' in app
assert 'box.querySelectorAll("[data-reappoint-officer]")' in app
assert 'rkms_members?id=eq.${encodeURIComponent(memberId)}' in app
assert 'q.dispatchEvent(new Event("input"))' not in app[app.find('box.querySelectorAll("[data-reappoint-officer]")'):app.find('async function saveAppointment')]
assert 'form.dataset.reappointOfficer=officerId' in app
assert 'await seedAppointmentLocationFromMember(member)' in app
assert (root/'assets/rkms-logo-transparent.png').exists()
print('RKMS final static verification: PASS')
print(f'resolveOfficerSignature: {refs} call/definition references, {defs} definition')
# Runtime guards that previously escaped the static checks.
for name in ('rkmsOfficerCanAccessTarget','rkmsLocationAllowed','validateFileSignature','validateSignatureImage'):
    assert re.search(rf'\bfunction\s+{name}\s*\(', app), f'missing critical function: {name}'
print('critical runtime helper definitions: PASS')
