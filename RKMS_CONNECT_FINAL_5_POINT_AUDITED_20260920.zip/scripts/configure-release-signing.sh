#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${RKMS_KEYSTORE_BASE64:-}" || -z "${RKMS_KEYSTORE_PASSWORD:-}" || -z "${RKMS_KEY_ALIAS:-}" || -z "${RKMS_KEY_PASSWORD:-}" ]]; then
  echo "Release signing secrets not supplied: building unsigned release AAB/APK."
  exit 0
fi

printf '%s' "$RKMS_KEYSTORE_BASE64" | base64 --decode > android/app/release.keystore
chmod 600 android/app/release.keystore

python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
if 'RKMS release signing' in s:
    raise SystemExit(0)
marker='android {'
if marker not in s:
    raise SystemExit('android block missing')
insert='''android {
    // RKMS release signing
    signingConfigs {
        release {
            storeFile file("release.keystore")
            storePassword System.getenv("RKMS_KEYSTORE_PASSWORD")
            keyAlias System.getenv("RKMS_KEY_ALIAS")
            keyPassword System.getenv("RKMS_KEY_PASSWORD")
        }
    }
'''
s=s.replace(marker,insert,1)
pos=s.find('buildTypes {')
if pos < 0:
    raise SystemExit('buildTypes block missing')
rel=s.find('release {', pos)
if rel < 0:
    raise SystemExit('release buildType block missing')
open_brace=s.find('{', rel)
s=s[:open_brace+1]+'\n        signingConfig signingConfigs.release'+s[open_brace+1:]
p.write_text(s)
PY

echo "Release signing configuration applied."
