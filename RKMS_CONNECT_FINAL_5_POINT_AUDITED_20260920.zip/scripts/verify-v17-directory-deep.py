from pathlib import Path
import re

root=Path('.')
app=(root/'app.js').read_text(encoding='utf-8')
sql=(root/'supabase/migrations/20260914090000_harden_directory_lists_v17.sql').read_text(encoding='utf-8')

checks=[]
def ok(name, cond):
    if not cond: raise AssertionError(name)
    checks.append(name)

# Guest/member public officer privacy.
ok('safe public officer RPC', 'rkms_public_active_officers' in app and 'rkms_public_active_officers' in sql)
ok('public officer card hides call for Guest/member', 'phone&&canContact' in app)
ok('officer detail contact uses defined management gate', 'phone&&management?' in app and 'phone&&isMgmt?' not in app)
offsql=sql.split('CREATE OR REPLACE FUNCTION public.rkms_public_active_officers()',1)[1].split('-- Member directory:',1)[0]
ok('public officer RPC excludes private mobile/email', "'mobile'" not in offsql and "'email'" not in offsql)

# Member directory completeness.
for x in ['memState','memMandal','memDistrict','memTehsil','memBlock','memVillage','memType','memWing','memPhoto']:
    ok(f'member filter {x}', x in app)
for x in ['data-state','data-mandal','data-district','data-tehsil','data-block','data-village','data-type','data-wing','data-photo']:
    ok(f'member card attr {x}', x in app)

# Officer directory completeness.
for x in ['dirLevel','dirState','dirMandal','dirDistrict','dirTehsil','dirBlock','dirVillage','dirWing']:
    ok(f'officer filter {x}', x in app)
for x in ['data-level','data-state','data-mandal','data-district','data-tehsil','data-block','data-village','data-wing']:
    ok(f'officer card attr {x}', x in app)

# Detail-only member deletion.
m=re.search(r'async function renderAdminMemberList\(\)\{(.*?)\n\}', app, re.S)
ok('member list function exists', bool(m))
member_fn=m.group(1)
ok('no checkbox in member list', 'type="checkbox"' not in member_fn.lower())
ok('no bulk delete in member list', 'bulk' not in member_fn.lower())
ok('delete is on member detail', 'memberDetailDelete' in app)
ok('highest authority can see member delete', "rkmsIsHighestAuthority()||['STATE','MANDAL','DISTRICT'].includes(lvl)" in app)

# PDA list is view-scoped; actions remain manage-scoped.
ok('PDA list uses access scope', "rkmsOfficerCanAccessTarget(x)" in app and "base.filter(x=>state.role==='super_admin'||rkmsIsHighestAuthority()||rkmsOfficerCanAccessTarget(x))" in app)
ok('PDA management action remains strict', 'rkmsOfficerCanManageTarget(x)' in app)
ok('strictly lower rank backend', 'public.rkms_level_rank(tp) < public.rkms_level_rank(ap)' in '\n'.join((root/'supabase/migrations/20260911200000_finalize_pda_hierarchy_authority.sql').read_text(encoding='utf-8').splitlines()))

# Member RPC cannot leak to anonymous callers.
ok('member RPC anonymous hard block', 'if not v_authenticated then' in sql and 'auth.uid() is not null' in sql)
ok('member RPC still grants authenticated', 'GRANT EXECUTE ON FUNCTION public.rkms_directory_members' in sql and 'TO anon, authenticated' in sql)

# Wing support is schema-tolerant via to_jsonb.
ok('member wing schema-tolerant', "to_jsonb(m)->>'wing_name'" in sql)

print('RKMS CONNECT V17 DIRECTORY DEEP AUDIT: PASS')
for x in checks: print('PASS:', x)
