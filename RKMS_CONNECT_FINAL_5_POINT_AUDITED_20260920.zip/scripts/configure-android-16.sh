#!/usr/bin/env bash
set -euo pipefail

ROOT="android"
VARS="$ROOT/variables.gradle"
ROOT_GRADLE="$ROOT/build.gradle"
WRAPPER="$ROOT/gradle/wrapper/gradle-wrapper.properties"

[ -f "$VARS" ] || { echo "ERROR: $VARS missing"; exit 1; }
[ -f "$ROOT_GRADLE" ] || { echo "ERROR: $ROOT_GRADLE missing"; exit 1; }
[ -f "$WRAPPER" ] || { echo "ERROR: $WRAPPER missing"; exit 1; }

python3 - <<'PY'
from pathlib import Path
p=Path('android/variables.gradle')
s=p.read_text()
import re
for key in ('compileSdkVersion','targetSdkVersion'):
    s=re.sub(rf'(\b{key}\s*=\s*)\d+', lambda m: m.group(1)+'36', s)
p.write_text(s)

p=Path('android/build.gradle')
s=p.read_text()
import re
s=re.sub(r"com\.android\.tools\.build:gradle:[0-9.]+", "com.android.tools.build:gradle:8.9.1", s)
p.write_text(s)

p=Path('android/gradle/wrapper/gradle-wrapper.properties')
s=p.read_text()
s=re.sub(r"distributionUrl=.*", "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip", s)
p.write_text(s)
PY

echo "Android 16 API 36 configuration applied: compileSdk=36 targetSdk=36 AGP=8.9.1 Gradle=8.11.1"
