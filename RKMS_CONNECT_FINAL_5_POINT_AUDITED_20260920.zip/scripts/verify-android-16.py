from pathlib import Path
import re, sys
errors=[]
css=Path('styles.css').read_text()
setup=Path('scripts/setup-android-native.sh').read_text()
vars_path=Path('android/variables.gradle')
if not vars_path.exists():
    setup=Path('scripts/setup-android-native.sh').read_text()
    assert 'platforms;android-36' in Path('.github/workflows/rkms-android16-release-apk.yml').read_text()
    wf=Path('.github/workflows/rkms-android16-release-apk.yml').read_text(); assert 'platforms;android-36' in wf and 'build-tools;36.0.0' in wf
    print('ANDROID 16 API 36 VERIFY: PASS (generated Android project not bundled; CI setup validated)')
    sys.exit(0)
vars=vars_path.read_text()
root=Path('android/build.gradle').read_text()
wrap=Path('android/gradle/wrapper/gradle-wrapper.properties').read_text()
if not re.search(r'compileSdkVersion\s*=\s*36', vars): errors.append('compileSdkVersion is not 36')
if not re.search(r'targetSdkVersion\s*=\s*36', vars): errors.append('targetSdkVersion is not 36')
if 'com.android.tools.build:gradle:8.9.1' not in root: errors.append('AGP 8.9.1 not configured')
if 'gradle-8.11.1-bin.zip' not in wrap: errors.append('Gradle 8.11.1 not configured')
if 'safe-area-inset-top' not in css or 'safe-area-inset-bottom' not in css: errors.append('edge-to-edge safe-area insets are not present in web UI')
if 'windowOptOutEdgeToEdgeEnforcement' in setup: errors.append('Android 16 edge-to-edge opt-out must not be used')
if 'enableOnBackInvokedCallback=\"true\"' not in setup: errors.append('predictive back is not explicitly enabled in generated manifest patch')
if errors:
    print('ANDROID 16 API 36 VERIFY: FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('ANDROID 16 API 36 VERIFY: PASS')
print(' - compileSdkVersion=36')
print(' - targetSdkVersion=36')
print(' - AGP=8.9.1')
print(' - Gradle=8.11.1')
print(' - edge-to-edge safe-area handling present')
print(' - predictive back enabled')
