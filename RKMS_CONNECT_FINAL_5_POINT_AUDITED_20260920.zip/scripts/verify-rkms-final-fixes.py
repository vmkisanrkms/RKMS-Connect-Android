from pathlib import Path
import sys
root=Path('.')
app=(root/'app.js').read_text(encoding='utf-8')
setup=(root/'scripts/setup-android-native.sh').read_text(encoding='utf-8')
checks={
 'Google Password Manager / Credential Manager':'autocomplete="current-password"' in app and 'savePassword' in setup and 'CredentialManager' in setup and 'RKMSSecureCredentials' not in app and 'RKMSSecureCredentials' not in setup,
 'Keyboard visualViewport':'visualViewport' in app and 'rkms-keyboard-open' in app,
 'Chat composer spacing':'.wa-compose-wrap' in app and '.wa-messages' in app,
 'Microphone permission JS':'requestRKMSMicrophonePermission' in app,
 'MediaRecorder voice flow':'MediaRecorder' in app and 'getUserMedia' in app,
 'Appointment authority':'getAppointmentMeta' in app and 'appointed_by_officer_id' in app,
 'PDF download handler':'data-download-pdf' in app and 'savePdfBlob' in app,
 'Native PDF chunk bridge':'beginPdfSave' in setup and 'appendPdfChunk' in setup and 'finishPdfSave' in setup,
 'Native keyboard resize':'SOFT_INPUT_ADJUST_RESIZE' in setup,
 'Native microphone WebView bridge':'onPermissionRequest' in setup and 'RESOURCE_AUDIO_CAPTURE' in setup,
 'Native microphone manifest':'android.permission.RECORD_AUDIO' in setup,
 'File chooser preserved':'onShowFileChooser' in setup,
 'FCM registration':'async function rkmsRegisterFcmPush' in app,
 'FCM foreground listener':"pushNotificationReceived" in app,
 'FCM tap listener':"pushNotificationActionPerformed" in app,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
if failed:raise SystemExit('RKMS final fix verification failed')
print('RKMS FINAL FIX STATIC VERIFICATION: PASS')
