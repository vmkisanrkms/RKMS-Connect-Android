from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
checks=[]
def ok(name,cond):
    checks.append((name,cond))
    print(('PASS: ' if cond else 'FAIL: ')+name)

ok('Opening Flash remains on splash only', 'setupOpening' in app and 'const active=await loadActiveFlash()' in app)
ok('Home no longer renders Flash as normal hero feed', 'const heroVisual=`<div class="hero-logo"><img src="assets/rkms-logo-transparent.png"' in app)
ok('Home no longer labels News as Flash', 'समाचार / Flash' not in app)
ok('Events remain directly after Book on Home', 'book-tile' in app and 'home-events-preview' in app and app.index('book-tile') < app.index('home-events-preview'))
ok('Event geographic target selector exists', 'id="e_target"' in app and 'id="e_state"' in app and 'id="e_district"' in app)
ok('Notification audience has member/officer/both choices', 'id="nt_audience"' in app and 'MEMBERS' in app and 'OFFICERS' in app and 'value="ALL"' in app)
ok('Notification Priority is explicit', 'id="nt_imp"' in app and 'Priority सूचना ऊपर' in app)
ok('Notification page uses targeted visibility reader', 'loadPriorityNotifications(50)' in app)
ok('Content attribution is rendered', 'content-attribution' in app and 'डाली गई:' in app)
ok('Admin has existing Content Management route', 'data-route="content-management"' in app)
ok('Admin has सूचना shortcut without new route', '><b>सूचना</b><small>सभी प्रकाशित सूचना' in app)
ok('No WhatsApp contact action introduced', 'data-route="whatsapp"' not in app.lower())

mig=root/'supabase/migrations/20260916210000_content_scope_audience_priority_attribution.sql'
ms=mig.read_text(encoding='utf-8')
ok('Content migration present', mig.exists())
ok('Flash backend restricted to top authority', "Opening Flash केवल Super Admin या राष्ट्रीय अध्यक्ष" in ms)
ok('Event scope backend guard present', 'rkms_event_scope_allowed' in ms and 'rkms_manage_events' in ms)
ok('Court order backend guard present', 'rkms_guard_court_order_authority' in ms and 'COURT_ORDER' in ms)
ok('Notification attribution RPC present', 'rkms_get_notification_attribution' in ms)

failed=[n for n,c in checks if not c]
print(f"\nCONTENT MANAGEMENT FINAL AUDIT: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print('FAILED: '+', '.join(failed)); sys.exit(1)
