# RKMS Chat fixed layout — 2026-09-19

This build changes only the Android/web chat layout behavior requested for the APK build.

## Chat list screen

- RKMS Chat title/header remains fixed.
- Refresh, group and new-chat actions remain fixed.
- Search chats remains fixed.
- All / Unread / Groups filters remain fixed.
- Only the recent-chat list scrolls.

## Conversation screen

- Member avatar/name/role header remains fixed.
- Refresh/menu actions remain fixed.
- Only the message area scrolls.
- The + button, message input, microphone and send button are one composer row.
- The composer remains anchored at the bottom and does not scroll with messages.
- Android VisualViewport changes are tracked so the composer follows the resized viewport when the soft keyboard opens.

## Android target

- Capacitor Android 6.2.2
- compileSdk 36
- targetSdk 36
- Android Build Tools 36.0.0
- AGP 8.9.1
- Gradle 8.11.1
- JDK 17
- Node 22

## Scope

No Supabase schema, PDA password logic, membership logic, Digital ID logic, or other application workflow was intentionally changed by this chat-layout fix.
