# RKMS CONNECT — Chat Group / Composer / Microphone Fix — 2026-09-20

## Fixed
- Group conversation menu now exposes Group members/Admin management.
- Group Admin can add members, remove members, make a member Admin, remove Admin role, and leave the group.
- Last remaining Group Admin cannot be removed.
- Server-side Supabase RPCs enforce Group Admin authorization and existing officer/member jurisdiction rules.
- Existing group `सभी जिलों की टीम` keeps its current Admin/member records; no group membership data was deleted.
- Chat composer is returned to normal flex flow instead of being fixed above the bottom navigation twice.
- Removed the runtime `padding-bottom` injection that created extra blank space below the composer.
- Microphone recording no longer opens a temporary test stream before the real MediaRecorder stream. That double `getUserMedia()` sequence could trigger Android WebView `NotReadableError` / “Microphone audio source शुरू नहीं हो पाया”.
- Recorder now uses a single real stream with Android-friendly audio constraints and a delayed fallback to simple `audio:true` on `NotReadableError`.
- Recorder stream is explicitly released and the recorder reference cleared after stop.

## Verification
- `node --check app.js`: PASS
- Chat + microphone static verification: PASS
- RKMS final static verification: PASS
- Native bridge verification: PASS
- PDF pipeline verification: PASS
- Saved-login / Credential Manager verification: PASS

## Supabase
Applied migration:
`chat_group_management_final_20260920`

New RPCs:
- `rkms_chat_group_info(uuid,text)`
- `rkms_chat_group_manage(uuid,text,text,text,uuid)`

No existing chat, FCM, saved-login, PDF or membership workflow was removed.
