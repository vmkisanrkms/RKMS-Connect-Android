# RKMS CONNECT — Complaint Workflow Final Implementation

## Implemented in this batch

1. **Member-only registration** — backend verifies authenticated APPROVED member identity; client-supplied location is not authoritative.
2. **Unique Complaint ID** — existing `RKMS-CMP-YYYY-######` sequence retained.
3. **Automatic routing** — selects the lowest available active authorized level in the complaint location: Block → Tehsil → District → Mandal → State → National.
4. **Deterministic tie-break** — President/अध्यक्ष posts are preferred, then non-IT-cell posts, then oldest active appointment.
5. **Conflict-of-interest protection** — an officer named as the accused cannot handle that complaint.
6. **Assignment ownership** — `assigned_to`, `assigned_at`, `assigned_by` and assignment history are recorded.
7. **Fallback queue** — if no eligible officer exists, complaint remains safely unassigned in `RECEIVED` and an audit event records the routing failure.
8. **Controlled status workflow** — supports RECEIVED, ASSIGNED, UNDER_REVIEW, NEED_INFORMATION, IN_PROGRESS, ACTION_TAKEN, RESOLVED, CLOSED, REOPENED and REJECTED with server-side transition validation.
9. **Hierarchy lock** — assigned officer or a strictly higher authority may change the complaint; same/lower unrelated officers cannot take over an assigned complaint.
10. **Transfer / Forward** — transfer requires a destination officer and a reason, validates destination authority, updates ownership and writes an immutable-style audit event.
11. **Member visibility** — member can see current responsible officer, status, priority, SLA date, action, resolution and lifecycle history.
12. **Officer detail UI** — shows current owner, SLA, attachments, transfer selector, reason field, controlled next statuses and audit history.
13. **Personal notifications** — complaint registration, assignment, transfer and status updates create targeted in-app notifications.
14. **FCM bridge** — personal MEMBER-targeted notifications are now included in the existing notification-to-FCM queue path.
15. **SLA foundation** — new complaints receive a 7-day default SLA timestamp; schema/indexes are ready for overdue reporting/automation.
16. **Invalid post cleanup** — the obsolete `तहसील कोषाध्यक्ष` post was removed; its active appointment record was made INACTIVE before post deletion.
17. **Existing open complaint backfill** — existing non-final unassigned complaints were routed to an eligible officer without rewriting their current status.
18. **RPC surface hardened** — complaint mutation/detail functions are authenticated-only; routing helper is not client-executable.

## Final business flow

`MEMBER → REGISTER → COMPLAINT ID → AUTO ROUTING → RESPONSIBLE OFFICER → UNDER REVIEW → NEED INFORMATION / TRANSFER / IN PROGRESS → ACTION TAKEN → RESOLVED → CLOSED`

Exceptions:
- `REJECTED` requires a reason.
- `REOPENED` is allowed from RESOLVED/CLOSED and returns the complaint to review/action.
- If no eligible officer exists, the complaint stays in `RECEIVED` queue until routed.

## Verification performed

- JavaScript syntax check: PASS
- Existing RKMS final static verification: PASS
- Complaint schema columns/checks: verified
- Complaint mutation RPC grants: anonymous execution blocked; authenticated execution enabled
- Existing open unassigned complaint count after backfill: 0
- Invalid `तहसील कोषाध्यक्ष` post count: 0
- Existing non-final complaint now has a responsible officer

## Remaining final-test items

The backend and UI changes are implemented, but real-phone end-to-end tests should still be run with test accounts at Block, Tehsil, District, Mandal, State and National levels for:

- registration + automatic assignment
- assignment push + in-app notification
- transfer push + audit history
- NEED_INFORMATION flow
- action/resolution/closure
- reopen
- rejection
- cross-jurisdiction access denial
- same/lower authority takeover denial
- conflict-of-interest denial
- concurrent update/transfer behavior
- attachment access
- SLA/overdue reporting
