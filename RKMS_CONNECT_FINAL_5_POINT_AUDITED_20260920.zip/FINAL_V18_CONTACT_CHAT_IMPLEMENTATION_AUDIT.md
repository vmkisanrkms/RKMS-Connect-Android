# RKMS CONNECT — V18 Member/PDA Contact + Direct Chat Audit

## लागू बदलाव
- Guest/public officer directory से private mobile/email exposure नहीं बदला गया; public RPC ही उपयोग होता है।
- जिस authorized card पर **📞 Call** दिखाई देता है, उसी gate में **💬 संदेश** भी दिखाई देता है।
- Officer target का Message existing RKMS Chat में `OFFICER` ID से खुलता है।
- Member target का Message existing RKMS Chat में `MEMBER` ID से खुलता है।
- External WhatsApp/contact link नहीं जोड़ा गया।
- Officer detail में undefined `isMgmt` runtime reference हटाकर defined `management` gate किया गया।
- Existing member/PDA list filters, detail-only member delete, geographic scope और lower-level management rules बरकरार रखे गए।
- `rkms_chat_open` backend में officer→member और officer→officer authority checks जोड़े/सुनिश्चित किए गए।
- `anon` को chat-open EXECUTE से revoke और `authenticated` को grant किया गया।

## Verification
- `node --check app.js` — PASS
- `scripts/verify-directory-contact-actions.py` — 11/11 PASS
- `scripts/verify-directory-lists.py` — PASS
- `scripts/verify-v17-directory-deep.py` — PASS
- `scripts/verify-authority-hierarchy.py` — PASS
- `scripts/verify-report-download-scope.py` — PASS
- `scripts/verify-pdf-pipeline.py` — PASS
- `scripts/verify-rkms-final.py` — PASS
- `npm run build` — PASS
- Live Supabase `rkms_chat_open(text,text,uuid)` — SECURITY DEFINER PASS
- Live Supabase anon EXECUTE — DENIED/PASS
- Live Supabase authenticated EXECUTE — GRANTED/PASS
- Live Supabase officer target guard — PASS
- Live Supabase member target guard — PASS

## Device verification
Real Android device tap-through is not claimed from this source ZIP alone. A fresh APK build/install is required to verify the rendered buttons and actual chat navigation on the phone.

## Source ZIP hygiene
Generated `dist/`, `node_modules/`, Android build output and `.github/` are not included in the source ZIP. CI should generate build artifacts during the APK workflow.
