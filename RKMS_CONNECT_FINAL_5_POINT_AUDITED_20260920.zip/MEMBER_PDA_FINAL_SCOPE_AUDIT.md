# RKMS Connect — Member/PDA Final Scope Audit

## Exact requested behavior implemented

1. Bottom navigation **सदस्य** now opens `member-hub` first, not a list directly.
2. `member-hub` shows exactly two list choices:
   - **सदस्य देखें** → `member-list`
   - **PDA अधिकारी देखें** → `directory`
3. Member list is rendered by `renderAdminMemberList()` and its cards use `memberDirectoryCard()` only.
4. PDA list is rendered by `renderDirectory()` and its cards use `officerCard()` only.
5. Member list and PDA list therefore remain separate; no cross-list rendering is introduced by the new hub.
6. Member list access uses `rkms_directory_members` with backend geographic scope enforcement.
7. PDA list uses active-officer directory data and existing officer target-scope checks for management views.
8. National/Super Admin highest-authority behavior remains intact.
9. Existing Call/Message actions remain attached to their own list cards and continue using existing authority checks.
10. No membership installment/kist/payment feature was added as part of this change.

## Verification

- `node --check app.js` PASS
- `node --check config.js` PASS
- Bottom nav verified as `data-route="member-hub"`.
- Router verified for `member-hub`, `member-list`, and `directory`.
