# RKMS CONNECT Complaint Workflow — Final V2 Hardening

Implemented after the V1 final audit.

- New complaint evidence uses private `rkms-complaints` storage (10 MB; JPG/PNG/WEBP/PDF).
- Evidence is stored as object paths and opened through short-lived signed URLs.
- Member can report an active officer as the subject of a complaint; that officer is excluded from automatic assignment/handling.
- Complaint registration now uses the authenticated member profile as the authoritative geography.
- Added `तकनीकी / डिजिटल` category and category-aware specialist tie-breaking for auto-routing.
- Added formal next-authority/consult guidance.
- Added member-only resolution confirmation/closure and member reopen flow.
- Officer UI offers a Close Complaint action after RESOLVED; backend authorization and status checks remain the security boundary. Member can close after resolution and can reopen with a reason.
- Added authorized priority management: LOW/NORMAL/HIGH/URGENT with audit event.
- Backfilled SLA for existing open complaints and added SLA breach processing/notifications.
- Complaint history is append-only at database trigger level.
- Complaint mutation/reporting RPCs are authenticated-only; PUBLIC/anon execute is revoked.
- Officer complaint dashboard invokes SLA processing so overdue assigned complaints are detected when management is opened.

## Validation

- `node --check app.js` PASS
- `npm run build` PASS
- `scripts/verify-rkms-final.py` PASS
- `scripts/verify-authority-hierarchy.py` PASS
- `scripts/verify-directory-lists.py` PASS
- Live private complaint bucket verified: `rkms-complaints`, public=false, 10 MB limit.
- Live existing open complaint SLA backfill verified.

## Important packaging note

This ZIP is the corrected web/source package. The original packaging intentionally excludes `android/`, `.github/`, `node_modules/`, and `dist/`; Android/APK generation therefore remains a separate native build step from the original repository/build context.
