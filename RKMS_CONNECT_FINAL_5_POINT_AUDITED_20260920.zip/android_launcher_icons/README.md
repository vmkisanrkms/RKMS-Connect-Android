# RKMS original Android launcher icon

The launcher icon uses the original RKMS transparent logo only. No CONNECT text is added to the artwork.
These pre-generated resources are copied into the generated Capacitor Android project by `scripts/setup-android-native.sh`.


Final launcher policy: use the exact legacy RKMS raster icon from ic_launcher.png. Do not use adaptive foreground/icon XML; this preserves the Debug APK appearance and avoids Android mask zoom/cropping.
