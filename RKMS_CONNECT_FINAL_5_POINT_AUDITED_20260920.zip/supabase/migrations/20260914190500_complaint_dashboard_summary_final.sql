create or replace function public.rkms_get_complaint_summary(p_officer_id uuid) returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog as $function$
declare v_officer uuid:=public.rkms_current_officer_id(); v_admin uuid:=public.rkms_current_super_admin_id(); v_total bigint; v_received bigint; v_assigned bigint; v_under_review bigint; v_need_info bigint; v_in_progress bigint; v_action bigint; v_resolved bigint; v_closed bigint; v_reopened bigint; v_rejected bigint;
begin
 if v_admin is null then
   if v_officer is null then return jsonb_build_object('success',false,'message','ACTIVE और authenticated officer नहीं मिला।'); end if;
   if p_officer_id is not null and p_officer_id<>v_officer then return jsonb_build_object('success',false,'message','दिए गए officer ID और authenticated officer अलग हैं।'); end if;
 else v_officer:=null; end if;
 if v_admin is not null then
   select count(*),count(*) filter(where status='RECEIVED'),count(*) filter(where status='ASSIGNED'),count(*) filter(where status='UNDER_REVIEW'),count(*) filter(where status='NEED_INFORMATION'),count(*) filter(where status='IN_PROGRESS'),count(*) filter(where status='ACTION_TAKEN'),count(*) filter(where status='RESOLVED'),count(*) filter(where status='CLOSED'),count(*) filter(where status='REOPENED'),count(*) filter(where status='REJECTED') into v_total,v_received,v_assigned,v_under_review,v_need_info,v_in_progress,v_action,v_resolved,v_closed,v_reopened,v_rejected from public.rkms_complaints;
 else
   select count(*),count(*) filter(where c.status='RECEIVED'),count(*) filter(where c.status='ASSIGNED'),count(*) filter(where c.status='UNDER_REVIEW'),count(*) filter(where c.status='NEED_INFORMATION'),count(*) filter(where c.status='IN_PROGRESS'),count(*) filter(where c.status='ACTION_TAKEN'),count(*) filter(where c.status='RESOLVED'),count(*) filter(where c.status='CLOSED'),count(*) filter(where c.status='REOPENED'),count(*) filter(where c.status='REJECTED') into v_total,v_received,v_assigned,v_under_review,v_need_info,v_in_progress,v_action,v_resolved,v_closed,v_reopened,v_rejected from public.rkms_complaints c where (public.rkms_can_handle_complaint(c.id,v_officer)->>'allowed')='true';
 end if;
 return jsonb_build_object('success',true,'total',v_total,'received',v_received,'assigned',v_assigned,'under_review',v_under_review,'need_information',v_need_info,'in_progress',v_in_progress,'action_taken',v_action,'resolved',v_resolved,'closed',v_closed,'reopened',v_reopened,'rejected',v_rejected,'pending',v_received+v_assigned+v_under_review+v_need_info+v_in_progress+v_action+v_reopened);
end;$function$;

create or replace function public.rkms_get_current_officer_complaint_summary() returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog as $function$
begin return public.rkms_get_complaint_summary(public.rkms_current_officer_id()); end;$function$;

create or replace function public.rkms_get_current_officer_complaints() returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog as $function$
begin return public.rkms_get_my_complaints(public.rkms_current_officer_id()); end;$function$;
