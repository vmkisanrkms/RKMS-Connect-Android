-- Keep complaint hardening RPCs authenticated-only; PUBLIC execute would also expose them to anon.
revoke execute on function public.rkms_register_complaint_final(uuid,text,text,text,text,text,text,text,text,text,text,text,uuid) from public;
revoke execute on function public.rkms_member_close_complaint(uuid,text) from public;
revoke execute on function public.rkms_member_reopen_complaint(uuid,text) from public;
revoke execute on function public.rkms_set_complaint_priority(uuid,text,text) from public;
revoke execute on function public.rkms_process_complaint_sla() from public;
revoke execute on function public.rkms_get_member_complaint_reportable_officers() from public;
revoke execute on function public.rkms_get_complaint_next_authority(uuid) from public;
