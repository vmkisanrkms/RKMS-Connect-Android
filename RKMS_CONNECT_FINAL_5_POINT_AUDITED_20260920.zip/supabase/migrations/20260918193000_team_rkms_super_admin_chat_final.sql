-- Team RKMS / Super Admin personal-chat identity final fix
-- Idempotently ensure the active SUPER_ADMIN has a dedicated approved chat identity.
insert into public.rkms_members (
  member_id, auth_user_id, name, mobile, status, membership_type, username
)
select 'A94473', a.auth_user_id, 'Team RKMS', '0000000000', 'APPROVED', 'GENERAL', 'team_rkms'
from public.rkms_admins a
where a.role='SUPER_ADMIN'
  and a.status='ACTIVE'
  and not exists (select 1 from public.rkms_members m where m.username='team_rkms')
  and not exists (select 1 from public.rkms_members m where m.member_id='A94473');

-- Make the Super Admin's Team RKMS chat identity resolvable by the
-- personal-chat functions.
create or replace function public.rkms_chat_current_person_member_id()
returns uuid
language sql
stable security definer
set search_path to 'public','pg_catalog'
as $function$
  select coalesce(
    (
      select m.id
      from public.rkms_members m
      where m.auth_user_id=auth.uid()
        and upper(coalesce(m.status,''))='APPROVED'
      order by case when lower(coalesce(m.username,''))='team_rkms' then 0 else 1 end,
               m.created_at desc
      limit 1
    ),
    (
      select m.id
      from public.rkms_members m
      join public.rkms_admins a on a.auth_user_id=m.auth_user_id
      where a.auth_user_id=auth.uid()
        and a.role='SUPER_ADMIN'
        and a.status='ACTIVE'
        and upper(coalesce(m.status,''))='APPROVED'
      order by case when lower(coalesce(m.username,''))='team_rkms' then 0 else 1 end,
               m.created_at desc
      limit 1
    )
  )
$function$;

grant execute on function public.rkms_chat_current_person_member_id() to authenticated;
