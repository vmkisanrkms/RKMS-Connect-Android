do $$
declare r record; v_assignee uuid; v_now timestamptz:=now();
begin
 for r in select id,complaint_id,status from public.rkms_complaints where assigned_to is null and status not in ('CLOSED','REJECTED') loop
   v_assignee:=public.rkms_select_complaint_officer(r.id);
   if v_assignee is not null then
     update public.rkms_complaints set assigned_to=v_assignee,assigned_at=coalesce(assigned_at,v_now),updated_at=v_now where id=r.id;
     insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_to,metadata)
     values(r.id,r.status,r.status,'Existing complaint automatically routed to the nearest eligible active officer.',v_assignee,v_now,'ASSIGNMENT_BACKFILL',null,v_assignee,jsonb_build_object('automatic',true,'backfill',true));
     insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
     select 'लंबित शिकायत आपको सौंपी गई','शिकायत '||r.complaint_id||' आपके अधिकार क्षेत्र में कार्रवाई के लिए सौंपी गई है।','COMPLAINT_ASSIGNED','MEMBER',m.id::text,true,false,null,'ALL'
     from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=v_assignee limit 1;
   end if;
 end loop;
end $$;
