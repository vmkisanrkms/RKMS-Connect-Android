-- RKMS CONNECT FINAL: member self-service profile updates.
-- Adds member signature storage and a tightly scoped self-update RPC.
alter table public.rkms_members
  add column if not exists signature_url text;

create or replace function public.rkms_update_member_self(p_data jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $$
declare
  v_member_id uuid;
  v_auth uuid:=auth.uid();
  v_mobile text:=nullif(regexp_replace(coalesce(p_data->>'mobile',''),'[^0-9]','','g'),'');
  v_whatsapp text:=nullif(regexp_replace(coalesce(p_data->>'whatsapp',''),'[^0-9]','','g'),'');
  v_email text:=nullif(lower(trim(coalesce(p_data->>'email',''))),'');
  v_address text:=nullif(trim(coalesce(p_data->>'address','')), '');
  v_photo text:=nullif(trim(coalesce(p_data->>'photo_url','')), '');
  v_signature text:=nullif(trim(coalesce(p_data->>'signature_url','')), '');
  v_member public.rkms_members%rowtype;
begin
  if v_auth is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  select id into v_member_id
  from public.rkms_members
  where auth_user_id=v_auth
  order by created_at desc nulls last
  limit 1;

  if v_member_id is null then
    return jsonb_build_object('success',false,'message','आपका member profile नहीं मिला।');
  end if;

  if v_mobile is not null then
    if length(v_mobile)=12 and left(v_mobile,2)='91' then v_mobile:=right(v_mobile,10); end if;
    if length(v_mobile)<>10 or left(v_mobile,1) not in ('6','7','8','9') then
      return jsonb_build_object('success',false,'message','मान्य 10 अंकों का मोबाइल नंबर दर्ज करें।');
    end if;
    if exists(select 1 from public.rkms_members where mobile=v_mobile and id<>v_member_id) then
      return jsonb_build_object('success',false,'message','यह मोबाइल नंबर किसी दूसरे सदस्य के पास पहले से है।');
    end if;
  end if;

  if v_whatsapp is not null then
    if length(v_whatsapp)=12 and left(v_whatsapp,2)='91' then v_whatsapp:=right(v_whatsapp,10); end if;
    if length(v_whatsapp)<>10 or left(v_whatsapp,1) not in ('6','7','8','9') then
      return jsonb_build_object('success',false,'message','मान्य 10 अंकों का WhatsApp नंबर दर्ज करें।');
    end if;
  end if;

  if v_email is not null and v_email !~* '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' then
    return jsonb_build_object('success',false,'message','मान्य ईमेल दर्ज करें।');
  end if;

  if v_photo is not null and length(v_photo)>1200 then
    return jsonb_build_object('success',false,'message','फोटो URL बहुत लंबा है।');
  end if;
  if v_signature is not null and length(v_signature)>1200 then
    return jsonb_build_object('success',false,'message','हस्ताक्षर URL बहुत लंबा है।');
  end if;
  if v_photo is not null and v_photo !~* '^https?://' then
    return jsonb_build_object('success',false,'message','फोटो का मान्य URL आवश्यक है।');
  end if;
  if v_signature is not null and v_signature !~* '^https?://' then
    return jsonb_build_object('success',false,'message','हस्ताक्षर का मान्य URL आवश्यक है।');
  end if;

  update public.rkms_members
  set mobile=coalesce(v_mobile,mobile),
      mobile_verified=case when v_mobile is distinct from mobile then false else mobile_verified end,
      whatsapp=coalesce(v_whatsapp,whatsapp),
      email=coalesce(v_email,email),
      address=coalesce(v_address,address),
      photo_url=coalesce(v_photo,photo_url),
      signature_url=coalesce(v_signature,signature_url),
      updated_at=now()
  where id=v_member_id
  returning * into v_member;

  return jsonb_build_object(
    'success',true,
    'message','प्रोफ़ाइल सफलतापूर्वक अपडेट हो गई।',
    'member',jsonb_build_object(
      'id',v_member.id,
      'member_id',v_member.member_id,
      'auth_user_id',v_member.auth_user_id,
      'name',v_member.name,
      'father_name',v_member.father_name,
      'mobile',v_member.mobile,
      'whatsapp',v_member.whatsapp,
      'email',v_member.email,
      'address',v_member.address,
      'photo_url',v_member.photo_url,
      'signature_url',v_member.signature_url,
      'status',v_member.status,
      'state',v_member.state,
      'mandal',v_member.mandal,
      'district',v_member.district,
      'tehsil',v_member.tehsil,
      'block',v_member.block,
      'village',v_member.village,
      'gram_panchayat',v_member.gram_panchayat
    )
  );
end;
$$;

grant execute on function public.rkms_update_member_self(jsonb) to authenticated;
