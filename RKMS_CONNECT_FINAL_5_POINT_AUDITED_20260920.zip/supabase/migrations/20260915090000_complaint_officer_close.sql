-- RKMS CONNECT: authorized PDA/officer complaint closure.
-- Officers may close only RESOLVED complaints they are authorized to handle.
-- Accused officers remain blocked by rkms_can_handle_complaint().

create or replace function public.rkms_officer_close_complaint(p_complaint_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_catalog
as $function$
declare
  v_actor uuid:=public.rkms_current_officer_id();
  v_admin uuid:=public.rkms_current_super_admin_id();
  v_check jsonb;
  v_old text;
  v_code text;
  v_assigned uuid;
  v_now timestamptz:=now();
begin
  if v_actor is null and v_admin is null then
    return jsonb_build_object('success',false,'message','केवल अधिकृत PDA अधिकारी या Super Admin शिकायत बंद कर सकता है।');
  end if;

  select status,complaint_id,assigned_to into v_old,v_code,v_assigned
  from public.rkms_complaints where id=p_complaint_id for update;

  if v_old is null then
    return jsonb_build_object('success',false,'message','Complaint नहीं मिली।');
  end if;

  if v_admin is null then
    v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor);
    if coalesce((v_check->>'allowed')::boolean,false)=false then
      return jsonb_build_object('success',false,'message','इस complaint को बंद करने की अनुमति नहीं है।','authorization',v_check);
    end if;
  end if;

  if v_old<>'RESOLVED' then
    return jsonb_build_object('success',false,'message','केवल RESOLVED complaint को बंद किया जा सकता है। पहले समाधान दर्ज करें।');
  end if;

  perform set_config('rkms.member_transition','1',true);
  update public.rkms_complaints
  set status='CLOSED',closed_at=v_now,updated_at=v_now
  where id=p_complaint_id;

  insert into public.rkms_complaint_history(
    complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata
  ) values (
    p_complaint_id,'RESOLVED','CLOSED','अधिकृत PDA अधिकारी द्वारा शिकायत बंद की गई।',v_actor,v_now,'OFFICER_CLOSURE',auth.uid(),v_assigned,v_assigned,
    jsonb_build_object('closure_actor','OFFICER','officer_id',v_actor,'super_admin',v_admin is not null)
  );

  insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
  select 'शिकायत बंद कर दी गई','शिकायत '||v_code||' अधिकृत अधिकारी द्वारा बंद कर दी गई है।','COMPLAINT_CLOSED','MEMBER',c.member_id::text,true,false,auth.uid(),'ALL'
  from public.rkms_complaints c where c.id=p_complaint_id;

  return jsonb_build_object('success',true,'message','Complaint successfully closed.','complaint_id',v_code,'status','CLOSED');
end;
$function$;

revoke all on function public.rkms_officer_close_complaint(uuid) from public,anon;
grant execute on function public.rkms_officer_close_complaint(uuid) to authenticated;
