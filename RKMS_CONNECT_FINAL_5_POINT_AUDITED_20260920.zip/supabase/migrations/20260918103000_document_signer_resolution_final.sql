-- Final signer resolution for Digital ID, Appointment Letter and Membership Certificate.
-- Never fabricates a signature: the signature URL is returned only when an
-- authorised officer has actually uploaded one.

create or replace function public.rkms_get_membership_approval_signer(p_member_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to public, pg_catalog
as $function$
declare
  m public.rkms_members%rowtype;
  o public.rkms_officers%rowtype;
  p public.rkms_posts%rowtype;
  approver_member public.rkms_members%rowtype;
  current_officer uuid;
  v_post text;
  v_name text;
begin
  select * into m from public.rkms_members where id=p_member_id limit 1;
  if not found then return jsonb_build_object('success',false,'error','Member not found'); end if;
  if auth.uid() is null then return jsonb_build_object('success',false,'error','Authentication required'); end if;

  if m.auth_user_id is distinct from auth.uid()
     and not public.rkms_is_super_admin()
     and not public.rkms_is_national_president_current() then
    current_officer:=public.rkms_current_officer_id();
    if current_officer is null or not public.rkms_officer_scope_matches_member(current_officer,p_member_id) then
      return jsonb_build_object('success',false,'error','Not authorized');
    end if;
  end if;

  if upper(coalesce(m.approval_authority_type,''))='NATIONAL_PRESIDENT'
     or m.approved_by_super_admin_id is not null then
    return jsonb_build_object(
      'success',true,
      'approver_authority_type','NATIONAL_PRESIDENT',
      'approver_officer_id',null,
      'approver_name','',
      'approver_post','अध्यक्ष',
      'approver_signature_url',''
    );
  end if;

  if m.approved_by is null then
    return jsonb_build_object('success',true,'approver_authority_type','OFFICER',
      'approver_officer_id',null,'approver_name','','approver_post','','approver_signature_url','');
  end if;

  select * into o from public.rkms_officers where id=m.approved_by limit 1;
  if not found then
    return jsonb_build_object('success',true,'approver_authority_type','OFFICER',
      'approver_officer_id',m.approved_by,'approver_name','','approver_post','','approver_signature_url','');
  end if;

  select * into approver_member from public.rkms_members where id=o.member_id limit 1;
  if o.post_id is not null then select * into p from public.rkms_posts where id=o.post_id limit 1; end if;

  v_post:=coalesce(p.post_name,'');
  if upper(coalesce(o.authority_level,''))='NATIONAL'
     or lower(trim(coalesce(v_post,''))) in ('राष्ट्रीय अध्यक्ष','national president') then
    v_post:='अध्यक्ष';
  end if;

  v_name:=coalesce(
    nullif(trim(approver_member.name),''),
    nullif(trim(o.signature_name),''),
    nullif(trim(o.appointing_authority_name),'')
  ,'');

  return jsonb_build_object(
    'success',true,
    'approver_authority_type','OFFICER',
    'approver_officer_id',o.id,
    'approver_name',v_name,
    'approver_post',v_post,
    'approver_signature_url',coalesce(o.signature_url,'')
  );
end;
$function$;

-- Keep Digital ID's existing secure authorization and signer model, but make
-- the officer-name fallback authoritative from the linked member record.
create or replace function public.rkms_get_digital_id_meta(p_member_id uuid)
returns jsonb
language plpgsql
stable security definer
set search_path to public, pg_catalog
as $function$
declare
  v_member_id uuid;
  v_national_name text;
  v_national_post text;
  v_national_signature text;
  v_appointed_by uuid;
  v_appointing_authority text;
  v_authority_norm text;
  v_appointed_name text;
  v_appointed_post text;
  v_appointed_signature text;
  v_appointed_level text;
begin
  v_member_id:=public.rkms_current_member_id();
  if v_member_id is null or p_member_id<>v_member_id then
    return jsonb_build_object('success',false,'message','इस member की Digital ID देखने की अनुमति नहीं है।');
  end if;

  select coalesce(l.name,'श्री V. M. Singh'),coalesce(l.post_name,'राष्ट्रीय अध्यक्ष')
    into v_national_name,v_national_post
  from public.rkms_leadership l
  where upper(coalesce(l.level,''))='NATIONAL'
    and upper(coalesce(l.status,'ACTIVE'))='ACTIVE'
  order by l.display_order nulls last,l.created_at asc limit 1;

  select o.signature_url into v_national_signature
  from public.rkms_officers o left join public.rkms_posts p on p.id=o.post_id
  where o.status='ACTIVE'
    and upper(coalesce(o.authority_level,p.level,''))='NATIONAL'
    and nullif(trim(coalesce(o.signature_url,'')),'') is not null
  order by o.created_at desc limit 1;

  select o.appointed_by_officer_id,o.appointing_authority_name
    into v_appointed_by,v_appointing_authority
  from public.rkms_officers o
  where o.member_id=v_member_id and o.status='ACTIVE'
    and (o.valid_from is null or o.valid_from<=current_date)
    and (o.valid_to is null or o.valid_to>=current_date)
  order by o.created_at desc limit 1;

  if v_appointed_by is not null then
    select m.name,p.post_name,o.signature_url,upper(coalesce(o.authority_level,p.level,''))
      into v_appointed_name,v_appointed_post,v_appointed_signature,v_appointed_level
    from public.rkms_officers o
    join public.rkms_members m on m.id=o.member_id
    left join public.rkms_posts p on p.id=o.post_id
    where o.id=v_appointed_by;
  end if;

  v_authority_norm:=lower(trim(coalesce(v_appointing_authority,'')));
  v_authority_norm:=regexp_replace(v_authority_norm,'(श्री|श्रीमती|सुश्री|कुमारी|जी|shri|sri|mr|mrs|ms|miss|ji)',' ','gi');
  v_authority_norm:=regexp_replace(v_authority_norm,'[[:punct:]]+',' ','g');
  v_authority_norm:=regexp_replace(v_authority_norm,'\s+',' ','g');
  v_authority_norm:=trim(v_authority_norm);

  if upper(coalesce(v_appointed_level,'')) in ('NATIONAL','NATIONAL_PRESIDENT')
     or lower(trim(coalesce(v_appointed_post,''))) in ('राष्ट्रीय अध्यक्ष','national president')
     or lower(trim(coalesce(v_appointing_authority,''))) in ('राष्ट्रीय अध्यक्ष','national president','super admin','super_admin') then
    return jsonb_build_object('success',true,
      'national_president_name',coalesce(v_national_name,'श्री V. M. Singh'),
      'national_president_post',coalesce(v_national_post,'राष्ट्रीय अध्यक्ष'),
      'national_president_signature_url',coalesce(v_national_signature,''),
      'appointing_officer_name','',
      'appointing_officer_post','',
      'appointing_officer_signature_url','',
      'appointing_authority_name',coalesce(v_appointing_authority,'राष्ट्रीय अध्यक्ष'),
      'appointment_authority_type','NATIONAL_PRESIDENT');
  end if;

  if (v_appointed_by is null or v_appointed_name is null or trim(v_appointed_name)='')
     and v_authority_norm not in ('','राष्ट्रीय अध्यक्ष','national president','super admin','super_admin') then
    select o.id,m.name,p.post_name,o.signature_url
      into v_appointed_by,v_appointed_name,v_appointed_post,v_appointed_signature
    from public.rkms_officers o
    join public.rkms_members m on m.id=o.member_id
    left join public.rkms_posts p on p.id=o.post_id
    cross join lateral (
      select trim(regexp_replace(regexp_replace(lower(coalesce(m.name,'')),
        '(श्री|श्रीमती|सुश्री|कुमारी|जी|shri|sri|mr|mrs|ms|miss|ji)',' ','gi'),'\s+',' ','g')) as member_name_norm
    ) n
    where n.member_name_norm<>''
      and (n.member_name_norm=v_authority_norm
       or v_authority_norm like '%'||n.member_name_norm||'%'
       or n.member_name_norm like '%'||v_authority_norm||'%')
    order by case when nullif(trim(coalesce(o.signature_url,'')),'') is not null then 0 else 1 end,
             case when o.status='ACTIVE' then 0 else 1 end,
             o.created_at desc limit 1;
  end if;

  return jsonb_build_object('success',true,
    'national_president_name',coalesce(v_national_name,'श्री V. M. Singh'),
    'national_president_post',coalesce(v_national_post,'राष्ट्रीय अध्यक्ष'),
    'national_president_signature_url',coalesce(v_national_signature,''),
    'appointing_officer_name',coalesce(v_appointed_name,''),
    'appointing_officer_post',coalesce(v_appointed_post,''),
    'appointing_officer_signature_url',coalesce(v_appointed_signature,''),
    'appointing_authority_name',coalesce(v_appointing_authority,''),
    'appointment_authority_type',case when v_appointed_by is not null then 'OFFICER' else 'NONE' end);
end;
$function$;
