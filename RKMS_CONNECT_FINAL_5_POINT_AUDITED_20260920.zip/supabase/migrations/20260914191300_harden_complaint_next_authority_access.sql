-- Prevent arbitrary authenticated users from using the complaint next-authority
-- RPC as an IDOR/data-disclosure endpoint. Only the complaint member, an
-- authorized handler/higher officer, or Super Admin may inspect it.
create or replace function public.rkms_get_complaint_next_authority(p_complaint_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare
  c record;
  v_assigned_level text;
  v_next_level text;
  v_hint text;
  v_data jsonb;
  v_member uuid:=public.rkms_current_member_id();
  v_officer uuid:=public.rkms_current_officer_id();
  v_admin uuid:=public.rkms_current_super_admin_id();
  v_allowed boolean:=false;
begin
  select * into c from public.rkms_complaints where id=p_complaint_id;
  if not found then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
  v_allowed := v_admin is not null or (v_member is not null and c.member_id=v_member) or (v_officer is not null and coalesce((public.rkms_can_handle_complaint(c.id,v_officer)->>'allowed')::boolean,false));
  if not v_allowed then return jsonb_build_object('success',false,'message','इस complaint की authority guidance देखने की अनुमति नहीं है।'); end if;
  select upper(authority_level) into v_assigned_level from public.rkms_officers where id=c.assigned_to;
  v_next_level:=case v_assigned_level when 'BLOCK' then 'TEHSIL' when 'TEHSIL' then 'DISTRICT' when 'DISTRICT' then 'MANDAL' when 'MANDAL' then 'STATE' when 'STATE' then 'NATIONAL' else 'NATIONAL' end;
  v_hint:=case when c.category='पदाधिकारी / प्रशासन' then 'संगठन/प्रशासन से जुड़े विषय में अगले स्तर के अध्यक्ष/प्रशासनिक अधिकारी से परामर्श करें।' when c.category='भूमि / किसान' then 'भूमि/किसान विषय में संबंधित किसान/भूमि विशेषज्ञ wing से परामर्श लें।' when c.category='भुगतान / आर्थिक' then 'भुगतान/आर्थिक विषय में संबंधित कोष/वित्त जिम्मेदार अधिकारी से परामर्श लें।' when c.category='सदस्यता / संगठन' then 'सदस्यता/संगठन विषय में संगठन प्रभारी से परामर्श लें।' else 'विषय के अनुसार संबंधित विशेषज्ञ/उच्च अधिकारी से परामर्श लें।' end;
  select coalesce(jsonb_agg(jsonb_build_object('officer_id',o.id,'name',m.name,'post_name',p.post_name,'authority_level',o.authority_level) order by o.created_at),'[]'::jsonb) into v_data
  from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
  where o.status='ACTIVE' and upper(o.authority_level)=v_next_level
    and (upper(o.authority_level)='NATIONAL' or lower(coalesce(o.state,''))=lower(coalesce(c.state,'')))
    and (v_next_level in ('NATIONAL','STATE') or lower(coalesce(o.mandal,''))=lower(coalesce(c.mandal,'')))
    and (v_next_level in ('NATIONAL','STATE','MANDAL') or lower(coalesce(o.district,''))=lower(coalesce(c.district,'')))
    and (v_next_level in ('NATIONAL','STATE','MANDAL','DISTRICT') or lower(coalesce(o.tehsil,''))=lower(coalesce(c.tehsil,'')))
    and (v_next_level in ('NATIONAL','STATE','MANDAL','DISTRICT','TEHSIL') or lower(coalesce(o.block,''))=lower(coalesce(c.block,'')))
    and (c.against_officer_id is null or o.id<>c.against_officer_id);
  return jsonb_build_object('success',true,'next_authority_level',v_next_level,'guidance',v_hint,'officers',v_data);
end;$function$;
revoke execute on function public.rkms_get_complaint_next_authority(uuid) from public;
grant execute on function public.rkms_get_complaint_next_authority(uuid) to authenticated;
