do $$
declare v_def text;
begin
 select pg_get_functiondef(p.oid) into v_def from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='rkms_update_complaint' and p.pronargs=7 limit 1;
 if v_def is null then raise exception 'rkms_update_complaint not found'; end if;
 v_def:=replace(v_def,'v_check jsonb; v_assignee_check jsonb; v_new_assignee uuid; v_event text;','v_check jsonb; v_assignee_check jsonb; v_new_assignee uuid; v_event text; v_actor_level text; v_assigned_level text;');
 v_def:=replace(v_def,$old$if v_admin is null then v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor_officer); if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को update करने की अनुमति नहीं है।','authorization',v_check); end if; end if;$old$,$new$if v_admin is null then
   v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor_officer);
   if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को update करने की अनुमति नहीं है।','authorization',v_check); end if;
   select upper(authority_level) into v_actor_level from public.rkms_officers where id=v_actor_officer;
   select upper(o.authority_level) into v_assigned_level from public.rkms_officers o where o.id=v_assigned;
   if v_assigned is not null and v_assigned<>v_actor_officer and public.rkms_level_rank(v_actor_level)<=public.rkms_level_rank(v_assigned_level) then
     return jsonb_build_object('success',false,'message','वर्तमान जिम्मेदार officer या उससे उच्च authority ही status बदल सकती है।');
   end if;
 end if;$new$);
 execute v_def;
end $$;
