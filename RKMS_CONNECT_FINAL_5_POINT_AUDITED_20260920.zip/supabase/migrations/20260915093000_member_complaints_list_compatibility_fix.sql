-- RKMS CONNECT: member complaint list compatibility endpoint.
-- Uses the authenticated member identity server-side and requires no RPC arguments.
-- This avoids client-side dependency on named/default RPC parameters while preserving security.

create or replace function public.rkms_get_member_complaints_compat()
returns jsonb
language plpgsql
stable
security definer
set search_path=public,pg_catalog
as $function$
declare
  v_member_id uuid;
  v_data jsonb;
begin
  v_member_id:=public.rkms_current_member_id();
  if v_member_id is null then
    return jsonb_build_object('success',false,'message','Current authenticated member नहीं मिला।','data','[]'::jsonb);
  end if;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id',c.id,
      'complaint_id',c.complaint_id,
      'member_id',c.member_id,
      'name',c.name,
      'mobile',c.mobile,
      'state',c.state,
      'mandal',c.mandal,
      'district',c.district,
      'tehsil',c.tehsil,
      'block',c.block,
      'village',c.village,
      'category',c.category,
      'subject',c.subject,
      'description',c.description,
      'photo_url',c.photo_url,
      'document_url',c.document_url,
      'status',c.status,
      'assigned_to',c.assigned_to,
      'action_taken',c.action_taken,
      'resolution',c.resolution,
      'created_at',c.created_at,
      'updated_at',c.updated_at
    ) order by c.created_at desc
  ),'[]'::jsonb)
  into v_data
  from public.rkms_complaints c
  where c.member_id=v_member_id;

  return jsonb_build_object('success',true,'count',jsonb_array_length(v_data),'data',v_data);
end;
$function$;

revoke all on function public.rkms_get_member_complaints_compat() from public,anon;
grant execute on function public.rkms_get_member_complaints_compat() to authenticated;
