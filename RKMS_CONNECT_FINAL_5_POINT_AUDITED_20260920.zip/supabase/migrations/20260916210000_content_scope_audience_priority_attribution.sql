-- Final content rules: Flash top-authority only; Events follow geographic hierarchy; notifications keep audience/priority.
create or replace function public.rkms_event_scope_allowed(p_target_type text,p_state text,p_mandal text,p_district text,p_tehsil text,p_block text,p_village text)
returns boolean language plpgsql stable security definer set search_path to 'public','pg_catalog' as $$
declare s jsonb; lvl text; st text; ma text; di text; te text; bl text; vi text; tgt text;
begin
 if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then return upper(coalesce(p_target_type,'ALL'))='ALL'; end if;
 s:=public.rkms_content_scope_json(); lvl:=upper(coalesce(s->>'authority_level','')); st:=s->>'state'; ma:=s->>'mandal'; di:=s->>'district'; te:=s->>'tehsil'; bl:=s->>'block'; vi:=s->>'village'; tgt:=upper(coalesce(nullif(trim(p_target_type),''),'ALL'));
 if tgt='ALL' then return false; end if;
 if lvl='STATE' then return tgt in ('STATE','DISTRICT','TEHSIL','BLOCK','VILLAGE') and lower(coalesce(p_state,''))=lower(coalesce(st,'')); end if;
 if lower(coalesce(p_state,''))<>lower(coalesce(st,'')) then return false; end if;
 if lvl='MANDAL' then return tgt in ('MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') and lower(coalesce(p_mandal,''))=lower(coalesce(ma,'')); end if;
 if lower(coalesce(p_mandal,''))<>lower(coalesce(ma,'')) then return false; end if;
 if lvl='DISTRICT' then return tgt in ('DISTRICT','TEHSIL','BLOCK','VILLAGE') and lower(coalesce(p_district,''))=lower(coalesce(di,'')); end if;
 if lower(coalesce(p_district,''))<>lower(coalesce(di,'')) then return false; end if;
 if lvl='TEHSIL' then return tgt in ('TEHSIL','BLOCK','VILLAGE') and lower(coalesce(p_tehsil,''))=lower(coalesce(te,'')); end if;
 if lower(coalesce(p_tehsil,''))<>lower(coalesce(te,'')) then return false; end if;
 if lvl='BLOCK' then return tgt in ('BLOCK','VILLAGE') and lower(coalesce(p_block,''))=lower(coalesce(bl,'')); end if;
 if lvl='VILLAGE' then return tgt='VILLAGE' and lower(coalesce(p_village,''))=lower(coalesce(vi,'')); end if;
 return false;
end; $$;

create or replace function public.rkms_can_manage_content(p_content_type text,p_action text default 'MANAGE') returns boolean language plpgsql security definer set search_path to 'public','pg_catalog' as $$
declare v_officer uuid; v_type text:=lower(trim(coalesce(p_content_type,''))); v_np boolean:=false; v_sp boolean:=false;
begin
 if public.rkms_current_super_admin_id() is not null then return v_type in ('events','news','flash','gallery','documents'); end if;
 if v_type not in ('events','news','flash','gallery','documents') then return false; end if;
 v_officer:=public.rkms_current_officer_id(); if v_officer is null then return false; end if;
 select exists(select 1 from public.rkms_officers o left join public.rkms_posts p on p.id=o.post_id where o.id=v_officer and (upper(coalesce(o.authority_level,''))='NATIONAL' or lower(coalesce(p.post_name,'')) like '%राष्ट्रीय अध्यक्ष%')) into v_np;
 if v_np then return true; end if;
 if v_type='flash' then return false; end if;
 select exists(select 1 from public.rkms_officers o join public.rkms_posts p on p.id=o.post_id where o.id=v_officer and upper(coalesce(o.status,''))='ACTIVE' and upper(coalesce(o.authority_level,''))='STATE' and lower(coalesce(p.post_name,'')) like '%प्रदेश अध्यक्ष%' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date)) into v_sp;
 if v_sp then return true; end if;
 return exists(select 1 from public.rkms_content_permissions p where p.officer_id=v_officer and p.content_type=v_type and p.can_manage=true);
end; $$;

create or replace function public.rkms_manage_events(p_action text,p_id uuid default null,p_data jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path to 'public','pg_catalog' as $$
declare v_actor uuid; v_id uuid; s jsonb; lvl text; st text; ma text; di text; te text; bl text; vi text; tgt text; ts text; tm text; td text; tt text; tb text; tv text;
begin
 if upper(p_action) in ('UPDATE','DELETE') then if not public.rkms_content_scope_allowed('events',p_action,p_id) then return jsonb_build_object('success',false,'message','कार्यक्रम पर अधिकार नहीं है।'); end if; elsif not public.rkms_can_manage_content('events',p_action) then return jsonb_build_object('success',false,'message','कार्यक्रम पर अधिकार नहीं है।'); end if;
 v_actor:=coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id()); s:=public.rkms_content_scope_json(); lvl:=upper(coalesce(s->>'authority_level','')); st:=s->>'state'; ma:=s->>'mandal'; di:=s->>'district'; te:=s->>'tehsil'; bl:=s->>'block'; vi:=s->>'village';
 tgt:=upper(coalesce(nullif(trim(p_data->>'target_type'),''),case when public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then 'ALL' else lvl end)); ts:=nullif(trim(p_data->>'target_state'),''); tm:=nullif(trim(p_data->>'target_mandal'),''); td:=nullif(trim(p_data->>'target_district'),''); tt:=nullif(trim(p_data->>'target_tehsil'),''); tb:=nullif(trim(p_data->>'target_block'),''); tv:=nullif(trim(p_data->>'target_village'),'');
 if tgt='ALL' then ts:=null;tm:=null;td:=null;tt:=null;tb:=null;tv:=null; else ts:=coalesce(ts,st); tm:=coalesce(tm,case when tgt in ('MANDAL','DISTRICT','TEHSIL','BLOCK','VILLAGE') then ma end); td:=coalesce(td,case when tgt in ('DISTRICT','TEHSIL','BLOCK','VILLAGE') then di end); tt:=coalesce(tt,case when tgt in ('TEHSIL','BLOCK','VILLAGE') then te end); tb:=coalesce(tb,case when tgt in ('BLOCK','VILLAGE') then bl end); tv:=coalesce(tv,case when tgt='VILLAGE' then vi end); end if;
 if upper(p_action)='CREATE' and not public.rkms_event_scope_allowed(tgt,ts,tm,td,tt,tb,tv) then return jsonb_build_object('success',false,'message','आप केवल अपने अधिकार क्षेत्र में कार्यक्रम डाल सकते हैं।'); end if;
 if upper(p_action)='CREATE' then insert into public.rkms_events(title,description,event_date,event_time,location,state,district,tehsil,block,village,image_url,status,created_by) values(nullif(trim(p_data->>'title'),''),p_data->>'description',(p_data->>'event_date')::date,p_data->>'event_time',p_data->>'location',ts,td,tt,tb,tv,p_data->>'image_url',coalesce(nullif(trim(p_data->>'status'),''),'UPCOMING'),v_actor) returning id into v_id;
 elsif upper(p_action)='UPDATE' then update public.rkms_events set title=coalesce(nullif(trim(p_data->>'title'),''),title),description=coalesce(p_data->>'description',description),event_date=coalesce((p_data->>'event_date')::date,event_date),event_time=coalesce(p_data->>'event_time',event_time),location=coalesce(p_data->>'location',location),image_url=coalesce(p_data->>'image_url',image_url),status=coalesce(p_data->>'status',status),updated_at=now() where id=p_id returning id into v_id;
 elsif upper(p_action)='DELETE' then delete from public.rkms_events where id=p_id returning id into v_id; else return jsonb_build_object('success',false,'message','Invalid action.'); end if;
 return jsonb_build_object('success',v_id is not null,'id',v_id,'action',upper(p_action));
exception when others then return jsonb_build_object('success',false,'message',sqlerrm); end; $$;

create or replace function public.rkms_manage_flash(p_action text,p_id uuid default null,p_data jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path to 'public','pg_catalog' as $$ declare v_actor uuid; v_id uuid; begin if public.rkms_current_super_admin_id() is null and not public.rkms_is_national_president_current() then return jsonb_build_object('success',false,'message','Opening Flash केवल Super Admin या राष्ट्रीय अध्यक्ष जारी कर सकते हैं।'); end if; v_actor:=coalesce(public.rkms_current_super_admin_id(),public.rkms_current_officer_id()); if upper(p_action)='CREATE' then insert into public.rkms_flash_messages(title,body,image_url,start_at,end_at,published,created_by) values(nullif(trim(p_data->>'title'),''),p_data->>'body',p_data->>'image_url',(p_data->>'start_at')::timestamptz,(p_data->>'end_at')::timestamptz,true,v_actor) returning id into v_id; elsif upper(p_action)='UPDATE' then update public.rkms_flash_messages set title=coalesce(p_data->>'title',title),body=coalesce(p_data->>'body',body),image_url=coalesce(p_data->>'image_url',image_url),start_at=coalesce((p_data->>'start_at')::timestamptz,start_at),end_at=coalesce((p_data->>'end_at')::timestamptz,end_at),updated_at=now() where id=p_id returning id into v_id; elsif upper(p_action)='DELETE' then delete from public.rkms_flash_messages where id=p_id returning id into v_id; end if; return jsonb_build_object('success',v_id is not null,'id',v_id,'action',upper(p_action)); exception when others then return jsonb_build_object('success',false,'message',sqlerrm); end; $$;

create or replace function public.rkms_get_notification_attribution(p_id uuid) returns jsonb language sql stable security definer set search_path to 'public','pg_catalog' as $$
select jsonb_build_object('success',true,'publisher_name',coalesce(m.name,o.signature_name,case when o.id is not null then 'अधिकारी' else 'Team' end),'publisher_post',coalesce(p.post_name,case when o.id is null then 'Super Admin' else '' end),'publisher_level',coalesce(o.authority_level,case when o.id is null then 'NATIONAL' else '' end))
from public.rkms_notifications n left join public.rkms_officers o on o.id=n.publisher_officer_id left join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id where n.id=p_id;
$$;

create or replace function public.rkms_guard_court_order_authority() returns trigger language plpgsql security definer set search_path to 'public','pg_catalog' as $$
begin if upper(coalesce(new.category,''))='COURT_ORDER' and public.rkms_current_super_admin_id() is null and not public.rkms_is_national_president_current() then raise exception 'न्यायालय आदेश केवल Super Admin या राष्ट्रीय अध्यक्ष ही जारी कर सकते हैं।'; end if; return new; end; $$;
drop trigger if exists rkms_court_order_authority_guard on public.rkms_documents;
create trigger rkms_court_order_authority_guard before insert or update of category on public.rkms_documents for each row execute function public.rkms_guard_court_order_authority();

create or replace function public.rkms_get_event_attribution(p_id uuid) returns jsonb language sql stable security definer set search_path to 'public','pg_catalog' as $$
select jsonb_build_object('success',true,'publisher_name',coalesce(m.name,o.signature_name,case when o.id is not null then 'अधिकारी' else 'Team' end),'publisher_post',coalesce(p.post_name,case when o.id is null then 'Super Admin' else '' end),'publisher_level',coalesce(o.authority_level,case when o.id is null then 'NATIONAL' else '' end))
from public.rkms_events e left join public.rkms_officers o on o.id=e.created_by left join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id where e.id=p_id;
$$;
