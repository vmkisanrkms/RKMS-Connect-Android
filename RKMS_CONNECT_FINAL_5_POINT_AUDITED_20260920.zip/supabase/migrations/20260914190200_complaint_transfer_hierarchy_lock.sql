do $$
declare v_def text;
begin
 select pg_get_functiondef(p.oid) into v_def from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='rkms_transfer_complaint' and p.pronargs=4 limit 1;
 if v_def is null then raise exception 'rkms_transfer_complaint not found'; end if;
 v_def:=replace(v_def,'v_old uuid; v_old_status text; v_code text; v_now timestamptz:=now(); v_check jsonb;','v_old uuid; v_old_status text; v_code text; v_now timestamptz:=now(); v_check jsonb; v_actor_level text; v_assigned_level text;');
 v_def:=replace(v_def,$old$if v_admin is null then v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor); if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को transfer करने की अनुमति नहीं है।'); end if; end if;$old$,$new$if v_admin is null then
   v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor);
   if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को transfer करने की अनुमति नहीं है।'); end if;
   select upper(authority_level) into v_actor_level from public.rkms_officers where id=v_actor;
   select upper(o.authority_level) into v_assigned_level from public.rkms_officers o where o.id=v_old;
   if v_old is not null and v_old<>v_actor and public.rkms_level_rank(v_actor_level)<=public.rkms_level_rank(v_assigned_level) then
     return jsonb_build_object('success',false,'message','वर्तमान जिम्मेदार officer या उससे उच्च authority ही complaint transfer कर सकती है।');
   end if;
 end if;$new$);
 execute v_def;
end $$;
