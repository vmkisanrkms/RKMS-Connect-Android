-- RKMS CONNECT Complaint Workflow V2 hardening
-- Private evidence, member closure/reopen, conflict reporting, priority, SLA breach, escalation guidance, immutable audit.

alter table public.rkms_complaints
  add column if not exists member_closed_at timestamptz,
  add column if not exists member_reopened_at timestamptz,
  add column if not exists member_feedback text,
  add column if not exists sla_breached_at timestamptz,
  add column if not exists sla_notified_at timestamptz;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('rkms-complaints','rkms-complaints',false,10485760,array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set public=false,file_size_limit=10485760,allowed_mime_types=excluded.allowed_mime_types;

-- Complaint evidence is readable only by the complaint member, its authorized handler/higher authority, or Super Admin.
drop policy if exists rkms_complaint_evidence_read on storage.objects;
create policy rkms_complaint_evidence_read on storage.objects
for select to authenticated
using (
  bucket_id='rkms-complaints'
  and exists (
    select 1 from public.rkms_complaints c
    where (c.photo_url like '%'||name or c.document_url like '%'||name)
      and (
        c.member_id=public.rkms_current_member_id()
        or public.rkms_is_super_admin()
        or (public.rkms_current_officer_id() is not null and coalesce((public.rkms_can_handle_complaint(c.id,public.rkms_current_officer_id())->>'allowed')::boolean,false))
      )
  )
);

drop policy if exists rkms_complaint_evidence_insert on storage.objects;
create policy rkms_complaint_evidence_insert on storage.objects
for insert to authenticated
with check (bucket_id='rkms-complaints' and (storage.foldername(name))[1]='complaints');

drop policy if exists rkms_complaint_evidence_delete on storage.objects;
create policy rkms_complaint_evidence_delete on storage.objects
for delete to authenticated
using (bucket_id='rkms-complaints' and (public.rkms_is_super_admin() or (storage.foldername(name))[2]=auth.uid()::text));

-- Existing public complaint URLs are not changed automatically because they may be historical/public records.
-- New registrations use the private bucket and store the object path, not a public URL.

create or replace function public.rkms_get_member_complaint_reportable_officers()
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare v_member uuid:=public.rkms_current_member_id(); v_state text; v_mandal text; v_district text; v_tehsil text; v_block text; v_data jsonb;
begin
  if v_member is null then return jsonb_build_object('success',false,'message','Current member नहीं मिला।'); end if;
  select state,mandal,district,tehsil,block into v_state,v_mandal,v_district,v_tehsil,v_block from public.rkms_members where id=v_member;
  select coalesce(jsonb_agg(jsonb_build_object('officer_id',o.id,'name',m.name,'post_name',p.post_name,'authority_level',o.authority_level,'state',o.state,'district',o.district,'tehsil',o.tehsil,'block',o.block) order by public.rkms_level_rank(upper(o.authority_level)) asc, o.created_at asc),'[]'::jsonb)
  into v_data
  from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
  where o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date)
    and upper(coalesce(o.authority_level,'')) in ('BLOCK','TEHSIL','DISTRICT','MANDAL','STATE','NATIONAL')
    and (upper(o.authority_level)='NATIONAL' or lower(coalesce(o.state,''))=lower(coalesce(v_state,'')))
    and (upper(o.authority_level) in ('NATIONAL','STATE') or lower(coalesce(o.mandal,''))=lower(coalesce(v_mandal,'')))
    and (upper(o.authority_level) in ('NATIONAL','STATE','MANDAL') or lower(coalesce(o.district,''))=lower(coalesce(v_district,'')))
    and (upper(o.authority_level) in ('NATIONAL','STATE','MANDAL','DISTRICT') or lower(coalesce(o.tehsil,''))=lower(coalesce(v_tehsil,'')))
    and (upper(o.authority_level) in ('NATIONAL','STATE','MANDAL','DISTRICT','TEHSIL') or lower(coalesce(o.block,''))=lower(coalesce(v_block,'')));
  return jsonb_build_object('success',true,'data',v_data);
end;$function$;

grant execute on function public.rkms_get_member_complaint_reportable_officers() to authenticated;
revoke execute on function public.rkms_get_member_complaint_reportable_officers() from anon;

-- New registration RPC with accused-officer support. Old RPC is disabled for clients after this migration.
create or replace function public.rkms_register_complaint_final(
 p_member_id uuid,p_state text,p_mandal text,p_district text,p_tehsil text,p_block text,p_village text,
 p_category text,p_subject text,p_description text,p_photo_path text default null,p_document_path text default null,p_against_officer_id uuid default null
) returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare v_member uuid:=public.rkms_current_member_id(); v_id uuid; v_code text; v_assignee uuid; v_now timestamptz:=now(); v_status text:='RECEIVED'; v_against_ok boolean:=false;
begin
 if v_member is null or p_member_id<>v_member then return jsonb_build_object('success',false,'message','Member verification failed.'); end if;
 if not exists(select 1 from public.rkms_members where id=v_member and status='APPROVED') then return jsonb_build_object('success',false,'message','केवल APPROVED member complaint दर्ज कर सकता है।'); end if;
 if nullif(trim(p_category),'') is null or nullif(trim(p_subject),'') is null or nullif(trim(p_description),'') is null then return jsonb_build_object('success',false,'message','श्रेणी, विषय और विवरण जरूरी हैं।'); end if;
 if length(trim(p_subject))>180 or length(trim(p_description))>5000 then return jsonb_build_object('success',false,'message','Subject/description की सीमा पार हो गई है।'); end if;
 if p_against_officer_id is not null then
   select exists(select 1 from public.rkms_officers o join public.rkms_members om on om.id=o.member_id where o.id=p_against_officer_id and o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date)) into v_against_ok;
   if not v_against_ok then return jsonb_build_object('success',false,'message','चयनित पदाधिकारी वैध ACTIVE officer नहीं है।'); end if;
 end if;
 v_id:=gen_random_uuid(); v_code:='RKMS-CMP-'||to_char(v_now,'YYYY')||'-'||lpad(nextval('rkms_complaint_seq')::text,6,'0');
 -- Ignore client-supplied geography; authoritative member profile is copied into the complaint.
 select state,mandal,district,tehsil,block,village into p_state,p_mandal,p_district,p_tehsil,p_block,p_village from public.rkms_members where id=v_member;
 insert into public.rkms_complaints(id,complaint_id,member_id,name,mobile,state,mandal,district,tehsil,block,village,category,subject,description,photo_url,document_url,status,priority,sla_due_at,against_officer_id,created_at,updated_at)
 select v_id,v_code,m.id,m.name,m.mobile,m.state,m.mandal,m.district,m.tehsil,m.block,m.village,trim(p_category),trim(p_subject),trim(p_description),nullif(trim(p_photo_path),''),nullif(trim(p_document_path),''),v_status,'NORMAL',v_now+interval '7 days',p_against_officer_id,v_now,v_now
 from public.rkms_members m where m.id=v_member;
 v_assignee:=public.rkms_select_complaint_officer(v_id);
 if v_assignee is not null then update public.rkms_complaints set assigned_to=v_assignee,assigned_at=v_now,assigned_by=null,status='ASSIGNED',updated_at=v_now where id=v_id; v_status:='ASSIGNED'; end if;
 insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata)
 values(v_id,null,v_status,'Complaint registered',null,v_now,'REGISTRATION',auth.uid(),null,v_assignee,jsonb_build_object('against_officer_id',p_against_officer_id,'category',p_category));
 if v_assignee is not null then
   insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata)
   values(v_id,'RECEIVED','ASSIGNED','Automatic jurisdiction routing',null,v_now,'ASSIGNMENT',auth.uid(),null,v_assignee,'{}'::jsonb);
 end if;
 insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
 select 'शिकायत दर्ज हुई','शिकायत '||v_code||' सफलतापूर्वक दर्ज हुई।','COMPLAINT_REGISTERED','MEMBER',m.id::text,true,false,auth.uid(),'ALL' from public.rkms_members m where m.id=v_member;
 if v_assignee is not null then
   insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
   select 'नई शिकायत सौंपी गई','शिकायत '||v_code||' आपके कार्यक्षेत्र में सौंपी गई है।','COMPLAINT_ASSIGNED','MEMBER',om.id::text,true,false,auth.uid(),'ALL'
   from public.rkms_officers o join public.rkms_members om on om.id=o.member_id where o.id=v_assignee;
 end if;
 return jsonb_build_object('success',true,'id',v_id,'complaint_id',v_code,'status',v_status,'assigned_to',v_assignee);
end;$function$;

grant execute on function public.rkms_register_complaint_final(uuid,text,text,text,text,text,text,text,text,text,text,text,uuid) to authenticated;
revoke execute on function public.rkms_register_complaint_final(uuid,text,text,text,text,text,text,text,text,text,text,text,uuid) from anon;
revoke execute on function public.rkms_register_complaint(uuid,text,text,text,text,text,text,text,text,text,text,text) from authenticated;
revoke execute on function public.rkms_register_complaint(uuid,text,text,text,text,text,text,text,text,text,text,text) from anon;

-- Append-only complaint audit trail.
create or replace function public.rkms_complaint_history_immutable()
returns trigger language plpgsql as $function$
begin raise exception 'Complaint history is append-only.'; end;$function$;
drop trigger if exists trg_rkms_complaint_history_immutable on public.rkms_complaint_history;
create trigger trg_rkms_complaint_history_immutable before update or delete on public.rkms_complaint_history for each row execute function public.rkms_complaint_history_immutable();

-- Only member RPCs may close/reopen after resolution; officer workflow cannot bypass member confirmation.
create or replace function public.rkms_complaint_member_transition_guard()
returns trigger language plpgsql as $function$
begin
 if old.status='RESOLVED' and new.status='CLOSED' and current_setting('rkms.member_transition',true)<>'1' then raise exception 'Member confirmation is required before closing a resolved complaint.'; end if;
 if new.status='REOPENED' and current_setting('rkms.member_transition',true)<>'1' and not public.rkms_is_super_admin() then raise exception 'Complaint can be reopened by the member or Super Admin.'; end if;
 return new;
end;$function$;
drop trigger if exists trg_rkms_complaint_member_transition_guard on public.rkms_complaints;
create trigger trg_rkms_complaint_member_transition_guard before update of status on public.rkms_complaints for each row execute function public.rkms_complaint_member_transition_guard();

create or replace function public.rkms_member_close_complaint(p_complaint_id uuid,p_feedback text default null)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare v_member uuid:=public.rkms_current_member_id(); v_old text; v_code text; v_now timestamptz:=now();
begin
 if v_member is null then return jsonb_build_object('success',false,'message','Current member नहीं मिला।'); end if;
 select status,complaint_id into v_old,v_code from public.rkms_complaints where id=p_complaint_id and member_id=v_member for update;
 if v_old is null then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
 if v_old<>'RESOLVED' then return jsonb_build_object('success',false,'message','केवल RESOLVED complaint को बंद किया जा सकता है।'); end if;
 perform set_config('rkms.member_transition','1',true);
 update public.rkms_complaints set status='CLOSED',closed_at=v_now,member_closed_at=v_now,member_feedback=nullif(trim(p_feedback),''),updated_at=v_now where id=p_complaint_id;
 insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata) values(p_complaint_id,'RESOLVED','CLOSED',nullif(trim(p_feedback),''),null,v_now,'MEMBER_CLOSURE',auth.uid(),null,null,'{}'::jsonb);
 return jsonb_build_object('success',true,'complaint_id',v_code,'status','CLOSED');
end;$function$;

grant execute on function public.rkms_member_close_complaint(uuid,text) to authenticated;
revoke execute on function public.rkms_member_close_complaint(uuid,text) from anon;

create or replace function public.rkms_member_reopen_complaint(p_complaint_id uuid,p_reason text)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare v_member uuid:=public.rkms_current_member_id(); v_old text; v_code text; v_assignee uuid; v_now timestamptz:=now();
begin
 if v_member is null then return jsonb_build_object('success',false,'message','Current member नहीं मिला।'); end if;
 if nullif(trim(p_reason),'') is null then return jsonb_build_object('success',false,'message','Reopen का कारण लिखना जरूरी है।'); end if;
 select status,complaint_id,assigned_to into v_old,v_code,v_assignee from public.rkms_complaints where id=p_complaint_id and member_id=v_member for update;
 if v_old is null then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
 if v_old not in ('RESOLVED','CLOSED') then return jsonb_build_object('success',false,'message','यह complaint अभी reopen नहीं की जा सकती।'); end if;
 perform set_config('rkms.member_transition','1',true);
 update public.rkms_complaints set status='REOPENED',reopened_at=v_now,member_reopened_at=v_now,member_feedback=nullif(trim(p_reason),''),updated_at=v_now where id=p_complaint_id;
 insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata) values(p_complaint_id,v_old,'REOPENED',trim(p_reason),null,v_now,'MEMBER_REOPEN',auth.uid(),v_assignee,v_assignee,'{}'::jsonb);
 return jsonb_build_object('success',true,'complaint_id',v_code,'status','REOPENED','assigned_to',v_assignee);
end;$function$;

grant execute on function public.rkms_member_reopen_complaint(uuid,text) to authenticated;
revoke execute on function public.rkms_member_reopen_complaint(uuid,text) from anon;

create or replace function public.rkms_set_complaint_priority(p_complaint_id uuid,p_priority text,p_reason text default null)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare v_actor uuid:=public.rkms_current_officer_id(); v_admin uuid:=public.rkms_current_super_admin_id(); v_check jsonb; v_old text; v_code text; v_now timestamptz:=now(); v_rank int; v_assigned uuid; v_actor_level text; v_assigned_level text; v_old_priority text;
begin
 if p_priority not in ('LOW','NORMAL','HIGH','URGENT') then return jsonb_build_object('success',false,'message','Invalid priority.'); end if;
 select status,complaint_id,assigned_to,priority into v_old,v_code,v_assigned,v_old_priority from public.rkms_complaints where id=p_complaint_id for update;
 if v_old is null then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
 if v_admin is null then
   if v_actor is null then return jsonb_build_object('success',false,'message','केवल अधिकृत officer priority बदल सकता है।'); end if;
   v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor);
   if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint की priority बदलने की अनुमति नहीं है।'); end if;
   select upper(authority_level) into v_actor_level from public.rkms_officers where id=v_actor;
   select upper(authority_level) into v_assigned_level from public.rkms_officers where id=v_assigned;
   if v_assigned is not null and v_actor<>v_assigned and public.rkms_level_rank(v_actor_level)<=public.rkms_level_rank(v_assigned_level) then return jsonb_build_object('success',false,'message','वर्तमान जिम्मेदार officer या उससे उच्च authority ही priority बदल सकती है।'); end if;
 end if;
 if v_old in ('CLOSED','REJECTED') then return jsonb_build_object('success',false,'message','Final complaint की priority नहीं बदल सकती।'); end if;
 update public.rkms_complaints set priority=p_priority,updated_at=v_now where id=p_complaint_id;
 insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata) values(p_complaint_id,v_old,v_old,'Priority: '||coalesce(p_reason,'')||' ('||p_priority||')',v_actor,v_now,'PRIORITY_CHANGE',auth.uid(),v_assigned,v_assigned,jsonb_build_object('old_priority',v_old_priority,'new_priority',p_priority));
 return jsonb_build_object('success',true,'complaint_id',v_code,'priority',p_priority);
end;$function$;
grant execute on function public.rkms_set_complaint_priority(uuid,text,text) to authenticated;
revoke execute on function public.rkms_set_complaint_priority(uuid,text,text) from anon;

-- Formal next-authority / specialist guidance. It does not override jurisdictional authorization.
create or replace function public.rkms_get_complaint_next_authority(p_complaint_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare c record; v_assigned_level text; v_next_level text; v_hint text; v_data jsonb;
begin
 select * into c from public.rkms_complaints where id=p_complaint_id;
 if not found then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
 select upper(authority_level) into v_assigned_level from public.rkms_officers where id=c.assigned_to;
 v_next_level:=case v_assigned_level when 'BLOCK' then 'TEHSIL' when 'TEHSIL' then 'DISTRICT' when 'DISTRICT' then 'MANDAL' when 'MANDAL' then 'STATE' when 'STATE' then 'NATIONAL' else 'NATIONAL' end;
 v_hint:=case when c.category='पदाधिकारी / प्रशासन' then 'संगठन/प्रशासन से जुड़े विषय में अगले स्तर के अध्यक्ष/प्रशासनिक अधिकारी से परामर्श करें।' when c.category='भूमि / किसान' then 'भूमि/किसान विषय में संबंधित किसान/भूमि विशेषज्ञ wing से परामर्श लें।' when c.category='भुगतान / आर्थिक' then 'भुगतान/आर्थिक विषय में संबंधित कोष/वित्त जिम्मेदार अधिकारी से परामर्श लें।' when c.category='सदस्यता / संगठन' then 'सदस्यता/संगठन विषय में संगठन प्रभारी से परामर्श लें।' when c.category='अन्य' then 'विषय के अनुसार संबंधित विशेषज्ञ/उच्च अधिकारी से परामर्श लें।' else 'विषय के अनुसार संबंधित अधिकारी से परामर्श लें।' end;
 select coalesce(jsonb_agg(jsonb_build_object('officer_id',o.id,'name',m.name,'post_name',p.post_name,'authority_level',o.authority_level) order by o.created_at),'[]'::jsonb) into v_data
 from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
 where o.status='ACTIVE' and upper(o.authority_level)=v_next_level and lower(coalesce(o.state,''))=lower(coalesce(c.state,''))
 and (v_next_level='NATIONAL' or lower(coalesce(o.mandal,''))=lower(coalesce(c.mandal,'')))
 and (v_next_level in ('NATIONAL','STATE','MANDAL') or lower(coalesce(o.district,''))=lower(coalesce(c.district,'')))
 and (v_next_level in ('NATIONAL','STATE','MANDAL','DISTRICT') or lower(coalesce(o.tehsil,''))=lower(coalesce(c.tehsil,'')))
 and (v_next_level in ('NATIONAL','STATE','MANDAL','DISTRICT','TEHSIL') or lower(coalesce(o.block,''))=lower(coalesce(c.block,'')))
 and (c.against_officer_id is null or o.id<>c.against_officer_id);
 return jsonb_build_object('success',true,'next_authority_level',v_next_level,'guidance',v_hint,'officers',v_data);
end;$function$;
grant execute on function public.rkms_get_complaint_next_authority(uuid) to authenticated;
revoke execute on function public.rkms_get_complaint_next_authority(uuid) from anon;

-- SLA processor: safe to call whenever an officer/admin opens complaint management. It records each breach once.
create or replace function public.rkms_process_complaint_sla()
returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare v_actor uuid:=public.rkms_current_officer_id(); v_admin uuid:=public.rkms_current_super_admin_id(); v_count int:=0; r record; v_now timestamptz:=now();
begin
 if v_actor is null and v_admin is null then return jsonb_build_object('success',false,'message','Officer authorization required.'); end if;
 for r in select c.id,c.complaint_id,c.member_id,c.assigned_to,c.sla_due_at,c.status from public.rkms_complaints c where c.sla_due_at is not null and c.sla_due_at<v_now and c.status not in ('CLOSED','REJECTED') and (c.sla_breached_at is null) and (v_admin is not null or c.assigned_to=v_actor) for update loop
   update public.rkms_complaints set sla_breached_at=v_now,updated_at=v_now where id=r.id;
   insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata) values(r.id,r.status,r.status,'SLA समयसीमा पार हो गई।',v_actor,v_now,'SLA_BREACH',auth.uid(),r.assigned_to,r.assigned_to,jsonb_build_object('sla_due_at',r.sla_due_at));
   insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience) values('शिकायत SLA पार','शिकायत '||r.complaint_id||' की निर्धारित समयसीमा पार हो गई है।','COMPLAINT_SLA_BREACH','MEMBER',(select id::text from public.rkms_members where id=r.member_id),true,false,auth.uid(),'ALL');
   if r.assigned_to is not null then insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience) select 'SLA चेतावनी','शिकायत '||r.complaint_id||' की SLA समयसीमा पार हो गई है।','COMPLAINT_SLA_BREACH','MEMBER',m.id::text,true,false,auth.uid(),'ALL' from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=r.assigned_to; end if;
   v_count:=v_count+1;
 end loop;
 return jsonb_build_object('success',true,'breached',v_count);
end;$function$;
grant execute on function public.rkms_process_complaint_sla() to authenticated;
revoke execute on function public.rkms_process_complaint_sla() from anon;

-- Backfill SLA for all currently open complaints.
update public.rkms_complaints set sla_due_at=created_at+interval '7 days' where sla_due_at is null and status not in ('CLOSED','REJECTED');

-- Explicit escalation event for future workflow calls; existing transfer remains available for ordinary reassignment.
alter table public.rkms_complaint_history drop constraint if exists rkms_complaint_history_event_type_check;
