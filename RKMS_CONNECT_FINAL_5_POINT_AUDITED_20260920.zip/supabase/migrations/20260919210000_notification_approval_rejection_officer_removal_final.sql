-- RKMS CONNECT FINAL: targeted notifications for membership decision and officer removal.
-- Appointment/reappointment already use trg_rkms_officer_appointment_notify.

create or replace function public.rkms_member_approval_notify()
returns trigger
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $function$
declare
  app_id text;
begin
  if TG_OP='UPDATE' and upper(coalesce(NEW.status,''))='APPROVED'
     and upper(coalesce(OLD.status,''))<>'APPROVED' then
    select a.id::text into app_id from public.rkms_member_applications a
    where a.member_id=NEW.id order by a.created_at desc nulls last limit 1;
    if app_id is not null then
      delete from public.rkms_notifications
      where notification_type='MEMBERSHIP_APPROVAL'
        and target_type='MEMBERSHIP_APPROVAL' and target_value=app_id;
    end if;
    if NEW.auth_user_id is not null and not exists (
      select 1 from public.rkms_notifications n
      where n.notification_type='MEMBERSHIP_APPROVED'
        and n.target_type='MEMBER' and n.target_value=NEW.id::text
        and n.created_at >= now()-interval '10 minutes') then
      insert into public.rkms_notifications
        (title,body,notification_type,target_type,target_value,target_audience,is_important,is_public)
      values
        ('सदस्यता अनुरोध स्वीकृत हो गया',
         'बधाई हो '||coalesce(NEW.name,'सदस्य')||' जी, आपका सदस्यता अनुरोध स्वीकृत कर दिया गया है। अब आप RKMS Connect में Login कर सकते हैं।',
         'MEMBERSHIP_APPROVED','MEMBER',NEW.id::text,'MEMBER',true,false);
    end if;
  elsif TG_OP='UPDATE' and upper(coalesce(NEW.status,'')) in ('REJECTED','REJECT')
        and upper(coalesce(OLD.status,'')) not in ('REJECTED','REJECT') then
    if NEW.auth_user_id is not null and not exists (
      select 1 from public.rkms_notifications n
      where n.notification_type='MEMBERSHIP_REJECTED'
        and n.target_type='MEMBER' and n.target_value=NEW.id::text
        and n.created_at >= now()-interval '10 minutes') then
      insert into public.rkms_notifications
        (title,body,notification_type,target_type,target_value,target_audience,is_important,is_public)
      values
        ('सदस्यता आवेदन अस्वीकृत',
         'आपका सदस्यता आवेदन अस्वीकृत किया गया है। कारण: '||coalesce(nullif(trim(NEW.rejection_reason),''),'कारण उपलब्ध नहीं है।'),
         'MEMBERSHIP_REJECTED','MEMBER',NEW.id::text,'MEMBER',true,false);
    end if;
  end if;
  return NEW;
exception when others then return NEW;
end;
$function$;

create or replace function public.rkms_officer_removal_notify()
returns trigger
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $function$
declare
  m public.rkms_members%rowtype;
  p public.rkms_posts%rowtype;
  v_post text;
  v_status text;
begin
  if TG_OP <> 'UPDATE' or upper(coalesce(OLD.status,'')) <> 'ACTIVE'
     or upper(coalesce(NEW.status,'')) not in ('INACTIVE','EXPIRED') then return NEW; end if;
  select * into m from public.rkms_members where id=NEW.member_id;
  if m.id is null or m.auth_user_id is null then return NEW; end if;
  select * into p from public.rkms_posts where id=NEW.post_id;
  v_post:=coalesce(p.post_name,'PDA पद');
  v_status:=case when upper(NEW.status)='EXPIRED' then 'समाप्त' else 'निष्क्रिय' end;
  if not exists (
    select 1 from public.rkms_notifications n
    where n.notification_type='PDA_REMOVED' and n.target_type='MEMBER'
      and n.target_value=NEW.member_id::text and n.created_at >= now()-interval '10 minutes') then
    insert into public.rkms_notifications
      (title,body,notification_type,target_type,target_value,target_audience,is_important,is_public,publisher_auth_user_id)
    values
      ('पदाधिकारी पद स्थिति अपडेट',
       'आपका '||v_post||' पद अब '||v_status||' कर दिया गया है।',
       'PDA_REMOVED','MEMBER',NEW.member_id::text,'MEMBER',true,false,auth.uid());
  end if;
  return NEW;
exception when others then return NEW;
end;
$function$;

drop trigger if exists trg_rkms_officer_removal_notify on public.rkms_officers;
create trigger trg_rkms_officer_removal_notify
after update of status on public.rkms_officers
for each row execute function public.rkms_officer_removal_notify();
