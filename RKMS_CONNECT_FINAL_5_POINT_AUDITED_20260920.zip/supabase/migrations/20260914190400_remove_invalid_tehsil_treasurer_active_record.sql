do $$
declare v_post uuid;
begin
 select id into v_post from public.rkms_posts where post_name='तहसील कोषाध्यक्ष' limit 1;
 if v_post is not null then
   update public.rkms_officers set status='INACTIVE',post_id=null,updated_at=now() where post_id=v_post and status='ACTIVE';
   delete from public.rkms_posts where id=v_post;
 end if;
end $$;
