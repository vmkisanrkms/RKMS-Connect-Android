-- Report fix: provide authoritative IT Cell flag so the client can
-- distinguish post distribution from Wing/Cell distribution.
CREATE OR REPLACE FUNCTION public.rkms_get_report_download_data()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO public, pg_catalog
AS $function$
DECLARE
  v_is_admin boolean := false;
  v_officer_id uuid;
  v_level text;
  v_state text;
  v_mandal text;
  v_district text;
  v_tehsil text;
  v_block text;
  v_village text;
  v_scope jsonb;
  v_members jsonb;
  v_officers jsonb;
  v_pending integer := 0;
  v_rejected integer := 0;
BEGIN
  v_is_admin := coalesce(public.rkms_is_super_admin(), false);

  IF v_is_admin THEN
    v_level := 'SUPER_ADMIN';
  ELSE
    v_officer_id := public.rkms_current_officer_id();
    IF v_officer_id IS NULL THEN
      RETURN jsonb_build_object('success', false, 'message', 'List download केवल अधिकृत PDA/Officer या Super Admin के लिए उपलब्ध है।');
    END IF;

    SELECT upper(o.authority_level), o.state, o.mandal, o.district, o.tehsil, o.block, o.village
      INTO v_level, v_state, v_mandal, v_district, v_tehsil, v_block, v_village
    FROM public.rkms_officers o
    WHERE o.id = v_officer_id
      AND o.status = 'ACTIVE'
      AND (o.valid_from IS NULL OR o.valid_from <= CURRENT_DATE)
      AND (o.valid_to IS NULL OR o.valid_to >= CURRENT_DATE)
    LIMIT 1;

    IF v_level IS NULL THEN
      RETURN jsonb_build_object('success', false, 'message', 'Current ACTIVE PDA/Officer नहीं मिला।');
    END IF;
  END IF;

  v_scope := jsonb_build_object(
    'level', v_level,
    'state', CASE WHEN v_is_admin OR v_level='NATIONAL' THEN NULL ELSE public.rkms_normalize_location_value(v_state) END,
    'mandal', CASE WHEN v_is_admin OR v_level IN ('NATIONAL','STATE') THEN NULL ELSE public.rkms_normalize_location_value(v_mandal) END,
    'district', CASE WHEN v_is_admin OR v_level IN ('NATIONAL','STATE','MANDAL') THEN NULL ELSE public.rkms_normalize_location_value(v_district) END,
    'tehsil', CASE WHEN v_is_admin OR v_level IN ('NATIONAL','STATE','MANDAL','DISTRICT') THEN NULL ELSE public.rkms_normalize_location_value(v_tehsil) END,
    'block', CASE WHEN v_is_admin OR v_level IN ('NATIONAL','STATE','MANDAL','DISTRICT','TEHSIL') THEN NULL ELSE public.rkms_normalize_location_value(v_block) END,
    'village', CASE WHEN v_is_admin OR v_level IN ('NATIONAL','STATE','MANDAL','DISTRICT','TEHSIL','BLOCK') THEN NULL ELSE public.rkms_normalize_location_value(v_village) END
  );

  SELECT coalesce(jsonb_agg(jsonb_build_object(
    'id',m.id,
    'member_id',m.member_id,
    'name',m.name,
    'photo_url',m.photo_url,
    'membership_type',m.membership_type,
    'status',m.status,
    'state',public.rkms_normalize_location_value(m.state),
    'mandal',public.rkms_normalize_location_value(m.mandal),
    'district',public.rkms_normalize_location_value(m.district),
    'tehsil',public.rkms_normalize_location_value(m.tehsil),
    'block',public.rkms_normalize_location_value(m.block),
    'gram_panchayat',m.gram_panchayat,
    'village',public.rkms_normalize_location_value(m.village)
  ) ORDER BY m.created_at DESC),'[]'::jsonb)
    INTO v_members
  FROM public.rkms_members m
  WHERE upper(coalesce(m.status,''))='APPROVED'
    AND (
      v_is_admin OR v_level='NATIONAL'
      OR (v_level='STATE' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state))
      OR (v_level='MANDAL' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal))
      OR (v_level='DISTRICT' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district))
      OR (v_level='TEHSIL' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil))
      OR (v_level='BLOCK' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block))
      OR (v_level='VILLAGE' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block) AND public.rkms_normalize_location_value(m.village)=public.rkms_normalize_location_value(v_village))
    );

  SELECT coalesce(jsonb_agg(jsonb_build_object(
    'officer_id',o.id,
    'member_id',o.member_id,
    'name',m.name,
    'photo_url',m.photo_url,
    'post_id',o.post_id,
    'post_name',p.post_name,
    'authority_level',o.authority_level,
    'is_it_cell',coalesce(p.is_it_cell,false),
    'state',public.rkms_normalize_location_value(o.state),
    'mandal',public.rkms_normalize_location_value(o.mandal),
    'district',public.rkms_normalize_location_value(o.district),
    'tehsil',public.rkms_normalize_location_value(o.tehsil),
    'block',public.rkms_normalize_location_value(o.block),
    'village',public.rkms_normalize_location_value(o.village),
    'appointment_no',o.appointment_no,
    'joining_date',o.joining_date,
    'status',o.status
  ) ORDER BY o.created_at DESC),'[]'::jsonb)
    INTO v_officers
  FROM public.rkms_officers o
  JOIN public.rkms_members m ON m.id=o.member_id
  LEFT JOIN public.rkms_posts p ON p.id=o.post_id
  WHERE upper(coalesce(o.status,''))='ACTIVE'
    AND (o.valid_from IS NULL OR o.valid_from<=CURRENT_DATE)
    AND (o.valid_to IS NULL OR o.valid_to>=CURRENT_DATE)
    AND (
      v_is_admin OR v_level='NATIONAL'
      OR (v_level='STATE' AND public.rkms_normalize_location_value(o.state)=public.rkms_normalize_location_value(v_state))
      OR (v_level='MANDAL' AND public.rkms_normalize_location_value(o.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(o.mandal)=public.rkms_normalize_location_value(v_mandal))
      OR (v_level='DISTRICT' AND public.rkms_normalize_location_value(o.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(o.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(o.district)=public.rkms_normalize_location_value(v_district))
      OR (v_level='TEHSIL' AND public.rkms_normalize_location_value(o.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(o.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(o.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(o.tehsil)=public.rkms_normalize_location_value(v_tehsil))
      OR (v_level='BLOCK' AND public.rkms_normalize_location_value(o.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(o.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(o.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(o.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(o.block)=public.rkms_normalize_location_value(v_block))
      OR (v_level='VILLAGE' AND public.rkms_normalize_location_value(o.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(o.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(o.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(o.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(o.block)=public.rkms_normalize_location_value(v_block) AND public.rkms_normalize_location_value(o.village)=public.rkms_normalize_location_value(v_village))
    );

  IF v_is_admin OR v_level='NATIONAL' THEN
    SELECT count(*) INTO v_pending FROM public.rkms_members WHERE upper(coalesce(status,''))='PENDING';
    SELECT count(*) INTO v_rejected FROM public.rkms_members WHERE upper(coalesce(status,''))='REJECTED';
  ELSE
    SELECT count(*) INTO v_pending FROM public.rkms_members m
    WHERE upper(coalesce(m.status,''))='PENDING'
      AND (
        (v_level='STATE' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state))
        OR (v_level='MANDAL' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal))
        OR (v_level='DISTRICT' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district))
        OR (v_level='TEHSIL' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil))
        OR (v_level='BLOCK' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block))
        OR (v_level='VILLAGE' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block) AND public.rkms_normalize_location_value(m.village)=public.rkms_normalize_location_value(v_village))
      );
    SELECT count(*) INTO v_rejected FROM public.rkms_members m
    WHERE upper(coalesce(m.status,''))='REJECTED'
      AND (
        (v_level='STATE' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state))
        OR (v_level='MANDAL' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal))
        OR (v_level='DISTRICT' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district))
        OR (v_level='TEHSIL' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil))
        OR (v_level='BLOCK' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block))
        OR (v_level='VILLAGE' AND public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) AND public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) AND public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) AND public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) AND public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block) AND public.rkms_normalize_location_value(m.village)=public.rkms_normalize_location_value(v_village))
      );
  END IF;

  RETURN jsonb_build_object(
    'success', true,
    'scope', v_scope,
    'members', v_members,
    'officers', v_officers,
    'pending_members', v_pending,
    'rejected_members', v_rejected,
    'member_count', jsonb_array_length(v_members),
    'officer_count', jsonb_array_length(v_officers)
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.rkms_get_report_download_data() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.rkms_get_report_download_data() FROM anon;
GRANT EXECUTE ON FUNCTION public.rkms_get_report_download_data() TO authenticated;
