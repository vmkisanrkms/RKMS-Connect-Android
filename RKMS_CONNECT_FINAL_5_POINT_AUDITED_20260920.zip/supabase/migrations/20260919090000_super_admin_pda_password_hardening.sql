-- RKMS FINAL PDA PASSWORD HARDENING
-- 1) Super Admin appointment/reappointment now require current Login Password.
-- 2) Super Admin officer removal now requires current Login Password.
-- 3) The previous passwordless Super Admin RPC signatures are renamed and
--    execute access is revoked so they cannot be called directly by clients.

DO $$
BEGIN
  IF to_regprocedure('public.rkms_super_admin_reappoint_officer(uuid,uuid,text,text,text,text,text,text,text,date)') IS NOT NULL THEN
    ALTER FUNCTION public.rkms_super_admin_reappoint_officer(uuid,uuid,text,text,text,text,text,text,text,date)
      RENAME TO rkms_super_admin_reappoint_officer_legacy;
  END IF;
  IF to_regprocedure('public.rkms_super_admin_appoint_officer(uuid,text,text,text,text,text,text,text,date)') IS NOT NULL THEN
    ALTER FUNCTION public.rkms_super_admin_appoint_officer(uuid,text,text,text,text,text,text,text,date)
      RENAME TO rkms_super_admin_appoint_officer_legacy;
  END IF;
END $$;

REVOKE ALL ON FUNCTION public.rkms_super_admin_reappoint_officer_legacy(uuid,uuid,text,text,text,text,text,text,text,date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.rkms_super_admin_reappoint_officer_legacy(uuid,uuid,text,text,text,text,text,text,text,date) FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.rkms_super_admin_appoint_officer_legacy(uuid,text,text,text,text,text,text,text,date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.rkms_super_admin_appoint_officer_legacy(uuid,text,text,text,text,text,text,text,date) FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.rkms_super_admin_appoint_officer(
  p_member_id uuid,
  p_post_name text,
  p_state text,
  p_mandal text DEFAULT NULL,
  p_district text DEFAULT NULL,
  p_tehsil text DEFAULT NULL,
  p_block text DEFAULT NULL,
  p_village text DEFAULT NULL,
  p_joining_date date DEFAULT CURRENT_DATE,
  p_password text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public','pg_catalog'
AS $$
DECLARE
  v_admin_id uuid;
BEGIN
  SELECT id INTO v_admin_id
  FROM public.rkms_admins
  WHERE auth_user_id=auth.uid()
    AND role='SUPER_ADMIN'
    AND status='ACTIVE'
  LIMIT 1;

  IF v_admin_id IS NULL THEN
    RETURN jsonb_build_object('success',false,'message','केवल ACTIVE SUPER_ADMIN ही यह नियुक्ति कर सकता है।');
  END IF;

  IF NOT public.rkms_verify_current_password(p_password) THEN
    RETURN jsonb_build_object('success',false,'message','इस नियुक्ति के लिए वर्तमान Login Password verification आवश्यक है।');
  END IF;

  RETURN public.rkms_super_admin_appoint_officer_legacy(
    p_member_id,p_post_name,p_state,p_mandal,p_district,p_tehsil,
    p_block,p_village,p_joining_date
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.rkms_super_admin_reappoint_officer(
  p_member_id uuid,
  p_old_officer_id uuid,
  p_post_name text,
  p_state text,
  p_mandal text DEFAULT NULL,
  p_district text DEFAULT NULL,
  p_tehsil text DEFAULT NULL,
  p_block text DEFAULT NULL,
  p_village text DEFAULT NULL,
  p_joining_date date DEFAULT CURRENT_DATE,
  p_password text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public','pg_catalog'
AS $$
DECLARE
  v_admin_id uuid;
  v_old_member uuid;
BEGIN
  SELECT id INTO v_admin_id
  FROM public.rkms_admins
  WHERE auth_user_id=auth.uid()
    AND role='SUPER_ADMIN'
    AND status='ACTIVE'
  LIMIT 1;

  IF v_admin_id IS NULL THEN
    RETURN jsonb_build_object('success',false,'message','केवल ACTIVE SUPER_ADMIN ही यह पद परिवर्तन कर सकता है।');
  END IF;

  IF NOT public.rkms_verify_current_password(p_password) THEN
    RETURN jsonb_build_object('success',false,'message','इस पद परिवर्तन के लिए वर्तमान Login Password verification आवश्यक है।');
  END IF;

  SELECT member_id INTO v_old_member
  FROM public.rkms_officers
  WHERE id=p_old_officer_id AND status='ACTIVE'
  FOR UPDATE;

  IF v_old_member IS NULL OR v_old_member<>p_member_id THEN
    RETURN jsonb_build_object('success',false,'message','पुरानी active नियुक्ति नहीं मिली।');
  END IF;

  -- The legacy implementation performs the same validated appointment flow
  -- and atomically retires the member's previous ACTIVE appointment.
  RETURN public.rkms_super_admin_appoint_officer_legacy(
    p_member_id,p_post_name,p_state,p_mandal,p_district,p_tehsil,
    p_block,p_village,p_joining_date
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.rkms_update_officer_status(
  p_officer_id uuid,
  p_new_status text,
  p_changed_by_officer_id uuid,
  p_valid_to date DEFAULT CURRENT_DATE,
  p_password text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public','pg_catalog'
AS $$
DECLARE
  v_actor_id uuid;
  v_admin_id uuid;
  v_target_post text;
  v_actor_post text;
  v_is_super_admin boolean:=false;
BEGIN
  SELECT id INTO v_admin_id
  FROM public.rkms_admins
  WHERE auth_user_id=auth.uid()
    AND role='SUPER_ADMIN'
    AND status='ACTIVE'
  LIMIT 1;

  v_is_super_admin:=v_admin_id IS NOT NULL;

  IF v_is_super_admin THEN
    IF NOT public.rkms_verify_current_password(p_password) THEN
      RETURN jsonb_build_object('success',false,'message','Officer हटाने के लिए वर्तमान Login Password verification आवश्यक है।');
    END IF;
  ELSE
    v_actor_id:=public.rkms_require_current_officer();
    IF v_actor_id IS NULL OR p_changed_by_officer_id<>v_actor_id THEN
      RETURN jsonb_build_object('success',false,'message','Authenticated officer सत्यापित नहीं है।');
    END IF;
    IF NOT public.rkms_verify_current_password(p_password) THEN
      RETURN jsonb_build_object('success',false,'message','Officer हटाने के लिए वर्तमान Password verification आवश्यक है।');
    END IF;
  END IF;

  IF p_new_status NOT IN ('INACTIVE','EXPIRED') THEN
    RETURN jsonb_build_object('success',false,'message','केवल INACTIVE या EXPIRED status किया जा सकता है।');
  END IF;

  SELECT p.post_name INTO v_target_post
  FROM public.rkms_officers o
  JOIN public.rkms_posts p ON p.id=o.post_id
  WHERE o.id=p_officer_id AND o.status='ACTIVE'
  FOR UPDATE;

  IF v_target_post IS NULL THEN
    RETURN jsonb_build_object('success',false,'message','Target officer नहीं मिला या पहले से inactive है।');
  END IF;

  IF NOT v_is_super_admin THEN
    IF p_officer_id=v_actor_id THEN
      RETURN jsonb_build_object('success',false,'message','Officer स्वयं अपना status नहीं बदल सकता।');
    END IF;

    SELECT p.post_name INTO v_actor_post
    FROM public.rkms_officers o
    JOIN public.rkms_posts p ON p.id=o.post_id
    WHERE o.id=v_actor_id AND o.status='ACTIVE';

    IF NOT public.rkms_can_manage_officer(v_actor_id,p_officer_id) THEN
      RETURN jsonb_build_object(
        'success',false,
        'message','आपके पद/क्षेत्राधिकार को इस officer का status बदलने का अधिकार नहीं है।',
        'your_post',v_actor_post,
        'target_post',v_target_post
      );
    END IF;
  END IF;

  IF p_new_status='EXPIRED' AND p_valid_to IS NULL THEN
    RETURN jsonb_build_object('success',false,'message','EXPIRED करने के लिए valid_to जरूरी है।');
  END IF;

  UPDATE public.rkms_officers
  SET status=p_new_status,
      valid_to=CASE WHEN p_new_status='EXPIRED' THEN p_valid_to ELSE valid_to END,
      updated_at=now()
  WHERE id=p_officer_id;

  RETURN jsonb_build_object(
    'success',true,
    'message','Officer status successfully updated.',
    'officer_id',p_officer_id,
    'new_status',p_new_status,
    'changed_by_officer_id',CASE WHEN v_is_super_admin THEN NULL ELSE v_actor_id END,
    'changed_by_super_admin',v_is_super_admin
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.rkms_super_admin_appoint_officer(uuid,text,text,text,text,text,text,text,date,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rkms_super_admin_reappoint_officer(uuid,uuid,text,text,text,text,text,text,text,date,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rkms_update_officer_status(uuid,text,uuid,date,text) TO authenticated;
