-- RKMS CONNECT — Complaint Workflow Final v1
-- Registration -> deterministic routing -> assignment -> review/action -> resolution/closure
-- Adds conflict-of-interest protection, assignment metadata, richer audit events and personal notifications.

alter table public.rkms_complaints
  add column if not exists priority text not null default 'NORMAL',
  add column if not exists sla_due_at timestamptz,
  add column if not exists assigned_at timestamptz,
  add column if not exists assigned_by uuid,
  add column if not exists first_reviewed_at timestamptz,
  add column if not exists action_at timestamptz,
  add column if not exists resolved_at timestamptz,
  add column if not exists closed_at timestamptz,
  add column if not exists reopened_at timestamptz,
  add column if not exists against_officer_id uuid,
  add column if not exists needs_information_reason text;

alter table public.rkms_complaint_history
  add column if not exists event_type text,
  add column if not exists actor_user_id uuid,
  add column if not exists assigned_from uuid,
  add column if not exists assigned_to uuid,
  add column if not exists metadata jsonb not null default '{}'::jsonb;

alter table public.rkms_complaints drop constraint if exists rkms_complaints_status_check;
alter table public.rkms_complaints
  add constraint rkms_complaints_status_check check (status in (
    'RECEIVED','ASSIGNED','UNDER_REVIEW','NEED_INFORMATION','IN_PROGRESS',
    'ACTION_TAKEN','RESOLVED','CLOSED','REOPENED','REJECTED'
  ));

alter table public.rkms_complaints drop constraint if exists rkms_complaints_priority_check;
alter table public.rkms_complaints
  add constraint rkms_complaints_priority_check check (priority in ('LOW','NORMAL','HIGH','URGENT'));

create index if not exists rkms_complaints_assigned_status_idx on public.rkms_complaints(assigned_to,status,updated_at desc);
create index if not exists rkms_complaints_sla_idx on public.rkms_complaints(sla_due_at,status);
create index if not exists rkms_complaints_against_officer_idx on public.rkms_complaints(against_officer_id);
create index if not exists rkms_complaint_history_complaint_created_idx on public.rkms_complaint_history(complaint_id,created_at desc);

create or replace function public.rkms_select_complaint_officer(p_complaint_id uuid)
returns uuid
language plpgsql
stable security definer
set search_path = public, pg_catalog
as $function$
declare
  v_state text; v_mandal text; v_district text; v_tehsil text; v_block text; v_against uuid; v_id uuid;
begin
  select c.state,c.mandal,c.district,c.tehsil,c.block,c.against_officer_id
    into v_state,v_mandal,v_district,v_tehsil,v_block,v_against
  from public.rkms_complaints c where c.id=p_complaint_id;
  if not found then return null; end if;

  select o.id into v_id
  from public.rkms_officers o
  left join public.rkms_posts p on p.id=o.post_id
  where o.status='ACTIVE'
    and (o.valid_from is null or o.valid_from<=current_date)
    and (o.valid_to is null or o.valid_to>=current_date)
    and upper(coalesce(o.authority_level,'')) in ('BLOCK','TEHSIL','DISTRICT','MANDAL','STATE','NATIONAL')
    and (v_against is null or o.id<>v_against)
    and (
      upper(o.authority_level)='NATIONAL'
      or (upper(o.authority_level)='STATE' and lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(v_state,''))))
      or (upper(o.authority_level)='MANDAL' and lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(v_state,''))) and lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(v_mandal,''))))
      or (upper(o.authority_level)='DISTRICT' and lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(v_state,''))) and lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(v_mandal,''))) and lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(v_district,''))))
      or (upper(o.authority_level)='TEHSIL' and lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(v_state,''))) and lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(v_mandal,''))) and lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(v_district,''))) and lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(v_tehsil,''))))
      or (upper(o.authority_level)='BLOCK' and lower(trim(coalesce(o.state,'')))=lower(trim(coalesce(v_state,''))) and lower(trim(coalesce(o.mandal,'')))=lower(trim(coalesce(v_mandal,''))) and lower(trim(coalesce(o.district,'')))=lower(trim(coalesce(v_district,''))) and lower(trim(coalesce(o.tehsil,'')))=lower(trim(coalesce(v_tehsil,''))) and lower(trim(coalesce(o.block,'')))=lower(trim(coalesce(v_block,''))))
    )
  order by
    case upper(o.authority_level) when 'BLOCK' then 1 when 'TEHSIL' then 2 when 'DISTRICT' then 3 when 'MANDAL' then 4 when 'STATE' then 5 when 'NATIONAL' then 6 else 99 end,
    case when lower(coalesce(p.post_name,'')) like '%president%' or p.post_name like '%अध्यक्ष%' then 0 else 1 end,
    case when coalesce(p.is_it_cell,false) then 1 else 0 end,
    o.created_at asc
  limit 1;
  return v_id;
end;
$function$;

create or replace function public.rkms_can_handle_complaint(p_complaint_id uuid,p_officer_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_catalog
as $function$
declare
  v_admin uuid;
  v_level text; v_state text; v_mandal text; v_district text; v_tehsil text; v_block text;
  c_state text; c_mandal text; c_district text; c_tehsil text; c_block text; c_against uuid;
  v_allowed boolean:=false; v_assigned uuid;
begin
  v_admin:=public.rkms_current_super_admin_id();
  if v_admin is not null then return jsonb_build_object('success',true,'allowed',true,'reason','SUPER_ADMIN'); end if;

  select upper(trim(o.authority_level)),o.state,o.mandal,o.district,o.tehsil,o.block
    into v_level,v_state,v_mandal,v_district,v_tehsil,v_block
  from public.rkms_officers o
  where o.id=p_officer_id and o.status='ACTIVE'
    and (o.valid_from is null or o.valid_from<=current_date)
    and (o.valid_to is null or o.valid_to>=current_date)
  limit 1;
  if v_level is null then return jsonb_build_object('success',true,'allowed',false,'message','Officer ACTIVE या valid नहीं है।'); end if;

  select c.state,c.mandal,c.district,c.tehsil,c.block,c.against_officer_id,c.assigned_to
    into c_state,c_mandal,c_district,c_tehsil,c_block,c_against,v_assigned
  from public.rkms_complaints c where c.id=p_complaint_id;
  if c_state is null then return jsonb_build_object('success',false,'allowed',false,'message','Complaint नहीं मिली।'); end if;

  if c_against is not null and c_against=p_officer_id then
    return jsonb_build_object('success',true,'allowed',false,'message','Conflict of interest: जिस पदाधिकारी के विरुद्ध complaint है, वही उसे handle नहीं कर सकता।');
  end if;

  if v_assigned=p_officer_id then
    return jsonb_build_object('success',true,'allowed',true,'reason','ASSIGNED_OFFICER');
  end if;

  if v_level='NATIONAL' then v_allowed:=true;
  elsif lower(trim(coalesce(v_state,'')))<>lower(trim(coalesce(c_state,''))) then v_allowed:=false;
  elsif v_level='STATE' then v_allowed:=true;
  elsif v_level='MANDAL' then v_allowed:=lower(trim(coalesce(v_mandal,'')))=lower(trim(coalesce(c_mandal,'')));
  elsif v_level='DISTRICT' then v_allowed:=lower(trim(coalesce(v_mandal,'')))=lower(trim(coalesce(c_mandal,''))) and lower(trim(coalesce(v_district,'')))=lower(trim(coalesce(c_district,'')));
  elsif v_level='TEHSIL' then v_allowed:=lower(trim(coalesce(v_mandal,'')))=lower(trim(coalesce(c_mandal,''))) and lower(trim(coalesce(v_district,'')))=lower(trim(coalesce(c_district,''))) and lower(trim(coalesce(v_tehsil,'')))=lower(trim(coalesce(c_tehsil,'')));
  elsif v_level='BLOCK' then v_allowed:=lower(trim(coalesce(v_mandal,'')))=lower(trim(coalesce(c_mandal,''))) and lower(trim(coalesce(v_district,'')))=lower(trim(coalesce(c_district,''))) and lower(trim(coalesce(v_tehsil,'')))=lower(trim(coalesce(c_tehsil,''))) and lower(trim(coalesce(v_block,'')))=lower(trim(coalesce(c_block,'')));
  end if;
  return jsonb_build_object('success',true,'allowed',v_allowed,'reason',case when v_allowed then 'JURISDICTION' else 'OUT_OF_SCOPE' end);
end;
$function$;

create or replace function public.rkms_register_complaint(
  p_member_id uuid,p_state text,p_mandal text,p_district text,p_tehsil text,p_block text,p_village text,
  p_category text,p_subject text,p_description text,p_photo_url text default null,p_document_url text default null
) returns jsonb
language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare
  v_current_member_id uuid; v_name text; v_mobile text; v_status text; v_auth uuid;
  v_code text; v_id uuid; v_assignee uuid; v_new_status text; v_now timestamptz:=now(); v_sla interval;
begin
  v_current_member_id:=public.rkms_current_member_id();
  if v_current_member_id is null or p_member_id is null or p_member_id<>v_current_member_id then
    return jsonb_build_object('success',false,'message','आप केवल अपने approved member account से complaint दर्ज कर सकते हैं।');
  end if;
  select m.name,m.mobile,m.status,m.auth_user_id into v_name,v_mobile,v_status,v_auth from public.rkms_members m where m.id=v_current_member_id;
  if v_auth is null or v_auth<>auth.uid() or v_status<>'APPROVED' then return jsonb_build_object('success',false,'message','केवल APPROVED और authenticated member complaint दर्ज कर सकता है।'); end if;
  if nullif(trim(p_category),'') is null then return jsonb_build_object('success',false,'message','Complaint category जरूरी है।'); end if;
  if nullif(trim(p_subject),'') is null then return jsonb_build_object('success',false,'message','Complaint subject जरूरी है।'); end if;
  if nullif(trim(p_description),'') is null then return jsonb_build_object('success',false,'message','Complaint description जरूरी है।'); end if;

  v_code:='RKMS-CMP-'||extract(year from current_date)::integer||'-'||lpad(nextval('public.rkms_complaint_seq')::text,6,'0');
  -- Location is authoritative from the member profile, not from client input.
  insert into public.rkms_complaints(complaint_id,member_id,name,mobile,state,mandal,district,tehsil,block,village,category,subject,description,photo_url,document_url,status,priority,sla_due_at)
  select v_code,m.id,m.name,m.mobile,m.state,m.mandal,m.district,m.tehsil,m.block,m.village,trim(p_category),trim(p_subject),trim(p_description),p_photo_url,p_document_url,'RECEIVED','NORMAL',v_now+interval '7 days'
  from public.rkms_members m where m.id=v_current_member_id returning id into v_id;

  v_assignee:=public.rkms_select_complaint_officer(v_id);
  if v_assignee is not null then
    v_new_status:='ASSIGNED';
    update public.rkms_complaints set assigned_to=v_assignee,assigned_at=v_now,assigned_by=null,status='ASSIGNED',updated_at=v_now where id=v_id;
  else
    v_new_status:='RECEIVED';
  end if;

  insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_to,metadata)
  values(v_id,null,'RECEIVED','Complaint successfully registered.',null,v_now,'REGISTERED',auth.uid(),null,jsonb_build_object('category',trim(p_category)));

  if v_assignee is not null then
    insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_to,metadata)
    values(v_id,'RECEIVED','ASSIGNED','Automatic routing: nearest active authorized officer selected.',v_assignee,v_now,'ASSIGNMENT',auth.uid(),v_assignee,jsonb_build_object('automatic',true));

    insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
    values('नई शिकायत आपको सौंपी गई', 'शिकायत '||v_code||' आपके अधिकार क्षेत्र में कार्रवाई के लिए सौंपी गई है।', 'COMPLAINT_ASSIGNED','MEMBER',(
      select m.id::text from public.rkms_members m join public.rkms_officers o on o.member_id=m.id where o.id=v_assignee limit 1
    ), true, false, auth.uid(), 'ALL');
  else
    insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,metadata)
    values(v_id,'RECEIVED','RECEIVED','Automatic routing को कोई eligible active officer नहीं मिला; complaint queue में रखी गई है।',null,v_now,'ROUTING_FALLBACK',auth.uid(),jsonb_build_object('automatic',true));
  end if;

  insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
  values('शिकायत दर्ज हो गई', 'आपकी शिकायत '||v_code||' सफलतापूर्वक दर्ज हो गई है।', 'COMPLAINT_REGISTERED','MEMBER',v_current_member_id::text,true,false,auth.uid(),'ALL');

  return jsonb_build_object('success',true,'message','Complaint successfully registered.','id',v_id,'complaint_id',v_code,'status',v_new_status,'assigned_to',v_assignee);
end;
$function$;

create or replace function public.rkms_update_complaint(
  p_complaint_id uuid,p_new_status text,p_officer_mobile text,p_assigned_to uuid default null,
  p_remarks text default null,p_action_taken text default null,p_resolution text default null
) returns jsonb
language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare
  v_actor_officer uuid:=public.rkms_current_officer_id(); v_admin uuid:=public.rkms_current_super_admin_id();
  v_actor_user uuid:=auth.uid(); v_old text; v_code text; v_assigned uuid; v_now timestamptz:=now();
  v_check jsonb; v_assignee_check jsonb; v_new_assignee uuid; v_event text;
begin
  if v_actor_officer is null and v_admin is null then return jsonb_build_object('success',false,'message','केवल अधिकृत पदाधिकारी या Super Admin complaint update कर सकता है।'); end if;
  if p_new_status not in ('RECEIVED','ASSIGNED','UNDER_REVIEW','NEED_INFORMATION','IN_PROGRESS','ACTION_TAKEN','RESOLVED','CLOSED','REOPENED','REJECTED') then return jsonb_build_object('success',false,'message','Invalid complaint status.'); end if;
  select status,complaint_id,assigned_to into v_old,v_code,v_assigned from public.rkms_complaints where id=p_complaint_id for update;
  if v_old is null then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
  if v_admin is null then
    v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor_officer);
    if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को update करने की अनुमति नहीं है।','authorization',v_check); end if;
  end if;

  if p_new_status=v_old then return jsonb_build_object('success',false,'message','Complaint पहले से इसी status में है।'); end if;
  if v_old='RECEIVED' and p_new_status not in ('ASSIGNED','UNDER_REVIEW','REJECTED') then return jsonb_build_object('success',false,'message','RECEIVED से केवल ASSIGNED, UNDER_REVIEW या REJECTED किया जा सकता है।'); end if;
  if v_old='ASSIGNED' and p_new_status not in ('UNDER_REVIEW','NEED_INFORMATION','REJECTED') then return jsonb_build_object('success',false,'message','ASSIGNED से केवल UNDER_REVIEW, NEED_INFORMATION या REJECTED किया जा सकता है।'); end if;
  if v_old='UNDER_REVIEW' and p_new_status not in ('IN_PROGRESS','ASSIGNED','NEED_INFORMATION','REJECTED') then return jsonb_build_object('success',false,'message','UNDER_REVIEW से केवल IN_PROGRESS, ASSIGNED, NEED_INFORMATION या REJECTED किया जा सकता है।'); end if;
  if v_old='NEED_INFORMATION' and p_new_status not in ('UNDER_REVIEW','IN_PROGRESS','ASSIGNED','REJECTED') then return jsonb_build_object('success',false,'message','NEED_INFORMATION से complaint को review/action में वापस लाना जरूरी है।'); end if;
  if v_old='IN_PROGRESS' and p_new_status not in ('ACTION_TAKEN','NEED_INFORMATION','ASSIGNED','REJECTED') then return jsonb_build_object('success',false,'message','IN_PROGRESS से केवल ACTION_TAKEN, NEED_INFORMATION, ASSIGNED या REJECTED किया जा सकता है।'); end if;
  if v_old='ACTION_TAKEN' and p_new_status not in ('RESOLVED','REJECTED') then return jsonb_build_object('success',false,'message','ACTION_TAKEN से केवल RESOLVED या REJECTED किया जा सकता है।'); end if;
  if v_old='RESOLVED' and p_new_status not in ('CLOSED','REOPENED') then return jsonb_build_object('success',false,'message','RESOLVED से केवल CLOSED या REOPENED किया जा सकता है।'); end if;
  if v_old='CLOSED' and p_new_status<>'REOPENED' then return jsonb_build_object('success',false,'message','CLOSED complaint केवल REOPENED हो सकती है।'); end if;
  if v_old='REOPENED' and p_new_status not in ('UNDER_REVIEW','ASSIGNED','IN_PROGRESS') then return jsonb_build_object('success',false,'message','REOPENED complaint को review/action में वापस लाना जरूरी है।'); end if;
  if v_old='REJECTED' then return jsonb_build_object('success',false,'message','REJECTED complaint final status में है।'); end if;

  if p_new_status='ASSIGNED' then
    v_new_assignee:=coalesce(p_assigned_to,v_assigned);
    if v_new_assignee is null then return jsonb_build_object('success',false,'message','ASSIGNED status के लिए officer चुनना जरूरी है।'); end if;
    v_assignee_check:=public.rkms_can_handle_complaint(p_complaint_id,v_new_assignee);
    if coalesce((v_assignee_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','चयनित officer इस complaint को handle नहीं कर सकता।','authorization',v_assignee_check); end if;
    if v_new_assignee=p_actor_officer then null; end if;
  end if;
  if p_new_status='NEED_INFORMATION' and nullif(trim(p_remarks),'') is null then return jsonb_build_object('success',false,'message','Member से आवश्यक जानकारी मांगने का कारण लिखें।'); end if;
  if p_new_status='ACTION_TAKEN' and nullif(trim(p_action_taken),'') is null then return jsonb_build_object('success',false,'message','ACTION_TAKEN status के लिए action details जरूरी हैं।'); end if;
  if p_new_status='RESOLVED' and nullif(trim(p_resolution),'') is null then return jsonb_build_object('success',false,'message','RESOLVED status के लिए resolution details जरूरी हैं।'); end if;
  if p_new_status='REJECTED' and nullif(trim(p_remarks),'') is null then return jsonb_build_object('success',false,'message','Complaint reject करने का कारण देना जरूरी है।'); end if;
  if p_new_status='CLOSED' and nullif(trim(p_remarks),'') is null then return jsonb_build_object('success',false,'message','Complaint close करने की टिप्पणी जरूरी है।'); end if;

  v_event:=case p_new_status when 'ASSIGNED' then 'ASSIGNMENT' when 'NEED_INFORMATION' then 'NEED_INFORMATION' when 'REOPENED' then 'REOPEN' when 'CLOSED' then 'CLOSURE' when 'REJECTED' then 'REJECTION' when 'RESOLVED' then 'RESOLUTION' when 'ACTION_TAKEN' then 'ACTION' when 'IN_PROGRESS' then 'IN_PROGRESS' when 'UNDER_REVIEW' then 'REVIEW' else 'STATUS_CHANGE' end;

  update public.rkms_complaints set
    status=p_new_status,
    assigned_to=case when p_new_status='ASSIGNED' then v_new_assignee when p_new_status='REOPENED' and v_assigned is null then public.rkms_select_complaint_officer(id) else assigned_to end,
    assigned_at=case when p_new_status='ASSIGNED' then coalesce(assigned_at,v_now) when p_new_status='REOPENED' and assigned_to is null then v_now else assigned_at end,
    assigned_by=case when p_new_status='ASSIGNED' then coalesce(v_actor_officer,assigned_by) else assigned_by end,
    first_reviewed_at=case when p_new_status='UNDER_REVIEW' and first_reviewed_at is null then v_now else first_reviewed_at end,
    action_taken=case when p_action_taken is not null then nullif(trim(p_action_taken),'') else action_taken end,
    action_at=case when p_new_status='ACTION_TAKEN' then v_now else action_at end,
    resolution=case when p_resolution is not null then nullif(trim(p_resolution),'') else resolution end,
    resolved_at=case when p_new_status='RESOLVED' then v_now else resolved_at end,
    closed_at=case when p_new_status='CLOSED' then v_now else closed_at end,
    reopened_at=case when p_new_status='REOPENED' then v_now else reopened_at end,
    needs_information_reason=case when p_new_status='NEED_INFORMATION' then nullif(trim(p_remarks),'') when p_new_status in ('UNDER_REVIEW','IN_PROGRESS','ASSIGNED') then null else needs_information_reason end,
    updated_at=v_now
  where id=p_complaint_id;

  insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata)
  values(p_complaint_id,v_old,p_new_status,nullif(trim(p_remarks),''),v_actor_officer,v_now,v_event,v_actor_user,v_assigned,case when p_new_status='ASSIGNED' then v_new_assignee else v_assigned end,jsonb_build_object('action_taken',p_action_taken,'resolution',p_resolution));

  -- Member gets every material lifecycle update.
  insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
  select case p_new_status when 'UNDER_REVIEW' then 'शिकायत समीक्षा में है' when 'NEED_INFORMATION' then 'शिकायत के लिए जानकारी आवश्यक है' when 'IN_PROGRESS' then 'शिकायत पर कार्रवाई चल रही है' when 'ACTION_TAKEN' then 'शिकायत पर कार्रवाई की गई' when 'RESOLVED' then 'शिकायत का समाधान दर्ज हुआ' when 'CLOSED' then 'शिकायत बंद कर दी गई' when 'REOPENED' then 'शिकायत फिर से खोल दी गई' when 'REJECTED' then 'शिकायत अस्वीकृत हुई' when 'ASSIGNED' then 'शिकायत अधिकारी को सौंपी गई' else 'शिकायत स्थिति अपडेट' end,
    'शिकायत '||v_code||' की स्थिति अब '||p_new_status||' है।', 'COMPLAINT_STATUS','MEMBER',c.member_id::text,true,false,v_actor_user,'ALL'
  from public.rkms_complaints c where c.id=p_complaint_id;

  return jsonb_build_object('success',true,'message','Complaint successfully updated.','complaint_id',v_code,'old_status',v_old,'new_status',p_new_status,'assigned_to',case when p_new_status='ASSIGNED' then v_new_assignee else v_assigned end,'updated_at',v_now);
end;
$function$;

create or replace function public.rkms_transfer_complaint(p_complaint_id uuid,p_new_officer_id uuid,p_officer_mobile text,p_remarks text)
returns jsonb language plpgsql security definer set search_path=public,pg_catalog
as $function$
declare
  v_actor uuid:=public.rkms_current_officer_id(); v_admin uuid:=public.rkms_current_super_admin_id(); v_old uuid; v_old_status text; v_code text; v_now timestamptz:=now(); v_check jsonb;
begin
  if v_actor is null and v_admin is null then return jsonb_build_object('success',false,'message','केवल अधिकृत पदाधिकारी या Super Admin transfer कर सकता है।'); end if;
  if p_new_officer_id is null then return jsonb_build_object('success',false,'message','नया officer चुनना जरूरी है।'); end if;
  if nullif(trim(p_remarks),'') is null then return jsonb_build_object('success',false,'message','Transfer का कारण देना जरूरी है।'); end if;
  select assigned_to,status,complaint_id into v_old,v_old_status,v_code from public.rkms_complaints where id=p_complaint_id for update;
  if v_old_status is null then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
  if v_old_status in ('CLOSED','REJECTED') then return jsonb_build_object('success',false,'message','Final status वाली complaint transfer नहीं की जा सकती।'); end if;
  if v_admin is null then
    v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor);
    if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को transfer करने की अनुमति नहीं है।'); end if;
  end if;
  v_check:=public.rkms_can_handle_complaint(p_complaint_id,p_new_officer_id);
  if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','नया officer इस complaint को handle नहीं कर सकता।','authorization',v_check); end if;
  if v_old=p_new_officer_id then return jsonb_build_object('success',false,'message','Complaint पहले से इसी officer को assigned है।'); end if;

  update public.rkms_complaints set assigned_to=p_new_officer_id,assigned_at=v_now,assigned_by=coalesce(v_actor,assigned_by),status='ASSIGNED',updated_at=v_now where id=p_complaint_id;
  insert into public.rkms_complaint_history(complaint_id,old_status,new_status,remarks,changed_by,created_at,event_type,actor_user_id,assigned_from,assigned_to,metadata)
  values(p_complaint_id,v_old_status,'ASSIGNED','Complaint transferred. '||trim(p_remarks),v_actor,v_now,'TRANSFER',auth.uid(),v_old,p_new_officer_id,jsonb_build_object('reason',trim(p_remarks)));

  insert into public.rkms_notifications(title,body,notification_type,target_type,target_value,is_important,is_public,publisher_auth_user_id,target_audience)
  select 'शिकायत आपको सौंपी गई','शिकायत '||v_code||' आपको कार्रवाई के लिए सौंपी गई है।','COMPLAINT_TRANSFER','MEMBER',m.id::text,true,false,auth.uid(),'ALL'
  from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=p_new_officer_id limit 1;

  return jsonb_build_object('success',true,'message','Complaint successfully transferred.','complaint_id',v_code,'old_assigned_to',v_old,'new_assigned_to',p_new_officer_id,'status','ASSIGNED','updated_at',v_now);
end;
$function$;

create or replace function public.rkms_get_complaint_details(p_complaint_id uuid,p_officer_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare v_check jsonb; v_data jsonb; v_admin uuid:=public.rkms_current_super_admin_id();
begin
  if v_admin is null then
    v_check:=public.rkms_can_handle_complaint(p_complaint_id,p_officer_id);
    if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint को देखने की अनुमति नहीं है।'); end if;
  end if;
  select jsonb_build_object('id',c.id,'complaint_id',c.complaint_id,'member_id',c.member_id,'name',c.name,'mobile',c.mobile,'state',c.state,'mandal',c.mandal,'district',c.district,'tehsil',c.tehsil,'block',c.block,'village',c.village,'category',c.category,'subject',c.subject,'description',c.description,'photo_url',c.photo_url,'document_url',c.document_url,'status',c.status,'priority',c.priority,'sla_due_at',c.sla_due_at,'assigned_to',c.assigned_to,'assigned_at',c.assigned_at,'first_reviewed_at',c.first_reviewed_at,'action_taken',c.action_taken,'resolution',c.resolution,'needs_information_reason',c.needs_information_reason,'created_at',c.created_at,'updated_at',c.updated_at,'resolved_at',c.resolved_at,'closed_at',c.closed_at,'reopened_at',c.reopened_at,'against_officer_id',c.against_officer_id,'assigned_officer',case when ao.id is null then null else jsonb_build_object('id',ao.id,'name',am.name,'mobile',am.mobile,'post_name',ap.post_name,'authority_level',ao.authority_level,'state',ao.state,'mandal',ao.mandal,'district',ao.district,'tehsil',ao.tehsil,'block',ao.block) end) into v_data
  from public.rkms_complaints c
  left join public.rkms_officers ao on ao.id=c.assigned_to
  left join public.rkms_members am on am.id=ao.member_id
  left join public.rkms_posts ap on ap.id=ao.post_id
  where c.id=p_complaint_id;
  if v_data is null then return jsonb_build_object('success',false,'message','Complaint नहीं मिली।'); end if;
  return jsonb_build_object('success',true,'data',v_data);
end;
$function$;

create or replace function public.rkms_get_complaint_visible_officers(p_complaint_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare v_actor uuid:=public.rkms_current_officer_id(); v_admin uuid:=public.rkms_current_super_admin_id(); v_check jsonb; v_data jsonb;
begin
  if v_admin is null then
    if v_actor is null then return jsonb_build_object('success',false,'message','Current ACTIVE officer नहीं मिला।'); end if;
    v_check:=public.rkms_can_handle_complaint(p_complaint_id,v_actor);
    if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint के officers देखने की अनुमति नहीं है।'); end if;
  end if;
  select coalesce(jsonb_agg(jsonb_build_object('officer_id',o.id,'member_id',o.member_id,'name',m.name,'mobile',m.mobile,'post_id',o.post_id,'post_name',p.post_name,'authority_level',o.authority_level,'state',o.state,'mandal',o.mandal,'district',o.district,'tehsil',o.tehsil,'block',o.block,'village',o.village,'appointment_no',o.appointment_no) order by case upper(o.authority_level) when 'BLOCK' then 1 when 'TEHSIL' then 2 when 'DISTRICT' then 3 when 'MANDAL' then 4 when 'STATE' then 5 when 'NATIONAL' then 6 else 99 end,case when lower(coalesce(p.post_name,'')) like '%president%' or p.post_name like '%अध्यक्ष%' then 0 else 1 end,o.created_at),'[]'::jsonb) into v_data
  from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
  where o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date)
    and public.rkms_can_handle_complaint(p_complaint_id,o.id)->>'allowed'='true';
  return jsonb_build_object('success',true,'data',v_data);
end;
$function$;


create or replace function public.rkms_get_complaint_history(p_complaint_id uuid,p_officer_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare v_check jsonb; v_admin uuid:=public.rkms_current_super_admin_id();
begin
  if v_admin is null then
    v_check:=public.rkms_can_handle_complaint(p_complaint_id,p_officer_id);
    if coalesce((v_check->>'allowed')::boolean,false)=false then return jsonb_build_object('success',false,'message','इस complaint की history देखने की अनुमति नहीं है।'); end if;
  end if;
  return jsonb_build_object('success',true,'data',coalesce((select jsonb_agg(jsonb_build_object('id',h.id,'complaint_id',h.complaint_id,'old_status',h.old_status,'new_status',h.new_status,'remarks',h.remarks,'changed_by',h.changed_by,'actor_user_id',h.actor_user_id,'event_type',h.event_type,'assigned_from',h.assigned_from,'assigned_to',h.assigned_to,'metadata',h.metadata,'created_at',h.created_at) order by h.created_at asc,h.id asc) from public.rkms_complaint_history h where h.complaint_id=p_complaint_id),'[]'::jsonb));
end;
$function$;

create or replace function public.rkms_get_current_member_complaint_details(p_complaint_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare v_member_id uuid; v_data jsonb;
begin
  v_member_id:=public.rkms_current_member_id();
  if p_complaint_id is null or v_member_id is null then return jsonb_build_object('success',false,'message','Complaint या current member नहीं मिला।'); end if;
  select jsonb_build_object('id',c.id,'complaint_id',c.complaint_id,'member_id',c.member_id,'name',c.name,'mobile',c.mobile,'state',c.state,'mandal',c.mandal,'district',c.district,'tehsil',c.tehsil,'block',c.block,'village',c.village,'category',c.category,'subject',c.subject,'description',c.description,'photo_url',c.photo_url,'document_url',c.document_url,'status',c.status,'priority',c.priority,'sla_due_at',c.sla_due_at,'assigned_to',c.assigned_to,'assigned_at',c.assigned_at,'action_taken',c.action_taken,'resolution',c.resolution,'needs_information_reason',c.needs_information_reason,'created_at',c.created_at,'updated_at',c.updated_at,'resolved_at',c.resolved_at,'closed_at',c.closed_at,'reopened_at',c.reopened_at,'assigned_officer',case when ao.id is null then null else jsonb_build_object('id',ao.id,'name',am.name,'post_name',ap.post_name,'authority_level',ao.authority_level) end) into v_data
  from public.rkms_complaints c left join public.rkms_officers ao on ao.id=c.assigned_to left join public.rkms_members am on am.id=ao.member_id left join public.rkms_posts ap on ap.id=ao.post_id
  where c.id=p_complaint_id and c.member_id=v_member_id;
  if v_data is null then return jsonb_build_object('success',false,'message','यह complaint आपके member account से जुड़ी नहीं है या उपलब्ध नहीं है।'); end if;
  return jsonb_build_object('success',true,'data',v_data);
end;
$function$;

create or replace function public.rkms_get_current_member_complaint_history(p_complaint_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public,pg_catalog
as $function$
declare v_member_id uuid;
begin
  v_member_id:=public.rkms_current_member_id();
  if v_member_id is null then return jsonb_build_object('success',false,'message','Current member नहीं मिला।'); end if;
  if not exists(select 1 from public.rkms_complaints c where c.id=p_complaint_id and c.member_id=v_member_id) then return jsonb_build_object('success',false,'message','यह complaint आपके member account से जुड़ी नहीं है।'); end if;
  return jsonb_build_object('success',true,'data',coalesce((select jsonb_agg(jsonb_build_object('id',h.id,'old_status',h.old_status,'new_status',h.new_status,'remarks',h.remarks,'event_type',h.event_type,'assigned_to',h.assigned_to,'metadata',h.metadata,'created_at',h.created_at) order by h.created_at asc,h.id asc) from public.rkms_complaint_history h where h.complaint_id=p_complaint_id),'[]'::jsonb));
end;
$function$;

-- Extend the existing notification push trigger without copying its deployment secret into source control.
do $$
declare v_def text; v_old text; v_new text;
begin
  select pg_get_functiondef(p.oid) into v_def from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='rkms_enqueue_notification_push' and p.pronargs=0 limit 1;
  if v_def is null then raise exception 'rkms_enqueue_notification_push not found'; end if;
  v_old := $old$upper(coalesce(new.target_type,'ALL'))='ALL'
          or (upper(new.target_type)='STATE'$old$;
  v_new := $new$upper(coalesce(new.target_type,'ALL'))='ALL'
          or (upper(new.target_type)='MEMBER' and lower(coalesce(new.target_value,''))=lower(m.id::text))
          or (upper(new.target_type)='STATE'$new$;
  if position(v_new in v_def)=0 then
    if position(v_old in v_def)=0 then raise exception 'notification push recipient predicate not found'; end if;
    v_def:=replace(v_def,v_old,v_new);
    execute v_def;
  end if;
end $$;

revoke all on function public.rkms_select_complaint_officer(uuid) from public,anon,authenticated;
revoke all on function public.rkms_can_handle_complaint(uuid,uuid) from public,anon;
revoke all on function public.rkms_register_complaint(uuid,text,text,text,text,text,text,text,text,text,text,text) from public,anon;
revoke all on function public.rkms_update_complaint(uuid,text,text,uuid,text,text,text) from public,anon;
revoke all on function public.rkms_transfer_complaint(uuid,uuid,text,text) from public,anon;
revoke all on function public.rkms_get_complaint_details(uuid,uuid) from public,anon;
revoke all on function public.rkms_get_complaint_visible_officers(uuid) from public,anon;
grant execute on function public.rkms_can_handle_complaint(uuid,uuid) to authenticated;
grant execute on function public.rkms_register_complaint(uuid,text,text,text,text,text,text,text,text,text,text,text) to authenticated;
grant execute on function public.rkms_update_complaint(uuid,text,text,uuid,text,text,text) to authenticated;
grant execute on function public.rkms_transfer_complaint(uuid,uuid,text,text) to authenticated;
grant execute on function public.rkms_get_complaint_details(uuid,uuid) to authenticated;
grant execute on function public.rkms_get_complaint_visible_officers(uuid) to authenticated;
