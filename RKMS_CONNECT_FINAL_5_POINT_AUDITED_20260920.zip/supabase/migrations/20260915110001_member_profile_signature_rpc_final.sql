-- RKMS CONNECT FINAL: expose member self-signature in current member profile.
create or replace function public.rkms_get_current_member_profile()
returns jsonb
language plpgsql
stable
security definer
set search_path to 'public','pg_catalog'
as $$
declare
  v_id uuid;
  v_member jsonb;
begin
  v_id:=public.rkms_current_member_id();
  if v_id is null then
    return jsonb_build_object('success',false,'message','इस login से कोई member नहीं मिला।');
  end if;
  select jsonb_build_object(
    'id',m.id,'member_id',m.member_id,'username',m.username,'name',m.name,
    'father_name',m.father_name,'mobile',m.mobile,'whatsapp',m.whatsapp,
    'email',m.email,'photo_url',m.photo_url,'signature_url',m.signature_url,
    'gender',m.gender,'date_of_birth',m.date_of_birth,'pincode',m.pincode,
    'post_office',m.post_office,'pin_address',m.pin_address,
    'aadhaar_document_path',m.aadhaar_document_path,'state',m.state,
    'mandal',m.mandal,'district',m.district,'tehsil',m.tehsil,'block',m.block,
    'village',m.village,'gram_panchayat',m.gram_panchayat,'address',m.address,
    'membership_type',m.membership_type,'status',m.status
  ) into v_member
  from public.rkms_members m
  where m.id=v_id and m.status='APPROVED';
  return jsonb_build_object('success',true,'member',v_member);
end;
$$;

grant execute on function public.rkms_get_current_member_profile() to authenticated;
