-- RKMS CONNECT FINAL: allow an authenticated member to upload only their own profile signature.
drop policy if exists "rkms member signature upload own" on storage.objects;
create policy "rkms member signature upload own"
on storage.objects for insert to authenticated
with check (
  bucket_id='rkms-media'
  and name like 'member-signatures/' || rkms_current_member_id()::text || '/%'
);
