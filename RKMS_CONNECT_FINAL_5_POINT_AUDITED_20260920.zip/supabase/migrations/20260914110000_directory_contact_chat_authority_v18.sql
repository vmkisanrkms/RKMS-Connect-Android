-- V18: Directory Call + Message parity and server-side chat authorization.
-- Existing role/geography rules remain authoritative. UI visibility is not security.

create or replace function public.rkms_chat_open(
  p_actor_type text,
  p_other_type text,
  p_other_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_catalog
as $function$
declare
  actor text := upper(coalesce(p_actor_type,''));
  typ text := upper(coalesce(p_other_type,''));
  me uuid;
  target uuid;
  cid uuid;
  target_officer uuid;
  actor_officer uuid;
begin
  if auth.uid() is null then
    return jsonb_build_object('success',false,'message','Login जरूरी है।');
  end if;

  me := public.rkms_chat_current_person_member_id();
  if me is null then
    return jsonb_build_object('success',false,'message','Approved member login जरूरी है।');
  end if;

  if typ='MEMBER' then
    select m.id into target
    from public.rkms_members m
    where m.id=p_other_id
      and upper(coalesce(m.status,''))='APPROVED';
  elsif typ='OFFICER' then
    select o.member_id,o.id into target,target_officer
    from public.rkms_officers o
    join public.rkms_members m on m.id=o.member_id
    where o.id=p_other_id
      and upper(coalesce(o.status,''))='ACTIVE'
      and upper(coalesce(m.status,''))='APPROVED';
  else
    return jsonb_build_object('success',false,'message','Invalid participant type.');
  end if;

  if target is null or target=me then
    return jsonb_build_object('success',false,'message','सदस्य उपलब्ध नहीं है।');
  end if;

  if actor='OFFICER' then
    actor_officer := public.rkms_chat_actor_officer_id();
    if actor_officer is null then
      return jsonb_build_object('success',false,'message','Active PDA अधिकारी login जरूरी है।');
    end if;

    if not public.rkms_is_top_authority() then
      if typ='MEMBER' then
        if not public.rkms_chat_officer_can_access_member(actor_officer,target) then
          return jsonb_build_object('success',false,'message','इस सदस्य से संपर्क करने का अधिकार आपके क्षेत्र में नहीं है।');
        end if;
      elsif typ='OFFICER' then
        if target_officer is null or not public.rkms_can_manage_officer(actor_officer,target_officer) then
          return jsonb_build_object('success',false,'message','इस पदाधिकारी से संपर्क करने का अधिकार आपके क्षेत्र में नहीं है।');
        end if;
      end if;
    end if;
  end if;

  -- Preserve the existing ordinary-member restriction for National President.
  if exists(
    select 1
    from public.rkms_officers o
    join public.rkms_posts p on p.id=o.post_id
    where o.member_id=target
      and upper(coalesce(o.status,''))='ACTIVE'
      and upper(coalesce(p.level,''))='NATIONAL'
      and trim(coalesce(p.post_name,''))='राष्ट्रीय अध्यक्ष'
  ) and actor='MEMBER' then
    return jsonb_build_object('success',false,'message','साधारण Member को राष्ट्रीय अध्यक्ष से Chat की अनुमति नहीं है।');
  end if;

  select c.id into cid
  from public.rkms_chat_conversations c
  where c.group_id is null
    and c.person_a_member_id=least(me,target)
    and c.person_b_member_id=greatest(me,target)
  order by c.updated_at desc
  limit 1;

  if cid is null then
    insert into public.rkms_chat_conversations(member_id,member_recipient_id)
    values(me,target)
    returning id into cid;
  end if;

  return jsonb_build_object('success',true,'conversation_id',cid);
end;
$function$;

revoke execute on function public.rkms_chat_open(text,text,uuid) from anon;
grant execute on function public.rkms_chat_open(text,text,uuid) to authenticated;
