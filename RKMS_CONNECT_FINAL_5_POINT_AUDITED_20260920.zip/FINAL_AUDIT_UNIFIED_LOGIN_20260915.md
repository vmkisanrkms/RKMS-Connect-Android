# RKMS CONNECT — Unified Login / Guest Navigation Final Audit

Date: 2026-09-15
Source baseline: `RKMS_MEMBER_PDA_FINAL_WORKFLOW_FIXED.zip`

## Change policy
Only the requested end-user changes were applied. Existing organization, complaint, directory, authority, FCM, PDF, appointment, and Digital ID code was otherwise left unchanged.

## Requested points verified
1. **Guest bottom navigation:** completely hidden. Guest no longer gets the bottom Member button or any other bottom navigation item.
2. **Authenticated bottom navigation:** existing bottom navigation remains available for logged-in Member/PDA users; no removal was applied to their current navigation.
3. **Single public Login label:** Home/header now show only `Login`, not `सदस्य/पदाधिकारी लॉगिन`.
4. **Book → Events:** Home now loads and displays a compact upcoming `कार्यक्रम` section immediately below the book section, with a link to all events.
5. **Digital ID signer:** existing Digital ID signer resolution was preserved and verified: membership approval signer / appointing PDA name, post and signature are resolved from backend metadata and rendered where applicable.
6. **One Login flow:** the old separate Member/Officer choice is bypassed. The same Login screen accepts Mobile/Email + Password. After authentication, the live backend identity is re-resolved. If the account is an active PDA officer, it opens the PDA Dashboard; otherwise it opens the Member Dashboard; Super Admin still opens the Admin dashboard. The legacy `#officer-login` route is mapped back to the same unified Login screen so a second credential form cannot be reached.
7. **Role upgrade:** when an approved Member is also an active PDA officer, the same account is automatically resolved as `officer` and receives the existing PDA dashboard without a second login.

## Regression/static audit results
- JavaScript syntax: PASS (`node --check app.js`)
- Final Login/Navigation audit: **19/19 PASS**
- RKMS final static verification: PASS
- Authority hierarchy verification: PASS
- Member/PDA scope verification: PASS
- Directory contact-action verification: 11/11 PASS
- Directory list verification: PASS
- Directory deep verification: PASS
- PDF pipeline static verification: PASS
- Report download scope verification: PASS
- Web build script: PASS (`npm run build`; dependencies were already sufficient in the runtime)

## Intentionally not changed
- Existing authenticated Member/PDA bottom navigation layout.
- Existing backend authorization/RLS migrations.
- Existing complaint, FCM, PDF, report, directory, appointment and notification workflows.
- Existing Digital ID backend signer migrations.

## Build-environment note
Some legacy verification scripts in the package expect generated Android files (for example `android/variables.gradle`) or an older workflow filename. Those files are generated/used by the GitHub Actions workflow and are not present in the source ZIP baseline, so those specific scripts cannot be executed meaningfully against the raw source directory. This does not indicate a regression in the requested changes.
