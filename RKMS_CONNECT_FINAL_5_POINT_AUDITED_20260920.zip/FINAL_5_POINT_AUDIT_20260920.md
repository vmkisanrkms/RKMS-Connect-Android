# RKMS CONNECT — Final 5-Point Source Audit — 20 Sep 2026

## Requested fixes

1. Chat composer को bottom footer से सही दूरी पर रखना.
2. Digital ID में नियुक्तिकर्ता की जानकारी सही दिखाना.
3. Digital ID / नियुक्ति पत्र / सदस्यता प्रमाण-पत्र का Android PDF live phone rendering से लेना, ताकि Download PDF live screen के समान रहे.
4. Android WebView voice recording को robust microphone permission + multi-constraint retry के साथ ठीक करना.
5. Group Admin / Super Admin को Group का नाम बदलने का secure option देना.

## Implemented

- Composer अब conversation viewport के अंदर flow में रहता है; bottom footer को fixed 62px box के रूप में reserve किया गया है और duplicate safe-area bottom padding हटाई गई है.
- Digital ID appointing-authority resolution अब National President appointment में भी नाम/post/signature लौटाता है; UI empty authority block नहीं छिपाता.
- Android PDF download में native `captureCurrentDocumentAsPdf()` bridge जोड़ा गया है. यह live WebView-rendered document को PDF में capture करता है; पुराने manual leaf-text canvas renderer को Android download path पर bypass किया जाता है. Web fallback renderer बरकरार है.
- Voice recording में minimal `{audio:true}` capture पहले try होता है, फिर Android-safe constraint variants; source errors पर retry और सभी tracks cleanup किया जाता है.
- Group rename के लिए server-side 6-argument `rkms_chat_group_manage(..., p_group_name)` action `RENAME` जोड़ा गया है. केवल Group Admin/Super Admin rename कर सकते हैं; नाम 1–80 characters तक सीमित है.

## Verification performed

All repository `scripts/verify-*.py` checks pass, including:

- Android 16/API 36
- Android PDF bridge
- Chat + microphone
- Authority hierarchy
- Complaint workflow
- Content management
- Directory/contact actions
- Directory lists/scope
- FCM pipeline
- Login/navigation
- Native bridge
- PDF pipeline
- Profile update
- Report download scope
- Saved login
- Final RKMS fixes

`node --check app.js` also passes and `bash -n scripts/setup-android-native.sh` passes.

## Supabase state

Production project has the 6-argument Group Management function in addition to the legacy 5-argument function, and the Digital ID metadata function is updated for National President appointing-authority visibility.

## Important runtime note

Static/source verification cannot substitute for installing the resulting Release APK on the Motorola Edge 50 Pro. The final APK must be installed and these five flows should be tapped once on-device: composer/footer position, Digital ID authority, Digital ID/appointment PDF, microphone recording, and Group Rename. No source audit can honestly certify those device-only outcomes without that APK runtime test.
