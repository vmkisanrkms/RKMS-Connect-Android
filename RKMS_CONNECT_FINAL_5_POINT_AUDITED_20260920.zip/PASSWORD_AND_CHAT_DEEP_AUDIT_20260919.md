# RKMS CONNECT — Chat + PDA Password Deep Audit
Date: 2026-09-19

## Chat layout
- Chat is rendered inside `#app`; the global RKMS site header and fixed bottom navigation remain outside it.
- Chat and conversation screens no longer use `position: fixed; inset: 0; z-index: 500`, so they cannot cover the global header/footer.
- Chat remains a self-contained WhatsApp-style module with search, filters, recent chats, New Chat, New Group, conversation, attachments, voice, and message actions.
- Team RKMS identity/logo logic is retained from the Team RKMS build and its Supabase migration.

## Password controls
- Normal PDA appointment uses `rkms_verify_current_password` before `rkms_appoint_officer`.
- Normal PDA reappointment uses `rkms_verify_current_password` before `rkms_reappoint_officer`.
- Member deletion requires the current login password and confirmation before the secure delete endpoint is called.
- Super Admin PDA appointment now requires current login password.
- Super Admin PDA reappointment now requires current login password.
- Super Admin PDA officer removal now requires current login password.
- The previous passwordless Super Admin appointment/reappointment RPC signatures were renamed to `_legacy` and direct `PUBLIC`, `anon`, and `authenticated` execution was revoked.
- The secure Super Admin RPCs accept `p_password` and are executable by `authenticated` only.

## Static verification
- `node --check app.js`: PASS
- RKMS final verification: PASS
- PDA authority hierarchy: PASS
- Directory/contact authorization: PASS
- FCM pipeline: PASS
- Final login/navigation: 19/19 PASS
- Member/PDA final scope: PASS
- Native bridge: PASS
- Saved login: PASS
- Report download scope: PASS
- V17 directory deep audit: PASS

## Live database verification
- Secure Super Admin appointment RPC exists with `p_password`.
- Secure Super Admin reappointment RPC exists with `p_password`.
- `rkms_update_officer_status` verifies the current password for Super Admin and normal officers.
- Legacy passwordless RPCs have no execute privilege for `PUBLIC`, `anon`, or `authenticated`.
- Secure RPCs are granted to `authenticated`.

## Not claimed
- A real-device APK/AAB install test and a two-account live Chat send/receive test require the generated build and authenticated devices. This source audit does not claim those tests were executed.


## Final correction — 2026-09-19
- PDA appointment: current Login Password required for Normal Officer and Super Admin.
- PDA reappointment/post change: current Login Password required for Normal Officer and Super Admin.
- PDA removal/status change: current Login Password required for Normal Officer and Super Admin.
- Chat: WhatsApp-style list/conversation UI remains inside the common app shell; the Chat screen no longer uses a full-viewport fixed overlay, so the common RKMS header/footer remain visible.
- Super Admin: Chat option removed from the bottom navigation and Super Admin dashboard; direct Chat route is blocked/redirected.
- Team RKMS: retained for Member/Officer Chat flows.
- Static JavaScript syntax check: PASS.
- Device visual verification of the newly packaged APK is still required before release.
