# RKMS CONNECT V16.2 — Member + Officer Directory Deep Audit

## Scope lock
Only these flows were changed:
- Member List + Member Detail
- Officer/PDA List + Officer Detail
- Search, filters, card/compact view, and list/detail actions directly related to those two directories

Dashboard, Reports, Chat, Notifications, Digital ID, Book, Login/Saved Login and unrelated app flows were not redesigned.

## Member List
- Guest: blocked; Member List requires authenticated member/officer/admin session.
- Approved Member: safe/basic directory view only; no delete/management.
- PDA Officer: backend-scoped Approved members; detail may expose management-only contact fields; Delete is available only from Member Detail for National/State/Mandal/District authority levels, matching the existing secure delete rule.
- Super Admin / National President: full directory/detail management.
- Search: name, Member ID and visible area text; Enter and button both work; live debounce filtering.
- Filters: State → District → Tehsil → Block → Village cascading; Membership Type; result count updates.
- View toggle: Card / Compact.
- List has no member-selection checkbox, no bulk delete, and no direct delete button.
- Member Detail is the only place where Delete is rendered for an authorized actor.
- Existing secure delete endpoint/password confirmation/audit flow is reused.

## Officer/PDA List
- Guest: public active-officer directory; view/search/filter/detail only.
- Approved Member: same public view; no management actions.
- PDA Officer: management directory containing only officers that the current PDA can manage under the existing strictly-lower-level + geographic-scope rule.
- Super Admin / National President: full active-officer management directory.
- Search: name, post, Member ID and visible area text; Enter and button both work; live debounce filtering.
- Filters: authority level, State, District, Wing/Cell.
- View toggle: Card / Compact.
- Eligible management actor gets `नई नियुक्ति` shortcut and Officer Detail actions.
- Officer Detail actions: `पद बदलें` opens the existing appointment flow in reappointment mode; `पद से हटाएँ` performs a confirmation and calls the existing backend status update after a client-side scope check.
- Public Officer Detail hides appointment number, joining date, Member ID and appointing-authority fields; management users can see them.

## Security / authority checks
- Existing `rkmsOfficerCanManageTarget()` remains the management gate.
- Existing `rkmsOfficerCanAccessTarget()` remains the officer-detail access gate.
- Member detail now correctly uses `rkmsOfficerCanAccessMember()` instead of treating a member as an officer target.
- Backend `rkms_directory_members` continues to enforce private-field visibility and officer geographic scope.
- No Wing restriction was introduced into the hierarchy rule.
- Equal/higher officer levels are not placed in a normal PDA management list.

## Delete UI change
All member-list checkbox/bulk-delete UI was removed, including the old pending-list checkbox delete controls. Delete is detail-only.

## Static verification
- `node --check app.js`: PASS
- production `npm run build`: PASS
- directory-list verification: PASS
- PDA authority hierarchy verification: PASS
- report-download scope verification: PASS
- saved-login verification: PASS
- FCM pipeline verification: PASS
- PDF pipeline verification: PASS
- final static verification: PASS
- no legacy member-delete checkbox/bulk-delete selectors remain: PASS
- dashboard function bodies unchanged by this directory release: PASS

## Not claimed
A real authenticated Supabase/Android-device tap test cannot be claimed from this ZIP-only static environment. Final device verification should test one Guest, one Approved Member, one PDA at each relevant authority level, and Super Admin/National President against live data before production release.
