# RKMS CONNECT — Professional Chat UI Fix — 2026-09-19

- Reduced the excessive vertical space at the top of the Chat module.
- Kept the global RKMS header and bottom navigation visible.
- Chat viewport now reserves space for both the common top header and fixed bottom navigation.
- Recent-chat rows use fixed vertical geometry so names, role and latest-message text do not jump up/down between rows.
- Avatar, name/role/preview and date/menu columns are aligned consistently.
- Search and filter controls were compacted for a cleaner mobile layout.
- No Supabase/database, authentication, PDA password, Digital ID, membership or chat authorization logic was changed.
- Chat behavior and data flow remain unchanged; this is a UI/layout-only patch.
