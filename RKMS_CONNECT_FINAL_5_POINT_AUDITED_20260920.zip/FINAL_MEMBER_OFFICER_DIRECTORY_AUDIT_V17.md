# RKMS CONNECT V17 — Member + PDA/Officer Directory Final Deep Audit

## Scope lock
Only these areas were changed:
- Member List
- Member Detail actions related to the list
- PDA/Officer List
- Officer Detail actions related to the list
- Search/filter/view behavior for these lists
- Directory-specific public/private RPC hardening

Dashboard and unrelated app flows were not changed.

## Member List
- Guest: route is blocked; anonymous member-directory RPC returns an empty safe result.
- Approved Member: can view safe member directory fields and member detail; private contact fields are not returned.
- PDA: receives only approved members inside the backend-enforced geographic scope; private fields are available only for authenticated officer use under the existing scope rules.
- Super Admin / National President: full approved-member directory access.
- Search: name, Member ID and visible card text.
- Filters: State, Mandal, District, Tehsil, Block, Village, Membership Type, Wing/Cell (when data exists), Photo/No Photo.
- Views: Card and Compact.
- Delete: no checkbox, no bulk delete, no list-level delete. Delete is available only from Member Detail for authorized actors.
- Delete confirmation keeps password verification and the existing secure delete endpoint.

## PDA/Officer List
- Guest: safe public officer directory only.
- Approved Member: safe public officer directory only.
- PDA: officers inside the PDA's geographic access scope are visible; management actions are shown only when the PDA can manage that target.
- Super Admin / National President: full officer list and unrestricted management according to existing highest-authority rules.
- Search: name, post, Member ID and visible area text.
- Filters: Post Level, State, Mandal, District, Tehsil, Block, Village, Wing/Cell.
- Views: Card and Compact.
- Officer Detail: public users receive public organizational information only. Management users receive additional management metadata.
- Management actions: Appoint (where appointment permission exists), Change Post and Remove, with strict lower-level + geographic authority enforcement.
- Equal/higher-level targets are never manageable by normal PDA officers.
- Cross-Wing lower-level management remains allowed.

## Privacy hardening
A dedicated `rkms_public_active_officers()` RPC was added for Guest/member directory use. It does not return mobile/email.

`rkms_directory_members()` now refuses anonymous member-directory data. Authenticated members receive safe fields; officer/admin private fields remain subject to the existing scope rules.

## Verification performed
- `node --check app.js` — PASS
- `npm run build` — PASS
- `scripts/verify-directory-lists.py` — PASS
- `scripts/verify-v17-directory-deep.py` — PASS
- `scripts/verify-authority-hierarchy.py` — PASS
- `scripts/verify-report-download-scope.py` — PASS
- `scripts/verify-saved-login.py` — PASS
- `scripts/verify-fcm-pipeline.py` — PASS
- `scripts/verify-pdf-pipeline.py` — PASS
- `scripts/verify-rkms-final.py` — PASS
- Dashboard function comparison against V16.2 — UNCHANGED for Home, Member Dashboard, Officer Dashboard, National President Dashboard, Reports and Chat.

## Remaining external verification
Static/source audit cannot prove live Supabase behavior or real-device taps. Before production, apply the new migration and test with real accounts for:
1. Guest
2. Approved Member
3. State/Mandal/District/Tehsil/Block/Village PDA levels as applicable
4. National President
5. Super Admin

For each role, verify both visible UI and direct unauthorized URL/RPC attempts.
