# RKMS Chat Scroll/Footer Patch — 2026-09-19

Applied to the supplied RKMS CONNECT source.

- Bottom navigation reduced to a 62px footprint.
- Chat viewport reserves 76px for the global header and 62px for the fixed footer.
- Chat list is the scroll container; the last row stays above the footer.
- Single-chat messages are the scroll container between header and composer.
- Document scrolling is disabled while Chat is active, preventing the chat header from being hidden under the global header.
- This is a source/UI patch only; APK/AAB compilation is not performed here.
