# RKMS CONNECT — FINAL MASTER CHANGE & AUDIT LIST

Date: 2026-09-15

## Purpose

यह master list RKMS CONNECT के वर्तमान final ZIP को audit करके तय की गई अंतिम requirements को दर्ज करती है। इसका उद्देश्य यह सुनिश्चित करना है कि केवल तय किए गए बदलाव किए जाएँ और बाकी existing organization/app functionality को अनावश्यक रूप से न बदला जाए।

---

# A. पहले से COMPLETE — दोबारा बदलाव नहीं करना

## 1. Guest Bottom Navigation
STATUS: **COMPLETE**

- Guest के लिए bottom navigation हटाई जा चुकी है।
- Guest को नीचे Member/PDA वाला navigation नहीं दिखना चाहिए।
- Logged-in Member/PDA की existing bottom navigation को नहीं हटाना है।

## 2. Unified Login
STATUS: **COMPLETE**

- Member और PDA Officer के लिए एक ही Login flow।
- अलग Officer Login form नहीं।
- वही account Member से PDA Officer बनने पर भी इस्तेमाल होगा।
- Login के बाद backend की active role/appointment स्थिति के अनुसार dashboard खुलेगा।
- Super Admin अपने उचित Admin dashboard में जाएगा।

## 3. Home Book → कार्यक्रम
STATUS: **COMPLETE**

- Home में Book section रहेगा।
- Book के ठीक नीचे कार्यक्रम/events section रहेगा।
- Existing Book functionality को नहीं हटाना है।

---

# B. FINAL FUNCTIONAL CHANGE — Member से PDA बनने पर

## 4. Member Dashboard → PDA Officer Dashboard
STATUS: **REQUIRED FINAL CHANGE**

जब कोई व्यक्ति केवल Member है:

- Member के सभी existing options बने रहें।
- **सदस्यता प्रमाण-पत्र** दिखे।

जब उसी Member को active PDA Officer नियुक्त कर दिया जाए:

- **सदस्यता प्रमाण-पत्र हटे।**
- उसी स्थान/Member certificate option की जगह **नियुक्ति पत्र** दिखे।
- Member के बाकी सभी options **जैसे हैं वैसे ही बने रहें।**
- Member का कोई दूसरा option हटाना या replace नहीं करना है।
- PDA Officer के सभी अतिरिक्त Officer options भी उसी dashboard में जुड़ें।

### Final logic

ONLY MEMBER:

Digital ID + जानकारी अपडेट करें + शिकायत + मेरी शिकायतें + सूचनाएँ + Chat + सदस्यता प्रमाण-पत्र

MEMBER + ACTIVE PDA OFFICER:

Digital ID + जानकारी अपडेट करें + शिकायत + मेरी शिकायतें + सूचनाएँ + Chat + नियुक्ति पत्र

PLUS:

PDA Officer के सभी अतिरिक्त management/authority options।

### Important

Member → PDA transition पर नया account नहीं बनेगा।

---

# C. Profile Update

## 5. प्रोफ़ाइल अपडेट
STATUS: **IMPLEMENTED / FINAL REQUIRED OPTION — MEMBER + PDA**

Dashboard में **“जानकारी अपडेट करें / प्रोफ़ाइल अपडेट”** का एक ही option रहेगा।

इसके अंदर ये तीन मुख्य update options रहेंगे:

1. 📷 **फोटो अपडेट करें**
2. 📱 **मोबाइल नंबर अपडेट करें**
3. ✍️ **हस्ताक्षर अपडेट करें**

### Important

- Profile Update का button **एक ही बार** दिखाई देगा।
- इसके अंदर ऊपर के तीनों update options रहेंगे।
- Member और PDA Officer दोनों के लिए उपलब्ध रहेगा।
- PDA बनने पर यह option हटेगा नहीं।
- एक ही account की profile information update होगी।

### Security rule

निम्न organizational fields सामान्य profile update से नहीं बदले जाएँगे:

- नियुक्त पद
- authority level
- organizational appointment
- अधिकार क्षेत्र
- अन्य protected organizational role data

# D. Digital ID

## 6. Approving Authority Name + Signature
STATUS: **IMPLEMENTED / MUST BE RETAINED AND VERIFIED**

Digital ID में संबंधित approval/appointment के अनुसार authority की जानकारी दिखनी चाहिए:

- **नाम**
- **पद**
- **Digital Signature**

### Membership approval

सिर्फ Member होने पर Digital ID में सदस्यता स्वीकृत करने वाले अधिकारी का:

**सदस्यता अनुमोदक अधिकारी**
- नाम
- पद
- हस्ताक्षर

backend approval metadata से आए।

### PDA appointment

यदि Member active PDA Officer है, तो appointment के अनुसार:

- नियुक्तिकर्ता अधिकारी / संबंधित authority
- नाम
- पद
- हस्ताक्षर

दिखना चाहिए।

### National President / Super Admin rule

यदि appointment/approval National President authority से हुआ है, तो existing authority rule के अनुसार केवल National President authority block दिखे।

### Critical rule

नाम/signature hard-coded नहीं होने चाहिए जहाँ backend record उपलब्ध है। वास्तविक approval/appointment metadata से resolution होना चाहिए।

**Current ZIP audit note:** `renderDigitalId()` में membership approval signer और appointment signer के नाम, पद तथा signature resolution का code मौजूद है। इसलिए इस requirement को हटाना नहीं है; final build में इसका UI/runtime verification आवश्यक है।

---

# E. Member/PDA List Page

## 7. सूची चयन वाला Page
STATUS: **IMPLEMENTED IN THIS UPDATED FINAL BUILD**

वर्तमान page से निम्न ऊपर वाला text हटाना है:

- `RKMS CONNECT`
- `सदस्य / PDA अधिकारी`
- `पहले सूची का प्रकार चुनें`
- `किसकी सूची देखनी है?`
- उसके साथ वाला explanatory paragraph

इसके स्थान पर **Login page पर चल रहा वही संगठन का slogan** लगाया जाए।

### सदस्य देखें card

केवल:

**👥 सदस्य देखें**

रहे।

नीचे की पूरी description हटे:

`केवल सदस्यों की सूची, विवरण, कॉल और संदेश।`

### PDA अधिकारी देखें card

केवल:

**👤 PDA अधिकारी देखें**

रहे।

नीचे की पूरी description हटे:

`केवल PDA/पदाधिकारियों की सूची, विवरण, कॉल और संदेश।`

### Important

Card का actual route/function नहीं बदलना है:

- सदस्य देखें → existing member list
- PDA अधिकारी देखें → existing officer directory

सिर्फ requested text/layout change करना है।

**Updated build:** chooser page now uses the Login slogan carousel and removes the requested heading/descriptions while preserving the two existing routes.

---

# F. Chat

## 8. Chat Option
STATUS: **FINAL RULE**

- Dashboard में **Chat option केवल एक बार** दिखाई देगा।
- Member से PDA Officer बनने पर Chat का दूसरा duplicate button नहीं बनेगा।
- Member + PDA Dashboard में एक ही Chat option रहेगा।
- Existing Chat functionality और permissions में अनावश्यक बदलाव नहीं करना है।

# F. PDA Officer Additional Options

## 9. PDA Officer Options
STATUS: **EXISTING OFFICER FEATURES — MUST REMAIN**

PDA Officer के existing additional options हटने नहीं चाहिए, जैसे:

- सदस्य Approval
- शिकायत प्रबंधन
- पदाधिकारी प्रबंधन
- Content Management
- Reports
- पदाधिकारी निर्देशिका
- सदस्य Delete (जहाँ authority अनुमति देती है)
- मेरा Digital Signature
- मेरी Digital ID
- नियुक्ति पत्र
- Chat

इनकी authority/RLS restrictions को bypass नहीं करना है।

---

# G. Logo Protection

## 10. RKMS Organization Logo
STATUS: **LOCKED / MUST NEVER BE REMOVED**

यह सबसे महत्वपूर्ण regression-protection requirement है।

- RKMS संगठन का logo किसी screen से हटाना नहीं है।
- Header logo नहीं हटाना है।
- Digital ID का RKMS logo नहीं हटाना है।
- Android launcher का RKMS logo नहीं हटाना है।
- Existing logo assets को delete/replace नहीं करना है।
- केवल requested text/layout changes किए जाएँ।

### Build audit

Final workflow में verify होना चाहिए:

- Original RKMS logo source मौजूद है।
- सभी launcher density icons मौजूद हैं।
- Generated Android launcher icons मौजूद हैं।
- AndroidManifest में launcher references मौजूद हैं।

किसी actual RKMS logo asset के गायब होने पर build fail होना चाहिए।

---

# H. Existing Features Protection

## 11. No Unnecessary Changes
STATUS: **LOCKED**

इन existing systems को बिना अलग requirement के नहीं बदलना है:

- Complaint workflow
- FCM / notifications
- Directory
- Authority hierarchy
- RLS/backend authorization
- PDF workflow
- Reports
- Appointment workflow
- Digital ID backend
- Chat
- Existing Member features
- Existing PDA features
- Organization branding/logo

---

# I. Android Build

## 12. Android 16 / API 36
STATUS: **REQUIRED FINAL BUILD TARGET**

Final Android build:

- Android 16
- API 36
- compileSdk = 36
- targetSdk = 36
- Android platform = android-36
- Build Tools = 36.0.0
- JDK = 17
- AGP = 8.9.1
- Gradle = 8.11.1

Only the requested APK build target should be changed/verified; app functionality should not be unnecessarily modified.

---

# FINAL AUDIT STATUS

| Requirement | Status |
|---|---|
| Guest bottom navigation removed | COMPLETE |
| Unified Member/PDA Login | COMPLETE |
| Book → कार्यक्रम | COMPLETE |
| Member Dashboard existing options preserved | REQUIRED TO VERIFY |
| Member → PDA same account | COMPLETE |
| सदस्यता प्रमाण-पत्र → नियुक्ति पत्र | REQUIRED FINAL CHANGE |
| PDA additional options | EXISTING / MUST REMAIN |
| प्रोफ़ाइल अपडेट (फोटो/मोबाइल/हस्ताक्षर) | IMPLEMENTED / FINAL |
| Digital ID approving authority name | PRESENT / VERIFY |
| Digital ID approving authority post | PRESENT / VERIFY |
| Digital ID approving authority signature | PRESENT / VERIFY |
| Chat duplicate prevention | FINAL RULE — ONE OPTION ONLY |
| Member/PDA list page top text replacement | PENDING |
| Member card description removal | IMPLEMENTED |
| PDA card description removal | IMPLEMENTED |
| RKMS logo protection | LOCKED |
| Android 16 / API 36 | REQUIRED FINAL BUILD |

---

# FINAL UI RULES

### Chat
**Chat option केवल एक बार रहेगा।** Member + PDA होने पर भी दूसरा Chat button नहीं आएगा।

### Profile Update
एक ही **“प्रोफ़ाइल अपडेट / जानकारी अपडेट करें”** option रहेगा। इसके अंदर:

- **फोटो अपडेट**
- **मोबाइल नंबर अपडेट**
- **हस्ताक्षर अपडेट**

तीनों options उपलब्ध रहेंगे।

# FINAL NON-REGRESSION RULE

**Member से PDA बनने पर Member Dashboard को PDA Dashboard से replace नहीं करना है।**

सही model:

**Member Dashboard**
+
**PDA Officer के अतिरिक्त options**

केवल एक Member certificate option बदलेगा:

**सदस्यता प्रमाण-पत्र → नियुक्ति पत्र**

बाकी Member options नहीं हटेंगे।

Digital ID role/approval के अनुसार dynamic authority information दिखाएगी।

RKMS संगठन का logo और बाकी existing functionality सुरक्षित रहेगी।

**यह master list final implementation checklist के रूप में रखी जाए।**


# FINAL RE-AUDIT AFTER IMPLEMENTATION

The updated build was statically re-audited after implementing the remaining requirements.

- JavaScript syntax: PASS
- Python audit scripts syntax: PASS
- Final login/navigation audit: 19/19 PASS
- Member/PDA scope audit: PASS
- PDA authority hierarchy audit: PASS
- Directory V17 deep audit: PASS
- Directory contact/chat audit: 11/11 PASS
- Report download scope audit: PASS
- PDF pipeline audit: PASS
- RKMS final static verification: PASS
- Profile update + single Chat audit: PASS
- RKMS logo source/icon SHA256 comparison against previous ZIP: PASS

### Newly implemented in this build

- Profile Update now has independent Photo, Mobile Number, Signature, Email and Address update controls; WhatsApp is intentionally removed from this screen.
- PDA Officer Dashboard also exposes the same Profile Update control.
- Member self-profile RPC supports tightly scoped partial updates; each UI action submits only its selected field.
- Current member profile RPC now returns the member signature URL.
- Member signature upload storage policy is restricted to the current member's own folder.
- For an active PDA, Profile Update signature upload also updates the authoritative PDA signature record so Digital ID/appointment signer rendering remains consistent.
- Every profile update action requires Login Password re-verification before the update RPC is called.
- The legacy PDA "मेरा Digital Signature" dashboard option has been removed; the unified Profile Update is now the single signature-update entry point.
- Member/PDA chooser now uses the same rotating Login slogans and removes the requested explanatory text.
- Chat remains exactly one quick option per Member/PDA/authority dashboard; no duplicate Chat option is introduced.
- Workflow launcher audit no longer requires the foreground helper PNG that native setup intentionally removes; it verifies the actual RKMS logo assets and generated launcher icons instead.

### Database deployment note

The ZIP includes the required Supabase migrations. The Mobile/Signature self-service migrations were also applied and verified in the connected Supabase production project during this final repair. The application UI additionally enforces password re-verification before each profile update action.

## FINAL DEEP RE-AUDIT — 2026-09-16

- Profile Update: photo, mobile, signature, email, address are independent update actions.
- WhatsApp: removed from Profile Update UI.
- Password verification: required before each profile update action.
- Legacy PDA/National President standalone `my-signature` dashboard option: removed from dashboard UI; legacy route redirects to Profile Update.
- Member Directory: active officer-linked approved members excluded at database level.
- Officer Directory: remains separate and authorization scoped.
- JS syntax: PASS.
- Python audit scripts: PASS.
- Web build: PASS.
- Workflow YAML parse: PASS.
- FCM static audit: PASS.
- Saved-login static audit: PASS.
- Complaint workflow audit: PASS.
- Profile update audit: PASS.
- Login/navigation audit: 19/19 PASS.
- Directory/contact/report/PDF/authority audits: PASS.
- Live Supabase migration `member_directory_exclude_active_officers`: applied and verified.
- Live database currently has 44 approved members; 17 are linked to an active officer and are therefore excluded from Member Directory; 27 are eligible for Member Directory.

### APK build readiness
Source ZIP is prepared for the existing Android 16 / API 36 GitHub Actions build workflow. Generated `android/` is intentionally created during CI, so a source-only ZIP does not itself contain generated Android output. This audit does not claim a physical-device runtime test.
