# RKMS Connect — Build Ready Source

This ZIP is the complete RKMS web source package consumed by the GitHub Actions Android 16 / API 36 workflow.

## Required workflow filename

`RKMS_CONNECT_FIXED_2026-09-18.zip`

The repository workflow looks for this exact filename first.

## Included

- `package.json` / `package-lock.json`
- `app.js`, `index.html`, `styles.css`, `config.js`
- `capacitor.config.json`
- `google-services.json` for `org.rkms.connect`
- Android 16/API 36 setup scripts
- Firebase/FCM verification scripts
- Supabase migrations and Edge Functions
- RKMS book, logos, VM Singh image, signatures and other assets
- Password-verification fix using a masked password field

## Validation performed

- JavaScript syntax check: PASS
- Firebase package check: `org.rkms.connect`
- Firebase project: `rkms-connect-92413`
- Password verification RPC: `rkms_verify_current_password`
- Protected officer-management RPCs receive `p_password`

The GitHub Actions workflow remains responsible for generating the Android project, applying API 36/native/Firebase configuration, signing, and producing the final APK/AAB.
