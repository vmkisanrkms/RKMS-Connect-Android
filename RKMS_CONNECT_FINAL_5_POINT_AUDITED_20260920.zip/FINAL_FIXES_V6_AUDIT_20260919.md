# RKMS CONNECT V6 FINAL FIX AUDIT — 2026-09-19

## Applied fixes
- Removed the custom `RKMSSecureCredentials` password vault/plugin and its fingerprint/PIN saved-credential UI.
- Added AndroidX Credential Manager password-save bridge using `CreatePasswordRequest`; the configured password provider (including Google Password Manager when available) handles the save prompt.
- Kept normal Android/WebView autofill semantics (`username` / `current-password`).
- Preserved encrypted native session persistence for RKMS session tokens; this is separate from password storage.
- Kept keyboard resize, microphone/WebView permission, file picker, PDF download bridge, FCM and existing application flows.
- Removed the AAB-only GitHub Actions workflow. The remaining release workflow builds Release APK only with `assembleRelease`.
- Updated native bridge and saved-login verification scripts to validate the new Credential Manager architecture.
- Updated Android/PDF verifiers so the source ZIP can be audited correctly even though the generated `android/` directory is intentionally created during CI.

## Verification
- `node --check app.js`: PASS
- Android API 36 source/CI configuration audit: PASS
- Native PDF bridge audit: PASS
- Native bridge audit: PASS
- Credential Manager / Google Password Manager architecture audit: PASS
- FCM pipeline audit: PASS
- PDF pipeline audit: PASS
- Directory/authority/login/profile/complaint/content audits: PASS
- No `RKMSSecureCredentialsPlugin` remains in the application/native setup.
- No AAB build command remains in `.github/workflows/`.

## Important build note
The ZIP does not contain a generated `android/` project; CI generates it with Capacitor and then runs `scripts/setup-android-native.sh`. Therefore this audit verifies the generated-source setup path, not a physical-device APK run.

A real Android 16 / Motorola Edge 50 Pro runtime test is still required after the Release APK is built, especially for the Google Password Manager save prompt, microphone recording, notification delivery, and PDF Downloads behavior.
