# RKMS Notification Direct Chat Fix — 2026-09-24

- Chat notification tap uses `conversation_id` as the authoritative target.
- Duplicate Android delivery (Capacitor action + native intent) is idempotent.
- If the exact chat is already open, no second render and no second history entry is created.
- `MainActivity.onResume()` no longer re-reads the persistent Activity Intent, preventing the same notification route from being reopened repeatedly.
- PDA/important popup remains suppressed while a chat notification route is pending.
- No Supabase/database schema or data changes are required for this fix.
