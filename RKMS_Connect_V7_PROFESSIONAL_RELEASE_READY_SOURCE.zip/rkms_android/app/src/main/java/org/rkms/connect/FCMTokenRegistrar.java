package org.rkms.connect;

import android.content.Context;
import android.provider.Settings;

import com.google.firebase.messaging.FirebaseMessaging;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class FCMTokenRegistrar {
    private FCMTokenRegistrar() {}

    public static void register(Context context, String accessToken) {
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token -> registerWithToken(context, accessToken, token))
                .addOnFailureListener(e -> android.util.Log.w("RKMS_FCM", "getToken failed", e));
    }

    public static void registerWithToken(Context context, String accessToken, String token) {
        if (accessToken == null || accessToken.isEmpty() || token == null || token.isEmpty()) return;
        post(context, accessToken, "register_token", token);
    }

    public static void unregister(Context context, String accessToken) {
        if (accessToken == null || accessToken.isEmpty()) return;
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token -> {
                    if (token != null && !token.isEmpty()) post(context, accessToken, "unregister_token", token);
                });
    }

    private static void post(Context context, String accessToken, String action, String token) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL("https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-push");
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Authorization", "Bearer " + accessToken);
                String safe = token.replace("\\", "\\\\").replace("\"", "\\\"");
                String deviceId;
                try { deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID); }
                catch (Throwable ignored) { deviceId = null; }
                String deviceSafe = deviceId == null ? "" : deviceId.replace("\\", "\\\\").replace("\"", "\\\"");
                String body = "{\"action\":\"" + action + "\",\"fcm_token\":\"" + safe +
                        "\",\"device_id\":\"" + deviceSafe + "\",\"platform\":\"android\",\"app_version\":\"" + BuildConfig.VERSION_NAME + "\"}";
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                c.getOutputStream().write(bytes);
                c.getOutputStream().flush();
                c.getOutputStream().close();
                int code = c.getResponseCode();
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                if (in != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                        StringBuilder sb = new StringBuilder(); String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                        if (code >= 400) android.util.Log.w("RKMS_FCM", "Token " + action + " failed " + code + ": " + sb);
                        else android.util.Log.d("RKMS_FCM", "Token " + action + " ok: " + sb);
                    }
                }
            } catch (IOException e) {
                android.util.Log.w("RKMS_FCM", "Token " + action + " network failure", e);
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }
}
