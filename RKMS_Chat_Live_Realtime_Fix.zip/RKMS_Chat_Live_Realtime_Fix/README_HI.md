# RKMS Connect — Chat Live Realtime Fix

यह APK-side patch है। Website में कोई बदलाव नहीं किया गया है।

## क्या ठीक किया गया
- खुली हुई chat में Supabase Realtime WebSocket subscription जोड़ी गई है।
- नया INSERT message आते ही existing authorized RPC से messages re-fetch होकर chat में तुरंत render होंगे।
- UPDATE/DELETE events भी chat refresh कराते हैं।
- Realtime उपलब्ध न होने पर 3-second foreground polling fallback है, ताकि chat फिर भी refresh के बिना काम करती रहे।
- Chat छोड़ते ही WebSocket और fallback timer बंद हो जाते हैं।
- Existing FCM, login, permissions और database RPC flow को नहीं बदला गया है।

## Build
Existing Android project में `assets/www/app.js` को इस patch वाले file से replace करें और उसी existing signing configuration से APK build करें। Website deploy करने की आवश्यकता नहीं है।

## Verification
JavaScript syntax check: PASS (`node --check`).
Live Supabase Realtime delivery को इस environment में real device से end-to-end verify नहीं किया जा सका; इसलिए fallback भी रखा गया है।
