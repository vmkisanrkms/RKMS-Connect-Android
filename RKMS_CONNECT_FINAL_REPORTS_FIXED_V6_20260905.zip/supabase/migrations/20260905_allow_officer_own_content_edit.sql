-- RKMS CONNECT: allow an officer to edit/delete content they originally published.
-- This preserves the normal geographic scope checks for content created by others.
create or replace function public.rkms_content_scope_allowed(p_content_type text, p_action text, p_id uuid default null::uuid)
returns boolean
language plpgsql
stable
security definer
set search_path to 'public','pg_catalog'
as $$
declare
  v_type text:=lower(trim(coalesce(p_content_type,'')));
  v_action text:=upper(trim(coalesce(p_action,'MANAGE')));
  s jsonb;
  v_level text;
  v_state text;
  v_mandal text;
  v_district text;
  v_tehsil text;
  v_block text;
  v_village text;
  v_actor uuid;
  v_owner uuid;
  r record;
begin
  if public.rkms_current_super_admin_id() is not null or public.rkms_is_national_president_current() then return true; end if;
  if not public.rkms_can_manage_content(v_type,v_action) then return false; end if;
  s:=public.rkms_content_scope_json();
  v_actor:=public.rkms_current_officer_id();
  v_level:=upper(coalesce(s->>'authority_level',''));
  v_state:=s->>'state'; v_mandal:=s->>'mandal'; v_district:=s->>'district'; v_tehsil:=s->>'tehsil'; v_block:=s->>'block'; v_village:=s->>'village';

  if v_action='CREATE' then return true; end if;
  if p_id is null then return false; end if;

  if v_type='flash' then
    select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village,created_by into r from public.rkms_flash_messages where id=p_id;
    v_owner:=r.created_by;
  elsif v_type='news' then
    select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village,created_by into r from public.rkms_news where id=p_id;
    v_owner:=r.created_by;
  elsif v_type='gallery' then
    select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village,scope_officer_id into r from public.rkms_gallery where id=p_id;
    v_owner:=r.scope_officer_id;
  elsif v_type='documents' then
    select scope_state,scope_mandal,scope_district,scope_tehsil,scope_block,scope_village,uploaded_by into r from public.rkms_documents where id=p_id;
    v_owner:=r.uploaded_by;
  elsif v_type='events' then
    select state as scope_state,district as scope_district,tehsil as scope_tehsil,block as scope_block,village as scope_village,null::text as scope_mandal,created_by into r from public.rkms_events where id=p_id;
    v_owner:=r.created_by;
  else
    return false;
  end if;
  if not found then return false; end if;

  -- An officer may always edit/delete content that they themselves originally published.
  -- This covers district IT Cell presidents managing their own area's public updates.
  if v_action in ('UPDATE','DELETE') and v_actor is not null and v_owner is not null and v_owner=v_actor then return true; end if;

  if v_state is null or lower(trim(coalesce(r.scope_state,'')))<>lower(trim(v_state)) then return false; end if;
  if v_level='STATE' then return true; end if;
  if v_mandal is not null and lower(trim(coalesce(r.scope_mandal,'')))<>lower(trim(v_mandal)) then return false; end if;
  if v_level='MANDAL' then return true; end if;
  if v_district is not null and lower(trim(coalesce(r.scope_district,'')))<>lower(trim(v_district)) then return false; end if;
  if v_level='DISTRICT' then return true; end if;
  if v_tehsil is not null and lower(trim(coalesce(r.scope_tehsil,'')))<>lower(trim(v_tehsil)) then return false; end if;
  if v_level='TEHSIL' then return true; end if;
  if v_block is not null and lower(trim(coalesce(r.scope_block,'')))<>lower(trim(v_block)) then return false; end if;
  if v_level='BLOCK' then return true; end if;
  if v_village is not null and lower(trim(coalesce(r.scope_village,'')))<>lower(trim(v_village)) then return false; end if;
  return v_level='VILLAGE';
end;
$$;
