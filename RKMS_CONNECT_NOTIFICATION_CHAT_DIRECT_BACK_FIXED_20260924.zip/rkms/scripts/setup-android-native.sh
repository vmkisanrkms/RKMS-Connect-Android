#!/usr/bin/env bash
set -euo pipefail
MAIN_ACTIVITY="$(find android/app/src/main -type f -name 'MainActivity.java' -print -quit)"
if [ -z "$MAIN_ACTIVITY" ]; then
  echo "ERROR: MainActivity.java not found after Capacitor Android generation" >&2
  find android/app/src/main -type f >&2 || true
  exit 1
fi
APP_SRC="$(dirname "$MAIN_ACTIVITY")"
mkdir -p "$APP_SRC"

# Capacitor Push Notifications uses Firebase Cloud Messaging. Ensure the
# Google Services Gradle plugin is actually applied to the generated Android
# project so google-services.json is processed for the RKMS package.
python3 - <<'PY2'
from pathlib import Path
root=Path('android/build.gradle')
s=root.read_text()
if 'com.google.gms:google-services:' not in s:
    marker='dependencies {'
    if marker not in s: raise SystemExit('android/build.gradle dependencies block missing')
    s=s.replace(marker, marker+'\n        classpath "com.google.gms:google-services:4.4.3"',1)
    root.write_text(s)
app=Path('android/app/build.gradle')
s=app.read_text()
if 'com.google.gms.google-services' not in s:
    s += '\n\n// RKMS FCM: process android/app/google-services.json\napply plugin: "com.google.gms.google-services"\n'
    app.write_text(s)
PY2

# Android Credential Manager: let the configured password provider (including Google Password Manager)
# handle password-save prompts. RKMS never stores login passwords itself.
python3 - <<'PYCM'
from pathlib import Path
p=Path("android/app/build.gradle")
s=p.read_text()
if "androidx.credentials:credentials:" not in s:
    marker="dependencies {"
    if marker not in s: raise SystemExit("dependencies block missing")
    s=s.replace(marker, marker+'\n    implementation "androidx.credentials:credentials:1.5.0"\n    implementation "androidx.credentials:credentials-play-services-auth:1.5.0"',1)
p.write_text(s)
PYCM

# Capacitor does not reliably copy a root-level google-services.json into the
# generated Android module. Put the verified RKMS Firebase configuration in
# the exact location required by the Google Services Gradle plugin.
if [ ! -f "google-services.json" ]; then
  echo "ERROR: root google-services.json is missing" >&2
  exit 1
fi
cp -f "google-services.json" "android/app/google-services.json"
chmod 600 "android/app/google-services.json"

python3 - <<'PY3'
import json
from pathlib import Path
p=Path('android/app/google-services.json')
data=json.loads(p.read_text())
clients=data.get('client', [])
packages=[]
for c in clients:
    packages.append(c.get('client_info',{}).get('android_client_info',{}).get('package_name'))
if 'org.rkms.connect' not in packages:
    raise SystemExit('ERROR: google-services.json has no org.rkms.connect client')
print('google-services.json package verification: PASS')
PY3

# Provide a stable FCM default channel for background notifications that arrive
# before the JS runtime creates its channel.
RES_DIR="android/app/src/main/res"
VALUES_DIR="$RES_DIR/values"
mkdir -p "$VALUES_DIR"
STRINGS="$VALUES_DIR/strings.xml"
if [ -f "$STRINGS" ]; then
  python3 - <<'PY3'
from pathlib import Path
p=Path('android/app/src/main/res/values/strings.xml')
s=p.read_text()
insert = []
if 'rkms_default_notification_channel_id' not in s:
    insert.append('    <string name="rkms_default_notification_channel_id">rkms_notifications_v3</string>')
if 'rkms_priority_notification_channel_id' not in s:
    insert.append('    <string name="rkms_priority_notification_channel_id">rkms_priority_v2</string>')
if insert:
    marker='</resources>'
    if marker not in s:
        raise SystemExit('strings.xml resources closing tag missing')
    s=s.replace(marker, '\n'.join(insert)+'\n'+marker, 1)
    p.write_text(s)
PY3
else
  cat > "$STRINGS" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="rkms_default_notification_channel_id">rkms_notifications_v3</string>
    <string name="rkms_priority_notification_channel_id">rkms_priority_v2</string>
</resources>
XML
fi
# Stable white notification icon for FCM system notifications.
DRAWABLE_DIR="$RES_DIR/drawable"
mkdir -p "$DRAWABLE_DIR"
cat > "$DRAWABLE_DIR/ic_stat_rkms.xml" <<'XML'
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFFFF" android:pathData="M12,2A7,7 0,0 0,5 9v4l-2,3v1h18v-1l-2,-3V9A7,7 0,0 0,12 2M9,19a3,3 0,0 0,6 0z"/>
</vector>
XML
python3 - <<'PY3'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
perm='    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n'
if 'android.permission.RECORD_AUDIO' not in s:
    pos=s.find('<application')
    if pos < 0: raise SystemExit('AndroidManifest application tag missing')
    s=s[:pos]+perm+s[pos:]
meta='    <meta-data android:name="com.google.firebase.messaging.default_notification_channel_id" android:value="@string/rkms_default_notification_channel_id" />\n    <meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_stat_rkms" />\n'
if 'com.google.firebase.messaging.default_notification_channel_id' not in s:
    marker='<application'
    if marker not in s: raise SystemExit('AndroidManifest application tag missing')
    s=s.replace(marker, '<application android:enableOnBackInvokedCallback="true"', 1)
    marker='</application>'
    if marker not in s: raise SystemExit('AndroidManifest application closing tag missing')
    s=s.replace(marker,meta+marker,1)
p.write_text(s)
PY3


MAIN="$MAIN_ACTIVITY"
if [ -f "$MAIN" ]; then
  MAIN_ACTIVITY_ENV="$MAIN_ACTIVITY" python3 - <<'PY'
import os
from pathlib import Path
p=Path(os.environ['MAIN_ACTIVITY_ENV'])
s=p.read_text()
if 'RKMSNativeBridge(this, rkmsWebView)' not in s:
    marker='public class MainActivity extends BridgeActivity {'
    replacement = """public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        com.google.firebase.FirebaseApp.initializeApp(this);
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        android.webkit.WebView rkmsWebView = getBridge().getWebView();
        // IMPORTANT: Do not replace Capacitor's internal WebViewClient here.
        // Capacitor owns the https://localhost/ asset bridge. Replacing it with
        // a plain android.webkit.WebViewClient causes ERR_CONNECTION_REFUSED.
        rkmsWebView.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_YES);
        rkmsWebView.setSaveEnabled(true);
        rkmsWebView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        rkmsWebView.addJavascriptInterface(new RKMSNativeBridge(this, rkmsWebView), "RKMSNative");
        rkmsInstallWebAudioPermissionBridge(rkmsWebView);
        createRkmsNotificationChannel();
        rkmsCaptureNotificationIntent(getIntent());
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::rkmsDispatchNotificationRoute, 700);
    }

    private volatile String rkmsPendingNotificationRoute = "";
    private String rkmsExtractNotificationRoute(android.content.Intent intent) {
        if (intent == null || intent.getExtras() == null) return "";
        android.os.Bundle b = intent.getExtras();
        // FCM/Capacitor may expose custom data either as direct extras or as a
        // JSON-encoded "data" extra. Read both forms so the notification target
        // cannot silently fall back to Home/Notifications.
        android.os.Bundle dataBundle = null;
        String dataJson = b.getString("data", "");
        if (dataJson != null && !dataJson.trim().isEmpty()) {
            try {
                org.json.JSONObject jo = new org.json.JSONObject(dataJson);
                dataBundle = new android.os.Bundle();
                java.util.Iterator<String> it = jo.keys();
                while (it.hasNext()) { String k = it.next(); dataBundle.putString(k, jo.optString(k, "")); }
            } catch (Exception ignored) {}
        }
        String route = b.getString("route", "");
        if (route == null || route.trim().isEmpty()) route = b.getString("url", "");
        if (route == null || route.trim().isEmpty()) route = b.getString("target_route", "");
        String type = b.getString("type", "");
        String cid = b.getString("conversation_id", "");
        if (cid == null || cid.trim().isEmpty()) cid = b.getString("conversationId", "");
        if (dataBundle != null) {
            if (route == null || route.trim().isEmpty()) route = dataBundle.getString("route", "");
            if (route == null || route.trim().isEmpty()) route = dataBundle.getString("url", "");
            if (route == null || route.trim().isEmpty()) route = dataBundle.getString("target_route", "");
            if (type == null || type.trim().isEmpty()) type = dataBundle.getString("type", "");
            if (cid == null || cid.trim().isEmpty()) cid = dataBundle.getString("conversation_id", "");
            if (cid == null || cid.trim().isEmpty()) cid = dataBundle.getString("conversationId", "");
        }
        boolean chatType = "rkms_chat".equalsIgnoreCase(type) || "chat".equalsIgnoreCase(type)
                || "message".equalsIgnoreCase(type) || "chat_message".equalsIgnoreCase(type);
        // A conversation_id is authoritative for chat notifications even when an
        // older FCM payload used a generic notification type or omitted route.
        if (cid != null && !cid.trim().isEmpty()) route = "chat/" + cid.trim();
        else if ((route == null || route.trim().isEmpty()) && chatType) route = "chat";
        if (route == null || route.trim().isEmpty()) {
            if ("CONTENT_NEWS".equalsIgnoreCase(type)) route = "news";
            else if ("CONTENT_EVENTS".equalsIgnoreCase(type)) route = "events";
            else if ("CONTENT_GALLERY".equalsIgnoreCase(type)) route = "gallery";
            else if ("CONTENT_DOCUMENTS".equalsIgnoreCase(type)) route = "documents";
            else if ("CONTENT_FLASH".equalsIgnoreCase(type)) route = "flash";
            else if ("CONTENT_REPORTS".equalsIgnoreCase(type)) route = "reports";
            else if ("CONTENT_CAMPAIGNS".equalsIgnoreCase(type)) route = "campaigns";
            else if ("CONTENT_LEADERSHIP".equalsIgnoreCase(type)) route = "leadership";
            else if ("APP_UPDATE".equalsIgnoreCase(type)) route = "notifications";
            else if (type != null && !type.trim().isEmpty()) route = "notifications";
        }
        if (route == null) route = "";
        return route.trim().replaceFirst("^#?[/]", "");
    }
    private final android.os.Handler rkmsNotificationHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private int rkmsNotificationDispatchAttempts = 0;
    private void rkmsCaptureNotificationIntent(android.content.Intent intent) {
        String route = rkmsExtractNotificationRoute(intent);
        if (route.isEmpty()) return;
        rkmsPendingNotificationRoute = route;
        rkmsNotificationDispatchAttempts = 0;
        rkmsDispatchNotificationRoute();
    }
    private void rkmsDispatchNotificationRoute() {
        final String route = rkmsPendingNotificationRoute;
        if (route == null || route.isEmpty()) return;
        android.webkit.WebView w = getBridge() == null ? null : getBridge().getWebView();
        if (w == null) {
            rkmsRetryNotificationDispatch();
            return;
        }
        String js = "(function(){try{if(typeof window.rkmsOpenNotificationRoute!=='function')return 'NOT_READY';" +
                "return Promise.resolve(window.rkmsOpenNotificationRoute(" + org.json.JSONObject.quote(route) + ")).then(function(ok){return ok?'OK':'WAIT';}).catch(function(){return 'ERROR';});" +
                "}catch(e){return 'ERROR';}})();";
        w.post(() -> w.evaluateJavascript(js, value -> {
            if ("\"NOT_READY\"".equals(value) || "\"ERROR\"".equals(value) || "\"WAIT\"".equals(value) || value == null || value.isEmpty()) {
                rkmsRetryNotificationDispatch();
            } else if ("\"OK\"".equals(value)) {
                rkmsPendingNotificationRoute = "";
                rkmsNotificationDispatchAttempts = 0;
            } else {
                rkmsRetryNotificationDispatch();
            }
        }));
    }
    private void rkmsRetryNotificationDispatch() {
        if (rkmsPendingNotificationRoute == null || rkmsPendingNotificationRoute.isEmpty()) return;
        if (++rkmsNotificationDispatchAttempts > 30) {
            rkmsNotificationDispatchAttempts = 0;
            return;
        }
        rkmsNotificationHandler.postDelayed(this::rkmsDispatchNotificationRoute, 350);
    }
    @Override protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        rkmsCaptureNotificationIntent(intent);
    }

    @Override public void onResume() {
        super.onResume();
        // Do not re-read getIntent() here. Android keeps the notification Intent
        // on the Activity, so doing that on every resume re-opens the same chat
        // repeatedly. onCreate/onNewIntent capture a new notification once;
        // resume only retries an already-pending dispatch.
        rkmsNotificationHandler.postDelayed(this::rkmsDispatchNotificationRoute, 250);
    }

    private android.webkit.PermissionRequest rkmsPendingPermissionRequest;
    private static final int RKMS_AUDIO_PERMISSION_REQUEST = 4127;
    private static final int RKMS_FILE_CHOOSER_REQUEST = 4128;
    private android.webkit.ValueCallback<android.net.Uri[]> rkmsFilePathCallback;
    private void rkmsInstallWebAudioPermissionBridge(android.webkit.WebView webView) {
        webView.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override public boolean onShowFileChooser(android.webkit.WebView view, android.webkit.ValueCallback<android.net.Uri[]> callback, android.webkit.WebChromeClient.FileChooserParams params) {
                if (rkmsFilePathCallback != null) rkmsFilePathCallback.onReceiveValue(null);
                rkmsFilePathCallback = callback;
                try {
                    android.content.Intent intent = params.createIntent();
                    startActivityForResult(intent, RKMS_FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) { rkmsFilePathCallback = null; return false; }
            }
            @Override public void onPermissionRequest(final android.webkit.PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsAudio = false;
                    for (String resource : request.getResources()) {
                        if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) { wantsAudio = true; break; }
                    }
                    if (!wantsAudio) { request.deny(); return; }
                    if (androidx.core.content.ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                        return;
                    }
                    rkmsPendingPermissionRequest = request;
                    androidx.core.app.ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.RECORD_AUDIO}, RKMS_AUDIO_PERMISSION_REQUEST);
                });
            }
        });
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RKMS_FILE_CHOOSER_REQUEST) {
            android.net.Uri[] results = null;
            if (resultCode == android.app.Activity.RESULT_OK) {
                if (data != null && data.getClipData() != null) {
                    int n=data.getClipData().getItemCount(); results=new android.net.Uri[n]; for(int i=0;i<n;i++) results[i]=data.getClipData().getItemAt(i).getUri();
                } else if (data != null && data.getData() != null) results=new android.net.Uri[]{data.getData()};
            }
            if (rkmsFilePathCallback != null) { rkmsFilePathCallback.onReceiveValue(results); rkmsFilePathCallback=null; }
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RKMS_AUDIO_PERMISSION_REQUEST) {
            android.webkit.PermissionRequest req = rkmsPendingPermissionRequest;
            rkmsPendingPermissionRequest = null;
            if (req == null) return;
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) req.grant(new String[]{android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else req.deny();
        }
    }

    private void createRkmsNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            android.app.NotificationManager nm = (android.app.NotificationManager)getSystemService(android.content.Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            android.app.NotificationChannel normal = new android.app.NotificationChannel("rkms_notifications_v3", "RKMS Notifications", android.app.NotificationManager.IMPORTANCE_HIGH);
            normal.setDescription("RKMS Connect notifications");
            normal.enableVibration(true);
            normal.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, null);
            nm.createNotificationChannel(normal);
            android.app.NotificationChannel priority = new android.app.NotificationChannel("rkms_priority_v2", "RKMS Important Notifications", android.app.NotificationManager.IMPORTANCE_HIGH);
            priority.setDescription("Important RKMS organisation notices");
            priority.enableVibration(true);
            priority.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, null);
            nm.createNotificationChannel(priority);
        }
    }
"""
    if marker not in s:
        raise SystemExit('MainActivity class marker missing')
    s=s.replace(marker,replacement,1)
    p.write_text(s)
PY
else
  echo "ERROR: MainActivity.java not found" >&2
  find android/app/src/main -type f >&2
  exit 1
fi

cat > "$APP_SRC/RKMSNativeBridge.java" <<'JAVA'
package org.rkms.connect;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import androidx.credentials.CredentialManager;
import androidx.credentials.CreatePasswordRequest;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetPasswordOption;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.PasswordCredential;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.print.PrintDocumentInfo;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
public final class RKMSNativeBridge {
 private static final String PREFS="rkms_native_session", KEY_ALIAS="RKMS_NATIVE_SESSION_AES";
 private final SharedPreferences prefs;
 private final android.app.Activity activity;
 private final android.webkit.WebView webView;
 public RKMSNativeBridge(android.app.Activity activity, android.webkit.WebView webView){
  this.activity=activity;
  this.webView=webView;
  prefs=activity.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);
 }
 private SecretKey key() throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(KEY_ALIAS))return((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore");kg.init(new android.security.keystore.KeyGenParameterSpec.Builder(KEY_ALIAS,android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).setUserAuthenticationRequired(false).build());return kg.generateKey();}
 private void put(String n,String v)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());prefs.edit().putString(n,Base64.encodeToString(c.doFinal(v.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP)).putString(n+"_iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).apply();}
 private String get(String n){try{String e=prefs.getString(n,"");String iv=prefs.getString(n+"_iv","");if(e.isEmpty()||iv.isEmpty())return"";Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(e,Base64.NO_WRAP)),StandardCharsets.UTF_8);}catch(Exception e){return"";}}
 @JavascriptInterface public void saveSession(String a,String r,String role){try{put("access",a==null?"":a);put("refresh",r==null?"":r);put("role",role==null?"":role);}catch(Exception ignored){}}
 @JavascriptInterface public void refreshFcmToken(){
  try{
   FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
    if(!task.isSuccessful()) return;
    String f=task.getResult();
    if(f==null||f.trim().isEmpty()) return;
    String js="window.rkmsNativeFcmToken&&window.rkmsNativeFcmToken("+JSONObject.quote(f.trim())+")";
    webView.post(()->webView.evaluateJavascript(js,null));
   });
  }catch(Exception ignored){}
 }
 @JavascriptInterface public void saveSessionNoPush(String a,String r,String role){saveSession(a,r,role);}
 @JavascriptInterface public String getAccessToken(){return get("access");}
 @JavascriptInterface public String getRefreshToken(){return get("refresh");}
 @JavascriptInterface public String getRole(){return get("role");}
 @JavascriptInterface public void clearSession(){prefs.edit().clear().apply();}
 @JavascriptInterface public boolean isMicrophonePermissionGranted(){
  return androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED;
 }
 @JavascriptInterface public void requestMicrophonePermission(){
  if(activity==null)return;
  activity.runOnUiThread(()->{
   if(!isMicrophonePermissionGranted()) androidx.core.app.ActivityCompat.requestPermissions(activity,new String[]{android.Manifest.permission.RECORD_AUDIO},4127);
  });
 }
 @JavascriptInterface public void printPage(){
  if(activity==null || webView==null)return;
  activity.runOnUiThread(()->{
   try{
    PrintManager pm=(PrintManager)activity.getSystemService(Context.PRINT_SERVICE);
    PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter("RKMS-document");
    pm.print("RKMS-document",adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("rkms","RKMS",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
   }catch(Exception e){android.widget.Toast.makeText(activity,"Print/PDF शुरू नहीं हो सका",android.widget.Toast.LENGTH_SHORT).show();}
  });
 }
 private java.io.FileDescriptor rkmsPdfFd=null;
 private java.io.ByteArrayOutputStream pdfBuffer; private String pdfSaveName;
 @JavascriptInterface public synchronized String beginPdfSave(String filename){ try{ pdfSaveName=(filename==null||filename.trim().isEmpty()?"RKMS-document.pdf":filename.trim()); if(!pdfSaveName.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf"))pdfSaveName+=".pdf"; pdfBuffer=new java.io.ByteArrayOutputStream(256*1024); return "OK"; }catch(Exception e){pdfBuffer=null;return "ERROR: PDF save शुरू नहीं हो सकी।";} }
 @JavascriptInterface public synchronized String appendPdfChunk(String base64Chunk){ try{if(pdfBuffer==null)return "ERROR: PDF save session नहीं मिली।"; if(base64Chunk!=null&&!base64Chunk.isEmpty())pdfBuffer.write(Base64.decode(base64Chunk,Base64.NO_WRAP)); return "OK";}catch(Exception e){return "ERROR: PDF data save नहीं हो सकी।";} }
 @JavascriptInterface public synchronized String finishPdfSave(){ android.net.Uri u=null; try{if(pdfBuffer==null)return "ERROR: PDF save session नहीं मिली।"; byte[] pdf=pdfBuffer.toByteArray(); if(pdf.length<100)return "ERROR: PDF data अमान्य है।"; if(pdf[0]!=0x25||pdf[1]!=0x50||pdf[2]!=0x44||pdf[3]!=0x46||pdf[4]!=0x2D)return "ERROR: PDF header अमान्य है।"; byte[] eof=new byte[]{0x25,0x25,0x45,0x4F,0x46}; boolean hasEof=false; int start=Math.max(0,pdf.length-1024); for(int i=start;i<=pdf.length-eof.length;i++){boolean ok=true;for(int j=0;j<eof.length;j++){if(pdf[i+j]!=eof[j]){ok=false;break;}}if(ok){hasEof=true;break;}} if(!hasEof)return "ERROR: PDF end marker अमान्य है।"; android.content.ContentValues v=new android.content.ContentValues(); v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,pdfSaveName); v.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/pdf"); v.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS+"/RKMS CONNECT"); v.put(android.provider.MediaStore.Downloads.IS_PENDING,1); android.content.ContentResolver r=activity.getContentResolver(); u=r.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)return "ERROR: Downloads folder में PDF file नहीं बन सकी।"; try(java.io.OutputStream out=r.openOutputStream(u)){if(out==null)throw new java.io.IOException("output");out.write(pdf);out.flush();} android.content.ContentValues done=new android.content.ContentValues();done.put(android.provider.MediaStore.Downloads.IS_PENDING,0);r.update(u,done,null,null); try(android.database.Cursor c=r.query(u,new String[]{android.provider.MediaStore.Downloads.SIZE},null,null,null)){ if(c==null||!c.moveToFirst())throw new java.io.IOException("PDF verification query failed"); long stored=c.getLong(0);if(stored!=pdf.length)throw new java.io.IOException("PDF size mismatch");} try(java.io.InputStream in=r.openInputStream(u)){if(in==null)throw new java.io.IOException("PDF reopen failed");byte[] h=new byte[5];int n=in.read(h);if(n!=5||h[0]!=0x25||h[1]!=0x50||h[2]!=0x44||h[3]!=0x46||h[4]!=0x2D)throw new java.io.IOException("Stored PDF header invalid");} pdfBuffer=null;pdfSaveName=null;return "OK";}catch(Exception e){ if(u!=null)try{activity.getContentResolver().delete(u,null,null);}catch(Exception ignored){} pdfBuffer=null;pdfSaveName=null;return "ERROR: PDF Downloads में save नहीं हो सकी।";} }
 @JavascriptInterface public String captureCurrentDocumentAsPdf(String filename){
  if(activity==null || webView==null)return "ERROR: WebView उपलब्ध नहीं है।";
  final String name=(filename==null||filename.trim().isEmpty()?"RKMS-document.pdf":filename.trim());
  webView.postDelayed(()->{
   try{
    int w=Math.max(1,webView.getWidth());
    int h=Math.max(1,webView.getHeight());
    android.graphics.Bitmap bitmap=android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888);
    android.graphics.Canvas canvas=new android.graphics.Canvas(bitmap);
    canvas.drawColor(android.graphics.Color.WHITE);
    webView.draw(canvas);
    android.graphics.pdf.PdfDocument pdf=new android.graphics.pdf.PdfDocument();
    android.graphics.pdf.PdfDocument.PageInfo info=new android.graphics.pdf.PdfDocument.PageInfo.Builder(w,h,1).create();
    android.graphics.pdf.PdfDocument.Page page=pdf.startPage(info);
    page.getCanvas().drawBitmap(bitmap,0,0,null);
    pdf.finishPage(page);
    android.content.ContentValues v=new android.content.ContentValues();
    v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf")?name:name+".pdf");
    v.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/pdf");
    v.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS+"/RKMS CONNECT");
    v.put(android.provider.MediaStore.Downloads.IS_PENDING,1);
    android.content.ContentResolver cr=activity.getContentResolver();
    android.net.Uri u=cr.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
    if(u==null)throw new java.io.IOException("Downloads insert failed");
    try(java.io.OutputStream out=cr.openOutputStream(u)){if(out==null)throw new java.io.IOException("output");pdf.writeTo(out);out.flush();}
    android.content.ContentValues done=new android.content.ContentValues();done.put(android.provider.MediaStore.Downloads.IS_PENDING,0);cr.update(u,done,null,null);
    pdf.close();bitmap.recycle();
    webView.post(()->webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('rkms:native-pdf-saved',{detail:{name:"+org.json.JSONObject.quote(name)+"}}));",null));
   }catch(Exception e){
    android.util.Log.e("RKMS","Native PDF capture failed",e);
    webView.post(()->webView.evaluateJavascript("window.dispatchEvent(new Event('rkms:native-pdf-failed'));",null));
   }
  },180);
  return "STARTED";
 }
 @JavascriptInterface public synchronized void cancelPdfSave(){pdfBuffer=null;pdfSaveName=null;}
 @JavascriptInterface public void savePassword(String identifier,String password){
  if(activity==null || identifier==null || password==null || identifier.trim().isEmpty() || password.isEmpty()) return;
  activity.runOnUiThread(()->{
   try{
    CredentialManager cm=CredentialManager.create(activity);
    CreatePasswordRequest req=new CreatePasswordRequest(identifier.trim(),password);
    cm.createCredentialAsync(activity,req,new CancellationSignal(),activity.getMainExecutor(),new androidx.credentials.CredentialManagerCallback<androidx.credentials.CreateCredentialResponse,androidx.credentials.exceptions.CreateCredentialException>(){
      @Override public void onResult(androidx.credentials.CreateCredentialResponse result){
        String js="window.dispatchEvent(new CustomEvent(\'rkms:password-saved\',{detail:{identifier:"+org.json.JSONObject.quote(identifier.trim())+"}}));";
        webView.post(()->webView.evaluateJavascript(js,null));
      }
      @Override public void onError(androidx.credentials.exceptions.CreateCredentialException e){ android.util.Log.w("RKMS","Credential Manager save cancelled/failed",e); }
    });
   }catch(Exception e){ android.util.Log.w("RKMS","Credential Manager unavailable",e); }
  });
 }
 @JavascriptInterface public void getSavedPassword(){
  if(activity==null || webView==null) return;
  activity.runOnUiThread(()->{
   try{
    CredentialManager cm=CredentialManager.create(activity);
    GetPasswordOption option=new GetPasswordOption();
    GetCredentialRequest req=new GetCredentialRequest.Builder().addCredentialOption(option).build();
    cm.getCredentialAsync(activity,req,new CancellationSignal(),activity.getMainExecutor(),new androidx.credentials.CredentialManagerCallback<GetCredentialResponse,androidx.credentials.exceptions.GetCredentialException>(){
      @Override public void onResult(GetCredentialResponse result){
        try{
          androidx.credentials.Credential c=result.getCredential();
          if(c instanceof PasswordCredential){
            PasswordCredential pc=(PasswordCredential)c;
            String js="window.dispatchEvent(new CustomEvent('rkms:saved-password',{detail:{identifier:"+org.json.JSONObject.quote(pc.getId())+",password:"+org.json.JSONObject.quote(pc.getPassword())+"}}));";
            webView.post(()->webView.evaluateJavascript(js,null));
          }
        }catch(Exception e){ android.util.Log.w("RKMS","Saved credential result handling failed",e); }
      }
      @Override public void onError(androidx.credentials.exceptions.GetCredentialException e){ android.util.Log.w("RKMS","Saved credential unavailable/cancelled",e); }
    });
   }catch(Exception e){ android.util.Log.w("RKMS","Credential Manager retrieval unavailable",e); }
  });
 }
 @JavascriptInterface public void showNotification(String title,String body,String route,boolean important){
  if(activity==null)return;
  activity.runOnUiThread(()->{
   try{
    if(android.os.Build.VERSION.SDK_INT>=33 && androidx.core.content.ContextCompat.checkSelfPermission(activity,android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
    String channel=important?"rkms_priority_v2":"rkms_notifications_v3";
    android.content.Intent i=new android.content.Intent(activity,MainActivity.class);
    i.addFlags(android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP|android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP);
    if(route!=null&&!route.trim().isEmpty())i.putExtra("route",route.trim());
    int requestCode=(int)(System.currentTimeMillis()&0x7fffffff);
    android.app.PendingIntent pi=android.app.PendingIntent.getActivity(activity,requestCode,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    android.app.Notification.Builder b=new android.app.Notification.Builder(activity,channel)
      .setSmallIcon(org.rkms.connect.R.drawable.ic_stat_rkms)
      .setContentTitle(title==null||title.trim().isEmpty()?"RKMS Connect":title.trim())
      .setContentText(body==null?"नई RKMS सूचना":body.trim())
      .setStyle(new android.app.Notification.BigTextStyle().bigText(body==null?"नई RKMS सूचना":body.trim()))
      .setAutoCancel(true).setContentIntent(pi).setCategory(important?android.app.Notification.CATEGORY_EVENT:android.app.Notification.CATEGORY_MESSAGE)
      .setPriority(android.app.Notification.PRIORITY_HIGH).setDefaults(android.app.Notification.DEFAULT_ALL);
    android.app.NotificationManager nm=(android.app.NotificationManager)activity.getSystemService(Context.NOTIFICATION_SERVICE);
    if(nm!=null)nm.notify(requestCode,b.build());
   }catch(Exception e){android.util.Log.w("RKMS","Foreground notification failed",e);}
  });
 }
 @JavascriptInterface public void setBookZoomMode(boolean enabled){}
}
JAVA

python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
if 'androidx.biometric:biometric:' not in s:
    marker='dependencies {'
    if marker in s:
        s=s.replace(marker, marker+'\n    implementation "androidx.biometric:biometric:1.1.0"',1)
    else:
        s += '\n\ndependencies { implementation "androidx.biometric:biometric:1.1.0" }\n'
p.write_text(s)
PY

# RKMS Android launcher icon: use the original transparent RKMS logo only.
# The launcher icon is intentionally separate from the web/header logo.
LAUNCHER_SRC="android_launcher_icons"
if [ -d "$LAUNCHER_SRC" ]; then
  mkdir -p "$RES_DIR/mipmap-mdpi" "$RES_DIR/mipmap-hdpi" "$RES_DIR/mipmap-xhdpi" "$RES_DIR/mipmap-xxhdpi" "$RES_DIR/mipmap-xxxhdpi" "$RES_DIR/drawable-nodpi" "$VALUES_DIR"
  for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
    cp "$LAUNCHER_SRC/mipmap-$density/ic_launcher.png" "$RES_DIR/mipmap-$density/ic_launcher.png"
    cp "$LAUNCHER_SRC/mipmap-$density/ic_launcher_round.png" "$RES_DIR/mipmap-$density/ic_launcher_round.png"
  done
  cat > "$RES_DIR/values/rkms_launcher_colors.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="rkms_launcher_background">#FFFFFF</color>
</resources>
XML
  rm -f "$RES_DIR/mipmap-anydpi-v26/ic_launcher.xml" "$RES_DIR/mipmap-anydpi-v26/ic_launcher_round.xml" "$RES_DIR/drawable-nodpi/rkms_launcher_foreground.png"
  rmdir "$RES_DIR/mipmap-anydpi-v26" 2>/dev/null || true
  python3 - <<'PYICON'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
import re
s=re.sub(r'\sandroid:icon="[^"]*"', '', s, count=1)
s=re.sub(r'\sandroid:roundIcon="[^"]*"', '', s, count=1)
s=s.replace('<application ', '<application android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher_round" ', 1)
p.write_text(s)
PYICON
  echo "RKMS original launcher icon installed."
fi
