from pathlib import Path
p=Path('app/src/main/java/org/rkms/connect/MainActivity.java')
s=p.read_text(encoding='utf-8')
checks=[
 'import android.content.ContentValues;',
 'import android.media.MediaScannerConnection;',
 'import android.os.Environment;',
 'import android.provider.MediaStore;',
 'import android.util.Base64;',
 'beginPdfSave(String filename)',
 'appendPdfChunk(String base64Chunk)',
 'finishPdfSave()',
 'cancelPdfSave()',
 'MediaStore.Downloads.EXTERNAL_CONTENT_URI',
 'MediaStore.Downloads.RELATIVE_PATH',
 'Environment.DIRECTORY_DOWNLOADS + "/RKMS CONNECT"',
 'application/pdf',
]
missing=[x for x in checks if x not in s]
if missing:
 print('MISSING:'); print('\n'.join(missing)); raise SystemExit(1)
print('ANDROID PDF BRIDGE: PASS')
