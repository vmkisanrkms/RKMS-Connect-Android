from pathlib import Path
import re
root=Path('.')
app=(root/'app.js').read_text(encoding='utf-8')
css=(root/'styles.css').read_text(encoding='utf-8')
setup=(root/'scripts/setup-android-native.sh').read_text(encoding='utf-8')
mg=(root/'supabase/migrations/20260920220000_chat_group_auth_scope_and_login_flow.sql').read_text(encoding='utf-8')
checks={
 'Chat closed: viewport subtracts site header + bottom nav': 'var(--rkms-chat-vh,100dvh) - var(--rkms-site-header-h,76px) - var(--rkms-bottom-nav-h,62px)' in app and 'var(--rkms-chat-vh,100dvh)' in css,
 'Chat open: bottom nav hidden': '.rkms-keyboard-open footer.rkms-bottom-nav{display:none!important}' in css or '.rkms-keyboard-open footer.rkms-bottom-nav' in app,
 'Composer is normal flex flow': '.wa-conversation-screen .wa-compose-wrap{padding:4px max(8px,3vw) 4px !important;margin:0 !important;position:relative !important;bottom:auto !important' in css,
 'No final fixed composer rule remains': not re.search(r'\.wa-conversation-screen \.wa-compose-wrap\{[^}]*position:fixed', css),
 'Group people include auth_user_id': 'm.auth_user_id' in mg and 'data-auth-user-id' in app,
 'Group people hide missing auth accounts': 'm.auth_user_id is not null' in mg,
 'Officer member list is jurisdiction scoped': 'public.rkms_chat_officer_can_access_member(me_officer,m.id)' in mg,
 'Officer participant additions are jurisdiction scoped': 'not public.rkms_chat_is_national_president(me_officer) and not public.rkms_chat_officer_can_access_member(me_officer,target_member)' in mg,
 'Group backend resolves auth id server-side': 'select m.id,m.auth_user_id into target_member,target_auth' in mg,
 'Group backend blocks null auth id': 'if target_auth is null then raise exception' in mg,
 'Login username autocomplete': 'autocomplete="username"' in app and 'name="username"' in app,
 'Login password autocomplete': 'autocomplete="current-password"' in app and 'name="password"' in app,
 'Saved credential retrieval bridge exists': '@JavascriptInterface public void getSavedPassword()' in setup,
 'Saved credential result reaches JS': "rkms:saved-password" in setup,
 'Saved Login UI exists': 'id="rkmsSavedLoginBtn"' in app,
 'Save prompt is one-time per account': 'rkms_password_save_prompted_v2:' in app and 'AUTH_STORE.getItem(key)===\'1\'' in app,
 'Both member and officer login use one-time save': app.count('rkmsMaybeSavePassword(')>=3,
 'Credential Manager dependency present': 'androidx.credentials:credentials:1.5.0' in setup and 'androidx.credentials:credentials-play-services-auth:1.5.0' in setup,
}
failed=[]
for k,v in checks.items():
 print(('PASS' if v else 'FAIL')+': '+k)
 if not v: failed.append(k)
print(f'\n{len(checks)-len(failed)}/{len(checks)} three-point checks passed')
if failed: raise SystemExit(1)
