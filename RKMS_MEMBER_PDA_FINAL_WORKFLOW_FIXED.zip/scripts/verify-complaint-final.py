from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text()
css=(root/'styles.css').read_text()
workflow=(root/'.github/workflows/android-apk-only.yml').read_text()
off=(root/'supabase/migrations/20260915090000_complaint_officer_close.sql').read_text()
hard=(root/'supabase/migrations/20260914191000_complaint_workflow_final_hardening.sql').read_text()
checks={
'Member close UI':'memberCloseComplaint' in app,
'Member reopen UI':'memberReopenComplaint' in app and 'memberReopenReason' in app,
'Officer close UI':'officerCloseComplaint' in app,
'Officer close only RESOLVED':'c.status==="RESOLVED"' in app,
'Officer close RPC':'rkms_officer_close_complaint' in app and 'rkms_officer_close_complaint' in off,
'Officer close backend RESOLVED guard':"if v_old<>'RESOLVED'" in off,
'Member close backend RESOLVED guard':"if v_old<>'RESOLVED'" in hard,
'Member reopen reason required':"nullif(trim(p_reason),'') is null" in hard,
'Member reopen limited statuses':"v_old not in ('RESOLVED','CLOSED')" in hard,
'Easy complaint CSS':'.complaint-action-card' in css,
'APK only build':'assembleRelease' in workflow and 'bundleRelease' not in workflow,
'No X/Twitter runtime refs':not re.search(r'(?:x\.com|twitter\.com|twitter:card)', app.lower()+workflow.lower()),
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
if failed: sys.exit('Complaint audit failed: '+', '.join(failed))
print('COMPLAINT FINAL AUDIT PASS')
