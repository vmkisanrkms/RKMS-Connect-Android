# RKMS CONNECT v11 — Deep Audit Corrections

This package corrects the v10 release blockers found in deep source audit:

1. Android workflow no longer extracts an older v8 source ZIP; it builds the checked-out commit.
2. Chat send no longer calls a second FCM dispatch path from the client, preventing duplicate push races with the database trigger.
3. Final static verification explicitly checks that Chat has no client-side duplicate dispatch path.
4. Android web build now copies only runtime web assets into `dist/`; Supabase migrations, scripts and audit files are not bundled into the APK.

Still required before device-level PASS:
- Build the APK from the v11 commit/source.
- Test notification delivery with app backgrounded/closed after 5h, 12h and 24h.
- Test notification tap navigation.
- Test token rotation/re-registration.
- Test Android notification permission and OEM battery restrictions.
