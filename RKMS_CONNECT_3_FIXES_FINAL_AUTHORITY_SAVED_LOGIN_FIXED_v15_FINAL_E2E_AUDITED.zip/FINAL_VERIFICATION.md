# RKMS CONNECT Final Verification

## Source/static status
- app.js syntax: PASS
- PDF pipeline static verification: PASS
- Report download scope verification: PASS
- Native bridge static verification: PASS
- RKMS final verification: PASS
- FCM client registration code: PASS
- FCM notification channel setup: PASS
- FCM token cleanup on logout: PASS
- GitHub workflow source selection: locked to `RKMS_CONNECT_3_FIXES_FINAL.zip`
- Firebase Android client configuration: CI requires `FIREBASE_GOOGLE_SERVICES_JSON` GitHub secret

## Functional release gates
The following require the generated APK on a real Android device before final PASS:
- Background/closed-app FCM notification delivery
- Notification tap navigation
- Digital ID area rendering (member-only hidden; officer shown)
- Digital ID approval signer
- Membership Certificate approval authority block
- Appointment authority block
- Digital ID/Certificate direct PDF save
- Digital ID Print
- Launcher logo/circular mask
- Saved Login after logout/reopen
- Logout returns to Home
- PDA State dropdown and full cascading location flow

## Final fixes applied in this build
1. FCM client registration is enabled through Capacitor Push Notifications and the authenticated user's FCM token is registered with `rkms-fcm-push`.
2. RKMS notification channel `rkms_notifications_v2` is created before FCM registration.
3. FCM token cleanup is attempted on logout and the token is re-associated on the next authenticated login.
4. Membership approval signer fallback now uses `member.approved_by` even when the approval RPC returns a successful-but-empty result.
5. Member-only Digital ID does not show the `क्षेत्र` line; appointed officers continue to show it.
6. Existing Saved Login, logout-to-Home, signature upload, PDF, authority-display and other previously verified functionality is retained.

## Important FCM build requirement
A real Android FCM build requires the Firebase Android client file from the RKMS Firebase project. It is intentionally not embedded in the source ZIP. GitHub Actions reads it from the `FIREBASE_GOOGLE_SERVICES_JSON` repository secret and installs it as `android/app/google-services.json` during the build.
