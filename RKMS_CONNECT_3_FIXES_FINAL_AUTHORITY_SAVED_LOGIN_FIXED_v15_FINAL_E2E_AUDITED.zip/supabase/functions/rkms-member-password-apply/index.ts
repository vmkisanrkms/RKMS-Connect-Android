import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(supabaseUrl, serviceKey);
const H = {"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const out=(x:unknown,status=200)=>new Response(JSON.stringify(x),{status,headers:H});
const mobile=(v:unknown)=>String(v??"").replace(/\D/g,"").slice(-10);
const emailOk=(v:unknown)=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v??""));
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:H});
 if(req.method!=="POST")return out({success:false,message:"POST required"},405);
 try{
  const b=await req.json();
  const mob=mobile(b.mobile),dob=String(b.dob??b.date_of_birth??"").trim(),email=String(b.email??"").trim().toLowerCase(),pass=String(b.password??b.new_password??b.newPassword??"");
  if(mob.length!==10||!dob||!emailOk(email))return out({success:false,message:"Mobile, DOB और Registered Email सही भरें।"},400);
  if(pass.length<8)return out({success:false,message:"Password कम से कम 8 अक्षरों का होना चाहिए।"},400);
  const {data:m,error:me}=await db.from("rkms_members").select("id,member_id,status,auth_user_id,email,date_of_birth").eq("status","APPROVED").eq("mobile",mob).eq("date_of_birth",dob).ilike("email",email).maybeSingle();
  if(me)throw me;if(!m)return out({success:false,message:"Mobile, DOB और Registered Email का Approved member record से मिलान नहीं हुआ।"},404);
  if(!m.auth_user_id)return out({success:false,message:"इस सदस्य का Login account उपलब्ध नहीं है।"},400);
  const {data:r,error:re}=await db.from("rkms_member_password_reset_requests").select("id,status").eq("member_id",m.id).eq("status","APPROVED").order("created_at",{ascending:false}).limit(1).maybeSingle();
  if(re)throw re;if(!r)return out({success:false,message:"इस पहचान के लिए PDA Approved Password Reset Request नहीं मिली।"},403);
  const {error:ae}=await db.auth.admin.updateUserById(m.auth_user_id,{password:pass,email_confirm:true});
  if(ae)throw ae;
  const {error:ue}=await db.from("rkms_member_password_reset_requests").update({status:"USED",updated_at:new Date().toISOString()}).eq("id",r.id).eq("status","APPROVED");
  if(ue)throw ue;
  return out({success:true,status:"USED",member_id:m.member_id,message:"नया Password सफलतापूर्वक save हो गया। अब इसी Password से Login करें।"});
 }catch(e){console.error(e);return out({success:false,message:e instanceof Error?e.message:"Server error"},500)}
});
