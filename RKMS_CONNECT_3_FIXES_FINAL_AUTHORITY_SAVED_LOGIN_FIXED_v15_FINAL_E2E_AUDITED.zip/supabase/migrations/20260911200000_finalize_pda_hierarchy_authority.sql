-- FINAL RKMS PDA AUTHORITY RULE
-- Normal PDA: strictly lower organizational level + own geographic scope.
-- Wing is never a restriction. Equal/higher posts are not manageable.
-- National President / Super Admin remain unrestricted.

CREATE OR REPLACE FUNCTION public.rkms_level_rank(p_level text)
RETURNS integer LANGUAGE sql IMMUTABLE SET search_path TO 'public','pg_catalog'
AS $$ SELECT CASE upper(coalesce(p_level,''))
 WHEN 'NATIONAL' THEN 8 WHEN 'STATE' THEN 7 WHEN 'MANDAL' THEN 6
 WHEN 'DISTRICT' THEN 5 WHEN 'ASSEMBLY' THEN 4 WHEN 'TEHSIL' THEN 3
 WHEN 'TAHSIL' THEN 3 WHEN 'SUBDISTRICT' THEN 3 WHEN 'BLOCK' THEN 2
 WHEN 'VILLAGE' THEN 1 WHEN 'GRAM' THEN 1 WHEN 'GRAM_PANCHAYAT' THEN 1 ELSE 0 END $$;

CREATE OR REPLACE FUNCTION public.rkms_officer_authority_rank(p_officer_id uuid)
RETURNS integer LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path TO 'public','pg_catalog' AS $$
declare v_level text; v_name text; v_level_rank int; v_role_rank int;
begin
 select upper(coalesce(p.level,'')),coalesce(p.post_name,'') into v_level,v_name
 from public.rkms_officers o join public.rkms_posts p on p.id=o.post_id where o.id=p_officer_id;
 v_level_rank:=public.rkms_level_rank(v_level);
 v_role_rank:=case when v_name like '%अध्यक्ष%' then 80 when v_name like '%उपाध्यक्ष%' then 70
  when v_name like '%महासचिव%' then 60 when v_name like '%संगठन मंत्री%' then 50
  when v_name like '%कोषाध्यक्ष%' then 40 when v_name like '%प्रचार मंत्री%' then 30
  when v_name like '%मीडिया प्रभारी%' then 20 when v_name like '%सचिव%' then 10 else 0 end;
 return v_level_rank*100+v_role_rank;
end; $$;

CREATE OR REPLACE FUNCTION public.rkms_can_manage_officer_post(p_actor_officer_id uuid,p_target_post_id uuid)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path TO 'public','pg_catalog' AS $$
declare a_level text; a_post text; a_it boolean; t_level text; t_post text;
begin
 select upper(trim(p.level)),coalesce(p.post_name,''),coalesce(p.is_it_cell,false) into a_level,a_post,a_it
 from public.rkms_officers o join public.rkms_posts p on p.id=o.post_id
 where o.id=p_actor_officer_id and o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date);
 if a_post is null then return false; end if;
 if a_level='NATIONAL' and a_post='राष्ट्रीय अध्यक्ष' and not a_it then return true; end if;
 select upper(trim(p.level)),coalesce(p.post_name,'') into t_level,t_post from public.rkms_posts p where p.id=p_target_post_id;
 if t_post is null then return false; end if;
 return public.rkms_level_rank(t_level) < public.rkms_level_rank(a_level);
end; $$;

CREATE OR REPLACE FUNCTION public.rkms_appointment_scope_allowed(p_authority text,p_state text,p_mandal text,p_district text,p_tehsil text,p_block text,p_village text,p_officer_id uuid)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path TO 'public','pg_catalog' AS $$
declare o public.rkms_officers%rowtype; a text;
begin
 select * into o from public.rkms_officers where id=p_officer_id and status='ACTIVE'
  and (valid_from is null or valid_from<=current_date) and (valid_to is null or valid_to>=current_date);
 if o.id is null then return false; end if;
 a:=upper(trim(coalesce(p_authority,'')));
 if a='NATIONAL' then return true; end if;
 if public.rkms_normalize_location_value(p_state)<>public.rkms_normalize_location_value(o.state) then return false; end if;
 if a='STATE' then return true; end if;
 if public.rkms_normalize_location_value(p_mandal)<>public.rkms_normalize_location_value(o.mandal) then return false; end if;
 if a='MANDAL' then return true; end if;
 if public.rkms_normalize_location_value(p_district)<>public.rkms_normalize_location_value(o.district) then return false; end if;
 if a='DISTRICT' or a='ASSEMBLY' then return true; end if;
 if public.rkms_normalize_location_value(p_tehsil)<>public.rkms_normalize_location_value(o.tehsil) then return false; end if;
 if a='TEHSIL' or a='TAHSIL' or a='SUBDISTRICT' then return true; end if;
 if public.rkms_normalize_location_value(p_block)<>public.rkms_normalize_location_value(o.block) then return false; end if;
 if a='BLOCK' then return true; end if;
 if public.rkms_normalize_location_value(p_village)<>public.rkms_normalize_location_value(o.village) then return false; end if;
 if a='VILLAGE' or a='GRAM' or a='GRAM_PANCHAYAT' then return true; end if;
 return false;
end; $$;

CREATE OR REPLACE FUNCTION public.rkms_can_manage_officer(p_actor_officer_id uuid,p_target_officer_id uuid)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path TO 'public','pg_catalog' AS $$
declare a public.rkms_officers%rowtype; t public.rkms_officers%rowtype; ap text; tp text; an text; ai boolean;
begin
 if p_actor_officer_id is null or p_target_officer_id is null or p_actor_officer_id=p_target_officer_id then return false; end if;
 select * into a from public.rkms_officers where id=p_actor_officer_id and status='ACTIVE' and (valid_from is null or valid_from<=current_date) and (valid_to is null or valid_to>=current_date);
 select * into t from public.rkms_officers where id=p_target_officer_id and status='ACTIVE' and (valid_from is null or valid_from<=current_date) and (valid_to is null or valid_to>=current_date);
 if a.id is null or t.id is null then return false; end if;
 select upper(trim(p.level)),coalesce(p.post_name,''),coalesce(p.is_it_cell,false) into ap,an,ai from public.rkms_posts p where p.id=a.post_id;
 select upper(trim(p.level)) into tp from public.rkms_posts p where p.id=t.post_id;
 if ap is null or tp is null then return false; end if;
 if ap='NATIONAL' and an='राष्ट्रीय अध्यक्ष' and not ai then return true; end if;
 if ap='STATE' and public.rkms_normalize_location_value(a.state)<>public.rkms_normalize_location_value(t.state) then return false; end if;
 if ap not in ('STATE') and public.rkms_normalize_location_value(a.mandal)<>public.rkms_normalize_location_value(t.mandal) then return false; end if;
 if ap not in ('STATE','MANDAL') and public.rkms_normalize_location_value(a.district)<>public.rkms_normalize_location_value(t.district) then return false; end if;
 if ap='TEHSIL' and public.rkms_normalize_location_value(a.tehsil)<>public.rkms_normalize_location_value(t.tehsil) then return false; end if;
 if ap='BLOCK' and (public.rkms_normalize_location_value(a.tehsil)<>public.rkms_normalize_location_value(t.tehsil) or public.rkms_normalize_location_value(a.block)<>public.rkms_normalize_location_value(t.block)) then return false; end if;
 if ap='VILLAGE' and (public.rkms_normalize_location_value(a.tehsil)<>public.rkms_normalize_location_value(t.tehsil) or public.rkms_normalize_location_value(a.block)<>public.rkms_normalize_location_value(t.block) or public.rkms_normalize_location_value(a.village)<>public.rkms_normalize_location_value(t.village)) then return false; end if;
 return public.rkms_level_rank(tp) < public.rkms_level_rank(ap);
end; $$;
