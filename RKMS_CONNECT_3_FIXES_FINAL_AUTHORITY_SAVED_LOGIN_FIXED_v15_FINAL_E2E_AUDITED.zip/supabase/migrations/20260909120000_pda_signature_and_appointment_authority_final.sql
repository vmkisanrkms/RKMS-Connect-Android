-- RKMS CONNECT FINAL: पदाधिकारी self-service Digital Signature + appointment authority rendering.
create or replace function public.rkms_update_my_signature(p_signature_url text)
returns jsonb language plpgsql security definer set search_path to 'public','pg_catalog' as $$
declare v_officer uuid; v_member uuid; v_name text; v_url text:=nullif(trim(coalesce(p_signature_url,'')),'');
begin
 v_officer:=public.rkms_current_officer_id();
 if v_officer is null then return jsonb_build_object('success',false,'message','केवल ACTIVE पदाधिकारी ही अपना हस्ताक्षर अपडेट कर सकता है।'); end if;
 select o.member_id,m.name into v_member,v_name from public.rkms_officers o join public.rkms_members m on m.id=o.member_id where o.id=v_officer and o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date);
 if v_member is null then return jsonb_build_object('success',false,'message','ACTIVE पदाधिकारी रिकॉर्ड नहीं मिला।'); end if;
 if v_url is not null and length(v_url)>1200 then return jsonb_build_object('success',false,'message','हस्ताक्षर file URL बहुत लंबा है।'); end if;
 if v_url is not null and v_url !~* '^https?://' then return jsonb_build_object('success',false,'message','हस्ताक्षर का मान्य URL आवश्यक है।'); end if;
 update public.rkms_officers set signature_url=v_url,signature_name=v_name,updated_at=now() where id=v_officer;
 return jsonb_build_object('success',true,'message',case when v_url is null then 'हस्ताक्षर हटा दिया गया।' else 'हस्ताक्षर सफलतापूर्वक सेव हो गया।' end,'officer_id',v_officer,'signature_url',coalesce(v_url,''));
end; $$;

create or replace function public.rkms_get_current_officer_profile()
returns jsonb language plpgsql stable security definer set search_path to 'public','pg_catalog' as $$
declare v_data jsonb;
begin
 select jsonb_build_object('officer_id',o.id,'member_id',o.member_id,'name',m.name,'mobile',m.mobile,'photo_url',m.photo_url,'post_id',o.post_id,'post_name',p.post_name,'authority_level',o.authority_level,'state',o.state,'mandal',o.mandal,'district',o.district,'tehsil',o.tehsil,'block',o.block,'village',o.village,'appointment_no',o.appointment_no,'joining_date',o.joining_date,'valid_from',o.valid_from,'valid_to',o.valid_to,'status',o.status,'signature_url',coalesce(o.signature_url,''),'signature_name',coalesce(o.signature_name,m.name,'')) into v_data
 from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id
 where m.auth_user_id=auth.uid() and o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date) order by o.created_at desc limit 1;
 if v_data is null then return jsonb_build_object('success',false,'message','Current ACTIVE officer नहीं मिला।'); end if;
 return jsonb_build_object('success',true,'officer',v_data);
end; $$;

create or replace function public.rkms_get_digital_id_meta(p_member_id uuid)
returns jsonb language plpgsql stable security definer set search_path to 'public','pg_catalog' as $$
declare v_member_id uuid; v_national_name text; v_national_post text; v_national_signature text; v_officer_id uuid; v_appointed_by uuid; v_appointing_authority text; v_appointed_name text; v_appointed_post text; v_appointed_signature text;
begin
 v_member_id:=public.rkms_current_member_id();
 if v_member_id is null or p_member_id<>v_member_id then return jsonb_build_object('success',false,'message','इस member की Digital ID देखने की अनुमति नहीं है।'); end if;
 select coalesce(l.name,'श्री V. M. Singh'),coalesce(l.post_name,'राष्ट्रीय अध्यक्ष') into v_national_name,v_national_post from public.rkms_leadership l where upper(coalesce(l.level,''))='NATIONAL' and upper(coalesce(l.status,'ACTIVE'))='ACTIVE' order by l.display_order nulls last,l.created_at asc limit 1;
 select o.signature_url into v_national_signature from public.rkms_officers o left join public.rkms_posts p on p.id=o.post_id where o.status='ACTIVE' and upper(coalesce(o.authority_level,p.level,''))='NATIONAL' and nullif(trim(coalesce(o.signature_url,'')),'') is not null order by o.created_at desc limit 1;
 select o.id,o.appointed_by_officer_id,o.appointing_authority_name into v_officer_id,v_appointed_by,v_appointing_authority from public.rkms_officers o where o.member_id=v_member_id and o.status='ACTIVE' and (o.valid_from is null or o.valid_from<=current_date) and (o.valid_to is null or o.valid_to>=current_date) order by o.created_at desc limit 1;
 if v_appointed_by is not null then select m.name,p.post_name,o.signature_url into v_appointed_name,v_appointed_post,v_appointed_signature from public.rkms_officers o join public.rkms_members m on m.id=o.member_id left join public.rkms_posts p on p.id=o.post_id where o.id=v_appointed_by; end if;
 if v_appointed_by is null and lower(trim(coalesce(v_appointing_authority,''))) in ('राष्ट्रीय अध्यक्ष','national president') then
   return jsonb_build_object('success',true,'national_president_name',coalesce(v_national_name,'श्री V. M. Singh'),'national_president_post',coalesce(v_national_post,'राष्ट्रीय अध्यक्ष'),'national_president_signature_url',coalesce(v_national_signature,''),'appointing_officer_name','','appointing_officer_post','','appointing_officer_signature_url','','appointment_authority_type','NATIONAL_PRESIDENT');
 end if;
 return jsonb_build_object('success',true,'national_president_name',coalesce(v_national_name,'श्री V. M. Singh'),'national_president_post',coalesce(v_national_post,'राष्ट्रीय अध्यक्ष'),'national_president_signature_url',coalesce(v_national_signature,''),'appointing_officer_name',coalesce(v_appointed_name,''),'appointing_officer_post',coalesce(v_appointed_post,''),'appointing_officer_signature_url',coalesce(v_appointed_signature,''),'appointment_authority_type',case when v_appointed_by is not null then 'OFFICER' else 'NONE' end);
end; $$;
