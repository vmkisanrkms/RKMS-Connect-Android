-- RKMS CONNECT V9: professional organization member directory.
-- Public/guest receives only safe directory fields.
-- Active PDA officers receive private member contact fields only inside their jurisdiction.
-- National President and Super Admin receive private member contact fields across the organization.
create or replace function public.rkms_directory_members(
  p_state text default null,
  p_mandal text default null,
  p_district text default null,
  p_tehsil text default null,
  p_block text default null,
  p_village text default null,
  p_limit integer default 500
)
returns jsonb
language plpgsql
stable
security definer
set search_path to 'public','pg_catalog'
as $$
declare
  v_is_admin boolean := false;
  v_officer_id uuid;
  v_level text;
  v_state text;
  v_mandal text;
  v_district text;
  v_tehsil text;
  v_block text;
  v_village text;
  v_private boolean := false;
  v_data jsonb;
begin
  v_is_admin := coalesce(public.rkms_is_super_admin(), false);

  if v_is_admin then
    v_private := true;
  else
    v_officer_id := public.rkms_current_officer_id();
    if v_officer_id is not null then
      select upper(o.authority_level), o.state, o.mandal, o.district, o.tehsil, o.block, o.village
      into v_level, v_state, v_mandal, v_district, v_tehsil, v_block, v_village
      from public.rkms_officers o
      where o.id = v_officer_id
        and o.status = 'ACTIVE'
        and (o.valid_from is null or o.valid_from <= current_date)
        and (o.valid_to is null or o.valid_to >= current_date)
      limit 1;
      if v_level is not null then v_private := true; end if;
    end if;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',m.id,
    'member_id',m.member_id,
    'name',m.name,
    'photo_url',m.photo_url,
    'membership_type',m.membership_type,
    'status',m.status,
    'state',public.rkms_normalize_location_value(m.state),
    'mandal',public.rkms_normalize_location_value(m.mandal),
    'district',public.rkms_normalize_location_value(m.district),
    'tehsil',public.rkms_normalize_location_value(m.tehsil),
    'block',public.rkms_normalize_location_value(m.block),
    'gram_panchayat',m.gram_panchayat,
    'village',public.rkms_normalize_location_value(m.village),
    'joining_date',case when v_private then m.joining_date else null end,
    'profile_completed',case when v_private then m.profile_completed else null end,
    'father_name',case when v_private then m.father_name else null end,
    'mobile',case when v_private then m.mobile else null end,
    'email',case when v_private then m.email else null end
  ) order by m.created_at desc),'[]'::jsonb)
  into v_data
  from public.rkms_members m
  where upper(coalesce(m.status,''))='APPROVED'
    and (nullif(trim(coalesce(p_state,'')),'') is null or public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(p_state))
    and (nullif(trim(coalesce(p_mandal,'')),'') is null or public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(p_mandal))
    and (nullif(trim(coalesce(p_district,'')),'') is null or public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(p_district))
    and (nullif(trim(coalesce(p_tehsil,'')),'') is null or public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(p_tehsil))
    and (nullif(trim(coalesce(p_block,'')),'') is null or public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(p_block))
    and (nullif(trim(coalesce(p_village,'')),'') is null or public.rkms_normalize_location_value(m.village)=public.rkms_normalize_location_value(p_village))
    and (
      not v_private
      or v_is_admin
      or v_level='NATIONAL'
      or (v_level='STATE' and public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state))
      or (v_level='MANDAL' and public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) and public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal))
      or (v_level='DISTRICT' and public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) and public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) and public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district))
      or (v_level='TEHSIL' and public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) and public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) and public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) and public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil))
      or (v_level='BLOCK' and public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) and public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) and public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) and public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) and public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block))
      or (v_level='VILLAGE' and public.rkms_normalize_location_value(m.state)=public.rkms_normalize_location_value(v_state) and public.rkms_normalize_location_value(m.mandal)=public.rkms_normalize_location_value(v_mandal) and public.rkms_normalize_location_value(m.district)=public.rkms_normalize_location_value(v_district) and public.rkms_normalize_location_value(m.tehsil)=public.rkms_normalize_location_value(v_tehsil) and public.rkms_normalize_location_value(m.block)=public.rkms_normalize_location_value(v_block) and public.rkms_normalize_location_value(m.village)=public.rkms_normalize_location_value(v_village))
    )
  limit greatest(1,least(coalesce(p_limit,500),500));

  return jsonb_build_object('success',true,'count',jsonb_array_length(v_data),'private_access',v_private,'data',v_data);
end;
$$;
revoke all on function public.rkms_directory_members(text,text,text,text,text,text,integer) from public;
grant execute on function public.rkms_directory_members(text,text,text,text,text,text,integer) to anon, authenticated;
