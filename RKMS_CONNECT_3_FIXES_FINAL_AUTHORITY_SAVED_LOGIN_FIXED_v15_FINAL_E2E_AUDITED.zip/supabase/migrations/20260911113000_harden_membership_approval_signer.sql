-- RKMS CONNECT V18: protect membership approval signer lookup.
-- Anonymous clients must not be able to enumerate signer identity/signature by member UUID.
create or replace function public.rkms_get_membership_approval_signer(p_member_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  m public.rkms_members%rowtype;
  o public.rkms_officers%rowtype;
  p public.rkms_posts%rowtype;
  current_officer uuid;
begin
  select * into m from public.rkms_members where id=p_member_id limit 1;
  if not found then
    return jsonb_build_object('success',false,'error','Member not found');
  end if;

  if auth.uid() is null then
    return jsonb_build_object('success',false,'error','Authentication required');
  end if;

  if m.auth_user_id is distinct from auth.uid()
     and not public.rkms_is_super_admin()
     and not public.rkms_is_national_president_current() then
    current_officer := public.rkms_current_officer_id();
    if current_officer is null or not public.rkms_officer_scope_matches_member(current_officer,p_member_id) then
      return jsonb_build_object('success',false,'error','Not authorized');
    end if;
  end if;

  if m.approved_by is null then
    return jsonb_build_object('success',true,'approver_officer_id',null,'approver_name','','approver_post','','approver_signature_url','');
  end if;

  select * into o from public.rkms_officers where id=m.approved_by limit 1;
  if not found then
    return jsonb_build_object('success',true,'approver_officer_id',m.approved_by,'approver_name','','approver_post','','approver_signature_url','');
  end if;

  if o.post_id is not null then
    select * into p from public.rkms_posts where id=o.post_id limit 1;
  end if;

  return jsonb_build_object('success',true,
    'approver_officer_id',o.id,
    'approver_name',coalesce(nullif(trim(o.signature_name),''),nullif(trim(o.appointing_authority_name),''),''),
    'approver_post',coalesce(p.post_name,''),
    'approver_signature_url',coalesce(o.signature_url,''));
end;
$function$;

revoke execute on function public.rkms_get_membership_approval_signer(uuid) from public;
grant execute on function public.rkms_get_membership_approval_signer(uuid) to authenticated;
