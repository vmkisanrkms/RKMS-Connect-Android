-- RKMS CONNECT FINAL: membership certificate / normal-member Digital ID signer.
-- The signer is the officer who approved the membership (rkms_members.approved_by).
create or replace function public.rkms_get_membership_approval_signer(p_member_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  m public.rkms_members%rowtype;
  o public.rkms_officers%rowtype;
  p public.rkms_posts%rowtype;
begin
  select * into m from public.rkms_members where id = p_member_id limit 1;
  if not found or m.approved_by is null then
    return jsonb_build_object('success',true,'approver_officer_id',null,'approver_name','','approver_post','','approver_signature_url','');
  end if;

  select * into o from public.rkms_officers where id = m.approved_by limit 1;
  if not found then
    return jsonb_build_object('success',true,'approver_officer_id',m.approved_by,'approver_name','','approver_post','','approver_signature_url','');
  end if;

  if o.post_id is not null then
    select * into p from public.rkms_posts where id = o.post_id limit 1;
  end if;

  return jsonb_build_object(
    'success',true,
    'approver_officer_id',o.id,
    'approver_name',coalesce(nullif(trim(o.signature_name),''),nullif(trim(o.appointing_authority_name),''),''),
    'approver_post',coalesce(p.post_name,''),
    'approver_signature_url',coalesce(o.signature_url,'')
  );
end;
$$;
