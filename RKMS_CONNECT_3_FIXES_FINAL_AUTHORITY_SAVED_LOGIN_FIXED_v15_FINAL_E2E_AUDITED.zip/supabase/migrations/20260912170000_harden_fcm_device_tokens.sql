-- Keep one current FCM token per authenticated user + app installation.
-- Multiple physical devices are still supported because each device has its own device_id.
CREATE UNIQUE INDEX IF NOT EXISTS rkms_fcm_tokens_one_token_per_user_device_idx
ON public.rkms_fcm_tokens(auth_user_id, device_id)
WHERE device_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS rkms_fcm_tokens_user_updated_idx
ON public.rkms_fcm_tokens(auth_user_id, updated_at DESC);
