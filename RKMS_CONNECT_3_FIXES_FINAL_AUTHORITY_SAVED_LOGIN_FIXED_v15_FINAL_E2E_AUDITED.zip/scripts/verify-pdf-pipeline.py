from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
app=(root/'app.js').read_text(encoding='utf-8')
checks={
 'build-image-pdf': bool(re.search(r'function buildImagePdf\s*\(',app)),
 'canvas-report-renderer': bool(re.search(r'async function renderReportToCanvas\s*\(',app)),
 'canvas-to-pdf': bool(re.search(r'function pdfBlobFromCanvas\s*\(',app)),
 'report-uses-canvas-pdf': 'pdfBlobFromCanvas(reportCanvas)' in app,
 'native-chunked-save': all(x in app for x in ['beginPdfSave','appendPdfChunk','finishPdfSave']),
 'member-download-guard': 'state.role!=="officer"&&state.role!=="super_admin"' in app,
 'scoped-rpc': 'rkms_get_report_download_data' in app,
 'remote-image-cors-prep': 'mode:"cors"' in app and 'readAsDataURL' in app and 'img.crossOrigin="anonymous"' in app,
 'tainted-image-safe-render': 'const safe=!/^https?:\\/\\//i.test(src)||src.startsWith(location.origin)' in app,
}
print('RKMS PDF PIPELINE STATIC VERIFICATION')
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if not all(checks.values()): sys.exit(1)
print('PASS: report PDF no longer depends on SVG foreignObject rendering; it uses Canvas text rendering before PDF encoding.')
