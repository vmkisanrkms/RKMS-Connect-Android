from pathlib import Path
import re

app=Path('app.js').read_text(encoding='utf-8')

m=re.search(r'async function publicOfficers\(\)\{(.*?)\n\}', app, re.S)
assert m, 'publicOfficers missing'
assert 'return arrOf(await rpc("rkms_get_active_officers"),"officers");' in m.group(1), 'Officer directory is unexpectedly filtered'
assert 'rkmsOfficerCanAccessTarget' not in m.group(1), 'Officer directory must not use management access filter'

m=re.search(r'async function loadDirectoryMembers\(filters=\{\}\)\{(.*?)\n\}', app, re.S)
assert m, 'loadDirectoryMembers missing'
assert 'return arrOf(r);' in m.group(1), 'Member directory does not return rows'
assert 'rows.filter(rkmsOfficerCanAccessMember)' not in m.group(1), 'Member directory is unexpectedly filtered'

# Management list must still be filtered, so authorization is not weakened.
assert 'allRows.filter(o=>rkmsOfficerCanManageTarget(o))' in app, 'Management officer list authorization filter missing'
assert 'rkmsOfficerCanAccessMember' in app, 'Member sensitive-access guard missing'

print('DIRECTORY LIST VERIFICATION: PASS')
print('PASS: PDA officer directory remains visible')
print('PASS: member directory remains visible')
print('PASS: management officer list remains authorization-filtered')
print('PASS: sensitive member detail/contact guard remains present')
