from pathlib import Path

path = Path('app/src/main/java/org/rkms/connect/MainActivity.java')
s = path.read_text(encoding='utf-8')

imports = [
    'import android.content.ContentValues;',
    'import android.media.MediaScannerConnection;',
    'import android.os.Environment;',
    'import android.provider.MediaStore;',
    'import android.util.Base64;',
    'import java.io.File;',
    'import java.io.FileOutputStream;',
]
anchor = 'import android.content.Context;'
for imp in imports:
    if imp not in s:
        s = s.replace(anchor, anchor + '\n' + imp, 1)

if 'beginPdfSave(String filename)' not in s:
    marker = '''        @JavascriptInterface\n        public void showNotification(String title, String body) { NotificationHelper.show(context, title, body, "home", null); }'''
    methods = '''        private java.io.ByteArrayOutputStream pdfBuffer;\n        private String pdfSaveName;\n\n        private String sanitizePdfName(String filename) {\n            String safe = filename == null ? "RKMS-document.pdf" : filename.trim();\n            safe = safe.replaceAll("[^A-Za-z0-9._\\\\- \\u0900-\\u097F]", "_");\n            if (safe.isEmpty()) safe = "RKMS-document.pdf";\n            if (!safe.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf")) safe += ".pdf";\n            return safe;\n        }\n\n        @JavascriptInterface\n        public synchronized String beginPdfSave(String filename) {\n            try {\n                pdfSaveName = sanitizePdfName(filename);\n                pdfBuffer = new java.io.ByteArrayOutputStream(256 * 1024);\n                return "OK";\n            } catch (Throwable e) {\n                pdfBuffer = null;\n                pdfSaveName = null;\n                return "ERROR: PDF save शुरू नहीं हो सकी।";\n            }\n        }\n\n        @JavascriptInterface\n        public synchronized String appendPdfChunk(String base64Chunk) {\n            try {\n                if (pdfBuffer == null) return "ERROR: PDF save session नहीं मिली।";\n                if (base64Chunk == null || base64Chunk.isEmpty()) return "OK";\n                byte[] chunk = Base64.decode(base64Chunk, Base64.DEFAULT);\n                pdfBuffer.write(chunk);\n                return "OK";\n            } catch (Throwable e) {\n                return "ERROR: PDF data save नहीं हो सकी।";\n            }\n        }\n\n        @JavascriptInterface\n        public synchronized String finishPdfSave() {\n            try {\n                if (pdfBuffer == null) return "ERROR: PDF save session नहीं मिली।";\n                byte[] pdf = pdfBuffer.toByteArray();\n                if (pdf.length < 100) return "ERROR: PDF data अमान्य है।";\n                String safe = sanitizePdfName(pdfSaveName);\n\n                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {\n                    ContentValues values = new ContentValues();\n                    values.put(MediaStore.Downloads.DISPLAY_NAME, safe);\n                    values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");\n                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/RKMS CONNECT");\n                    values.put(MediaStore.Downloads.IS_PENDING, 1);\n\n                    android.content.ContentResolver resolver = context.getContentResolver();\n                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);\n                    if (uri == null) return "ERROR: Downloads folder में PDF file नहीं बन सकी।";\n                    try (java.io.OutputStream out = resolver.openOutputStream(uri)) {\n                        if (out == null) throw new java.io.IOException("Output stream नहीं मिला");\n                        out.write(pdf);\n                        out.flush();\n                    } catch (Throwable writeError) {\n                        try { resolver.delete(uri, null, null); } catch (Throwable ignored) {}\n                        throw writeError;\n                    }\n                    ContentValues done = new ContentValues();\n                    done.put(MediaStore.Downloads.IS_PENDING, 0);\n                    resolver.update(uri, done, null, null);\n                } else {\n                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "RKMS CONNECT");\n                    if (!dir.exists() && !dir.mkdirs()) return "ERROR: Downloads folder नहीं बन सका।";\n                    File outFile = new File(dir, safe);\n                    try (FileOutputStream out = new FileOutputStream(outFile)) {\n                        out.write(pdf);\n                        out.flush();\n                    }\n                    MediaScannerConnection.scanFile(context, new String[]{outFile.getAbsolutePath()}, new String[]{"application/pdf"}, null);\n                }\n                pdfBuffer = null;\n                pdfSaveName = null;\n                return "OK";\n            } catch (Throwable e) {\n                android.util.Log.e("RKMS_PDF", "PDF save failed", e);\n                pdfBuffer = null;\n                pdfSaveName = null;\n                return "ERROR: PDF Downloads में save नहीं हो सकी।";\n            }\n        }\n\n        @JavascriptInterface\n        public synchronized void cancelPdfSave() {\n            pdfBuffer = null;\n            pdfSaveName = null;\n        }\n\n'''
    import re
    m = re.search(r'(?m)^\s*@JavascriptInterface\s*\n\s*public\s+void\s+showNotification\s*\(\s*String\s+title\s*,\s*String\s+body\s*\)\s*\{[^\n]*\}\s*$', s)
    if not m:
        raise SystemExit('Native bridge marker not found; refusing unsafe patch.')
    s = s[:m.start()] + methods + s[m.start():]

path.write_text(s, encoding='utf-8')
print('Android PDF chunked bridge patch applied:', path)
