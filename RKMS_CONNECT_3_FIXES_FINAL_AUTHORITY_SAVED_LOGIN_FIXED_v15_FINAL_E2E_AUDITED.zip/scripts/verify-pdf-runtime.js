const fs=require('fs');
function pdfAsciiBytes(str){return new TextEncoder().encode(str)}
function pdfConcat(parts){const total=parts.reduce((n,p)=>n+p.length,0);const out=new Uint8Array(total);let o=0;for(const p of parts){out.set(p,o);o+=p.length}return out}
function buildImagePdf(jpegs,width,height){
 const objects=[],pageIds=[];let next=3;const catalogId=1,pagesId=2;
 for(let i=0;i<jpegs.length;i++){
  const pageId=next++,contentId=next++,imageId=next++;pageIds.push(pageId);
  objects.push({id:pageId,bytes:null,dict:`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im${i+1} ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>`});
  const draw=`q\n595.28 0 0 841.89 0 0 cm\n/Im${i+1} Do\nQ\n`,cb=pdfAsciiBytes(draw);
  objects.push({id:contentId,bytes:pdfConcat([pdfAsciiBytes(`<< /Length ${cb.length} >>\nstream\n`),cb,pdfAsciiBytes('endstream')]),dict:null});
  const jpg=jpegs[i];objects.push({id:imageId,bytes:pdfConcat([pdfAsciiBytes(`<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`),jpg,pdfAsciiBytes('\nendstream')]),dict:null});
 }
 objects.unshift({id:pagesId,bytes:null,dict:`<< /Type /Pages /Kids [${pageIds.map(x=>x+' 0 R').join(' ')}] /Count ${pageIds.length} >>`});objects.unshift({id:catalogId,bytes:null,dict:`<< /Type /Catalog /Pages ${pagesId} 0 R >>`});objects.sort((a,b)=>a.id-b.id);
 const chunks=[pdfAsciiBytes('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n')];const offsets=new Array(objects.length+1).fill(0);let pos=chunks[0].length;
 for(const obj of objects){offsets[obj.id]=pos;const head=pdfAsciiBytes(`${obj.id} 0 obj\n`),body=obj.dict?pdfAsciiBytes(obj.dict):obj.bytes,tail=pdfAsciiBytes('\nendobj\n');chunks.push(head,body,tail);pos+=head.length+body.length+tail.length}
 const xrefPos=pos;let xref=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;for(let i=1;i<=objects.length;i++)xref+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';xref+=`trailer\n<< /Size ${objects.length+1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;chunks.push(pdfAsciiBytes(xref));return pdfConcat(chunks);
}
const imagePath=process.argv[2];if(!imagePath) throw new Error('Usage: node verify-pdf-runtime.js <jpeg> [output]');
const out=process.argv[3]||'/tmp/rkms-pdf-runtime-test.pdf';const jpg=new Uint8Array(fs.readFileSync(imagePath));if(jpg.length<1000)throw new Error('Test JPEG is unexpectedly small.');const pdf=buildImagePdf([jpg],794,1123);fs.writeFileSync(out,pdf);if(pdf.length<1000||!pdf.slice(0,8).every((x,i)=>x===Buffer.from('%PDF-1.4')[i]))throw new Error('Generated PDF header invalid.');console.log(`PASS: generated ${out} (${pdf.length} bytes)`);
