from pathlib import Path
import re
app=Path('app.js').read_text(encoding='utf-8')
setup=Path('scripts/setup-android-native.sh').read_text(encoding='utf-8')
workflow=Path('.github/workflows/android-apk.yml').read_text(encoding='utf-8')
checks={
 'Capacitor push plugin dependency': '@capacitor/push-notifications' in workflow,
 'FCM registration function': 'async function rkmsRegisterFcmPush' in app,
 'stable device id': 'function rkmsDeviceId' in app and 'device_id:rkmsDeviceId()' in app,
 'registration listener': "addListener('registration'" in app,
 'foreground listener': "addListener('pushNotificationReceived'" in app,
 'tap listener': "addListener('pushNotificationActionPerformed'" in app,
 'notification channel': "rkms_notifications_v2" in app and 'createRkmsNotificationChannel' in setup,
 'resume token re-registration': 'visibilitychange' in app and 'rkmsRegisterFcmPush()' in app,
 'server endpoint': 'rkms-fcm-push' in app,
 'no client chat push duplicate fallback': 'rkms-fcm-dispatch' not in app[app.find('async function sendChatMessage'):app.find('function showChatActionSheet')],
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
if not all(checks.values()): raise SystemExit('FCM pipeline verification failed')
print('FCM PIPELINE STATIC VERIFICATION: PASS')
