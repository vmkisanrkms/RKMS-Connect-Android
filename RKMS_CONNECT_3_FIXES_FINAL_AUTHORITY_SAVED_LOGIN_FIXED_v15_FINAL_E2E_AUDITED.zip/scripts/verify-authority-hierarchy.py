from pathlib import Path

app=Path('app.js').read_text(encoding='utf-8')
mig=list(Path('supabase/migrations').glob('*finalize_pda_hierarchy_authority.sql'))
assert mig, 'final PDA authority migration missing'
sql=mig[-1].read_text(encoding='utf-8')
checks=[
    ('ASSEMBLY:4', app),
    ('tl>=ol', app),
    ('allRows.filter(o=>rkmsOfficerCanManageTarget(o))', app),
    ('Wing is never a restriction', app),
    ("return public.rkms_level_rank(t_level) < public.rkms_level_rank(a_level);", sql),
    ("if a='DISTRICT' or a='ASSEMBLY' then return true;", sql),
    ("ASSEMBLY", sql),
]
for needle,text in checks:
    assert needle in text, f'missing authority check: {needle}'
print('PDA AUTHORITY HIERARCHY VERIFICATION: PASS')
print('PASS: strictly lower organizational level only')
print('PASS: equal/higher posts excluded')
print('PASS: cross-wing lower-level management allowed')
print('PASS: own geographic scope preserved')
print('PASS: ASSEMBLY hierarchy handled')
