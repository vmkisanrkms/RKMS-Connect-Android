# RKMS CONNECT — Chat JWT Resume Fix

## Fix
- Refresh the Supabase access token silently when Android resumes the app after screen lock/background time.
- Retry authenticated API/RPC requests once when the server returns HTTP 401 or a JWT/token-expired/invalid-token error.
- Prevent an older Android native-session snapshot from overwriting a newer local access token during app startup.
- Reconnect Chat Realtime only after the session has been refreshed.
- Re-fetch the active Chat conversation after resume so the user does not see a stale JWT-expired error.

## Expected behavior
After leaving RKMS Chat open, locking the phone for several minutes, and unlocking it, Chat should continue working without requiring the user to log in again.

The existing persistent-login, FCM, and Chat permission/RPC logic is otherwise unchanged.
