# RKMS CONNECT V14 — End-to-End Audit Summary

## Scope audited
- Appointment-letter signer rule
- PDA hierarchy / rank-down authorization
- Saved login + Android native bridge
- PDF/report pipeline
- FCM registration, background/closed-app delivery path, token rotation and duplicate-token hardening
- Android launcher icon sizing
- GitHub Actions APK source selection and build verification

## Appointment signer final rule
1. PDA officer appointment: National President block + appointing officer block.
2. National President / Super Admin appointment: only the National President block; the other side is completely empty.
3. The appointment-letter signer display does not hard-code a second `राष्ट्रीय अध्यक्ष` label.
4. National President's real authority designation remains in the database for authorization; display-only shortening is limited to the signer presentation.

## FCM final architecture
- Android uses Capacitor Push Notifications.
- Each installation gets a persistent `device_id`.
- The current FCM token is registered against the authenticated account and installation.
- A unique database index prevents two current tokens for the same user + installation.
- Android creates the `rkms_notifications_v2` high-importance channel natively at startup.
- Server sends FCM HTTP v1 with HIGH priority, notification payload, default sound/vibration and the RKMS channel.
- Notification tap routes to Chat or Notifications using FCM data payload.
- Foreground notifications are handled in-app.
- Android resume re-registers the token to cover token rotation after long idle/lock periods.
- Invalid FCM tokens are removed automatically.
- Delivery attempts are written to `rkms_fcm_delivery_log`.
- Re-registration retries only recent undelivered queue items (24h, max 20), avoiding an unbounded historical replay.

## Live backend audit
- Exactly one NATIONAL officer record is currently present in `rkms_officers`.
- The stale member-less National record previously identified is no longer present.
- FCM Edge Function `rkms-fcm-push` is ACTIVE at version 9.
- FCM dispatch Edge Function `rkms-fcm-dispatch-v2` is ACTIVE at version 2.
- Live FCM token records exist and recent queue entries include successful deliveries as well as invalid-token cleanup cases.

## Static verification completed
- JavaScript syntax
- RKMS final checks
- FCM pipeline checks
- Native bridge checks
- PDF pipeline checks
- Report-download scope checks
- Saved-login checks
- PDA authority hierarchy checks
- Directory-list checks
- SHA256 checksum verification
- Bash syntax
- Python compilation
- GitHub Actions YAML parsing

## Important runtime limitation
Static/database verification cannot truthfully prove a physical Android device remained backgrounded/closed for 5h, 12h and 24h. Those elapsed-time checks still require one real-device test cycle. The code/backend path for those tests is now hardened for token rotation, Android notification channels, HIGH-priority FCM delivery, closed-app display and tap routing.
