# RKMS Book Reader v2.1

Base: previous v1.7 Book Reader structure.

Changes:
- Preserved 61-page book, cover/page mapping, page-curl visuals, controls, preload, resume and download bridge.
- Preserved single-finger horizontal page-curl at native 1x scale.
- Removed custom pinch zoom logic; Book uses Android WebView native pinch zoom.
- At WebView visualViewport scale > 1.02, page-curl gesture is disabled so one-finger movement is left to native WebView pan/scroll.
- Book viewport clipping was removed/relaxed to allow native zoomed content to move.
- Native WebView zoom is disabled outside Book and enabled only while Book is open.
- Download remains native current-page asset download to Downloads/RKMS.
- Version 2.1 / versionCode 9.
