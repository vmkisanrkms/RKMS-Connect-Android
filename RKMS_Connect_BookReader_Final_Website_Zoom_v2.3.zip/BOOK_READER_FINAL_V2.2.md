# Book Reader Final v2.2

- Preserved the 61-page reader, page-curl visual, First/Previous/Next/Last/Download controls, preload and resume.
- Native Android WebView pinch zoom remains the only zoom engine; custom pinch zoom is removed.
- Added explicit active-touch tracking: the instant a second finger appears, page-curl is cancelled and native pinch owns the gesture.
- While zoomed or multi-touch is active, the page-curl handler never consumes the gesture, allowing native one-finger pan.
- Download is native-only inside the Android app; the old WebView external ACTION_VIEW fallback is no longer used by the Book button.
- Android download saves the selected page to Downloads/RKMS using the existing 61-page asset mapping.
