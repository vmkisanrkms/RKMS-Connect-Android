package org.rkms.connect;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class NotificationWorkerBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) { }
}
