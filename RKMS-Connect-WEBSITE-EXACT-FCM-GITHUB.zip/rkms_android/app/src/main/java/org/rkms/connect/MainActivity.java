package org.rkms.connect;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION = 1001;
    private static final int FILE_CHOOSER = 2001;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.addJavascriptInterface(new RKMSBridge(this), "RKMSNative");
        NotificationHelper.ensureChannel(this);
        requestNotificationPermission();
        try { FCMTokenRegistrar.registerCurrentToken(this); } catch (Throwable ignored) {}
        loadInitialRoute(getIntent());
    }

    private void loadInitialRoute(Intent intent) {
        String route = intent == null ? null : intent.getStringExtra("rkms_route");
        if (route == null || route.trim().isEmpty()) route = "";
        if (!route.startsWith("#") && !route.isEmpty()) route = "#" + route;
        webView.loadUrl("file:///android_asset/www/index.html" + route);
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
            @Override public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                installNativeSessionSync(v);
            }
        });
        view.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent i = params.createIntent();
                    startActivityForResult(i, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
    }

    private void installNativeSessionSync(WebView v) {
        String js = "(function(){if(window.__RKMSNativeSync)return;window.__RKMSNativeSync=true;" +
                "function s(){try{var a=localStorage.getItem('rkms_access_token')||'';var r=localStorage.getItem('rkms_refresh_token')||'';" +
                "if(window.RKMSNative){RKMSNative.syncSession(a,r);}}catch(e){}}" +
                "var os=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){var x=os.call(this,k,v);" +
                "if(k==='rkms_access_token'||k==='rkms_refresh_token')setTimeout(s,0);return x};" +
                "var or=Storage.prototype.removeItem;Storage.prototype.removeItem=function(k){var x=or.call(this,k);" +
                "if(k==='rkms_access_token'||k==='rkms_refresh_token')setTimeout(s,0);return x};" +
                "window.addEventListener('visibilitychange',s);s();})();";
        v.evaluateJavascript(js, null);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String route = intent == null ? null : intent.getStringExtra("rkms_route");
        if (route != null && !route.trim().isEmpty() && webView != null) {
            if (!route.startsWith("#")) route = "#" + route;
            webView.loadUrl("file:///android_asset/www/index.html" + route);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER) {
            if (fileCallback != null) fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    public static class RKMSBridge {
        private final Context context;
        RKMSBridge(Context c) { context = c.getApplicationContext(); }
        @JavascriptInterface public void syncSession(String accessToken, String refreshToken) {
            String old = SessionStore.access(context);
            if (accessToken == null) accessToken = "";
            if (refreshToken == null) refreshToken = "";
            if (accessToken.trim().isEmpty()) {
                if (!old.isEmpty()) { try { FCMTokenRegistrar.unregister(context, old); } catch (Throwable ignored) {} }
                SessionStore.clear(context);
                return;
            }
            SessionStore.save(context, accessToken, refreshToken);
            if (!accessToken.equals(old)) {
                try { FCMTokenRegistrar.register(context, accessToken); } catch (Throwable ignored) {}
            }
        }
        @JavascriptInterface public void showNotification(String title, String body) { NotificationHelper.show(context, title, body); }
        @JavascriptInterface public void toast(String message) { Toast.makeText(context, message, Toast.LENGTH_SHORT).show(); }
    }
}
