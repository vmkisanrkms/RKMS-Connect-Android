package org.rkms.connect;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class NotificationCheckWorker extends Worker {
    private static final String SUPABASE_URL = "https://kzczivaydandiqgnzfeg.supabase.co";
    private static final String ANON_KEY = "sb_publishable_zPG4bJ8bpE8mokGVgEmNxg_eCDlju_9";
    public NotificationCheckWorker(@NonNull Context c, @NonNull WorkerParameters p) { super(c,p); }
    @NonNull @Override public Result doWork() {
        String access=SessionStore.access(getApplicationContext());
        if(access.isEmpty()) return Result.success();
        return Result.success();
    }
}
