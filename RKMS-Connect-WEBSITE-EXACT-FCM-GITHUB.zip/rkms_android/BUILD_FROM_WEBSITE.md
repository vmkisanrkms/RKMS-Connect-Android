# Build source decision

Source of truth: the uploaded `website-app.zip`.

The Android runtime website is copied from that package. The previous Android project is used only for the Android wrapper/FCM infrastructure (Firebase configuration, notification service, permissions, and WebView shell); its old web UI is NOT copied over the new runtime website.

This separation prevents the previous problem where an older bundled `app.js` made the APK show an older/different Chat screen.
