# RKMS Connect — Website-to-Android exact-copy build

This Android project is built from the **uploaded `website-app.zip` as the source of truth**.

## What is bundled
- `app/src/main/assets/www/index.html`
- `app/src/main/assets/www/app.js`
- `app/src/main/assets/www/styles.css`
- `app/src/main/assets/www/config.js`
- `app/src/main/assets/www/assets/**`

These runtime website files are copied from the supplied website package. The Android app does not replace the website's screens with a separate native UI: it displays the same website inside Android WebView, so the website's member/officer dashboards, Digital ID, appointment letter, book, complaints, notifications, and **Recent Chats / New Chat / conversation screens** come from the same website code.

The original supplied website package is also preserved at the project root as `website-source/` for audit/comparison.

## Chat
The bundled `app.js` contains the website's Recent Chats/New Chat implementation and uses the live Supabase chat RPCs. The Android wrapper does not ship an alternate/old chat screen.

## FCM notifications
The Android wrapper includes Firebase Cloud Messaging. After login, the WebView session tokens are detected without changing the website UI and registered with the live Supabase `rkms-fcm-push` Edge Function. Incoming FCM messages create high-priority Android notifications and can open the app directly on `#chat` (or the route supplied in the push payload).

The Firebase project configuration is the existing RKMS project configuration supplied with the previous Android build and matches package `org.rkms.connect`.

## File upload support
The WebView includes an Android file chooser so the website's existing file/photo inputs can open the device picker.

## GitHub build
The included `.github/workflows/build-apk.yml` installs Java 17 + Gradle 8.13 and builds an installable debug APK. The APK is uploaded as a GitHub Actions artifact named:

`RKMS-Connect-Website-Sync-FCM-Debug`

## Important
The website source itself was not redesigned in this Android project. If a website screen is present in the supplied website package, the Android WebView uses that screen. If the website package is later updated, replace `website-source` and refresh the runtime copy under `app/src/main/assets/www/` before building.
