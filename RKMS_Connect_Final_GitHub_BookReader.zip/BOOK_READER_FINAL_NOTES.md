# RKMS Connect — GitHub Final Package (Book Reader)

This package preserves the RKMS Connect Android project and includes the Book Reader feature.

Book Reader included:
- Book cover + 60 page images
- Next / Previous / First / Last page controls
- Saved last-read page using localStorage
- Page progress indicator
- Zoom In / Zoom Out / Reset
- Two-finger pinch zoom on mobile
- Double-tap zoom
- Page preloading
- Page-switch transition
- Download-current-page action
- GitHub Actions APK build workflow

Source package: RKMS_Connect_FINAL_V17.zip
