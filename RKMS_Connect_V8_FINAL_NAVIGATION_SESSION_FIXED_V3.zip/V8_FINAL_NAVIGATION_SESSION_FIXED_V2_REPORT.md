# RKMS Connect V8 Final Navigation + Session Fix V2

## Targeted defects
1. Android physical/gesture Back from notification-opened Chat could finish MainActivity.
2. Notification intent could be retained and replay the same Chat after Activity recreation.
3. SPA hash/WebView history was being used as the primary Android Back source.
4. Native session restore could briefly fall through to Login during boot.

## Changes
- MainActivity Back is deterministic: Chat -> Home, login -> Home, other managed screens use managed history.
- Added JS bridge hooks `rkmsAndroidRouteChanged` and `rkmsAndroidBack`.
- Notification route is anchored in the same SPA history: Home -> Chat.
- Consumed notification intent is cleared from Activity intent state.
- Chat header back now uses managed navigation instead of only re-rendering.
- Boot explicitly calls `ensureSession()` then `refreshIdentity(true)` before rendering.
- Removed forced WebView `location.reload()` during native session synchronization.
- Existing FCM channel/sound/vibration and notification tap code preserved.

## Verification
- ZIP structure verified.
- MainActivity contains notification route handling and deterministic Back logic.
- SessionStore access/refresh persistence present.
- NotificationHelper high-priority channel and PendingIntent present.
- FCM service present.
- `assets/www/index.html` and `app.js` present.
- Real-device behavior must still be confirmed with a newly built APK.
