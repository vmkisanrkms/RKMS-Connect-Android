RKMS Connect V8 Navigation + Session Fix V3
==============================================

Verified source changes:
- MainActivity Android Back: Chat/chat/<id> deterministically returns to #home; it no longer depends on WebView history for Chat.
- Login/officer-login Back is normalized to Home.
- Saved native role is restored into localStorage as rkms_native_role.
- Session /user request gets one silent refresh-and-retry before failing.
- refreshIdentity retains persisted role during a transient /user failure.
- chatActorType can use the persisted role during session restore.
- Existing FCM sound/vibration/notification route code preserved.
- Existing notification route boot sequence preserved: Home entry then route push.
- ZIP integrity checked after packaging.
