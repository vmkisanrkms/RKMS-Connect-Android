# RKMS CONNECT V16 Final Build Verification

Final source includes the established signer hierarchy plus requirements 11 and 12.

1. Normal member Digital ID signer = membership approving officer (`approved_by`).
2. Normal member Membership Certificate signer = membership approving officer (`approved_by`).
3. Officer Digital ID signer = officer who appointed them (`appointed_by_officer_id`).
4. Officer Appointment Letter signer = officer who appointed them (`appointed_by_officer_id`).
5. National President / Super Admin appointment = only National President authority block.
6. Opposite authority block is completely absent in National President appointments.
7. Stored backend digital signature has priority; defined Gurpratap fallback remains restricted to its intended signer identity/post.
8. Appointment metadata resolves from `rkms_officers`, not `rkms_appointment_authority`.
9. Appointment authority/name/signature hierarchy is enforced in the database RPC.
10. Frontend cache-busting and Netlify no-cache rules retained.
11. Login credentials can be saved only through the Android native secure-credential bridge; password is encrypted with an Android Keystore AES key and retrieval requires biometric/device-credential verification. Logout clears the RKMS session but intentionally does not erase the saved credential.
12. Login UI shows the saved ID only after the first matching character is typed; tapping it invokes fingerprint/device PIN/password verification and then fills ID + password. Launcher logo is padded slightly so the full circular RKMS emblem remains visible.

Validation performed: JavaScript syntax check passed; workflow YAML syntax check passed; source logo SHA-256 remains the expected exact RKMS logo; launcher icon padding was rendered and visually checked.
