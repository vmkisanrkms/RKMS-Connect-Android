# RKMS CONNECT — iOS GitHub Build

This release is prepared for Capacitor iOS generation and GitHub-hosted macOS/Xcode builds. The workflow uses the current `macos-26` standard arm64 runner and does not depend on a hard-coded Xcode application path.

## What the workflow does

1. Installs the existing RKMS web dependencies plus `@capacitor/ios` 6.2.2.
2. Builds the existing web application into `dist/`.
3. Generates the native `ios/` Capacitor project in CI.
4. Syncs the web assets and Capacitor plugins.
5. Applies RKMS app metadata, safe iOS settings and the RKMS launcher icon.
6. Compiles both the physical-device (`iphoneos`) and simulator (`iphonesimulator`) targets.
7. Publishes both builds as GitHub Actions artifacts.

## Important: unsigned vs App Store/TestFlight IPA

The default workflow intentionally builds **unsigned** iOS binaries. This proves that the project compiles for iPhone without requiring Apple signing credentials in the repository.

An unsigned `.app` is **not** directly installable on a normal iPhone. For TestFlight/App Store distribution, the repository must additionally be configured with an Apple Developer team, signing certificate/provisioning profile (or App Store Connect signing workflow), and the Apple Push Notification entitlement/credentials.

Do not commit Apple certificates, private keys, provisioning profiles, APNs keys, or passwords to the repository. Store them in GitHub Actions Secrets.

## Push notifications

The JavaScript now identifies the native platform when registering a push token (`ios` vs `android`). The existing RKMS push backend still needs an iOS-capable delivery path and Apple/Firebase credentials before background/closed-app iPhone notifications can be considered production-ready.

## Current Android behavior

The Android-specific native bridge remains untouched. The iOS work is additive and does not remove the Android build path.

## What is verified in this ZIP

- Capacitor iOS dependency: `@capacitor/ios` 6.2.2
- SPM iOS project generation in CI
- iPhoneOS and Simulator compilation commands
- JavaScript syntax check
- iOS source/static verification
- RKMS icon generation
- No Apple certificates, private keys, provisioning profiles, or APNs `.p8` files are included

## Important production note

The GitHub workflow is an **unsigned build-validation workflow**. It proves the iOS target can be generated and compiled, but it does not create a signed TestFlight/App Store IPA. Apple signing must be added through GitHub Actions secrets when distribution is required.

The current RKMS source also uses the existing `rkms-fcm-push` backend endpoint. The iOS Capacitor Push Notifications registration callback provides the native iOS/APNs registration token; it must not be treated as an FCM token unless an iOS Firebase Messaging layer is configured. Therefore iOS background/closed-app push delivery is **not marked production-ready** in this ZIP.
