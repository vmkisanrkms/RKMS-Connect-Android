# RKMS CONNECT iOS Readiness Audit

## Result

**GitHub iOS compile readiness: PASS (static/source audit).** The workflow is designed to generate the native iOS project during CI, so the repository does not need to contain a generated `ios/` folder. A real GitHub-hosted macOS build is still required for final external confirmation.

The uploaded RKMS CONNECT source has been prepared for **Capacitor iOS generation and GitHub-hosted macOS/Xcode compilation** without removing or replacing the existing Android implementation.

## PASS

- Existing Capacitor architecture is retained.
- `@capacitor/ios` 6.2.2 is added alongside the existing Android packages.
- Capacitor iOS configuration is present.
- Existing Supabase/web application remains the shared codebase.
- iOS GitHub Actions workflow is included and uses the current `macos-26` runner without a brittle hard-coded Xcode path.
- Workflow generates the iOS platform in CI, so a Mac is not required on the developer's local machine just to compile.
- Workflow compiles both `iphoneos` and `iphonesimulator` targets.
- RKMS app icon generation is automated from the existing 1536×1536 transparent RKMS logo.
- iOS metadata and export-compliance declaration are prepared.
- Safe-area handling already exists in the existing CSS and remains active.
- Android-specific bridge code remains available for Android; it is not required by the iOS build.
- Push-token registration now identifies `ios` versus `android` rather than hard-coding Android.
- JavaScript syntax and the iOS source verification script pass locally.

## NOT CLAIMED AS COMPLETE UNTIL APPLE CREDENTIALS ARE PROVIDED

A normal iPhone cannot install the default GitHub artifact directly because the workflow intentionally creates an **unsigned** device build. Apple signing is required for TestFlight/App Store distribution or registered-device installation.

Production iPhone push notifications also require an Apple-capable push delivery configuration. The current RKMS backend endpoint is named `rkms-fcm-push` and the uploaded source contains Android FCM configuration. Capacitor iOS registration yields an APNs token; the current JavaScript sends that value under `fcm_token`, so iOS push delivery must be changed to a Firebase Messaging/APNs-capable path before claiming background/closed-app iOS notifications are production-ready.

## Why this is the safest build design

The repository does not contain Apple private signing material. Certificates, provisioning profiles, APNs keys and passwords must not be placed in the ZIP or committed to GitHub. They should be supplied through GitHub Actions Secrets when an installable/TestFlight build is configured.
