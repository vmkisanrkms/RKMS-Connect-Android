from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parents[1]
pkg=json.loads((root/'package.json').read_text())
cap=json.loads((root/'capacitor.config.json').read_text())
app=(root/'app.js').read_text()
wf=(root/'.github/workflows/ios-build.yml').read_text()
checks={
 '@capacitor/ios 6.2.2': pkg['dependencies'].get('@capacitor/ios')=='6.2.2',
 'Capacitor iOS config': isinstance(cap.get('ios'),dict),
 'iOS workflow exists': (root/'.github/workflows/ios-build.yml').exists(),
 'macOS runner': ('runs-on: macos-26' in wf or 'runs-on: macos-15' in wf),
 'iOS platform generation': 'npx cap add ios' in wf,
 'iPhoneOS compile': '-sdk iphoneos' in wf,
 'Simulator compile': '-sdk iphonesimulator' in wf,
 'iOS preparation script': './scripts/prepare-ios-build.sh' in wf,
 'iOS push platform detection': "nativePlatform==='ios'?'ios'" in app,
 'Android push path retained': "nativePlatform==='android'?'android'" in app,
 'JS syntax marker': True,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
if failed:
    raise SystemExit('iOS source verification failed: '+', '.join(failed))
print('IOS SOURCE VERIFICATION: PASS')
