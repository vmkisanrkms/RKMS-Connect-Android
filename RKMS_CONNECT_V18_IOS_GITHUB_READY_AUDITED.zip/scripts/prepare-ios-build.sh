#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IOS_DIR="$ROOT/ios/App/App"
PLIST="$IOS_DIR/Info.plist"
ENT="$IOS_DIR/App.entitlements"
ICON_DIR="$IOS_DIR/Assets.xcassets/AppIcon.appiconset"

if [[ ! -d "$ROOT/ios/App" ]]; then
  echo "iOS platform has not been generated yet."
  exit 1
fi

/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName RKMS" "$PLIST" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string RKMS" "$PLIST"
/usr/libexec/PlistBuddy -c "Set :ITSAppUsesNonExemptEncryption false" "$PLIST" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :ITSAppUsesNonExemptEncryption bool false" "$PLIST"
/usr/libexec/PlistBuddy -c "Set :UIViewControllerBasedStatusBarAppearance true" "$PLIST" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :UIViewControllerBasedStatusBarAppearance bool true" "$PLIST"

cat > "$ENT" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>aps-environment</key>
    <string>production</string>
</dict>
</plist>
EOF

# Replace the default Capacitor icon set with the RKMS logo. The build remains
# functional even if an individual simulator icon is omitted; the complete set
# below is included for App Store validation.
mkdir -p "$ICON_DIR"
SRC="$ROOT/assets/rkms-logo-transparent.png"
if command -v sips >/dev/null 2>&1 && [[ -f "$SRC" ]]; then
  declare -a ITEMS=(
    "AppIcon-20@2x.png 40" "AppIcon-20@3x.png 60"
    "AppIcon-29@2x.png 58" "AppIcon-29@3x.png 87"
    "AppIcon-40@2x.png 80" "AppIcon-40@3x.png 120"
    "AppIcon-60@2x.png 120" "AppIcon-60@3x.png 180"
    "AppIcon-20-ipad@1x.png 20" "AppIcon-20-ipad@2x.png 40"
    "AppIcon-29-ipad@1x.png 29" "AppIcon-29-ipad@2x.png 58"
    "AppIcon-40-ipad@1x.png 40" "AppIcon-40-ipad@2x.png 80"
    "AppIcon-76-ipad@1x.png 76" "AppIcon-76-ipad@2x.png 152"
    "AppIcon-83.5-ipad@2x.png 167" "AppIcon-1024.png 1024"
  )
  for item in "${ITEMS[@]}"; do
    name="${item% *}"; size="${item##* }"
    sips -z "$size" "$size" "$SRC" --out "$ICON_DIR/$name" >/dev/null
  done
  python3 - "$ICON_DIR/Contents.json" <<'PY'
import json,sys
p=sys.argv[1]
items=[
('20','2x','AppIcon-20@2x.png','iphone'),('20','3x','AppIcon-20@3x.png','iphone'),
('29','2x','AppIcon-29@2x.png','iphone'),('29','3x','AppIcon-29@3x.png','iphone'),
('40','2x','AppIcon-40@2x.png','iphone'),('40','3x','AppIcon-40@3x.png','iphone'),
('60','2x','AppIcon-60@2x.png','iphone'),('60','3x','AppIcon-60@3x.png','iphone'),
('20','1x','AppIcon-20-ipad@1x.png','ipad'),('20','2x','AppIcon-20-ipad@2x.png','ipad'),
('29','1x','AppIcon-29-ipad@1x.png','ipad'),('29','2x','AppIcon-29-ipad@2x.png','ipad'),
('40','1x','AppIcon-40-ipad@1x.png','ipad'),('40','2x','AppIcon-40-ipad@2x.png','ipad'),
('76','1x','AppIcon-76-ipad@1x.png','ipad'),('76','2x','AppIcon-76-ipad@2x.png','ipad'),
('83.5','2x','AppIcon-83.5-ipad@2x.png','ipad'),
('1024','1x','AppIcon-1024.png','ios-marketing')]
print(json.dump({'images':[{'idiom':idiom,'size':size+'x'+size,'scale':scale,'filename':fn} for size,scale,fn,idiom in items],'info':{'author':'xcode','version':1}},open(p,'w'),indent=2))
PY
fi

echo "iOS preparation complete: $ROOT/ios"
