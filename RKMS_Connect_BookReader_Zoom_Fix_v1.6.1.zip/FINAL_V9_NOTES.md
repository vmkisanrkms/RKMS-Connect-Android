# RKMS V9 final fixes

- Android display name is RKMS.
- Flash upload now uploads each selected photo first and refuses to save a Flash without a valid public URL.
- Notification audience UI explicitly labels ALL as all members + all PDA/officers + National President + Super Admin.
- Notification attachment upload remains supported for PDF/JPG/PNG/WEBP/DOC/DOCX.
- GitHub workflow extracts the single RKMS ZIP, verifies the Android project and app name, and builds the debug APK.

Important: the live Supabase database/FCM routing must remain configured so publishing an order/notice creates recipients for all intended accounts.

## Location Dropdown Reliability Fix — v1.5
- Location dropdown RPCs now use the public Supabase key instead of a potentially stale authenticated JWT.
- Each location request retries up to 3 times for transient/weak-network failures.
- State dropdown shows an explicit loading state instead of appearing silently empty.
- Membership screen waits for the initial State list before presenting the form as ready.
- Cascading State → Mandal → District → Tehsil → Block → Village loads now have guarded error states and retry-friendly behavior.
- Android app version bumped to 1.5 (versionCode 5).
