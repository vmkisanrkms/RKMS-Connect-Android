RKMS CHAT COMPOSER/NAV FINAL FIX — 2026-09-20
Fixed: conversation viewport now subtracts site header + bottom nav when keyboard closed; header only when keyboard open.
Composer remains in normal flex flow; bottom nav hidden during keyboard.
