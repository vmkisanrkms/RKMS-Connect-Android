package org.rkms.connect;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public final class NotificationHelper {
    public static final String CHANNEL_ID = "rkms_updates";
    private NotificationHelper() {}

    public static void show(Context context, String title, String body) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        int id = (int) (System.currentTimeMillis() & 0x7fffffff);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "RKMS Connect" : title)
                .setContentText(body == null ? "नई सूचना" : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "नई सूचना" : body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);
        NotificationManagerCompat.from(context).notify(id, b.build());
    }
}
