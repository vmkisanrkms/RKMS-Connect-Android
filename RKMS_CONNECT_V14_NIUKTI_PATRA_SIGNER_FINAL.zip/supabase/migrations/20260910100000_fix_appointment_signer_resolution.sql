-- RKMS CONNECT: robust नियुक्तिकर्ता name/post/signature resolution.
-- Fixes appointment letters where appointed_by_officer_id is unavailable but
-- appointing_authority_name already contains the appointing officer's name.

create or replace function public.rkms_get_digital_id_meta(p_member_id uuid)
returns jsonb language plpgsql stable security definer set search_path to 'public','pg_catalog' as $$
declare
 v_member_id uuid;
 v_national_name text;
 v_national_post text;
 v_national_signature text;
 v_officer_id uuid;
 v_appointed_by uuid;
 v_appointing_authority text;
 v_appointed_name text;
 v_appointed_post text;
 v_appointed_signature text;
 v_authority_norm text;
begin
 v_member_id:=public.rkms_current_member_id();
 if v_member_id is null or p_member_id<>v_member_id then
   return jsonb_build_object('success',false,'message','इस member की Digital ID देखने की अनुमति नहीं है।');
 end if;

 select coalesce(l.name,'श्री V. M. Singh'),coalesce(l.post_name,'राष्ट्रीय अध्यक्ष')
 into v_national_name,v_national_post
 from public.rkms_leadership l
 where upper(coalesce(l.level,''))='NATIONAL'
   and upper(coalesce(l.status,'ACTIVE'))='ACTIVE'
 order by l.display_order nulls last,l.created_at asc limit 1;

 select o.signature_url
 into v_national_signature
 from public.rkms_officers o
 left join public.rkms_posts p on p.id=o.post_id
 where o.status='ACTIVE'
   and upper(coalesce(o.authority_level,p.level,''))='NATIONAL'
   and nullif(trim(coalesce(o.signature_url,'')),'') is not null
 order by o.created_at desc limit 1;

 select o.id,o.appointed_by_officer_id,o.appointing_authority_name
 into v_officer_id,v_appointed_by,v_appointing_authority
 from public.rkms_officers o
 where o.member_id=v_member_id and o.status='ACTIVE'
   and (o.valid_from is null or o.valid_from<=current_date)
   and (o.valid_to is null or o.valid_to>=current_date)
 order by o.created_at desc limit 1;

 -- Normal case: the appointment stores the exact appointing officer id.
 if v_appointed_by is not null then
   select m.name,p.post_name,o.signature_url
   into v_appointed_name,v_appointed_post,v_appointed_signature
   from public.rkms_officers o
   join public.rkms_members m on m.id=o.member_id
   left join public.rkms_posts p on p.id=o.post_id
   where o.id=v_appointed_by;
 end if;

 v_authority_norm:=lower(trim(coalesce(v_appointing_authority,'')));

 -- Recovery case: older appointment records may contain the appointing
 -- officer's name but not appointed_by_officer_id. Resolve that name against
 -- ACTIVE officer records so the letter still shows name/post/signature.
 if v_appointed_by is null
    and v_authority_norm not in ('','राष्ट्रीय अध्यक्ष','national president','super admin','super_admin') then
   -- Older rows may have the signer name in appointing_authority_name but no
   -- appointed_by_officer_id. Resolve against ALL officer history (not only
   -- ACTIVE), because an officer can later be removed/reappointed while the
   -- old appointment letter must continue to show the original signer.
   select o.member_id,m.name,p.post_name,o.signature_url,o.id
   into v_appointed_by,v_appointed_name,v_appointed_post,v_appointed_signature,v_officer_id
   from public.rkms_officers o
   join public.rkms_members m on m.id=o.member_id
   left join public.rkms_posts p on p.id=o.post_id
   where lower(trim(m.name))=v_authority_norm
      or lower(trim(coalesce(m.name,''))) like '%'||v_authority_norm||'%'
      or v_authority_norm like '%'||lower(trim(coalesce(m.name,'')))||'%'
   order by
      case when nullif(trim(coalesce(o.signature_url,'')),'') is not null then 0 else 1 end,
      case when o.status='ACTIVE' then 0 else 1 end,
      o.created_at desc
   limit 1;
 end if;

 -- National President / Super Admin appointments must show only the
 -- National President authority block, as required by the final layout rule.
 if v_appointed_by is null and v_authority_norm in ('राष्ट्रीय अध्यक्ष','national president','super admin','super_admin') then
   return jsonb_build_object(
     'success',true,
     'national_president_name',coalesce(v_national_name,'श्री V. M. Singh'),
     'national_president_post',coalesce(v_national_post,'राष्ट्रीय अध्यक्ष'),
     'national_president_signature_url',coalesce(v_national_signature,''),
     'appointing_officer_name','',
     'appointing_officer_post','',
     'appointing_officer_signature_url','',
     'appointment_authority_type','NATIONAL_PRESIDENT'
   );
 end if;

 return jsonb_build_object(
   'success',true,
   'national_president_name',coalesce(v_national_name,'श्री V. M. Singh'),
   'national_president_post',coalesce(v_national_post,'राष्ट्रीय अध्यक्ष'),
   'national_president_signature_url',coalesce(v_national_signature,''),
   'appointing_officer_name',coalesce(v_appointed_name,''),
   'appointing_officer_post',coalesce(v_appointed_post,''),
   'appointing_officer_signature_url',coalesce(v_appointed_signature,''),
   'appointment_authority_type',case when v_appointed_by is not null then 'OFFICER' else 'NONE' end
 );
end; $$;
