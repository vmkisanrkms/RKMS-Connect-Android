# RKMS FCM backend

Deploy `rkms-fcm-push/index.ts` to the existing Supabase Edge Function named `rkms-fcm-push`.
The function expects the existing `FIREBASE_SERVICE_ACCOUNT` secret and Supabase service-role environment.
It sends Android HIGH-priority data-only FCM messages so the Android app's own notification service controls channel, sound, vibration and tap routing.
