RKMS Connect V8 Integrated Fix

UPLOAD STRUCTURE
================
Extract this ZIP before uploading to GitHub. Upload the contents so the repository root contains:

.github/workflows/build-apk.yml
rkms_android/settings.gradle
rkms_android/app/build.gradle

Do NOT upload this ZIP as the only repository source if you want GitHub Actions to see the workflow.

This build includes Android notification channel v2, sound/vibration/lock-screen visibility, notification tap route handling, native session bootstrap, FCM data-only backend source, and automatic Android project discovery.

IMPORTANT
=========
After installing the new APK, Android may still have an older RKMS notification channel from an older installation. This version intentionally uses rkms_notifications_v2.

The Supabase Edge Function source is in backend/rkms-fcm-push/. Deploy it to the existing rkms-fcm-push function before testing background/closed-app FCM.
