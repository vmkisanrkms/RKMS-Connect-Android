package org.rkms.connect;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class RKMSFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        try {
            String accessToken = SessionStore.access(getApplicationContext());
            if (accessToken != null && !accessToken.isEmpty()) {
                FCMTokenRegistrar.registerWithToken(
                        getApplicationContext(),
                        accessToken,
                        token
                );
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        super.onMessageReceived(message);

        String title = "RKMS Connect";
        String body = "";

        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) {
                title = message.getNotification().getTitle();
            }
            if (message.getNotification().getBody() != null) {
                body = message.getNotification().getBody();
            }
        }

        Map<String, String> data = message.getData();
        if (data.containsKey("title") && data.get("title") != null) {
            title = data.get("title");
        }
        if (data.containsKey("body") && data.get("body") != null) {
            body = data.get("body");
        }
        if (body.isEmpty() && data.containsKey("message") && data.get("message") != null) {
            body = data.get("message");
        }

        NotificationHelper.show(getApplicationContext(), title, body);
    }
}
