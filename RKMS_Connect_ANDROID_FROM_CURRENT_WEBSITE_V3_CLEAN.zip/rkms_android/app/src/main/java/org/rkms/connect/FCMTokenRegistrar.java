package org.rkms.connect;

import android.content.Context;

import com.google.firebase.messaging.FirebaseMessaging;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class FCMTokenRegistrar {
    private FCMTokenRegistrar() {}

    public static void register(Context context, String accessToken) {
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token ->
                        registerWithToken(context, accessToken, token));
    }

    public static void registerWithToken(Context context, String accessToken, String token) {
        if (accessToken == null || accessToken.isEmpty() ||
                token == null || token.isEmpty()) return;

        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(
                        "https://kzczivaydandiqgnzfeg.supabase.co/functions/v1/rkms-fcm-push"
                );
                c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Authorization", "Bearer " + accessToken);

                String body = "{\"action\":\"register\",\"token\":\"" +
                        token.replace("\\", "\\\\").replace("\"", "\\\"") +
                        "\"}";

                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                c.getOutputStream().write(bytes);
                c.getOutputStream().flush();
                c.getOutputStream().close();
                c.getResponseCode();
            } catch (IOException ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    public static void unregister(Context context, String accessToken) {
        // Token cleanup is handled server-side on token invalidation.
    }
}
